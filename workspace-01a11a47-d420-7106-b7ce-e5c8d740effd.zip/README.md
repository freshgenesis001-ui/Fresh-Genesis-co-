# Fresh Genesis — workspace

## book/  — AI Made Simple for Nigerian Small-Business Owners (Book 1)
- `PDF/AI-Made-Simple-Nigerian-Small-Business-Owners.pdf` — final book (131 pages)
- `cover/cover.png` (1600×2400) · `cover/cover-art.png`
- `library/Prompt-Library.html|.txt` — all 120 prompts with copy buttons (send to buyers)
- `sample/3-AI-Prompts-…-FREE-SAMPLE.pdf` — 8-page lead magnet
- `LISTING-AND-LAUNCH-KIT.md` — pricing, listing copy, FAQ, launch messages, Quick Replies, upload checklist
- `SERIES-PLAN-AI-Made-Simple-v2.md` — Books 1–7 plan
- `00…09-*.md` — manuscript sources · `build/` — PDF + extras build scripts (see book/README.md)

## simplifyai-site/  — the live site (freshgenesiscopresents.netlify.app), fixed
- Drop `simplifyai-site-deploy.zip` on https://app.netlify.com/drop to update the live site
- Pages: index · business-book (new) · sales · faq · thank-you · refund-policy · privacy · terms · free/ sample PDF
- `assets/config.js` — payment links, prices, WhatsApp · `_build/patch.py` — rebuild script

## fresh-genesis-website/  — earlier standalone site (backup)
- `index.html`, `sales.html` self-contained; `PDFs/`; `LIVE-SITE-REVIEW-SimplifyAI.md` (the critique of the live site)

## Payment links
Paystack https://paystack.shop/pay/7eipl558t6 (also /pay/Freshgenesisco) · Flutterwave USD https://flutterwave.com/pay/nahf6maetqjs · Bizflex https://www.bizflex.com.ng/store/blessing-ukwuoma · WhatsApp +234 902 190 6332
