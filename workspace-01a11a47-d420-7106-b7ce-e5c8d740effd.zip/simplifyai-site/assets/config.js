window.FRESH_GENESIS_CONFIG = {
  brand: "Fresh Genesis",
  supportWhatsApp: "2349021906332",
  supportEmail: "freshgenesisco@gmail.com",

  // Free Quick Start: leave empty to deliver via WhatsApp ("START" message).
  // Or paste your Selar free-product URL to deliver by email instead.
  freeGuideUrl: "",

  paymentLinks: {
    paystack: "https://paystack.shop/pay/Freshgenesisco",
    flutterwave: "https://flutterwave.com/pay/nahf6maetqjs",
    bizflexStore: "https://www.bizflex.com.ng/store/blessing-ukwuoma"
  },

  prices: {
    foundationsPack: { ngn: "₦7,500", usd: "$12" },
    completeSystem: { ngn: "₦15,000", usd: "$15" },
    businessBook: { ngn: "₦5,000", usd: "$7" },
    foundations: { ngn: "₦4,000", usd: "$7" },
    practiceLab: { ngn: "₦3,000", usd: "$5" },
    promptVault: { ngn: "₦4,000", usd: "$7" },
    weeklyReset: { ngn: "₦4,000", usd: "$7" },
    weeklyPlanner: { ngn: "₦4,000", usd: "$7" },
    clarityLife: { ngn: "₦5,000", usd: "$9" }
  }
};
