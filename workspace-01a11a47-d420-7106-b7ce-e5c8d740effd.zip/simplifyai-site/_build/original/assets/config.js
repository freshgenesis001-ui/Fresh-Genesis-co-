window.FRESH_GENESIS_CONFIG = {
  brand: "Fresh Genesis Co SimplifyAI",
  supportWhatsApp: "2349021906332",
  supportEmail: "Freshgenesisco@gmail.com",

  // Add the URL of your free Selar product after creating it.
  // Selar will collect the subscriber's email and deliver Quick Start.
  freeGuideUrl: "",

  paymentLinks: {
    paystack: "https://paystack.shop/pay/Freshgenesisco",
    flutterwave: "https://flutterwave.com/pay/nahf6maetqjs",
    bizflexStore: "https://www.bizflex.com.ng/store/blessing-ukwuoma"
  },

  prices: {
    foundationsPack: { ngn: "₦7,500", usd: "$12" },
    completeSystem: { ngn: "₦15,000", usd: "$25" },
    foundations: { ngn: "₦4,000", usd: "$7" },
    practiceLab: { ngn: "₦3,000", usd: "$5" },
    promptVault: { ngn: "₦4,000", usd: "$7" },
    weeklyReset: { ngn: "₦4,000", usd: "$7" },
    weeklyPlanner: { ngn: "₦4,000", usd: "$7" },
    clarityLife: { ngn: "₦5,000", usd: "$9" }
  }
};
