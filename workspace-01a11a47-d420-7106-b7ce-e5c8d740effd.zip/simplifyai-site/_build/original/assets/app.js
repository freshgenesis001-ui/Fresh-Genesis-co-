(function(){
  const cfg=window.FRESH_GENESIS_CONFIG||{};
  const $=(s,r=document)=>r.querySelector(s);
  const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));

  const year=$('#year'); if(year) year.textContent=new Date().getFullYear();
  const menuBtn=$('#menuToggle'); const mobile=$('#mobileMenu');
  if(menuBtn&&mobile){
    menuBtn.addEventListener('click',()=>{const open=mobile.classList.toggle('open');menuBtn.setAttribute('aria-expanded',String(open));menuBtn.textContent=open?'×':'☰';});
    $$('a',mobile).forEach(a=>a.addEventListener('click',()=>{mobile.classList.remove('open');menuBtn.setAttribute('aria-expanded','false');menuBtn.textContent='☰';}));
  }

  const toast=$('#toast'); let toastTimer;
  function showToast(msg){if(!toast)return;toast.textContent=msg;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),3200);}

  const freeUrl=(cfg.freeGuideUrl||'').trim();
  $$('[data-free-guide]').forEach(link=>{
    if(freeUrl){link.href=freeUrl;link.target='_blank';link.rel='noopener';}
    else{link.href='#';link.addEventListener('click',e=>{e.preventDefault();showToast('Add your Selar free-product link in assets/config.js before launch.');});}
  });

  const modal=$('#payModal');
  const payTitle=$('#payTitle'); const payPrice=$('#payPrice');
  const payPaystack=$('#payPaystack'); const payFlutterwave=$('#payFlutterwave'); const payBizflex=$('#payBizflex'); const payWhatsApp=$('#payWhatsApp');
  function closeModal(){if(!modal)return;modal.hidden=true;document.body.style.overflow='';}
  function openModal(btn){
    if(!modal)return;
    const product=btn.dataset.product||'Fresh Genesis Co SimplifyAI product';
    const ngn=btn.dataset.ngn||''; const usd=btn.dataset.usd||'';
    payTitle.textContent=product; payPrice.textContent=[ngn,usd].filter(Boolean).join(' / ');
    if(payPaystack) payPaystack.href=cfg.paymentLinks?.paystack||'#';
    if(payFlutterwave) payFlutterwave.href=cfg.paymentLinks?.flutterwave||'#';
    if(payBizflex) payBizflex.href=cfg.paymentLinks?.bizflexStore||'#';
    if(payWhatsApp){
      const msg=`Hello Fresh Genesis Co. I want to order ${product} (${ngn}${ngn&&usd?' / ':''}${usd}). Please send the payment and delivery instructions.`;
      payWhatsApp.href=`https://wa.me/${cfg.supportWhatsApp}?text=${encodeURIComponent(msg)}`;
    }
    modal.hidden=false;document.body.style.overflow='hidden';$('.modal-close',modal)?.focus();
  }
  $$('[data-buy]').forEach(btn=>btn.addEventListener('click',e=>{e.preventDefault();openModal(btn);}));
  $$('[data-modal-close]').forEach(el=>el.addEventListener('click',closeModal));
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});

  $$('.whatsapp-support').forEach(a=>{a.href=`https://wa.me/${cfg.supportWhatsApp}?text=${encodeURIComponent('Hello Fresh Genesis Co. I need help with SimplifyAI.')}`;a.target='_blank';a.rel='noopener';});
  $$('.support-email').forEach(a=>{
    if(cfg.supportEmail){a.href=`mailto:${cfg.supportEmail}`;a.textContent=cfg.supportEmail;}
    else a.hidden=true;
  });
})();
