#!/usr/bin/env python3
"""Apply the review fixes to the SimplifyAI site. Run from /home/user/simplifyai-site:
   python3 _build/patch.py
Reads the original live-site files from _build/original/ and writes fixed pages to the site root."""
import re, os, shutil
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

WA = "2349021906332"
PAGES = ["index.html", "sales.html", "faq.html", "thank-you.html", "refund-policy.html", "privacy.html", "terms.html"]

def read(p): return open(os.path.join("_build/original", p), encoding="utf-8").read()
def write(p, s): open(p, "w", encoding="utf-8").write(s)

# ---------- global fixes applied to every page ----------
def global_fix(s):
    # Netlify comment + badge script
    s = re.sub(r"<!-- This site is hosted on Netlify\..*?-->", "", s, flags=re.S)
    s = re.sub(r'<script async src="/\.netlify/scripts/hud[^>]*></script>\s*', "", s)
    # Brand naming
    s = s.replace("Fresh Genesis Co presents SimplifyAI.", "SimplifyAI by Fresh Genesis.")
    s = s.replace("Fresh Genesis Co presents SimplifyAI", "SimplifyAI by Fresh Genesis")
    s = s.replace("Fresh Genesis Co SimplifyAI", "Fresh Genesis · SimplifyAI")
    s = s.replace("Fresh Genesis Co", "Fresh Genesis")
    s = s.replace("Freshgenesisco@gmail.com", "freshgenesisco@gmail.com")
    s = s.replace("Hello%20Fresh%20Genesis%20Co.", "Hello%20Fresh%20Genesis.")
    # Vol. 1 / Volume 1
    s = s.replace(" — Vol. 1", "").replace(" — Volume 1", "").replace(" Volume 1", "")
    # Developer notes
    s = s.replace('<p class="form-note">Before launch, connect your Selar free-product URL in <code>assets/config.js</code>.</p>',
                  '<p class="form-note">Sent instantly to your WhatsApp — or by email if you prefer.</p>')
    s = s.replace("<p>Use the exact price shown above. Product-specific fixed-price links should replace these general links before public launch.</p>",
                  "<p>Enter the exact amount shown above on the payment page. Your file is delivered to your WhatsApp or email as soon as payment is confirmed.</p>")
    s = s.replace("Files are delivered digitally after payment confirmation. Automatic delivery should be configured in your checkout platform before the site is publicly launched.",
                  "Instantly by download link, or to your WhatsApp/email within minutes of payment confirmation during business hours (8am–9pm WAT).")
    s = s.replace("The intended delivery method is a free Selar product. Selar collects the email address and sends the PDF. The Selar URL must be connected before launch.",
                  "Tap the button and send us “START” on WhatsApp — the PDF arrives in the chat. Prefer email? Say so in the message and we’ll send it there.")
    s = s.replace("Paid products are delivered digitally after payment confirmation. Product-specific checkout and delivery automation should be configured before the public launch.",
                  "Paid products are delivered digitally after payment confirmation — by download link, WhatsApp or email, usually within minutes during business hours.")
    s = s.replace("Visit the delivery-help page or contact Fresh Genesis through WhatsApp with your transaction reference.",
                  'Visit the <a href="/thank-you">delivery-help page</a> or <a class="whatsapp-support" href="#">contact us on WhatsApp</a> with your transaction reference.')
    s = s.replace("Review the Refund Policy for exceptions", 'Review the <a href="/refund-policy">Refund Policy</a> for exceptions')
    # Vague AI-tool phrasing
    s = s.replace("No specific paid AI service is required. You can apply the methods with a reputable chat-based AI tool available to you, subject to that service’s limits and terms.",
                  "No. Everything works with free tools — Meta AI inside WhatsApp, ChatGPT (free), Gemini or DeepSeek.")
    s = s.replace("No specific service is required. Apply the methods with a reputable chat-based AI tool available to you and follow its current terms and privacy controls.",
                  "No. Meta AI inside WhatsApp, ChatGPT (free), Gemini or DeepSeek all work. Follow the tool’s privacy settings and don’t paste sensitive personal data.")
    # Draft/launch notices on legal pages
    s = re.sub(r'<p class="notice"><strong>Important:</strong> These terms are a practical website draft.*?</p>', '', s)
    s = re.sub(r'<p class="notice"><strong>Launch note:</strong>.*?</p>', '', s)
    s = s.replace("Automatic delivery should be used where available. ", "")
    # Relative .html links (work on Netlify Drop and locally)
    for slug in ["sales","faq","thank-you","refund-policy","privacy","terms","business-book"]:
        s = re.sub(rf"href=(['\"])/{slug}(#[^'\"]*)?\1", rf"href=\1{slug}.html\2\1", s)
    s = re.sub(r"href=(['\"])/(#[^'\"]*)?\1", r"href=\1index.html\2\1", s)
    # Trust footer line
    s = s.replace('<p>Clear, calm, practical AI and planning tools for complete beginners.</p>',
                  '<p>Plain-English AI guides and planners for Nigerians who want to work smarter.</p><p class="micro" style="margin-top:10px;color:#cfe3d5">Secure payments via Paystack &amp; Flutterwave · WhatsApp support · Instant digital delivery</p>')
    s = s.replace("Clear, calm, practical AI and planning tools for complete beginners.", "Plain-English AI guides and planners for Nigerians who want to work smarter.")
    return s

# ---------- INDEX ----------
idx = global_fix(read("index.html"))
idx = idx.replace("<title>Fresh Genesis · SimplifyAI | Beginner-Friendly AI Workflows and Planning Tools</title>",
                  "<title>SimplifyAI — Learn to Use AI in Plain English | Fresh Genesis</title>")
idx = re.sub(r'<meta name="description" content="[^"]*">',
             '<meta name="description" content="Learn to use AI properly in 7 days, then apply it to your work: SimplifyAI guides and planners, plus AI Made Simple for Nigerian Small-Business Owners — 120 prompts, 15 tools. From Fresh Genesis.">', idx)
idx = idx.replace('<div class="announcement">Launch pricing is now available. <strong>Clear guidance. Practical workflows. Beginner-first design.</strong></div>',
                  '<div class="announcement">New: <strong>AI Made Simple for Nigerian Small-Business Owners</strong> — 120 prompts + 15 tools. Launch price ₦5,000 / $7 for 14 days. <a href="/business-book" style="color:inherit;text-decoration:underline">See the book →</a></div>')
# Hero
idx = idx.replace('<h1>Use AI confidently. Build useful workflows. Plan a <span class="text-green">calmer week.</span></h1>',
                  '<h1>Learn to use AI properly in 7 days — then use it to <span class="text-green">write, plan, sell and decide faster.</span></h1>')
idx = idx.replace('<p class="lead">A beginner-friendly system that helps you understand AI, practise safely, use 96 practical prompts, and organize your priorities—without technical jargon or information overload.</p>',
                  '<p class="lead">Plain-English guides, copy-paste prompts and planners for busy Nigerians — no laptop, no jargon. Start with the free 7-day Quick Start, learn the basics with SimplifyAI, then apply it to your work with the <em>AI Made Simple</em> books.</p>')
idx = idx.replace('<div class="cta-row"><a class=\'btn btn-primary\' href=\'/sales\'>Explore the complete system</a><a class="btn btn-secondary" href="#free-guide">Start free for 7 days</a></div>',
                  '<div class="cta-row"><a class="btn btn-primary" href="#offers">Choose your path</a><a class="btn btn-secondary" href="#free-guide">Start free for 7 days</a></div>')
idx = idx.replace('<div class="trust-row"><span>Seven connected resources</span><span>104 customer-ready pages</span><span>Human-review checkpoints</span><span>Digital delivery after confirmation</span></div>',
                  '<div class="trust-row"><span>8 PDFs · 235 pages</span><span>216 copy-paste prompts</span><span>Works with Meta AI on WhatsApp</span><span>Instant download · Pay in ₦ or $</span></div>')
idx = idx.replace('<div class="hero-card-top"><span class="pill">Complete Starter System</span><span class="pill price-pill">₦15,000 / $25</span></div>',
                  '<div class="hero-card-top"><span class="pill">New · Business eBook</span><span class="pill price-pill">₦5,000 / $7 launch</span></div>')
idx = idx.replace('<img src="assets/covers/complete-system.jpg" alt="SimplifyAI Complete Starter System cover">',
                  '<img src="assets/covers/ai-made-simple.jpg" alt="AI Made Simple for Nigerian Small-Business Owners cover">')
idx = idx.replace("<a class='btn btn-accent btn-full' href='/sales'>See everything included</a>\n      <p class=\"micro\">Launch price. Seven PDFs plus a 104-page all-in-one edition.</p>",
                  "<a class='btn btn-accent btn-full' href='/business-book'>See what's inside the book</a>\n      <p class=\"micro\">131 pages · 120 prompts with real Nigerian examples · 15 ready-to-use tools · 90-day plan.</p>")
# Offers: three paths
offers_old_start = idx.index('<section class="section section-white" id="offers">')
offers_old_end = idx.index('</section>', offers_old_start) + len('</section>')
offers_new = '''<section class="section section-white" id="offers">
  <div class="container">
    <div class="section-head"><span class="kicker">Choose your path</span><h2>Where are you starting from?</h2><p>Three ways in. Every option works on a phone with the free AI tools you already have.</p></div>
    <div class="offer-grid">
      <article class="offer-card">
        <span class="tag">Free</span><h3>I want a free start</h3><p><strong>SimplifyAI Quick Start</strong> — a 7-day checklist to complete your first useful AI task, with review steps so you can trust the result.</p>
        <ul class="offer-list"><li>10–15 minutes a day for 7 days</li><li>Prompt → review → refine → save</li><li>Sent to your WhatsApp or email</li><li>No card, no account</li></ul>
        <div class="price"><strong>Free</strong><span>WhatsApp or email</span></div>
        <a class="btn btn-secondary btn-full" href="#" data-free-guide>Get Quick Start free</a>
      </article>
      <article class="offer-card featured">
        <span class="tag">Most popular</span><h3>I run a small business</h3><p><strong>AI Made Simple for Nigerian Small-Business Owners</strong> — 120 copy-paste prompts with a real Naija example and tip for each, plus 15 business tools and a 90-day plan.</p>
        <ul class="offer-list"><li>Customers · marketing · sales · costs · new income · finance</li><li>Daily sales sheet, NEPA calculator, 60 Status hooks, 40 follow-ups</li><li>Works in Meta AI on WhatsApp</li><li>131-page PDF</li></ul>
        <div class="price"><strong>₦5,000</strong><span>/ $7 launch</span></div><p class="saving">Launch price for 14 days, then ₦7,500 / $9.</p>
        <button class="btn btn-accent btn-full" data-buy data-product="AI Made Simple for Nigerian Small-Business Owners" data-ngn="₦5,000" data-usd="$7">Get the book</button>
        <p class="micro" style="text-align:center;margin-top:10px"><a href="/business-book">Full details &amp; contents →</a></p>
      </article>
      <article class="offer-card">
        <span class="tag">All 7</span><h3>I want to learn AI properly</h3><p><strong>SimplifyAI Complete Starter System</strong> — all seven guides and planners: understand AI, practise safely, 96 prompts, and a calmer weekly rhythm.</p>
        <ul class="offer-list"><li>Foundations, Practice Lab, Prompt Vault</li><li>Weekly Reset, two planners, Quick Start</li><li>104-page all-in-one edition included</li><li>Print-ready planner pages</li></ul>
        <div class="price"><strong>₦15,000</strong><span>/ $15</span></div><p class="saving">Less than buying the seven separately.</p>
        <button class="btn btn-primary btn-full" data-buy data-product="SimplifyAI Complete Starter System" data-ngn="₦15,000" data-usd="$15">Get the complete system</button>
        <p class="micro" style="text-align:center;margin-top:10px"><a href="/sales">See everything included →</a></p>
      </article>
    </div>
  </div>
</section>

<section class="section section-soft" id="proof">
  <div class="container">
    <div class="section-head"><span class="kicker">Who made this</span><h2>Built by a Nigerian small-business owner, for Nigerian small-business owners</h2><p>Fresh Genesis is run by Blessing — a Nigerian entrepreneur who sells online, uses WhatsApp for business every day, and learned to put AI to work without a laptop or a tech background. Every guide is tested on real work: writing Status posts, answering “last price?”, tracking cash, planning the week.</p></div>
    <div class="steps">
      <article class="step"><div class="step-num">₦</div><h3>Pay the way you already pay</h3><p>Paystack (card, transfer, USSD) for naira. Flutterwave for international cards. Or order on WhatsApp and pay by transfer.</p></article>
      <article class="step"><div class="step-num">→</div><h3>Delivered to your phone</h3><p>Download link on payment, plus the PDF sent to your WhatsApp or email. No app to install.</p></article>
      <article class="step"><div class="step-num">✓</div><h3>Honest about AI</h3><p>Every guide teaches you to check important answers. No “AI will make you rich” promises — just faster, better work.</p></article>
    </div>
  </div>
</section>'''
idx = idx[:offers_old_start] + offers_new + idx[offers_old_end:]
# Library: remove page counts, replace meta with role phrases
roles = {
  "quick-start": "Start here · 7 days",
  "foundations": "Understand AI · Beginner guide",
  "practice-lab": "Learn by doing · 6 modules",
  "prompt-vault": "96 prompts · 12 categories",
  "weekly-reset": "Plan a calmer week · 6 lessons",
  "weekly-planner": "Reusable planner · Print-ready",
  "clarity-life": "Goals, habits &amp; 90-day reviews",
}
def fix_card(m):
    card = m.group(0)
    key = re.search(r'covers/([a-z-]+)\.jpg', card).group(1)
    card = re.sub(r'<div class="product-meta">.*?</div>', f'<div class="product-meta"><span>{roles.get(key,"")}</span></div>', card)
    return card
idx = re.sub(r'<article class="product-card">.*?</article>', fix_card, idx, flags=re.S)
idx = idx.replace('<div class="section-head"><span class="kicker">Individual product library</span><h2>Buy only the resource you need</h2><p>Every product has a specific role. The numbered order is recommended for complete beginners.</p></div>',
                  '<div class="section-head"><span class="kicker">SimplifyAI individual library</span><h2>Or buy only the guide you need</h2><p>Each product does one job. The numbered order is the recommended path if you are new to AI.</p></div>')
idx = idx.replace('<a class="btn btn-secondary btn-full" href="#" data-free-guide>Get by email</a>', '<a class="btn btn-secondary btn-full" href="#" data-free-guide>Get it free</a>')
# Business book feature section (before How the system works)
book_section = '''<section class="section section-white" id="business-book">
  <div class="container free-panel">
    <img src="assets/covers/ai-made-simple.jpg" alt="AI Made Simple for Nigerian Small-Business Owners cover" style="max-width:340px;margin:auto">
    <div><span class="kicker">New from Fresh Genesis</span><h2>AI Made Simple for Nigerian Small-Business Owners</h2><p>For the salon owner, the POS agent, the fashion seller, the buka, the provisions shop, the farmer. 120 prompts you copy, fill the [brackets], and paste into Meta AI on WhatsApp — each with a real Nigerian example and a Naija tip.</p>
    <ul class="offer-list"><li><strong>Part 1–6:</strong> know your customer · market for free · close “last price” · cut costs 35% · add new income · keep your profit</li><li><strong>15 tools:</strong> 90-Day Revenue Tracker, Daily Sales Sheet, NEPA &amp; Generator Calculator, 60 Status hooks, 40 follow-up messages, Referral Card, Proposal Template, Risk Matrix</li><li><strong>90-Day Action Plan</strong> — week by week</li></ul>
    <div class="cta-row"><button class="btn btn-accent" data-buy data-product="AI Made Simple for Nigerian Small-Business Owners" data-ngn="₦5,000" data-usd="$7">Get the book — ₦5,000 / $7</button><a class="btn btn-secondary" href="/business-book">Read the full contents</a></div>
    <p class="micro">Launch price for 14 days, then ₦7,500 / $9 · 131-page PDF · Instant delivery</p></div>
  </div>
</section>

<section class="section section-soft">'''
idx = idx.replace('<section class="section section-soft">\n  <div class="container">\n    <div class="section-head"><span class="kicker">How the system works</span>', book_section + '\n  <div class="container">\n    <div class="section-head"><span class="kicker">How the system works</span>', 1)
idx = idx.replace('<h2>Learn, practise, organize and improve</h2></div>', '<h2>Learn the skill once. Apply it everywhere.</h2><p>SimplifyAI teaches you how to use AI well. The <em>AI Made Simple</em> books apply it to your specific work.</p></div>')
# Free guide section copy
idx = idx.replace('<li>Delivered to your email through Selar</li>', '<li>Sent to your WhatsApp (or email) in minutes</li>')
idx = idx.replace('<li>Delivered through Selar email signup</li>', '<li>Sent to your WhatsApp or email</li>')
# Home FAQ: positive first, honest lower
faq_start = idx.index('<div class="faq-list">'); faq_end = idx.index('</div>', faq_start) + 6
idx = idx[:faq_start] + '''<div class="faq-list">
    <details class="faq-item" open><summary>Do I need a laptop or a paid AI account?</summary><p>No. Everything works on a phone with free tools — Meta AI inside WhatsApp, ChatGPT (free), Gemini or DeepSeek.</p></details>
    <details class="faq-item"><summary>I run a small business. Where should I start?</summary><p>Start with <a href="/business-book">AI Made Simple for Nigerian Small-Business Owners</a>. It assumes you have never used AI and goes straight to your customers, sales, costs and money. Add SimplifyAI later if you want the general foundations.</p></details>
    <details class="faq-item"><summary>How do I pay and how do I get the file?</summary><p>Paystack (card, transfer, USSD) for naira; Flutterwave for international cards; or order on WhatsApp and pay by transfer. You get a download link on payment, and we also send the PDF to your WhatsApp or email — usually within minutes during business hours.</p></details>
    <details class="faq-item"><summary>Is this suitable for someone who has never used AI?</summary><p>Yes. Quick Start and Foundations begin with basic concepts and low-risk practice tasks. The business book shows you exactly what to type, with a filled-in example every time.</p></details>
    <details class="faq-item"><summary>Does AI always give accurate answers?</summary><p>No. AI can make mistakes. Every guide teaches you to check important answers — especially anything about money, law, health or tax.</p></details>
  </div>''' + idx[faq_end:]
# Nav
idx = idx.replace('<nav class="main-nav" aria-label="Primary navigation"><a class=\'active\' href=\'/\'>Home</a><a href="#offers">Offers</a><a href="#library">Product Library</a><a href=\'/sales\'>Complete System</a><a href=\'/faq\'>FAQ</a></nav>',
                  '<nav class="main-nav" aria-label="Primary navigation"><a class=\'active\' href=\'/\'>Home</a><a href="/business-book">Business Book</a><a href=\'/sales\'>SimplifyAI System</a><a href="#library">Library</a><a href=\'/faq\'>FAQ</a></nav>')
idx = idx.replace('<a class="btn btn-primary btn-small" href="#offers">Choose your starting point</a>', '<a class="btn btn-primary btn-small" href="#offers">Choose your path</a>')
idx = idx.replace('<nav class="mobile-menu" id="mobileMenu" aria-label="Mobile navigation"><a href=\'/\'>Home</a><a href="#offers">Offers</a><a href="#library">Product Library</a><a href=\'/sales\'>Complete System</a><a href=\'/faq\'>FAQ</a><a href="#free-guide">Free Quick Start</a></nav>',
                  '<nav class="mobile-menu" id="mobileMenu" aria-label="Mobile navigation"><a href=\'/\'>Home</a><a href="/business-book">Business Book</a><a href=\'/sales\'>SimplifyAI System</a><a href="#library">Library</a><a href=\'/faq\'>FAQ</a><a href="#free-guide">Free Quick Start</a></nav>')
idx = idx.replace('<li><a href="#offers">Featured offers</a></li>', '<li><a href="/business-book">Business book</a></li>')
write("index.html", idx)

# ---------- SALES ----------
sal = global_fix(read("sales.html"))
sal = sal.replace("₦15,000 / $25", "₦15,000 / $15").replace("/ $25 launch price", "/ $15 launch price").replace('data-usd="$25"', 'data-usd="$15"').replace("<span>/ $25</span>", "<span>/ $15</span>")
sal = sal.replace("<li>Personal-use licence</li>", "<li>Instant delivery · pay in ₦ or $</li>")
# cross-sell block before footer
xsell = '''<section class="section section-soft"><div class="container callout"><div><span class="kicker" style="color:#0f7a4e">Run a business?</span><h2 style="margin:6px 0 10px">You may want the business book instead — or as well</h2><p><strong>AI Made Simple for Nigerian Small-Business Owners</strong> skips the general theory and goes straight to your customers, WhatsApp marketing, “last price”, generator costs and profit — 120 prompts, 15 tools, ₦5,000 / $7 launch price.</p><div class="cta-row"><a class="btn btn-accent" href="/business-book">See the business book</a></div></div></div></section>
<footer'''
sal = sal.replace("<footer", xsell, 1)
write("sales.html", sal)

# ---------- OTHER PAGES ----------
for p in ["faq.html", "thank-you.html", "refund-policy.html", "privacy.html", "terms.html"]:
    write(p, global_fix(read(p)))

# ---------- BUSINESS BOOK PAGE ----------
head = sal[:sal.index("<main")]
head = re.sub(r"<title>.*?</title>", "<title>AI Made Simple for Nigerian Small-Business Owners — 120 AI Prompts + 15 Tools | Fresh Genesis</title>", head, flags=re.S)
head = re.sub(r'<meta name="description" content="[^"]*">', '<meta name="description" content="120 copy-paste AI prompts with real Nigerian examples, 15 business tools and a 90-day plan. For shop owners, salons, POS agents, fashion, food and service businesses. Works in Meta AI on WhatsApp. ₦5,000 / $7 launch price.">', head)
footer = sal[sal.index("<footer"):]
footer = footer.replace(xsell.replace("\n<footer",""), "")
book_main = '''<main id="main">
<section class="page-hero"><div class="container"><span class="eyebrow">New from Fresh Genesis · AI Made Simple, Book 1</span><h1>AI Made Simple for Nigerian Small-Business Owners</h1><p class="lead">120 copy-paste AI prompts — each with a real Nigerian example and a Naija tip — plus 15 ready-to-use business tools and a week-by-week 90-day plan. Works in Meta AI on WhatsApp. No laptop needed.</p><div class="cta-row"><button class="btn btn-accent" data-buy data-product="AI Made Simple for Nigerian Small-Business Owners" data-ngn="₦5,000" data-usd="$7">Get the book — ₦5,000 / $7</button><a class="btn btn-secondary" href="#contents">See the contents</a></div><div class="trust-row"><span>131-page PDF</span><span>120 prompts · 15 tools</span><span>Launch price for 14 days, then ₦7,500 / $9</span><span>Instant delivery</span></div></div></section>

<section class="section section-white"><div class="container sales-grid"><aside class="sticky-cover"><img src="assets/covers/ai-made-simple.jpg" alt="AI Made Simple for Nigerian Small-Business Owners cover"></aside><div>
<span class="kicker">Who it’s for</span><h2>Shop owners, salons, POS agents, fashion sellers, food vendors, farmers, service businesses</h2>
<p>You already work harder than most people can imagine. NEPA, fuel, POS charges, haggling customers, WhatsApp vendors undercutting you, a naira that won’t sit still. You don’t need more hustle. You need a tireless assistant who writes your messages, does your maths, rehearses your negotiations and plans your week — free, inside the WhatsApp you already use. This book shows you exactly what to type.</p>
<p><strong>Designed to help you</strong> add ₦1.5M–₦3M in revenue within 90 days and cut operating costs by 35% — by knowing your customer, marketing for free, closing more sales at better prices, and keeping the money you earn. Trackers are included so you measure your own results. <em>Not a guarantee — a plan.</em></p>

<span class="kicker" id="contents">What’s inside</span><h2>Six Parts · 120 prompts</h2>
<div class="faq-list">
<details class="faq-item" open><summary>Part 1 — Deep Customer Understanding &amp; Market Research (20 prompts)</summary><p>Build your ideal customer profile · find what customers really want · why they buy from your competitor · survey questions people answer · the real problem you solve · map your local market · buying habits and timing · segments · complaints as intelligence · test a product before stocking · what customers will pay · where they spend time · reality-test a business idea · find more of your best customers · hidden objections · customer journey · trends · new customer groups · competitor pricing · one-page market brief.</p></details>
<details class="faq-item"><summary>Part 2 — Low-Cost Marketing That Actually Works in Naija (20)</summary><p>WhatsApp Business profile · 30 days of Status posts · broadcasts people read · captions that get “how much?” · flyers · your business story · testimonials · referral system · follow-ups for people who went quiet · zero-budget launch · Reels/TikTok ideas · festive campaigns · replies that convert · local partnerships · church/mosque/community groups · smart giveaways · repeat customers · radio/voice-note ads · 15-minute daily plan · honest monthly review.</p></details>
<details class="faq-item"><summary>Part 3 — Sales, Negotiation &amp; Closing More Deals (20)</summary><p>Core sales script · “e too cost” without discounting · negotiation floor and “last price” · “I’ll come back” · price replies on WhatsApp · “is it original / are you real?” · upsell and cross-sell · abandoned orders and debts · 12-objection table · AI role-play practice · quotations for schools and companies · wholesale · the “send account details” drop-off · mood-matched messages · selling services · market haggling · honest urgency · complaints and refunds · training staff to sell · funnel review.</p></details>
<details class="faq-item"><summary>Part 4 — Operations, Automation &amp; Cost Cutting (20)</summary><p>Expense audit for the 35% · generator and fuel costs (with solar payback) · SOPs · stock control · WhatsApp automation and Quick Replies · invoices and price lists · hiring with practical tests · 5-day onboarding · waste and spoilage · supplier negotiation · delivery costs · a week that doesn’t eat your life · daily sales and cash sheet · support templates · bank/POS charges · quality checklists · AI as daily assistant · buy vs rent vs outsource · written policies · monthly operations review.</p></details>
<details class="faq-item"><summary>Part 5 — Product Innovation &amp; New Revenue Streams (20)</summary><p>Ideas from what you already have · bundles · premium tier · subscriptions · seasonal products · under-served groups and B2B · paid classes · digital products · complementary products · merchandise · home service · 21-day cheap test · joint products · rentals · product improvement · diaspora dollar revenue · loyalty programme · resellers and agents · side income streams · 12-month roadmap.</p></details>
<details class="faq-item"><summary>Part 6 — Finance, Funding &amp; Smart Growth (20)</summary><p>True cost and real profit · pricing for profit · break-even · 8-week cash-flow · separate business and personal money · monthly P&amp;L · debtors · emergency fund · tax and levies explained · should you take a loan · grants strategy · business proposal · 12-month projection · profit allocation · second branch · investor conversations · Nigerian risk protection · inflation response · monthly money review · your 90-day growth plan.</p></details>
<details class="faq-item"><summary>Bonus Section — 15 ready-to-use tools</summary><p>90-Day Revenue Growth Tracker · Monthly Expense Tracker · Customer Avatar Builder · Content Calendar · AI Prompt Cheat Sheet · WhatsApp Business Profile Optimizer · Price List Generator · Business Proposal Template · 60 WhatsApp Status Sales Hooks · NEPA &amp; Generator Expense Calculator · Daily Sales Record Sheet (POS-friendly) · 40 Customer Follow-Up Messages · Referral Reward Card · Business Name &amp; Slogan Creator · Risk &amp; Survival Decision Matrix.</p></details>
<details class="faq-item"><summary>Back Matter</summary><p>Week-by-week 90-Day Action Plan · “I need help with…” quick-find index · plain-English glossary · what to read next.</p></details>
</div>

<span class="kicker">Every prompt, the same way</span><h2>Copy. Fill the [brackets]. Paste.</h2>
<p>Each of the 120 prompts has six parts: the prompt number, a title, <strong>Use this when</strong>, <strong>Copy this prompt</strong>, a <strong>real example filled in</strong> for a Nigerian business (a salon in Ikeja, a buka in Uyo, a phone shop in Onitsha, a poultry farm in Ogun…), and a <strong>Naija tip</strong> with the local angle.</p>

<div class="callout" style="margin-top:22px"><div><h3 style="margin:0 0 8px">Launch offer</h3><p style="margin:0 0 14px"><strong>₦5,000 / $7</strong> for the first 14 days — then ₦7,500 / $9. Less than one day’s generator fuel, and it pays for itself with one extra sale.</p><div class="cta-row"><button class="btn btn-accent" data-buy data-product="AI Made Simple for Nigerian Small-Business Owners" data-ngn="₦5,000" data-usd="$7">Get the book now</button><a class="btn btn-secondary whatsapp-support" href="#">Ask a question on WhatsApp</a></div></div></div>

<span class="kicker" style="margin-top:28px;display:block">Before you buy</span><h2>Questions</h2>
<div class="faq-list">
<details class="faq-item"><summary>Do I need a laptop or to pay for AI?</summary><p>No. Everything works on a phone. Meta AI inside WhatsApp is enough; ChatGPT (free), Gemini and DeepSeek also work.</p></details>
<details class="faq-item"><summary>Is it only for big businesses?</summary><p>No — it was written for kiosks, market stalls, salons, POS points, one-woman fashion brands and food vendors. Examples start from ₦500 sales.</p></details>
<details class="faq-item"><summary>How do I receive it?</summary><p>Download link on payment, plus the PDF sent to your WhatsApp or email — usually within minutes during business hours.</p></details>
<details class="faq-item"><summary>Is the ₦1.5M–₦3M guaranteed?</summary><p>No. It is a target with a plan and trackers. Results depend on your business and your execution. The book is honest about this on page one.</p></details>
<details class="faq-item"><summary>Refunds?</summary><p>Digital product — not refundable once delivered, except for duplicate charges or files that cannot be opened after support. See the <a href="/refund-policy">refund policy</a>.</p></details>
</div>
</div></div></section>
</main>
'''
nav_new = '<nav class="main-nav" aria-label="Primary navigation"><a href=\'/\'>Home</a><a class="active" href="/business-book">Business Book</a><a href=\'/sales\'>SimplifyAI System</a><a href="/#library">Library</a><a href=\'/faq\'>FAQ</a></nav>'
head = re.sub(r'<nav class="main-nav".*?</nav>', nav_new, head, flags=re.S)
head = re.sub(r'<nav class="mobile-menu".*?</nav>', nav_new.replace('main-nav" aria-label="Primary navigation"','mobile-menu" id="mobileMenu" aria-label="Mobile navigation"'), head, flags=re.S)
head = re.sub(r'<a class="btn btn-accent btn-small"[^>]*>[^<]*</a>', '<button class="btn btn-accent btn-small" data-buy data-product="AI Made Simple for Nigerian Small-Business Owners" data-ngn="₦5,000" data-usd="$7">Get the book</button>', head)
head = re.sub(r'<div class="announcement">.*?</div>', '<div class="announcement">Launch offer: <strong>₦5,000 / $7 for 14 days</strong>, then ₦7,500 / $9. Instant delivery to your phone.</div>', head, flags=re.S)
book = head + book_main + footer
book = book.replace("<a class='brand' href='/'>", "<a class='brand' href='/'>")
write("business-book.html", book)

# ---------- CONFIG + APP.JS ----------
cfg = read("assets/config.js")
cfg = cfg.replace('brand: "Fresh Genesis Co SimplifyAI"', 'brand: "Fresh Genesis"')
cfg = cfg.replace('supportEmail: "Freshgenesisco@gmail.com"', 'supportEmail: "freshgenesisco@gmail.com"')
cfg = cfg.replace('  // Add the URL of your free Selar product after creating it.\n  // Selar will collect the subscriber\'s email and deliver Quick Start.\n  freeGuideUrl: "",',
                  '  // Free Quick Start: leave empty to deliver via WhatsApp ("START" message).\n  // Or paste your Selar free-product URL to deliver by email instead.\n  freeGuideUrl: "",')
cfg = cfg.replace('completeSystem: { ngn: "₦15,000", usd: "$25" },', 'completeSystem: { ngn: "₦15,000", usd: "$15" },\n    businessBook: { ngn: "₦5,000", usd: "$7" },')
write("assets/config.js", cfg)

app = read("assets/app.js")
app = app.replace("""    else{link.href='#';link.addEventListener('click',e=>{e.preventDefault();showToast('Add your Selar free-product link in assets/config.js before launch.');});}""",
                  """    else{link.href=`https://wa.me/${cfg.supportWhatsApp}?text=${encodeURIComponent('START — please send me the free SimplifyAI Quick Start PDF.')}`;link.target='_blank';link.rel='noopener';}""")
app = app.replace("const product=btn.dataset.product||'Fresh Genesis Co SimplifyAI product';", "const product=btn.dataset.product||'Fresh Genesis product';")
app = app.replace("Hello Fresh Genesis Co. I want to order", "Hello Fresh Genesis. I want to order")
app = app.replace("'Hello Fresh Genesis Co. I need help with SimplifyAI.'", "'Hello Fresh Genesis. I have a question about your products.'")
write("assets/app.js", app)

# copy assets
for f in os.listdir("_build/original/assets/covers"):
    shutil.copy(os.path.join("_build/original/assets/covers", f), os.path.join("assets/covers", f))
shutil.copy("_build/original/assets/styles.css", "assets/styles.css")
# minor CSS: featured offer emphasis + step-num text
open("assets/styles.css", "a").write("\n/* v2 */\n.offer-card.featured{border-color:var(--orange);box-shadow:var(--shadow)}\n.step-num{font-size:1.1rem}\n.offer-card h3{padding-right:110px}\n@media(max-width:700px){.offer-card h3{padding-right:0;margin-top:26px}}\n.free-panel img{border-radius:18px;box-shadow:var(--shadow)}\n")
# Netlify: pretty URLs + no-badge
open("_redirects", "w").write("/business-book   /business-book.html   200\n")
open("netlify.toml", "w").write('[build]\n  publish = "."\n\n[[headers]]\n  for = "/*"\n  [headers.values]\n    X-Frame-Options = "SAMEORIGIN"\n')

# ---------- final link pass ----------
def rel_links(s):
    for slug in ["sales","faq","thank-you","refund-policy","privacy","terms","business-book"]:
        s = re.sub(rf"href=(['\"])/{slug}(#[^'\"]*)?\1", rf"href=\1{slug}.html\2\1", s)
    s = re.sub(r"href=(['\"])/(#[^'\"]*)?\1", r"href=\1index.html\2\1", s)
    return s
for p in PAGES + ["business-book.html"]:
    write(p, rel_links(open(p, encoding="utf-8").read()))

# ---------- checks ----------
bad = []
for p in PAGES + ["business-book.html"]:
    s = open(p, encoding="utf-8").read()
    for needle in ["config.js</code>", "netlify.new", "/.netlify/scripts", "before launch", "before the public launch", "Fresh Genesis Co", "Vol. 1", "$25", "Freshgenesisco@"]:
        if needle in s and not (needle == "config.js</code>" and False):
            bad.append((p, needle))
print("remaining issues:", bad or "none")
print("pages:", [p for p in os.listdir(".") if p.endswith(".html")])
