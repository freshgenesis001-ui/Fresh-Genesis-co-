# SimplifyAI site (freshgenesiscopresents.netlify.app) — fixed build

Deploy: drag this folder (everything except `_build/`) onto https://app.netlify.com/drop,
or upload `simplifyai-site-deploy.zip`.

Pages: index · business-book (new) · sales · faq · thank-you · refund-policy · privacy · terms
Config: `assets/config.js` (payment links, prices, WhatsApp, optional Selar free-guide URL)

What changed vs. the live site — see `../fresh-genesis-website/LIVE-SITE-REVIEW-SimplifyAI.md`:
- Dead free buttons now open WhatsApp ("START") until a Selar URL is added to config
- All developer notes removed; Netlify badge/script removed
- New product: AI Made Simple for Nigerian Small-Business Owners (home hero, "Choose your path", feature section, /business-book page, sales-page cross-sell)
- Hero/copy rewritten around outcomes; page counts removed from cards; 3 paths above the fold
- Complete System shown as ₦15,000 / $15 (was $25) — change in config.js + index/sales if you disagree
- Brand unified to "Fresh Genesis"; email lower-cased; FAQ links to refund/delivery pages; positive-first FAQ
- "Who made this" + payment/delivery trust block

Rebuild after editing `_build/patch.py`:  `python3 _build/patch.py`
