# BACK MATTER

---

## YOUR 90-DAY ACTION PLAN

You have 120 prompts and 15 tools. Here is the order to use them in, week by week, so that you reach the extra ₦1.5M–₦3M and the 35% cost cut without burning out.

**The rules of the plan:**
- **One hour a day**, ideally the same hour (early morning or after closing).
- **No more than 5 actions per week.** Depth beats breadth.
- **Track every Sunday** in the 90-Day Revenue Growth Tracker (Bonus 1).
- If you miss a week — NEPA, family, illness — **don't restart. Do the next week.**

### PHASE 1 — FOUNDATION (Days 1–30): *Know, Set Up, Start Selling Better*

**Goal by Day 30:** customer clarity, WhatsApp fully set up, daily posting habit, sales script live, daily cash sheet balancing, expense audit done.

| Week | Actions | Prompts / Tools |
|---|---|---|
| **1** | ① Write your 90-Day Promise. ② Build your ideal customer profile. ③ Discover the real problem you solve. ④ Set up the Daily Sales Record Sheet. ⑤ Set up the 90-Day Tracker with your baseline. | 1.1 · 1.5 · Bonus 11 · Bonus 1 |
| **2** | ① Complete your WhatsApp Business profile, greeting, away message, 12 Quick Replies. ② Create 30 days of Status content; start posting daily. ③ Understand why customers choose your competitor. ④ Write your core sales script. ⑤ Set your negotiation floor and "last price" system. | Bonus 6 · 2.2 · 1.3 · 3.1 · 3.3 |
| **3** | ① Do the full expense audit. ② Build your trust "Proof" folder. ③ Write your 12-objection table and rehearse it. ④ Start the 3-message follow-up for everyone who "went quiet." ⑤ Send your first testimonial requests. | 4.1 · 3.6 · 3.9 · 2.9 · 2.7 |
| **4** | ① Calculate true cost and real profit of top 5 products. ② Find your daily break-even; put it on the wall. ③ Open a separate business account; set your owner's salary. ④ Write your first 3 SOPs. ⑤ **Day 30 checkpoint** — fill in Bonus 1; do your first monthly P&L and money review. | 6.1 · 6.3 · 6.5 · 4.3 · 6.6 · 6.19 |

**Day 30 check:** Are enquiries up? Is cash balancing daily? Do you know your break-even? If any is "no," repeat that action in Week 5 before moving on.

### PHASE 2 — GROWTH ENGINES (Days 31–60): *More Leads, More Conversions, Lower Costs*

**Goal by Day 60:** referral system live, bundles selling, upsells on every sale, generator and supplier costs cut, first new revenue stream in test.

| Week | Actions | Prompts / Tools |
|---|---|---|
| **5** | ① Launch your referral programme with cards or digital version. ② Design and display 2–3 named bundles. ③ Add upsell/cross-sell lines to every sale. ④ Cut generator/fuel costs — apply the calculator. ⑤ Post from the Hook Bank daily. | 2.8 · Bonus 13 · 5.2 · 3.7 · 4.2 · Bonus 10 · Bonus 9 |
| **6** | ① Negotiate with your top 2 suppliers. ② Fix the "send account details" drop-off. ③ Write and post your policies (deposits, delivery, returns, credit). ④ Segment customers with WhatsApp Labels. ⑤ Start a waste/spoilage log. | 4.10 · 3.13 · 4.19 · 1.8 · 4.9 |
| **7** | ① Generate your adjacent product/stream ideas; pick one. ② Design its 21-day test with a written "go" threshold. ③ Launch the test to existing customers. ④ Plan your next seasonal/festive campaign. ⑤ Build a weekly schedule that protects your time. | 5.1 · 5.12 · 5.10/5.4/5.7/5.11 · 2.12/5.5 · 4.12 |
| **8** | ① Collect and manage debtors; write your credit policy. ② Build your 8-week cash-flow forecast. ③ Start your emergency fund with an automatic transfer. ④ Turn one-time buyers into repeat customers. ⑤ **Day 60 checkpoint** — Bonus 1; monthly P&L; operations review; sales-funnel review. | 6.7 · 6.4 · 6.8 · 2.17 · 6.6 · 4.20 · 3.20 |

**Day 60 check:** Are you at ⅔ of your revenue target? Have operating costs dropped at least 20%? Did the 21-day test hit its threshold? Decide: scale the new stream or adjust and retest.

### PHASE 3 — SCALE & SECURE (Days 61–90): *Multiply What Works, Protect What You've Built*

**Goal by Day 90:** full target hit, second revenue stream live, B2B or diaspora customer won, systems that run without you, 12-month roadmap ready.

| Week | Actions | Prompts / Tools |
|---|---|---|
| **9** | ① Scale the winning new stream (or launch the second-ranked idea). ② Contact your first B2B or diaspora prospect with a one-page proposal. ③ Add a premium tier to your best seller. ④ Run a monthly marketing review — drop what isn't working. ⑤ Hire or train with the one-page sales guide if needed. | 5.6/5.16 · 3.11 · 5.3 · 2.20 · 3.19/4.8 |
| **10** | ① Build your 12-month product & revenue roadmap. ② Set prices for profit; announce any increases honestly. ③ Create quality-control checklists. ④ Score your risks in the Risk Matrix; add top-3 protections. ⑤ Practise a difficult negotiation with AI role-play. | 5.20 · 6.2 · 4.16 · Bonus 15 · 3.10 |
| **11** | ① Prepare your "Grant Folder" (documents, photos, P&Ls). ② Draft a business proposal if you plan to seek funding. ③ Build your 12-month financial projection. ④ Launch your loyalty programme. ⑤ Test: leave the shop for 2 days — does it run? | 6.11 · Bonus 8 · 6.13 · 5.17 · 6.15 |
| **12** | ① Set your profit-allocation rule and automate it. ② Update your one-page Customer & Market Brief. ③ Improve your best product from feedback. ④ Run your monthly money review. ⑤ Write thank-you messages to your top 20 customers. | 6.14 · 1.20 · 5.15 · 6.19 · Bonus 12 |
| **13** | ① **Day 90 checkpoint** — complete Bonus 1. ② Compare Day 1 vs. Day 90: revenue, costs, profit, hours worked. ③ Write down your 3 biggest wins and 3 biggest lessons. ④ Build the *next* 90-day plan. ⑤ Celebrate — properly. You earned it. | Bonus 1 · Bonus 2 · 6.20 |

### After Day 90

The habits are the prize: daily posting, daily cash sheet, weekly tracker, monthly P&L and reviews, quarterly risk and roadmap check. Keep them, and every 90 days compounds on the last.

---

## QUICK-FIND INDEX: "I NEED HELP WITH…"

| Situation | Go to |
|---|---|
| I don't know who my customer really is | 1.1, 1.14, Bonus 3 |
| Sales are slow and I don't know why | 1.2, 3.20, 2.20 |
| Customers ask price and disappear | 3.5, 2.9, Bonus 12 (A) |
| "E too cost" / "last price?" | 3.2, 3.3, 3.16 |
| "Is it original? Are you real?" | 3.6 |
| People say "I'll come back" | 3.4 |
| I need content for Status | 2.2, Bonus 4, Bonus 9 |
| I want more referrals | 2.8, Bonus 13 |
| I need testimonials | 2.7 |
| Someone owes me money | 3.8, 6.7, Bonus 12 (F) |
| A customer is angry | 3.18, Bonus 12 (G) |
| Generator is eating my profit | 4.2, Bonus 10 |
| Cash doesn't balance | 4.13, Bonus 11 |
| Staff keep making mistakes | 4.3, 4.16, 3.19, 4.8 |
| I need to hire | 4.7 |
| I'm working 14 hours a day | 4.12, 4.5 |
| I want to add a new product or income | 5.1, 5.12, 5.20 |
| I want to raise my average sale | 5.2, 5.3, 3.7 |
| I want dollar customers | 5.16 |
| I don't know my real profit | 6.1, 6.6 |
| I want to raise prices without losing customers | 6.2, 6.18 |
| I'm considering a loan | 6.10 |
| I want a grant | 6.11, 6.12, Bonus 8 |
| Someone wants to invest | 6.16 |
| Should I open a second branch? | 6.15 |
| I need a business name or slogan | Bonus 14 |
| What if disaster strikes? | 6.17, Bonus 15 |
| I need a quotation for a company/school | 3.11, Bonus 7 |
| The AI's answer isn't good | Bonus 5 (Universal Fix-It Prompt) |

---

## GLOSSARY: PLAIN-ENGLISH TERMS USED IN THIS BOOK

| Term | What it means |
|---|---|
| **AI (Artificial Intelligence)** | Software that understands and produces text like a person. In this book: Meta AI, ChatGPT, Gemini, DeepSeek, Copilot. |
| **Prompt** | What you type to the AI — your question or instruction. Better prompt, better answer. |
| **Attach rate** | The share of customers who buy an add-on with their main purchase. |
| **Average sale / average order value** | Total sales ÷ number of transactions. Raising it is often easier than finding new customers. |
| **B2B** | Business-to-business — selling to companies, schools, hotels, churches instead of individuals. |
| **Break-even** | The sales level where you cover all your costs — no profit, no loss. Below it, you're losing money. |
| **Bundle** | Several items sold together at one price, usually with a saving. |
| **Cash flow** | Money actually coming in and going out, and *when*. Different from profit. |
| **Conversion** | Turning an enquiry into a paid sale. "Conversion rate" = paid ÷ enquiries. |
| **Cost of sales / cost of goods** | What you paid for the stock or materials in the products you sold. |
| **Cross-sell** | Suggesting a related item ("a case with that phone"). |
| **Customer avatar / persona** | A detailed description of your ideal customer as if they were one real person. |
| **Debtor** | A customer who owes you money. |
| **Deposit** | Part payment made in advance to secure an order. |
| **Diaspora** | Nigerians living abroad. |
| **Emergency fund** | Money set aside to survive a crisis — target: 3 months of fixed costs. |
| **Fixed costs** | Costs you pay whether you sell or not: rent, salaries, generator baseline, data. |
| **Funnel** | The stages from enquiry → price → agreed → paid. Where people drop off is where money leaks. |
| **Gross profit** | Revenue minus cost of sales. |
| **Gross margin** | Gross profit as a % of revenue. |
| **Lead** | A potential customer who has shown interest. |
| **Lifetime value** | Total profit a customer brings over all the time they buy from you. |
| **Margin** | The profit portion of a price, usually as a percentage. |
| **Net profit** | What's left after *all* costs, including fixed costs — the real profit. |
| **Objection** | A reason a customer gives for not buying ("too expensive", "let me think"). |
| **P&L (Profit & Loss)** | A one-page monthly summary: revenue, costs, profit. |
| **Payback period** | How long an investment takes to pay for itself from savings or profit. |
| **Positioning** | How customers see you compared to competitors (cheapest, best quality, fastest, most trusted). |
| **Pre-order** | Customers pay before the product is ready or arrives. |
| **Quick Replies** | Saved messages in WhatsApp Business you send with a shortcut like /price. |
| **Repurposing** | Using one piece of content in several ways. |
| **Reseller / agent** | Someone who buys from you at a lower price and sells to their own customers. |
| **RRP** | Recommended retail price — the price you tell resellers to sell at. |
| **Segment** | A group of customers with similar needs (bulk buyers, walk-ins, corporate). |
| **SOP (Standard Operating Procedure)** | A written, step-by-step instruction for a task so it's done the same way every time. |
| **Subscription** | Customers pay regularly (weekly/monthly) for regular delivery. |
| **Testimonial** | A customer's words about their experience — your best marketing. |
| **Tier** | A level of offer: standard, premium; silver, gold. |
| **Upsell** | Suggesting a better/bigger version ("the 10-inch instead of the 8-inch"). |
| **Variable costs** | Costs that rise with each sale: materials, packaging, delivery, POS charges. |
| **Wholesale** | Selling in bulk at a lower unit price to resellers. |
| **Working capital** | The cash you need to run day to day — buying stock before you sell it. |

---

## A FINAL WORD FROM THE AUTHOR

This book was written with one conviction: **the Nigerian small-business owner is one of the most resourceful people on earth.** You have built and kept a business alive through fuel hikes, currency swings, power failures, harassment, and a thousand daily frictions that would close most businesses elsewhere in a month.

You never lacked intelligence or work ethic. What was missing was a **tireless, patient, knowledgeable assistant** — one who could write your messages, do your maths, rehearse your negotiations, plan your week and never charge you a kobo. That assistant now lives inside the phone in your hand.

AI will not build your business. **You** will — one prompt, one customer, one honest week of numbers at a time. But you will do it faster, with fewer mistakes, and with more of your profit staying in your pocket.

Use the prompts. Fill in the trackers. Do the Sunday reviews. In 90 days, look back.

Then send me your story — I mean it.

*— Fresh Genesis*

---

## SHARE YOUR RESULTS

Your progress is proof for the next business owner who is where you were on Day 1.

- **WhatsApp:** +234 902 190 6332 — send your Day 1 vs. Day 90 numbers, your biggest win, or a question.
- Tag or forward this book to one business owner who needs it. Small businesses grow small businesses.

---

## WHAT TO READ NEXT — THE *AI MADE SIMPLE* SERIES

Each book in the series follows the same format you've just used: 6 Parts × 20 prompts, real examples, local tips, and ready-to-use tools.

| Book | For | Target outcome |
|---|---|---|
| **AI Made Simple for Job Seekers** | Graduates, NYSC members, career switchers, Nigerians applying abroad | More interviews, confident answers, a better offer |
| **AI Made Simple for Students** | SS1–SS3, JAMB candidates, undergraduates, postgraduates | Higher grades in fewer study hours — honestly |
| **AI Made Simple for Freelancers & Remote Workers** | Writers, designers, VAs, developers selling to local and international clients | Better clients, higher rates, fewer hours |
| **AI Made Simple for Content Creators** | YouTubers, TikTokers, Reels creators, thread writers | Double your output, grow, get paid |
| **AI Made Simple for Teachers & Tutors** | Teachers, lesson tutors, tutorial-centre owners | Two-thirds less prep time, more engaged students, more income |
| **AI Made Simple for Busy Professionals** | Corporate staff, managers, bankers, lawyers, doctors | 8–12 hours a week back, better decisions, faster promotion |

**Also from Fresh Genesis:**
- **Clarity Life Template Pack** — planners and templates to organise your week and goals.
- **Beginner-Friendly AI Prompt Workbook** — 90 general-purpose prompts for everyday life and work.
- **Fresh Start Digital Bundle** — both of the above, together.

Available via WhatsApp (+234 902 190 6332) and the Fresh Genesis store.

---

## ABOUT FRESH GENESIS

Fresh Genesis creates simple, practical digital products that help everyday people use modern tools — especially AI — to earn more, save time, and make better decisions. Everything we publish is built on one test: *could a busy person with a phone use this today?*

---

## COPYRIGHT & DISCLAIMER

© Fresh Genesis. All rights reserved.

This book is for personal use by the purchaser. You may print it for your own business and share individual prompts with your staff. Please do not resell, redistribute, or upload the full book. If it helped you, send someone the link instead — thank you.

**Disclaimer:** This book provides general business education. It is not financial, legal, tax, or investment advice. AI tools can produce errors; results depend on your business, your market, and your execution. Revenue and cost-saving figures are targets and examples, not guarantees. Verify all fees, rates, regulations and programme details with the relevant institutions or a qualified professional before making decisions. Fresh Genesis accepts no liability for actions taken on the basis of this content.

Names, businesses and figures in the examples are illustrative composites drawn from common Nigerian small-business situations.

---

*AI Made Simple for Nigerian Small-Business Owners*
*120 Practical Prompts to Grow Your Business With AI — Even If You've Never Used It Before*

**— END —**
