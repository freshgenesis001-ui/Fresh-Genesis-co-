# AI Made Simple for Nigerian Small-Business Owners

**Subtitle:** 120 Practical Prompts to Grow Your Business With AI — Even If You've Never Used It Before

**Who this book is for:** Shop owners, salon operators, POS agents, fashion sellers, agropreneurs, restaurant owners, and service businesses in Nigeria.

**The 90-day target:** Generate an extra ₦1.5M–₦3M in revenue within 90 days while cutting your marketing and operating costs by at least 35%.

> *No tech jargon. No laptop needed. If you can send a WhatsApp message, you can use this book.*

---

## WHAT'S INSIDE AT A GLANCE

| Section | What it does for you |
|---|---|
| **Part 1** — Customer Understanding & Market Research (Prompts 1.1–1.20) | Know exactly who your customers are, what they want, and what they'll pay — before you spend a kobo. |
| **Part 2** — Low-Cost Marketing That Actually Works in Naija (Prompts 2.1–2.20) | Get customers with WhatsApp, status ads, and word-of-mouth systems that cost little or nothing. |
| **Part 3** — Sales, Negotiation & Closing (Prompts 3.1–3.20) | Handle haggling, objections, and "I'll come back" — and turn more of them into paid sales. |
| **Part 4** — Operations, Automation & Cost Cutting (Prompts 4.1–4.20) | Save hours every week and cut at least 35% off your running costs. |
| **Part 5** — Product Innovation & New Revenue (Prompts 5.1–5.20) | Add new products and income streams from what you already have. |
| **Part 6** — Finance, Funding & Smart Growth (Prompts 6.1–6.20) | Price right, track money, and prepare for funding — sensibly and safely. |
| **Bonus Section** — 15 ready-to-use tools | Copy-paste templates: scripts, trackers, calculators, message banks, and decision frameworks. |

Every prompt follows the same six-part format:

1. **Prompt number** (e.g., Prompt 1.3)
2. **Title** — what it does in one line
3. **Use this when:** — so you can spot the right prompt in seconds
4. **Copy this prompt:** — the full prompt, ready to paste into your AI
5. **Real example (filled in)** — a Nigerian business scenario showing the prompt at work
6. **Naija tip:** — the local angle that makes the difference

---

## TABLE OF CONTENTS

### FRONT MATTER
- Cover Page & Title Page
- What's Inside at a Glance
- Introduction
- How to Use This Book
- Which AI to Use
- Check Before You Trust It
- Your 90-Day Promise

### PART 1: DEEP CUSTOMER UNDERSTANDING & MARKET RESEARCH *(Prompts 1.1 – 1.20)*
### PART 2: LOW-COST MARKETING THAT ACTUALLY WORKS IN NAIJA *(Prompts 2.1 – 2.20)*
### PART 3: SALES, NEGOTIATION & CLOSING MORE DEALS *(Prompts 3.1 – 3.20)*
### PART 4: OPERATIONS, AUTOMATION & COST CUTTING *(Prompts 4.1 – 4.20)*
### PART 5: PRODUCT INNOVATION & NEW REVENUE STREAMS *(Prompts 5.1 – 5.20)*
### PART 6: FINANCE, FUNDING & SMART GROWTH *(Prompts 6.1 – 6.20)*

### BONUS SECTION *(Bonus 1 – 15)*
1. 90-Day Revenue Growth Tracker
2. Monthly Business Expense Tracker
3. Customer Avatar & Persona Builder
4. Social Media Content Calendar
5. AI Prompt Cheat Sheet (Quick Reference)
6. WhatsApp Business Profile Optimizer
7. Price List Generator
8. Business Proposal Template (Banks / Grants / Investors)
9. WhatsApp Status Sales Hook Bank
10. NEPA & Generator Expense Calculator
11. Daily Sales Record Sheet (POS-Friendly)
12. Customer Follow-Up Message Bank
13. Referral Reward Card Template
14. Business Name, Catchphrase & Slogan Creator
15. Risk & Survival Decision Matrix for Naija Businesses

### BACK MATTER
- Your 90-Day Action Plan (Week by Week)
- Quick-Find Index: "I Need Help With…"
- Glossary: Plain-English Terms
- A Final Word from the Author
- What to Read Next — The *AI Made Simple* Series
- Copyright & Disclaimer

---

## INTRODUCTION

If you run a small business in Nigeria, you already work harder than most people can imagine. Between NEPA taking light, fuel and generator costs, market competition, WhatsApp vendors, POS charges, naira pressures, and customers haggling, your profit can vanish quietly — even on a good day.

The good news: you don't need a laptop, a degree in tech, or expensive software to put AI to work. You only need to be able to **copy, paste, and answer a few questions**.

**AI** (Artificial Intelligence) is a very fast assistant. You give it clear instructions in plain English (or Pidgin), and it gives you useful answers in seconds — answers that would otherwise take you hours, days, or a paid consultant.

This book doesn't teach AI theory. It teaches **action**. For every problem, you'll copy a ready-made **prompt** into an AI tool, then copy its answer straight back to work.

With the trackers, checklists, and templates included, your goal isn't a vague hope — it's something you can measure **week by week, for 90 days**.

---

## HOW TO USE THIS BOOK

Follow these five steps. That's it:

1. **Pick a problem.** Find the Part that solves your biggest headache right now (e.g., "not enough customers" → Part 2).
2. **Find the right prompt.** Each prompt has a title and a **"Use this when:"** line, so you can spot it in seconds.
3. **Fill the [brackets].** In every prompt you'll see words in square brackets like `[type of business]`, `[your location]`, or `[price]`. Replace *only* what's inside the brackets with your own details. Leave everything else exactly as it is.
4. **Copy and paste.** Copy the entire **"Copy this prompt:"** block into your AI, then hit Send.
5. **Put the answer to work.** Use what it gives you the same day. Don't let it sit.

**If the first answer is weak,** copy and paste this follow-up:

> *"That answer isn't quite right. I need it to be more practical for a Nigerian small business. Make it simpler, use plain English with Pidgin only if useful, give concrete examples, and avoid guesswork. Try again, using this feedback: [explain what you want changed]."*

**A very important rule:** Always fill in the `[brackets]` first. The AI needs your real business details to give you useful answers — not generic ones. The quality of the answer depends on the quality of what you put in.

---

## WHICH AI TO USE

You don't need to pay anything to get real value from this book. Here are the options, ranked for Nigerian small businesses:

| AI Tool | Free or Paid | Best For | Works Well On |
|---|---|---|---|
| **Meta AI (inside WhatsApp)** | Free | **Highly recommended for Nigerian business owners.** It lives inside WhatsApp — an app almost every Nigerian phone already has. Perfect for shop owners, market traders, salon operators, POS agents, and vendors who already do business on WhatsApp. | Any phone (Android or iPhone) |
| **Gemini** | Free, generous limits | Very solid and easy to use on mobile. | Phone, tablet, or computer |
| **ChatGPT** | Free + paid | Very popular and easy to follow; some advanced features need payment. | Phone, tablet, or computer |
| **DeepSeek** | Free | Strong free option with good reasoning; popular for business planning and writing tasks. | Phone, tablet, or computer |
| **Microsoft Copilot** | Free | Clean, practical answers. Easy to use. | Phone, tablet, or computer |

**My number one pick for most Naija business owners: Meta AI inside WhatsApp.** There's no new app to download or learn — and you're very likely already using WhatsApp for your business every single day.

> **Note:** WhatsApp's new per-message charges (from October 2026) apply only to big companies on the WhatsApp Business *Platform (API)* — not to you on the normal, free WhatsApp or WhatsApp Business app. Your AI chats in WhatsApp remain free.
>
> AI tools update from time to time. If one tool isn't giving useful answers, simply try another from the table above.

---

## CHECK BEFORE YOU TRUST IT

AI is an assistant, not an infallible expert. Treat everything it gives you as a **draft you verify**. Keep these rules in mind:

- **Finance, funding & tax (Part 6):** For bank proposals, loan discussions, tax matters, or anything involving large sums, treat AI output as a starting point only. Cross-check with your bank, accountant, auditor, or a trusted adviser before you act.
- **Contracts, terms & legal decisions:** The prompts can draft proposals, clauses, and templates. Nigerian laws and regulations change — for binding contracts or high-stakes commitments, get proper professional advice.
- **Prices, charges & POS:** Bank fees, POS charges, transport, fuel, and generator costs vary by location and change over time. Always verify today's prices in your market before committing.
- **Accuracy:** AI can occasionally guess. If a number or claim looks off, ask it to show how it arrived at the answer — or verify with a human source.
- **Local reality:** Nigeria is unique — NEPA, fuel costs, inflation, naira volatility, haggling, and market dynamics. This book leans heavily into Nigerian context, but you know your business better than any AI ever will. **You are the final decision-maker.**
- **Your business data:** Never paste sensitive private details — full account numbers, BVN, or customers' full ID details. Remove or generalise them first.

**Designed for action, not perfection.** Your goal is progress week by week over 90 days, measured with the trackers provided.

---

## YOUR 90-DAY PROMISE

Write this down somewhere you'll see it every morning:

> *"For the next 90 days, I will use at least one prompt from this book every working day, put the answer to work the same day, and track my progress every week."*

That's it. That's the whole system. The prompts in this book are powerful — but only the ones you actually use.

Now turn the page. Part 1 starts with the most important person in your business: **your customer.**
