# PART 2: LOW-COST MARKETING THAT ACTUALLY WORKS IN NAIJA
*(Prompts 2.1 – 2.20)*

---

## Why Most Small-Business Marketing in Nigeria Fails

It is not because owners don't try. It is because they copy what big brands do — flashy graphics, giveaways, "follow us on all platforms" — without the budget or the team to sustain it. Two weeks later the Instagram page is dead, the flyers are in the gutter, and the owner concludes that "marketing doesn't work."

Marketing that works for a small Nigerian business follows three rules:

1. **It costs little or nothing.** WhatsApp Status, referrals, community presence, and honest word-of-mouth beat paid ads at this stage.
2. **It is consistent.** One post every day for 90 days beats ten posts in one week and silence for a month.
3. **It sounds like a person, not a company.** Nigerians buy from people they know, like, and trust — not from logos.

In this Part, you will use AI to write your WhatsApp Status posts, broadcast messages, captions, flyers, referral offers, and customer follow-ups — fast, in your own voice, without hiring anybody. You already did the customer research in Part 1. Now we use it.

**Work through it like this:** Start with Prompts 2.1, 2.2 and 2.8. They set up your WhatsApp presence, your daily content, and your referral engine — the three pillars. The rest are tools you pull out as needed.

---

## Prompt 2.1

### Title: Write a WhatsApp Business Profile That Sells While You Sleep

**Use this when:** Your WhatsApp Business "About", description, and catalogue are empty or half-done, and new contacts cannot tell in 5 seconds what you sell and why they should trust you.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. I sell [products/services] to [customer type]. What makes me different: [your edge — quality, speed, price, warranty, experience, etc.]. My opening hours are [hours] and I deliver [where / how]. Write me: (1) a short "About" line for WhatsApp Business (under 139 characters), (2) a full business description (under 500 characters) that says what I sell, who it's for, why to trust me, and how to order, (3) five product/service catalogue entries with a title (under 40 characters) and a 2-line description each, and (4) a friendly greeting message that sends automatically when someone messages me for the first time. Use simple, warm, confident Nigerian English. No corporate jargon.

**Real example (filled in):**

> I run a small bakery in Ibadan. I sell fresh bread, meat pies, chin chin, and custom birthday cakes to families, small shop owners, and event planners. What makes me different: baked fresh every morning by 6am, no preservatives, I deliver within Bodija and Agbowo, and cakes are ready in 48 hours. Opening hours 6am–8pm Monday to Saturday. Write me: (1) a short "About" line under 139 characters, (2) a full business description under 500 characters, (3) five catalogue entries with a title under 40 characters and a 2-line description each, and (4) a friendly automatic greeting message for first-time contacts. Simple, warm, confident Nigerian English.

**Naija tip:** Set up the greeting message and the "away message" in WhatsApp Business (Business tools → Greeting message / Away message). Many Nigerian customers message at 11pm; a warm automatic reply that says "I've seen your message, I'll respond by 7am" keeps them from moving to the next vendor. Also put your **real name and face** in the profile photo or the description — "Mama Tobi's Bakery, run by Funke" — because people trust a face more than a logo.

---

## Prompt 2.2

### Title: Create 30 Days of WhatsApp Status Posts in One Sitting

**Use this when:** You know you should be posting daily but you run out of ideas by day 3, or all your posts are just "buy this, ₦5,000."

**Copy this prompt:**

> I run a [business type] in Nigeria selling [products/services] to [customer type]. Create a 30-day WhatsApp Status content plan for me. Each day should have: the post type, a short caption (under 40 words), and what photo or video I should take with my phone. Mix these post types across the month: product showcase, customer testimonial, behind-the-scenes, tip or advice related to my business, a question that invites replies, a limited offer, a "before and after", a personal story, and a reminder of how to order. Only about 1 in 3 posts should directly sell. The tone should be friendly, real, and Nigerian — not like a big company. Present it as a table: Day | Post type | Caption | Photo/video to take.

**Real example (filled in):**

> I run a small skincare business in Abuja selling natural black soap, shea butter cream, and turmeric face scrub to women aged 22–40. Create a 30-day WhatsApp Status content plan. Each day: post type, a short caption under 40 words, and what photo or video to take with my phone. Mix product showcase, customer testimonial, behind-the-scenes, skincare tips, questions that invite replies, a limited offer, before-and-after, personal story, and how-to-order reminders. Only about 1 in 3 posts should directly sell. Friendly, real, Nigerian tone. Present as a table: Day | Post type | Caption | Photo/video to take.

**Naija tip:** Post between **7–9am** and **7–10pm** — those are the hours Nigerians scroll Status. Post 2–4 times a day, not 15 (people mute vendors who flood). Once a week, post something that has nothing to do with selling — your child's school event, a Nigerian joke, a Sunday prayer — because customers buy from *people*, and Status is where they get to know you as one. Save the AI's table as a note on your phone and tick each day off.

---

## Prompt 2.3

### Title: Write a Broadcast Message That People Don't Ignore

**Use this when:** You want to send a message to many customers at once — new stock, a promo, a festive offer — and you want it to be read and acted on, not deleted.

**Copy this prompt:**

> I want to send a WhatsApp broadcast to my customers about [what: new stock / promo / festive offer / restock / price change / new service]. Details: [product, price, offer, deadline, how to order]. My customers are [describe them]. Write me 3 versions of the message, each under 80 words: (1) a warm, personal version that sounds like I'm writing to one friend, (2) a short, urgent version with a clear deadline, and (3) a version that starts with a benefit or a question instead of the product. Each should end with one clear action: reply, call, or click. Don't use ALL CAPS or too many emojis — a maximum of 3. Nigerian English, simple and natural.

**Real example (filled in):**

> I want to send a WhatsApp broadcast to my customers about new stock of Ankara fabric — 20 fresh designs just arrived from Kano, ₦4,500 per 6 yards, first 15 customers get free delivery within Ilorin, offer ends Sunday. Order by replying "ANKARA" or calling 0902 190 6332. My customers are women aged 25–55 who sew for church, weddings, and aso-ebi. Write me 3 versions under 80 words each: (1) warm and personal, (2) short and urgent with deadline, (3) starting with a benefit or question. Each ends with one clear action. Maximum 3 emojis. Nigerian English.

**Naija tip:** WhatsApp broadcasts only reach people who have **saved your number**. That is why Prompt 2.1 and every receipt, invoice, or delivery note should say "Save my number as [Business Name] so you don't miss offers." Also: send broadcasts to labelled segments (from Part 1, Prompt 1.8), not to everybody. The bulk buyer does not need the ₦4,500 retail message — send them the wholesale price.

---

## Prompt 2.4

### Title: Write Product Captions That Make People Ask "How Much?"

**Use this when:** You post products and get zero replies, or your captions are just the product name and price.

**Copy this prompt:**

> Write 5 different captions for this product: [product name, what it does, key features, price, who it's for]. Each caption should be under 50 words and use a different angle: (1) the problem it solves, (2) a mini-story of a customer using it, (3) a surprising fact or comparison, (4) a direct offer with urgency, and (5) a question that makes the reader think about their own situation. Make each one end with a soft call to action like "Send me a DM" or "Reply 'YES' for price." The language should be natural Nigerian English, with light Pidgin only if it sounds better. No hashtags.

**Real example (filled in):**

> Write 5 different captions for this product: rechargeable standing fan, 16 inches, lasts 8–12 hours on one charge, has LED light and USB phone charging port, ₦38,000, for families and small shop owners who are tired of heat when NEPA takes light. Each caption under 50 words with a different angle: (1) problem it solves, (2) mini-story of a customer, (3) surprising fact or comparison, (4) direct offer with urgency, (5) a question that makes the reader think. Soft call to action at the end of each. Natural Nigerian English, light Pidgin only if it sounds better. No hashtags.

**Naija tip:** The caption that usually wins in Nigeria is the **comparison to a known pain**: "This fan runs 10 hours on one charge — that's one night of sleep without generator noise or ₦3,000 of fuel." Numbers + a familiar pain = replies. Test two captions on the same product on different days and notice which gets more "how much?" — then use that angle for everything.

---

## Prompt 2.5

### Title: Design a Flyer or Poster That Works (Without a Designer)

**Use this when:** You need a flyer for the neighbourhood, a poster for your shop front, or a graphic for Status — and you plan to make it yourself in Canva or a phone app.

**Copy this prompt:**

> I need a [flyer / shop poster / WhatsApp Status graphic] for my [business type] in [area], Nigeria. The goal is to [get people to visit / call / order / try a new service]. My audience is [customer type]. Write me the exact text for the design: (1) a headline of 5–8 words that stops people, (2) a sub-headline of one sentence that explains the benefit, (3) 3 bullet points of what I offer or why to choose me, (4) the offer or reason to act now, and (5) the contact line with phone/WhatsApp and location or delivery area. Then give me simple design instructions: what colours to use, what one photo to feature, where to place each text element, and what to avoid so it doesn't look crowded or cheap.

**Real example (filled in):**

> I need a flyer for my mobile car wash service in Gwarinpa, Abuja. The goal is to get estate residents to book a first wash. My audience is car owners aged 28–55 who are busy and don't want to queue at a car wash. Write the exact text: (1) a headline of 5–8 words, (2) a one-sentence sub-headline, (3) 3 bullet points, (4) the offer — first wash ₦3,000 instead of ₦4,500 this month, (5) contact line with WhatsApp 0902 190 6332 and "We come to your house." Then give simple design instructions: colours, one photo to feature, layout, and what to avoid.

**Naija tip:** One headline, one photo, one offer, one phone number. That is a flyer. Anything more and nobody reads it. Use your **real photo** (your actual product, your actual van, your actual shop) — stock images scream "not real." Print 200 flyers first (₦8,000–₦15,000 at most print shops), not 2,000, and hand them out yourself with a smile at the estate gate on Saturday morning. Track how many people mention the flyer. If fewer than 5 in 200 respond, change the offer, not the paper.

---

## Prompt 2.6

### Title: Write Your Business Story (People Buy From People)

**Use this when:** You want customers to feel connected to you — for your WhatsApp description, Instagram bio, a pinned Status, or the "About Us" on a simple website.

**Copy this prompt:**

> Help me write my business story in a way that builds trust and connection with Nigerian customers. Facts about me: [how and why you started, what problem you saw, a struggle you overcame, what you believe about your product or service, how long you've been doing it, what customers say]. Write 3 versions: (1) a 2-sentence version for a bio, (2) a 100-word version for WhatsApp Business description or pinned Status, and (3) a 250-word version for a website or flyer back page. The tone should be humble, honest, and warm — not boastful. Avoid clichés like "passion for excellence." Make it sound like a real Nigerian person telling their story, not a company.

**Real example (filled in):**

> Help me write my business story. Facts: I started my catfish farm in Ikorodu in 2021 after I lost my job at a hotel during COVID. I began with one small tank and ₦60,000 borrowed from my sister. The first batch nearly all died because I didn't understand water changes. I learnt from YouTube and an older farmer in the area. Today I have 6 tanks, supply 3 restaurants and 2 markets, and I smoke fish for people who want it dry. I believe fish should be fresh, fairly priced, and properly weighed. Customers say my fish are "always alive and always the size you promised." Write 3 versions: 2-sentence bio, 100-word description, and 250-word website version. Humble, honest, warm. No clichés.

**Naija tip:** Nigerians deeply respect the story of hustle and honesty — "I started with ₦60,000 and one tank" earns more trust than "we are the leading aquaculture solutions provider." Tell the true story, including one failure. Then pin the 100-word version as a WhatsApp Status highlight or post it on the first Monday of every month. New contacts will read it, and old customers will forward it when recommending you.

---

## Prompt 2.7

### Title: Get Customer Testimonials (And Turn Them Into Marketing)

**Use this when:** You have happy customers but no proof to show new ones — no reviews, screenshots, or videos.

**Copy this prompt:**

> I run a [business type] in Nigeria. I want to collect testimonials from happy customers and use them in my marketing. Write me: (1) a short, polite WhatsApp message asking a satisfied customer for a testimonial, making it easy for them by suggesting 2–3 things they could mention, (2) a follow-up for those who agree but haven't sent it after 3 days, (3) a message asking permission to use their words and first name (or a nickname) publicly, and (4) three ways to turn a simple text testimonial into a Status post or graphic that looks credible, not fake. Also tell me how to ask for a 15-second voice note or video testimonial without making the customer uncomfortable.

**Real example (filled in):**

> I run a small event decoration business in Enugu — balloon décor, backdrops, and table setups for birthdays and weddings. I want to collect testimonials. Write me: (1) a short polite WhatsApp message asking a satisfied customer for a testimonial with 2–3 suggested things to mention, (2) a follow-up for those who agree but haven't sent after 3 days, (3) a message asking permission to use their words and first name publicly, and (4) three ways to turn a text testimonial into a credible Status post. Also tell me how to ask for a 15-second voice note or video testimonial without making them uncomfortable.

**Naija tip:** The best time to ask is **within 24 hours of the moment they were happiest** — right after the event, right after the delivery arrived, right when they said "thank you so much." Screenshot every unprompted "thank you" or "the thing is so fine" message (crop out the phone number). A folder of 20 real screenshots is worth more than any advert in Nigeria — because everybody knows you can't easily fake 20 different WhatsApp chats.

---

## Prompt 2.8

### Title: Build a Referral System That Actually Brings Customers

**Use this when:** Most of your customers come by word of mouth, but you have no system to make it happen faster and more often.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. My average sale is ₦[amount] and my profit per sale is roughly ₦[amount]. Design a simple referral programme I can run through WhatsApp with no app or software. Include: (1) what reward to give the referrer and whether the new customer should also get something — with 3 options at different cost levels, (2) exactly how customers will refer (what they say, what they send, how I track it without confusion), (3) the message I send to existing customers announcing the programme, (4) the message I send to thank a referrer and deliver their reward, and (5) how to avoid the common problems — people claiming referrals that aren't real, forgetting to reward, or the reward eating all my profit.

**Real example (filled in):**

> I run a home cleaning service in Lekki, Lagos. Average sale is ₦25,000 per cleaning, profit roughly ₦10,000. Design a simple referral programme I can run through WhatsApp. Include: (1) what reward to give the referrer and the new customer, with 3 options at different cost levels, (2) exactly how customers will refer and how I track it, (3) the announcement message, (4) the thank-you-and-reward message, and (5) how to avoid fake claims, forgetting rewards, or the reward eating my profit.

**Naija tip:** Nigerians refer naturally — but they refer **faster** when there is something in it and when it is **easy**. The easiest system: "Tell your friend to mention your name when they book. After their first payment, you get ₦2,500 airtime / a free product / ₦3,000 off your next order." Airtime is the most-loved reward in Nigeria because it's instant and universally useful. Send the reward the same day — a delayed reward kills the programme.

---

## Prompt 2.9

### Title: Write Follow-Up Messages for People Who Asked But Didn't Buy

**Use this when:** You have a list of people who asked "how much?" and disappeared. This is money sitting in your chat list.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price]. Many people asked for the price on WhatsApp and then went quiet. Write me a 3-message follow-up sequence I can send them: (1) Day 2 — a gentle, no-pressure check-in that offers help or answers a common worry, (2) Day 5 — a message that adds value (a tip, a testimonial, or a photo idea) and reminds them the item is available, (3) Day 10 — a final message with a small incentive or a reason to act now, and a graceful "no wahala if it's not for you now." Each message under 50 words. Should feel human, never desperate or pushy. Also give me one line I can use if they reply "it's too expensive."

**Real example (filled in):**

> I sell wigs and hair bundles in Port Harcourt, ₦35,000–₦120,000. Many people asked for price on WhatsApp and went quiet. Write me a 3-message follow-up sequence: (1) Day 2 gentle check-in offering help or answering a common worry (like "is it human hair?"), (2) Day 5 value message — a care tip, testimonial, or styling idea, and a reminder it's available, (3) Day 10 final message with a small incentive and a graceful "no wahala." Each under 50 words, human, never desperate. Also one line for when they reply "it's too expensive."

**Naija tip:** In Nigeria, "I'll get back to you" usually means one of three things: no money *yet*, waiting for salary, or checking elsewhere. A gentle Day 5 message that lands around the 25th–28th of the month (salary time) converts remarkably well. Never send "Hello? Are you still interested?" — it sounds like a debt collector. Send value instead: "Just posted a video of how this wig looks after 3 washes — thought you'd want to see."

---

## Prompt 2.10

### Title: Launch a New Product or Service Without a Budget

**Use this when:** You are introducing something new and you want buzz, pre-orders, or first customers using only your existing contacts and WhatsApp.

**Copy this prompt:**

> I am launching [new product/service] for my [business type] in [area], Nigeria, on [date]. Price: ₦[amount]. Who it's for: [customer type]. Why it's valuable: [key benefits]. Create a 7-day launch plan using only WhatsApp Status, broadcasts, and personal messages — zero ad spend. For each day give me: the goal, what to post on Status (with a caption), and any direct messages to send. Include a teaser phase, a pre-order or early-bird offer, the launch-day announcement, social proof from first buyers, and a final "closing soon" push. Also suggest one small, cheap incentive for the first 10 buyers.

**Real example (filled in):**

> I am launching a weekly "Soup Pot" subscription for my food business in Yaba, Lagos, on Monday next week — customers get a 2-litre pot of egusi, efo riro, or ogbono delivered every Saturday for ₦7,500/week. It's for busy workers and students who don't have time to cook soup. Benefits: home taste, fresh ingredients, saves 3 hours every weekend, cheaper than eating out. Create a 7-day launch plan using only WhatsApp Status, broadcasts, and personal messages — zero ad spend. Include teaser, early-bird offer, launch-day announcement, social proof, and closing push. Suggest one cheap incentive for the first 10 subscribers.

**Naija tip:** Get **5 people to pay before you announce publicly** — friends, loyal customers, family who will genuinely use the thing. Then your launch-day post can honestly say "5 spots already gone" and include a real screenshot of a payment or a happy message. Nigerians move when they see other Nigerians moving. Nobody wants to be the first — everybody wants to be the sixth.

---

## Prompt 2.11

### Title: Create Instagram / TikTok Content Ideas You Can Film With Your Phone

**Use this when:** Your product is visual (food, fashion, beauty, décor, crafts) and you want to grow on Instagram or TikTok without a camera crew or editing skills.

**Copy this prompt:**

> I run a [business type] in Nigeria selling [products] to [audience]. Give me 15 short-video ideas (15–45 seconds each) I can film alone with my phone for Instagram Reels or TikTok. For each: the idea, a hook for the first 3 seconds (spoken or on-screen text), what to show, and a caption. Mix: process/behind-the-scenes, before-and-after, "things people don't know about [my product]", customer reactions, day-in-the-life, common mistakes people make, price reveal, and packaging an order. Ideas should suit Nigerian viewers — use situations, humour, and references they'll recognise. Tell me which 3 to film first.

**Real example (filled in):**

> I run a small shoemaking business in Aba — handmade leather sandals, loafers, and slides for men, ₦8,000–₦25,000. Audience: Nigerian men 22–45 who want quality made-in-Nigeria shoes, and women buying for husbands/boyfriends. Give me 15 short-video ideas I can film alone with my phone. For each: idea, 3-second hook, what to show, caption. Mix process, before-and-after, things people don't know about Aba-made shoes, customer reactions, day-in-the-life, common mistakes, price reveal, packaging an order. Suit Nigerian viewers. Tell me which 3 to film first.

**Naija tip:** The **process video** is king for Nigerian makers — people are amazed to watch a sandal, a cake, or a gown come to life, and it quietly kills the "is it original / is it really handmade?" objection. Film in natural daylight, hold the phone steady, and add trending Nigerian audio (Afrobeats, a viral skit sound). Post 3–4 times a week for 8 weeks before you judge results. Consistency beats quality at the start.

---

## Prompt 2.12

### Title: Write Festive and Seasonal Campaigns (Christmas, Sallah, Easter, Back-to-School, Valentine's)

**Use this when:** A season or festival is coming and you want a plan — not just a "Happy Sallah" graphic on the day.

**Copy this prompt:**

> [Festival/season] is coming in [number] weeks. I run a [business type] in [area], Nigeria, selling [products/services]. Create a simple 3-week campaign plan for me. Include: (1) what to offer — a bundle, gift pack, pre-order, or special edition that fits this season and my products, (2) the pricing and any early-bird deal, (3) a week-by-week plan for WhatsApp Status and broadcasts with sample captions, (4) how to handle the rush — order cut-off date, deposits, delivery planning, (5) a message for after the festival to thank buyers and keep them coming back. Consider Nigerian realities like travel, salary timing, and price increases in the market.

**Real example (filled in):**

> Christmas is coming in 5 weeks. I run a small frozen foods and grocery shop in Warri, selling chicken, turkey, fish, rice, oil, and drinks. Create a 3-week campaign plan. Include: (1) what to offer — hampers, bulk deals, or pre-order packs for families, (2) pricing and early-bird deal, (3) week-by-week plan for WhatsApp Status and broadcasts with captions, (4) how to handle the rush — cut-off dates, deposits, delivery, (5) a thank-you message for after Christmas. Consider people travelling to villages, salary and bonus timing, and market prices going up in December.

**Naija tip:** In Nigeria, the money for December is spent between the **20th and 24th**; for Sallah, in the 5 days before. Start marketing **3 weeks early** and collect deposits — it protects you from price spikes in the market (buy your stock at today's price with their money) and locks the customer in before your competitor's post appears. And "pre-order to secure your turkey" sells better than "turkey available."

---

## Prompt 2.13

### Title: Reply to Comments and DMs in a Way That Converts

**Use this when:** People comment "how much?", "DM price", "still available?", or "is it original?" and your replies aren't leading to sales.

**Copy this prompt:**

> I sell [product/service] in Nigeria. Give me smart, friendly replies to these common comments and DMs that lead toward a sale instead of ending the conversation: (1) "How much?" (2) "Send price." (3) "Is it original?" (4) "Still available?" (5) "Location?" (6) "Do you deliver to [far city]?" (7) "Last price?" (8) "I'll get back to you." (9) "Do you have it in another colour/size?" (10) "Can I pay on delivery?" Each reply should be 1–3 sentences, answer the question, and include a next step or question that keeps them engaged. Sound like a real, warm Nigerian seller — not a robot or a hype man.

**Real example (filled in):**

> I sell affordable men's native wear (senator, kaftan, agbada) in Kaduna, ₦15,000–₦60,000, and deliver nationwide through GIG and dispatch riders. Give me smart, friendly replies to: "How much?", "Send price", "Is it original fabric?", "Still available?", "Location?", "Do you deliver to Lagos?", "Last price?", "I'll get back to you", "Do you have it in another colour/size?", and "Can I pay on delivery?" Each 1–3 sentences, answers the question, and includes a next step. Warm Nigerian seller tone, not a robot or hype man.

**Naija tip:** Never reply "DM for price" publicly — it annoys Nigerians and looks like you're hiding something. State the price and immediately add a question: "₦18,000 with free delivery in Kaduna. Which colour do you like — navy or wine?" The question moves them from spectator to participant. For "pay on delivery," have a clear policy (e.g., "POD within Kaduna only; outside Kaduna, ₦2,000 commitment fee") and state it kindly — it filters out unserious buyers.

---

## Prompt 2.14

### Title: Partner With Other Local Businesses (Cross-Promotion)

**Use this when:** You want to reach new customers through businesses that serve the same people but don't compete with you.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, serving [customer type]. Suggest 8 types of local businesses that serve the same customers but don't compete with me, and for each, one specific partnership idea — such as flyer exchange, a joint bundle, referral commission, sharing each other's Status, or a small event. Then write me: (1) a short, respectful WhatsApp or in-person opening line to approach a business owner about partnering, (2) a simple description of the deal that makes it clearly fair for both sides, and (3) how to test the partnership for 30 days and measure if it's working. Keep everything low-cost and simple enough to manage on WhatsApp.

**Real example (filled in):**

> I run a children's clothing and school-uniform shop in Ikeja, Lagos, serving parents of kids aged 2–14. Suggest 8 types of local businesses that serve the same parents but don't compete with me — e.g., crèches, children's barbers, paediatric clinics, party planners — with one specific partnership idea each. Then write: (1) a respectful opening line to approach the owner, (2) a simple, fair deal description, and (3) how to test it for 30 days and measure results.

**Naija tip:** In Nigeria, partnerships work when they are **personal and small**. Don't propose a "strategic alliance" — propose "I'll keep your flyers at my counter and mention you to every parent; you do the same for me. Let's try it till end of month." Bring something when you go — a small gift or a sample. Relationship first, business second. The crèche owner who likes you will send you 20 parents in one term.

---

## Prompt 2.15

### Title: Market Your Business Through Church, Mosque and Community Groups (Respectfully)

**Use this when:** You belong to a church, mosque, estate association, alumni group, or trade union, and you want to promote your business without being the annoying person who spams the group.

**Copy this prompt:**

> I run a [business type] in Nigeria and I'm a member of [type of community: church, mosque, estate WhatsApp group, alumni group, professional association, women's fellowship, etc.]. I want to grow my business through this community without offending anyone or seeming like I only came to sell. Give me: (1) 5 respectful, low-key ways to make my business known within the community, (2) how often I should mention my business in the group chat, and what kind of messages are acceptable, (3) a short introduction message for the group that presents my business humbly and offers members something special, (4) how to serve community members so well that they become my sales team, and (5) mistakes that make people mute or resent business owners in such groups.

**Real example (filled in):**

> I run a small travel and visa consultancy in Lagos and I'm an active member of my church's young adults' fellowship (about 300 members, active WhatsApp group) and my estate's residents' group. I want to grow through these communities without being annoying. Give me: (1) 5 respectful ways to make my business known, (2) how often to mention it and what messages are acceptable, (3) a humble introduction message with a special offer for members, (4) how to serve members so well they become my sales team, and (5) mistakes that make people mute or resent business owners in such groups.

**Naija tip:** The rule is **serve first, sell rarely**. Answer questions in the group generously, for free, without pitching. When someone asks "does anyone know a good travel agent?" — let another member recommend you. That happens when you have been quietly helpful for weeks. Post your business once a month at most in general groups, and always with a members-only benefit. Never send private DMs to group members who haven't spoken to you — that's the fastest way to get reported to the admin.

---

## Prompt 2.16

### Title: Run a Small, Smart Giveaway or Promo That Brings Real Customers

**Use this when:** You want to run a giveaway or promotion but you've seen others attract only freebie-hunters who never buy.

**Copy this prompt:**

> I run a [business type] in Nigeria selling [products] at around ₦[price range]. I want to run a giveaway or promotion with a budget of no more than ₦[amount] that attracts people who are likely to become paying customers — not just freebie-hunters. Design it for me: (1) what to give away (something only a real potential customer would want), (2) the entry rule that gets me something useful — a saved contact, a referral, a testimonial, a small purchase, or a question answered, (3) the announcement message and the winner announcement message, (4) how long it should run, and (5) how to follow up with everyone who entered but didn't win, to turn them into customers. Make it simple to run on WhatsApp alone.

**Real example (filled in):**

> I run a small perfume and body-mist business in Ibadan, products ₦4,000–₦18,000. I want to run a giveaway with a budget of no more than ₦20,000 that attracts real potential customers. Design it: (1) what to give away, (2) an entry rule that gets me something useful — saved contacts, referrals, testimonials, or a small purchase, (3) announcement and winner-announcement messages, (4) how long it runs, and (5) how to follow up with everyone who didn't win. Simple to run on WhatsApp alone.

**Naija tip:** The smartest Nigerian giveaway entry rule is **"buy anything, even ₦1,000, to enter"** or **"send me the name of someone who'd love this, and I'll message them with your greeting."** Both filter out professional freebie-hunters. And the real prize of a giveaway is not the winner — it's the **50 people who now have your number saved and just got a "sorry you didn't win, here's ₦1,000 off this week" message**. That is where the sales are.

---

## Prompt 2.17

### Title: Turn One-Time Buyers Into Repeat Customers

**Use this when:** People buy once and vanish. You're spending all your energy finding new customers instead of keeping the ones you have.

**Copy this prompt:**

> I run a [business type] in Nigeria. Customers typically buy [product/service] and then I don't hear from them for [how long / never]. The natural repeat cycle for my product is roughly [every week / month / 3 months / occasion-based]. Design a simple repeat-customer system I can run on WhatsApp: (1) what to say and do right after the first purchase to set up the next one, (2) a reminder message timed to when they'd naturally need me again, (3) a small loyalty reward after 3 or 5 purchases that doesn't kill my margin, (4) a "we miss you" message for customers who haven't bought in a long time, and (5) how to keep track of all this using only WhatsApp labels, a notebook, or a simple phone spreadsheet.

**Real example (filled in):**

> I run a barbing salon in Surulere, Lagos. Customers get a cut (₦2,500–₦5,000) and many don't return regularly — some come back in 2 weeks, some disappear for months, some go to whichever barber is nearest. Natural repeat cycle is 2–3 weeks. Design a repeat-customer system on WhatsApp: (1) what to say and do right after the cut, (2) a reminder timed for 2–3 weeks later, (3) a loyalty reward after 5 cuts, (4) a "we miss you" message for those gone 2+ months, and (5) how to track it simply.

**Naija tip:** It costs 5–7 times more to get a new customer than to keep one — and in Nigeria, where trust is slow to build, a customer who has already paid you once is gold. The simplest loyalty tool is still the **paper card with 5 boxes** ("5th cut free" / "5th order gets free delivery"). It works because Nigerians love a visible progress and a promised reward. Combine it with a WhatsApp reminder, and you have a system.

---

## Prompt 2.18

### Title: Write an Ad Script for Radio or a Voice Note Advert

**Use this when:** You want to advertise on local radio (still powerful in many Nigerian towns), or create a short voice note/audio advert to send on WhatsApp or play in your shop.

**Copy this prompt:**

> Write me a [30 / 45 / 60]-second [radio / voice note] advert script for my [business type] in [area], Nigeria. We sell [products/services] to [audience]. Key things to mention: [main benefit, one offer, phone number, location or delivery area]. The script should: start with a hook that grabs attention in the first 5 seconds, sound like a real conversation or a relatable situation, be in simple Nigerian English (a little Pidgin is fine if it fits), repeat the phone number twice, and end with a clear call to action. Give me 2 versions: one with a single speaker, and one as a short dialogue between two people. Mark where a jingle or sound effect could go.

**Real example (filled in):**

> Write me a 45-second radio advert script for my agro-input shop in Makurdi, Benue State. We sell improved seeds, fertiliser, herbicides, and knapsack sprayers to farmers. Key things: original products only (no fake fertiliser), fair prices, free advice on which seed suits which soil, phone 0902 190 6332, located opposite Wurukum Market. Hook in first 5 seconds, relatable situation, simple Nigerian English with a little Pidgin, phone number twice, clear call to action. Two versions: single speaker and a short dialogue. Mark jingle/sound effect spots.

**Naija tip:** Local radio in towns like Makurdi, Ilorin, Sokoto, or Owerri can cost as little as ₦3,000–₦15,000 per slot and reaches people who are never on Instagram. Ask the station for their **early morning (6–8am) and evening (5–7pm) local-language slots** — those are when traders and farmers listen. Better still, record the script as a **WhatsApp voice note** first (free), send it to 50 customers, and see who responds before paying the radio station.

---

## Prompt 2.19

### Title: Create a Simple Monthly Marketing Plan You'll Actually Follow

**Use this when:** You do marketing "when you remember" and want a simple, realistic routine that fits around running the business.

**Copy this prompt:**

> I run a [business type] in Nigeria. I have about [number] hours per week for marketing and a monthly budget of ₦[amount, or 0]. My main channels are [WhatsApp Status, broadcasts, Instagram, referrals, community groups — pick yours]. Create a simple monthly marketing plan I can realistically follow. Include: (1) a daily 15-minute routine, (2) a weekly 1-hour task, (3) two monthly activities (like a promo, a partnership, or a testimonial round-up), (4) what to track each week to know if it's working — using numbers I can count myself, such as new contacts saved, replies, orders, referrals, and (5) a simple rule for what to do if a month's results are poor. Make it fit a busy person who also serves customers all day.

**Real example (filled in):**

> I run a small pharmacy/patent medicine store in Nsukka. I have about 4 hours per week for marketing and a budget of ₦10,000 monthly. Main channels: WhatsApp Status, broadcasts to labelled customers, and my church women's group. Create a simple monthly marketing plan: (1) daily 15-minute routine, (2) weekly 1-hour task, (3) two monthly activities, (4) what to track each week using numbers I can count myself, and (5) a rule for what to do if results are poor. Fit a busy person serving customers all day.

**Naija tip:** Marketing that fits in 15 minutes a day gets done. Marketing that needs a "free afternoon" never happens in Nigeria. The 15-minute routine: post 2 Statuses, reply to every pending message, send 3 follow-ups or thank-yous, save 2 new numbers with proper names. That's it. Do it while your food is warming or in the quiet hour after lunch. Track one number above all: **how many new people messaged you this week**. If it's going up, keep going.

---

## Prompt 2.20

### Title: Review Your Marketing Honestly and Fix What's Not Working

**Use this when:** You've been marketing for a month or more and want to know what to keep, what to change, and what to stop — based on evidence, not feelings.

**Copy this prompt:**

> Here is a summary of my marketing for the past [30 / 60 / 90] days for my [business type] in Nigeria: [what you did — channels, how often, any promos]. Here are the results I can count: [new contacts, enquiries/replies, orders, revenue, referrals, testimonials collected, money spent]. Here is what felt like it worked and what felt like a waste: [your honest impressions]. Analyse this like an experienced marketing adviser who understands Nigerian small businesses. Tell me: (1) what is clearly working and should get more of my time, (2) what is clearly not working and should stop, (3) what I can't judge yet and should test properly, (4) the one change most likely to increase enquiries next month, and (5) a simpler plan for the next 30 days based on all of this.

**Real example (filled in):**

> Summary of my marketing for the past 60 days for my small furniture-making workshop in Nnewi: posted on WhatsApp Status almost daily (about 45 days), sent 4 broadcasts, posted on Instagram 8 times, printed 300 flyers and shared at two estates, asked 6 customers for referrals. Results: 38 new contacts saved, 22 enquiries, 7 orders worth ₦1.1M total, 3 referrals, 4 testimonials, ₦18,000 spent (flyers + data). Felt like: Status got most enquiries; flyers got 1 call; Instagram got likes but no orders; referrals brought the two biggest orders. Analyse this as an experienced marketing adviser. Tell me: (1) what's working, (2) what to stop, (3) what to test properly, (4) the one change most likely to increase enquiries next month, and (5) a simpler 30-day plan.

**Naija tip:** Most Nigerian small businesses discover the same thing when they finally count: **80% of orders come from 20% of the marketing effort** — usually WhatsApp Status plus referrals. Doing this review once a month gives you permission to stop the things that only feel productive (endless Instagram posting, flyers nobody reads) and double down on what pays. Write the numbers in the Bonus tracker at the back of this book. What you count, you improve.

---

## Part 2 Checkpoint

Before moving to Part 3, make sure you have **done** (not just read) these five things:

1. Your WhatsApp Business profile is complete — About, description, catalogue, greeting message. *(Prompt 2.1)*
2. You have at least 14 days of Status content planned and are posting daily. *(Prompt 2.2)*
3. You have a folder of at least 5 real testimonials or screenshots. *(Prompt 2.7)*
4. Your referral offer exists and at least 10 customers know about it. *(Prompt 2.8)*
5. Your 3-message follow-up sequence is saved and you've sent it to everyone who "went quiet" this month. *(Prompt 2.9)*

If those five are in place, enquiries will rise. The next challenge is turning enquiries into money — handling "last price?", "I'll come back", and "it's too expensive" without losing the sale or your profit.

**Next: Part 3 — Sales, Negotiation & Closing More Deals (Prompts 3.1 – 3.20)**
