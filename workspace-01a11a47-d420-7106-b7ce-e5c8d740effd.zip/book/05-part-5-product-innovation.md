# PART 5: PRODUCT INNOVATION & NEW REVENUE STREAMS
*(Prompts 5.1 – 5.20)*

---

## More Money From What You Already Have

By now you know your customer (Part 1), you can reach them cheaply (Part 2), you can close them (Part 3), and your costs are under control (Part 4). Now we grow the top line — and we do it the smart way.

The mistake most Nigerian business owners make when they want more income is to start something completely new: the hairdresser opens a provisions shop, the tailor starts selling phones. New business, new customers, new problems, new capital — and the old business suffers.

The smarter path is **adjacent growth**: new products, offers and income streams that sit next to what you already do, sell to customers you already have, and use skills, space, stock and trust you already own. A salon that adds a hair-products line. A caterer who sells frozen soup packs. A tailor who teaches a Saturday sewing class. A printer who sells digital templates. A poultry farmer who offers a monthly egg subscription.

Every idea in this Part is filtered through four questions:

1. **Do my existing customers want it?**
2. **Can I test it for under ₦50,000?**
3. **Does it use what I already have?**
4. **Does it improve my margin, my cash flow, or both?**

Some of these streams will be small — an extra ₦40,000 a month. Some will become bigger than your original business. You won't know which until you test. That's what the prompts are for.

**Start with 5.1, 5.2 and 5.7** — the idea generator, the bundle builder, and the "sell the knowledge" prompt. Between them, most businesses find their next ₦500,000.

---

## Prompt 5.1

### Title: Generate New Product and Service Ideas From What You Already Have

**Use this when:** You want to grow revenue but don't know what to add — and you want ideas that fit your business, not random ones.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. What I currently sell: [list]. My customers are: [describe]. What I already have that could be used differently: [skills, equipment, space, suppliers, stock, staff, time slots when I'm quiet, relationships]. What customers often ask for that I don't offer: [list]. Generate 15 ideas for new products, services or income streams that: use what I already have, appeal to my existing customers, and can be tested for under ₦50,000. For each, give: the idea in one line, who buys it, estimated price, why it fits my business, and a difficulty score out of 5. Then rank the top 5 by likely profit and ease, and tell me which ONE to test first.

**Real example (filled in):**

> I run a unisex salon in Ikeja, Lagos. I currently sell braiding, weaving, wig installation, barbing, nails, and pedicure. Customers are women 20–45 and men 18–40, mostly working class and young professionals. What I have: 3 stylists with strong skills, a shop that's quiet Monday–Wednesday mornings, a good supplier of hair and products, a WhatsApp list of about 400 customers, and a small back room. Customers often ask: where to buy good wigs, how to maintain braids, whether I do home service, and whether I can train their younger sister. Generate 15 ideas that use what I have, appeal to my customers, and cost under ₦50,000 to test. Give price, buyer, fit, and difficulty for each. Rank the top 5 and tell me which one to test first.

**Naija tip:** The best ideas usually come from the **"customers often ask for"** list — they are already telling you what to sell. The second best come from your **quiet hours**: a salon empty on Monday mornings is wasted rent, so fill it with a training class, a discounted "Monday Madness" slot, or a product-sales morning. Never launch more than one new idea at a time; test it for 30 days, then decide.

---

## Prompt 5.2

### Title: Create Bundles and Packages That Raise Your Average Sale

**Use this when:** Customers buy one item at a time and your average sale is stuck. Bundles are the fastest, cheapest revenue lever in any business.

**Copy this prompt:**

> I run a [business type] in Nigeria. Products/services and prices: [list with cost prices if possible]. My average sale is currently ₦[amount]. Design 5 bundles or packages that increase the average sale while giving customers a real reason to choose the bundle. For each bundle: a catchy Nigerian-friendly name, what's included, the individual total, the bundle price, the customer's saving, my profit on the bundle versus selling items separately, and who it's perfect for. Include: a starter bundle, a premium bundle, a gift bundle, a seasonal or occasion bundle, and a "buy more, save more" quantity deal. Then write the one-line pitch for each and tell me where to display them.

**Real example (filled in):**

> I run a natural skincare business in Abuja. Products and cost/selling prices: black soap ₦1,200/₦2,500; shea butter cream ₦1,500/₦3,500; turmeric face scrub ₦1,300/₦3,000; rosewater toner ₦900/₦2,500; lip balm ₦400/₦1,200; body oil ₦1,600/₦4,000. Average sale is ₦3,200. Design 5 bundles that raise the average sale: a starter bundle, a premium bundle, a gift bundle, a seasonal bundle (e.g., harmattan skin rescue), and a "buy more, save more" deal. For each: catchy name, contents, individual total, bundle price, customer saving, my profit vs. separate sales, ideal buyer, one-line pitch. Tell me where to display them.

**Naija tip:** Nigerians love a **named package** — "The Glow-Up Box," "Harmattan Rescue Kit," "Bride's Prep Set" — far more than "3 items for ₦8,000." The name makes it a *thing* people ask for by name. Price bundles so the saving is visible (show the "was ₦9,000, now ₦7,500") but your profit per transaction still rises. And always have one **premium bundle** — some customers want to spend more, and you should let them.

---

## Prompt 5.3

### Title: Add a Premium Version of What You Already Sell

**Use this when:** You sell at one price point, and some customers would happily pay more for something better, faster or more exclusive — but you've never offered it.

**Copy this prompt:**

> I run a [business type] in Nigeria and currently sell [main product/service] at ₦[price]. Help me create a premium version that some customers will pay 50–150% more for. Suggest: (1) 6 ways to make it genuinely premium — better materials, faster delivery, personalisation, exclusive access, extra service, superior packaging, guarantee, priority slots, (2) the best combination of 2–3 of these for my type of customer, (3) a name and a price for the premium version, (4) how to present standard and premium side by side so the premium looks attractive without making the standard look bad, and (5) how to test whether customers want it before investing heavily.

**Real example (filled in):**

> I run a cake business in Enugu and currently sell an 8-inch buttercream birthday cake at ₦18,000. Help me create a premium version customers will pay 50–150% more for. Suggest 6 ways to make it genuinely premium (e.g., fondant finishing, custom toppers, same-day priority, a matching cupcake box, luxury packaging with a personal card, delivery with a photographer moment), the best 2–3 for my customers (young professionals and mothers celebrating children's birthdays), a name and price, how to present standard vs. premium side by side, and how to test demand before investing.

**Naija tip:** There is always a customer who wants **"the best one you have."** If you don't have a "best one," they buy it elsewhere. The premium tier also does something quiet: it makes your standard price feel reasonable ("₦18,000? That's the *normal* one"). Present three options where possible — Good, Better, Best — and most Nigerians pick the middle. That's fine: you've just raised your average sale.

---

## Prompt 5.4

### Title: Launch a Subscription or Repeat-Order Plan

**Use this when:** Your product is consumed regularly (food, eggs, water, toiletries, hair care, drinks, data, cleaning) and you want predictable weekly or monthly income instead of hoping people come back.

**Copy this prompt:**

> I run a [business type] in Nigeria selling [product/service] that customers typically buy every [frequency]. Design a subscription or standing-order plan for me. Include: (1) 2–3 plan options (e.g., weekly, fortnightly, monthly) with what's delivered and a price that rewards commitment but protects my margin, (2) how to collect payment in Nigeria simply — upfront monthly transfer, standing instruction, or a payment link — and how to handle missed payments, (3) how to manage delivery days and communicate schedules on WhatsApp, (4) the launch message to existing customers, (5) how to handle pauses, changes and cancellations without stress, and (6) how many subscribers I need for this to be worth running.

**Real example (filled in):**

> I run a poultry farm in Ogun State selling crates of eggs (₦4,800 per crate) and live/dressed chickens to families, restaurants and small shops in Abeokuta and Sango. Customers typically buy eggs weekly or fortnightly. Design an egg (and optional chicken) subscription: 2–3 plan options with pricing, how to collect payment monthly in Nigeria and handle missed payments, delivery-day scheduling on WhatsApp, the launch message to my existing customers, how to handle pauses and cancellations, and how many subscribers make it worthwhile.

**Naija tip:** Subscriptions work in Nigeria when they are **prepaid** ("pay ₦18,000 for 4 weekly crates, save ₦1,200") and delivered on a **fixed day** ("Every Saturday morning"). Prepayment gives you cash flow to buy feed or stock; the fixed day makes delivery cheap. Start with 10 loyal customers — it feels small but it's ₦180,000 guaranteed on the first of the month, before you sell anything else.

---

## Prompt 5.5

### Title: Create Seasonal and Festive Products That Sell Out

**Use this when:** You want to make the most of Christmas, Sallah, Easter, Valentine's, Mother's Day, back-to-school, Detty December, harmattan, rainy season — with products designed for the moment.

**Copy this prompt:**

> I run a [business type] in Nigeria. The next big occasion is [festival/season] in [number] weeks. Suggest 8 seasonal products, packages or services that fit both my business and the occasion — gift-ready, occasion-specific, or solving a seasonal problem. For each: name, contents, price, cost estimate, who buys it, and how many I should make/stock for a first run. Then tell me: the ideal timing to announce, open pre-orders, and stop taking orders; how to package it so it looks gift-worthy on a small budget; and how to sell leftover stock after the occasion without looking desperate.

**Real example (filled in):**

> I run a small honey, spices and natural foods business in Kano. The next big occasion is Sallah in 6 weeks. Suggest 8 seasonal products or packages that fit — for example Sallah gift hampers, ram-seasoning spice packs, a "Sallah Kitchen Box", corporate gift boxes for offices, a date-and-honey gift set. For each: name, contents, price, cost, buyer, first-run quantity. Tell me when to announce, open pre-orders and close orders; how to package gift-worthy on a small budget; and how to sell leftovers after Sallah.

**Naija tip:** Seasonal products have a **3-week selling window** — miss it and you're holding stock for a year. Announce 4 weeks out, take **pre-orders with deposits** 3 weeks out, and close orders 5 days before the day. Corporate gift hampers are the hidden goldmine: one company ordering 30 hampers at ₦15,000 is ₦450,000 from a single WhatsApp conversation. Ask the AI to write that corporate pitch too.

---

## Prompt 5.6

### Title: Find Under-Served Customers Your Business Could Serve

**Use this when:** Your current market feels saturated and you want to find a group nobody is serving properly — with what you already do, slightly adapted.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, currently serving [current customers]. Identify 6 customer groups in my area or online that are probably under-served for my type of product/service — for example: corporate clients, schools, churches/mosques, estates, hospitals, hotels, students, the elderly, people with specific dietary or cultural needs, diaspora Nigerians buying for family at home, other businesses (B2B). For each group: what they'd need from me that's slightly different, how big the opportunity might be, how to reach them, what objection they'd have, and one small adaptation I'd need to make. Then pick the best two and outline a 30-day plan to win the first customer in each.

**Real example (filled in):**

> I run a laundry and dry-cleaning business in Wuse, Abuja, currently serving individual walk-in customers and a few families. Identify 6 under-served groups I could serve — such as hotels and guest houses, hospitals and clinics (staff uniforms and linen), salons and spas (towels), corporate offices, estates, and diaspora Nigerians who want laundry service arranged for elderly parents in Abuja. For each: what they'd need that's different, opportunity size, how to reach them, likely objection, one adaptation. Pick the best two and give me a 30-day plan to win the first customer in each.

**Naija tip:** **B2B is the fastest way to multiply revenue** without multiplying marketing — one hotel is 50 families' worth of laundry. To win them: offer a **free trial week**, show up in person with a one-page proposal (Prompt 3.11), and emphasise reliability over price. And don't ignore the diaspora angle: Nigerians abroad pay in dollars for anyone who reliably takes care of their parents' food, laundry, medicine or errands back home.

---

## Prompt 5.7

### Title: Turn Your Skill or Knowledge Into a Paid Class, Workshop or Training

**Use this when:** People keep asking "can you teach me?" — and you've been giving it away for free.

**Copy this prompt:**

> I run a [business type] in Nigeria and I'm skilled at [what you do well]. People often ask me to teach them. Help me create a paid training offer. Give me: (1) 3 formats to consider — a one-day physical workshop, a 4-week weekend class, an online WhatsApp/Zoom class — with pros and cons for my situation, (2) a course outline for the best format: sessions, what's taught in each, what students go home able to do, (3) pricing for Nigeria (with an early-bird and a payment-plan option) and how many students I need per batch, (4) what to include (materials, certificate, starter kit, WhatsApp support group) to justify the price, (5) the announcement message for WhatsApp Status, and (6) how to turn graduates into future customers, suppliers, or staff.

**Real example (filled in):**

> I run a small-chops and finger-foods business in Port Harcourt and I'm very good at making puff-puff, samosa, spring rolls, and mini-pies with consistent quality. People often ask me to teach them. Help me create a paid training offer: 3 formats with pros and cons, a course outline for the best one (sessions, skills, outcomes), Nigerian pricing with early-bird and payment plan and minimum students per batch, what to include to justify the price, the WhatsApp Status announcement, and how to turn graduates into customers, suppliers, or staff.

**Naija tip:** In Nigeria, **skills training is a huge market** — youths, NYSC members, housewives and retirees all want a "handwork." A one-day physical class at ₦15,000–₦35,000 with 10–15 students can earn more than a week of sales. Add a **certificate** (make one in Canva) and a **starter kit**; both raise the perceived value enormously. Photograph every class — those photos market the next batch.

---

## Prompt 5.8

### Title: Create a Digital Product You Can Sell Repeatedly

**Use this when:** You want income that doesn't require your hands every time — an eBook, template pack, recipe guide, price list, checklist, video course, or planner based on what you already know.

**Copy this prompt:**

> I run a [business type] in Nigeria and I know a lot about [your expertise]. Help me create a digital product I can sell repeatedly with no extra production cost. Suggest 5 digital product ideas (eBook, guide, template, checklist, mini video course, planner, recipe pack, price calculator), each with: title, who buys it, what problem it solves, price in naira (and USD for diaspora buyers), and how long it would take me to create with AI's help. Pick the best one and give me: a full outline, how to create it using free tools (Google Docs, Canva, phone video), how to deliver it after payment (Selar, Paystack link + WhatsApp, Gumroad), and a launch plan for my existing WhatsApp contacts.

**Real example (filled in):**

> I run a home tutoring and lesson-teaching business in Lagos and I know a lot about helping SS3 students pass WAEC Mathematics and preparing JAMB candidates. Help me create a digital product I can sell repeatedly: 5 ideas (e.g., "WAEC Maths: 50 Must-Know Questions Explained", a JAMB 8-week study planner, a parent's guide to supporting a WAEC candidate, a video mini-course on the 10 hardest topics), each with title, buyer, problem solved, naira and USD price, and time to create with AI's help. Pick the best one and give me a full outline, how to create it with free tools, how to deliver after payment, and a launch plan for my WhatsApp contacts.

**Naija tip:** You are reading a digital product right now — proof the model works. Selar and Paystack storefronts handle Nigerian payments and automatic delivery; Gumroad works for international buyers. Price digital products in Nigeria between ₦2,000 and ₦15,000 for most audiences, and always create a **free mini-version** (2 pages, one checklist) to give away on Status — it's the best advert for the paid one.

---

## Prompt 5.9

### Title: Add Complementary Products Your Customers Already Buy Elsewhere

**Use this when:** Your customers leave your shop and go to buy something related from someone else — money that could have been yours.

**Copy this prompt:**

> I run a [business type] in Nigeria selling [products/services] to [customers]. Think about the complete journey of my customer around my product — what they buy before, alongside, and after. List 12 complementary products or services my customers probably buy from someone else right now. For each: how it relates to what I sell, estimated price and margin, whether I should stock it, resell it on commission, or partner with a supplier, and the risk (space, capital, spoilage, expertise). Then choose the best 4 to add first, estimate the extra monthly revenue if just 20% of my customers buy them, and write the line I'd use to introduce each at the point of sale.

**Real example (filled in):**

> I run a phone sales and repair shop in Ilorin selling new and UK-used phones and doing screen and battery repairs, to students, traders and young workers. List 12 complementary products or services my customers currently buy elsewhere — e.g., screen protectors, cases, chargers, power banks, earphones, memory cards, SIM registration help, data subscriptions, phone insurance, laptop repair referrals, phone swap/trade-in, and software setup. For each: relationship to my sales, price and margin, stock vs. commission vs. partner, and risk. Choose the best 4, estimate extra monthly revenue if 20% of my roughly 300 monthly customers buy them, and write my point-of-sale line for each.

**Naija tip:** The moment someone buys a phone from you, they are in **buying mode** — "You'll need a screen protector and case for this one; I'll give you both for ₦3,000 instead of ₦4,000" converts more than half the time. Attach rate is the metric: how many of your phone buyers also buy an accessory? Move it from 20% to 60% and you may double your profit without one extra customer.

---

## Prompt 5.10

### Title: Explore Print-on-Demand, Branded Merchandise and Custom Items

**Use this when:** You have a brand, a following, a church/school/community, or a design skill — and want to sell branded T-shirts, mugs, caps, tote bags, notebooks, or custom items without holding stock.

**Copy this prompt:**

> I run a [business type / community / creative brand] in Nigeria with [audience size and type]. I'm interested in selling branded or custom merchandise. Help me: (1) suggest 8 merchandise items that would sell to my audience, with realistic Nigerian production costs and selling prices, (2) explain how to run this without holding stock — pre-orders in batches, local printers who do small runs, or print-on-demand services accessible from Nigeria, (3) identify occasions and campaigns that drive merch sales (anniversaries, events, church programmes, school colours, "Naija pride" moments, staff uniforms for other businesses), (4) design ideas or slogans that would resonate with my audience, and (5) a pre-order launch plan that ensures I collect money before I print.

**Real example (filled in):**

> I run a fitness bootcamp in Lekki with about 120 active members and 3,000 Instagram followers. I want to sell branded merchandise. Help me: suggest 8 items with Nigerian production costs and prices (e.g., dri-fit tees, caps, gym towels, water bottles, resistance bands, tote bags), how to run it with pre-orders and small-batch local printers, occasions that drive sales (bootcamp anniversary, 30-day challenge completion, December fitness fest), design and slogan ideas that resonate with Lagos fitness people, and a pre-order launch plan so I collect money before printing.

**Naija tip:** The rule for merchandise in Nigeria is **never print before you collect**. Run a 10-day pre-order window, hit your minimum (usually 20–30 pieces for a good unit price), then print. Also look sideways: your printing contact can also produce **staff uniforms and branded items for other small businesses** — that's a B2B revenue stream on top of your own merch, with zero extra skills.

---

## Prompt 5.11

### Title: Offer Home Service, Delivery or Mobile Versions of Your Business

**Use this when:** Customers say "can you come to my house?" or "can you deliver?" — and you've been saying no, or doing it without a proper price.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Customers ask for [home service / delivery / mobile version]. Help me design this as a proper, profitable offer. Include: (1) what to charge — a pricing structure by distance/zone or by service level that covers transport, time and the premium of convenience, (2) which of my services suit home/mobile delivery and which don't, (3) scheduling rules — days, hours, minimum order, advance booking, deposits, (4) what equipment or packaging I need to do it well, (5) safety and reliability measures for me and the customer, and (6) the message announcing this new option to my customers, positioning it as premium convenience, not a favour.

**Real example (filled in):**

> I run a barbing salon in Surulere, Lagos. Customers — especially busy professionals, fathers with young sons, and elderly men — keep asking if I can come to their houses. Help me design a proper home-service offer: pricing by zone (Surulere / Yaba–Ikoyi / Lekki–Ajah) that covers transport and time with a convenience premium, which services suit home visits (haircuts, beard, kids' cuts) versus not, scheduling rules with advance booking and deposit, the kit I need (portable clippers, cape, sterilising spray, mirror, power bank), safety measures, and a launch message positioning it as premium convenience.

**Naija tip:** Home service should cost **at least 2× the shop price** — you're selling time and convenience, and the customers who ask can afford it. Bundle for households: "Dad + 2 sons home cut: ₦12,000." Sunday mornings and weekday evenings are your golden slots. Ask for a **deposit on booking** to eliminate no-shows, and carry a power bank — every mobile Nigerian business runs on one.

---

## Prompt 5.12

### Title: Test a New Product Idea Cheaply Before Investing

**Use this when:** You have an idea from any of the prompts above and want to validate it with real customers and real money in 2–3 weeks — before you spend big.

**Copy this prompt:**

> I want to test this new product/service idea for my [business type] in Nigeria: [describe the idea, intended price, and who it's for]. Design a 21-day low-cost test for me. Include: (1) the smallest version of the idea I can offer (minimum viable version) and what it will cost to prepare, (2) how to offer it to my existing customers and measure genuine interest — pre-orders, deposits, waitlist replies, not just "nice idea" comments, (3) a simple scoring system: what numbers mean "go big," "adjust and retest," or "drop it," (4) a day-by-day plan for the 21 days including what to post and who to message, and (5) the 3 questions to ask people who showed interest but didn't buy.

**Real example (filled in):**

> I want to test this idea for my provisions shop in Nyanya, Abuja: a "Monthly Foodstuff Box" for young families — a fixed box of rice, beans, garri, oil, seasoning, spaghetti and tomato paste at ₦28,000, paid at month-start and delivered within Nyanya. Design a 21-day low-cost test: the smallest version I can offer and its prep cost, how to measure genuine interest with pre-orders and deposits (not just comments), a scoring system for "go big / adjust / drop," a day-by-day 21-day plan with posts and messages, and 3 questions to ask people who were interested but didn't buy.

**Naija tip:** The Nigerian validation rule is simple and unforgiving: **"like" is not "buy."** Fifty fire emojis on a Status mean nothing; five deposits of ₦5,000 mean everything. Set your "go" threshold before you start (e.g., 10 paid pre-orders in 21 days) and honour it. If you hit it — scale. If you don't — you've lost ₦20,000 and gained a lesson, not lost ₦400,000 and gained a warehouse.

---

## Prompt 5.13

### Title: Collaborate With Another Business on a Joint Product

**Use this when:** You want a new product but lack a skill, ingredient or audience — and another local business has exactly what you're missing.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. I want to create a joint product or offer with another business. What I bring: [skills, product, audience, space, equipment]. What I lack: [what you need]. Suggest 6 types of businesses I could partner with and, for each, a specific joint product or package, who buys it, how we'd price and split revenue fairly, and who handles what. Then write: (1) a short, respectful proposal message to send to a potential partner, (2) a simple one-page agreement covering money split, responsibilities, timelines, customer ownership, and how to end the partnership peacefully, and (3) how to launch the joint product to both of our customer bases.

**Real example (filled in):**

> I run a bakery in Benin City. What I bring: quality cakes and pastries, a shop on a busy road, and 600 WhatsApp contacts. What I lack: drinks, decoration, photography, and event coordination. Suggest 6 businesses I could partner with — e.g., a zobo/smoothie maker, a balloon decorator, a photographer, an event planner, a flower seller, a gift-box maker — each with a specific joint product (like a "Birthday-in-a-Box": cake + drinks + balloons + a 15-minute photoshoot), buyer, pricing and revenue split, and responsibilities. Write a respectful proposal message, a one-page agreement, and a joint launch plan.

**Naija tip:** Partnerships in Nigeria collapse over **money and credit** — who got paid, who did more, whose customer is it. Write it down before the first sale, however friendly you are: "Customer pays me, I pay you your ₦X within 24 hours, screenshot as proof." Start with a **one-event or one-month trial**. If it works, extend. If it doesn't, you both walk away without a fight.

---

## Prompt 5.14

### Title: Add a Small Rental or Hire Income Stream

**Use this when:** You own equipment, space, tools, or items that sit idle part of the time — and other people would pay to use them.

**Copy this prompt:**

> I run a [business type] in Nigeria and I own [list assets — equipment, machines, space, vehicles, tools, chairs/canopies, cameras, generators, freezers, decor items, sound systems] that are idle about [percentage] of the time. Help me create a rental or hire income stream: (1) which assets are worth renting out and which are too risky, (2) fair daily/hourly rental prices in my area, (3) how to protect the asset — deposits, ID and guarantor, condition checklist with photos, a simple agreement, (4) who would rent them and how to reach those people, (5) how to schedule rentals without disrupting my own business, and (6) estimated monthly income if the assets are rented just 4–6 times a month.

**Real example (filled in):**

> I run an event catering business in Ibadan and I own 150 plastic chairs, 20 tables, 3 canopies, 2 large coolers, 6 chafing dishes, a 5kVA generator, and a small sound system, which sit idle about 70% of the time. Help me create a rental income stream: which assets to rent out and which are too risky, fair daily prices in Ibadan, how to protect them (deposits, ID, condition checklist, agreement), who rents such items and how to reach them, scheduling around my own events, and estimated monthly income at 4–6 rentals per month.

**Naija tip:** Rental income is **almost pure profit** — you already own the asset. The risks are damage and non-return; solve both with a **refundable deposit (30–50% of replacement value)**, a photocopy of the renter's ID, and time-stamped photos at handover and return. Your own customers are your first rental market: "Booking a caterer? We also rent chairs and canopies — one call, less stress."

---

## Prompt 5.15

### Title: Improve an Existing Product Based on Customer Feedback

**Use this when:** You have a product that sells okay but could sell far better with the right adjustments — and you want to make those adjustments intelligently.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price]. It sells [okay / slowly / well but with complaints]. Feedback I've collected from customers: [list positives and negatives]. What competitors do differently: [if known]. Help me improve it. Give me: (1) the 5 most valuable improvements ranked by impact on sales versus cost to implement, (2) which improvements I could charge more for and which are simply expected, (3) 3 packaging or presentation changes that raise perceived value cheaply, (4) how to announce the improved version so existing customers rebuy and new customers notice, and (5) how to measure whether the improvement actually worked over 30 days.

**Real example (filled in):**

> I sell homemade peanut butter and groundnut snacks in Jos at ₦2,500 per 500g jar. It sells okay. Feedback: customers love the taste and that there's no added sugar; complaints include the jar lid leaks in transit, the label looks homemade, some want a smaller size for trying, others want a crunchy version, and some worry about shelf life. Competitors use branded plastic jars with nutritional info and sell in supermarkets. Help me improve: the 5 most valuable improvements ranked by impact vs. cost, which I can charge more for, 3 cheap packaging/presentation changes, how to announce the improved version, and how to measure results over 30 days.

**Naija tip:** In Nigeria, **packaging is often the whole difference** between "market" and "supermarket" pricing. The same peanut butter in a leak-proof jar with a printed label, an expiry date and a NAFDAC number can sell for double — and get into shops. Fix the complaint that costs you the most repeat sales first (the leaky lid), then the one that limits new buyers (the smaller trial size). Announce it as "New & Improved — you asked, we listened," and credit your customers publicly.

---

## Prompt 5.16

### Title: Sell to Nigerians Abroad (Diaspora Revenue in Dollars)

**Use this when:** You want customers who pay in foreign currency — Nigerians in the UK, US, Canada, Europe or the Gulf buying for family at home or wanting a taste of home.

**Copy this prompt:**

> I run a [business type] in [city], Nigeria. Help me build a revenue stream from Nigerians abroad. Tell me: (1) which of my products or services diaspora Nigerians would pay for — either delivered to their family here (gifts, food, care packages, services for parents, event catering, tailoring for occasions) or shipped/delivered to them abroad (if feasible), (2) how to price in USD/GBP fairly and get paid (payment links that accept foreign cards, and what to check about fees and settlement), (3) how to build trust remotely — photo/video proof of delivery, live video calls, references, (4) where and how to reach diaspora Nigerians — WhatsApp groups, Facebook community groups, Instagram, alumni and hometown associations, and (5) a simple offer and message to start with.

**Real example (filled in):**

> I run a food and catering business in Enugu. Help me build a diaspora revenue stream: which products diaspora Nigerians would pay for (e.g., weekly cooked meals delivered to their elderly parents in Enugu, Christmas food packages for family, event catering when they come home for burials and weddings, or vacuum-sealed dried foods like crayfish, ogbono and egusi shipped abroad if feasible), how to price in USD/GBP and get paid with links that accept foreign cards, how to build trust remotely with photo and video proof, where to reach diaspora Nigerians from Enugu/Anambra area, and a simple starter offer and message.

**Naija tip:** The diaspora market has one powerful driver: **guilt and love for parents back home**. "Weekly hot meals for Mama in Enugu, $60/month, with a photo every delivery" sells itself in London and Houston. Your Flutterwave or Paystack link already accepts foreign cards — check the settlement details and fees first (*Check Before You Trust It*). Join hometown and alumni groups abroad and let satisfied clients recommend you; one diaspora referral chain can be worth ₦2M a year.

---

## Prompt 5.17

### Title: Create a Loyalty Programme That Increases Lifetime Value

**Use this when:** You want existing customers to buy more often and spend more over time — and you want a simple system, not an app.

**Copy this prompt:**

> I run a [business type] in Nigeria. Average customer spends ₦[amount] per visit and buys about [frequency]. Design a simple loyalty programme I can run with a paper card, WhatsApp, or a notebook: (1) 3 programme options — stamp card, points, tiered VIP (silver/gold), or a surprise-reward system — with pros and cons for my business, (2) the reward structure for the best option that increases visits by at least 25% while costing me under 5% of revenue, (3) how customers join and track progress, (4) messages to announce it, remind people of their progress, and celebrate when they earn a reward, and (5) how to measure if it's actually working after 60 days.

**Real example (filled in):**

> I run a small restaurant in Lagos (Ikeja) serving lunch to office workers. Average customer spends ₦2,800 per visit and buys about twice a week. Design a simple loyalty programme I can run with a paper card or WhatsApp: 3 options with pros and cons, the reward structure for the best one that increases visits by 25% while costing under 5% of revenue, how customers join and track progress, announcement/reminder/celebration messages, and how to measure success after 60 days.

**Naija tip:** Keep it **stupid-simple**: "Buy 7 lunches, the 8th is free." A paper card with a stamp is still the most effective loyalty tool in Nigeria — visible, tangible, no data needed. Add a **surprise** occasionally ("Today, every Gold member gets free drink") — unexpected generosity is remembered and talked about far more than the scheduled reward.

---

## Prompt 5.18

### Title: Turn Your Business Into a Brand Others Want to Sell (Distributors & Agents)

**Use this when:** You make something — food, soap, drinks, fashion, cosmetics, crafts — and want it sold in more places than you can personally reach.

**Copy this prompt:**

> I produce [product] in [city], Nigeria, currently selling directly to customers at ₦[price] with a cost of ₦[cost]. I want other people to sell it for me — agents, distributors, shops, market sellers, online vendors. Help me design a reseller programme: (1) the pricing ladder — my cost, distributor price, retailer price, recommended retail price — with margin for everyone, (2) minimum orders and payment terms for each level, (3) how to recruit resellers and what kind of person makes a good one, (4) what support to give them — product photos, captions, sales training, marketing materials, (5) rules to protect my brand — consistent pricing, territory, quality, no dilution, and (6) a simple reseller agreement and the recruitment message.

**Real example (filled in):**

> I produce a range of natural hair-care products (shampoo, deep conditioner, hair growth oil) in Ibadan, selling directly at ₦3,500–₦6,000 with costs of ₦1,400–₦2,300. I want salons, beauty-supply shops, Instagram vendors and student agents to sell for me. Help me design a reseller programme: pricing ladder with margin for everyone, minimum orders and payment terms per level, how to recruit resellers and who makes a good one, what support to give them, rules to protect my brand and pricing, and a simple reseller agreement plus the recruitment message.

**Naija tip:** Nigeria runs on **agent networks** — from telecom recharge to cosmetics to bread. Students and stay-at-home mothers make excellent agents when the margin is clear and the starter pack is affordable (₦15,000–₦30,000). Give them a **ready-made sales kit** (photos, captions, a price list, a testimonial video) so they can start selling the same day. Protect your brand with one non-negotiable rule: sell below the RRP and you lose reseller status.

---

## Prompt 5.19

### Title: Build a Second Income Stream That Runs Alongside Your Main Business

**Use this when:** You want an additional, semi-passive stream — affiliate commissions, referral fees, agency for a bigger brand, POS services, a small side product — that doesn't distract from your core business.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, and I have [describe assets — daily foot traffic, a customer list of X, a shop location, delivery routes, a following, spare counter space, relationships with certain groups]. Suggest 8 side income streams that could run alongside my business with under 3 hours a week of my attention — e.g., becoming an agent for a bigger brand, POS/bill-payment services, referral fees from complementary businesses, affiliate links for products my customers buy, renting shelf or wall space, small commission sales. For each: how it works, estimated monthly income, what it requires, risks, and whether it strengthens or distracts from my main business. Rank them and tell me which one to start this month.

**Real example (filled in):**

> I run a busy pharmacy in Ikorodu with about 120 walk-in customers daily, a WhatsApp list of 800, a small counter area, and good relationships with local clinics and mothers' groups. Suggest 8 side income streams that could run alongside with under 3 hours a week — e.g., POS/bill payments, insurance or HMO agent, baby-product brand agency, health-supplement affiliate, renting shelf space to a cosmetics brand, referral fees from a diagnostic lab, selling a small baby-care digital guide. For each: how it works, estimated monthly income, requirements, risks, and whether it strengthens or distracts. Rank and tell me which to start this month.

**Naija tip:** The best side stream is the one that **serves the same customer, in the same visit**. Foot traffic is an asset most shop owners undervalue — 120 people a day walking past your counter is an audience brands and services will pay to reach. But protect your core: if the side hustle starts taking your attention or confusing your customers about what you are, cut it. Focus is also a revenue strategy.

---

## Prompt 5.20

### Title: Build Your 12-Month Product & Revenue Roadmap

**Use this when:** You've generated ideas from this Part and want to turn them into an orderly plan — what to launch when, so you grow without overwhelming yourself or your cash.

**Copy this prompt:**

> Here are the new product, service and revenue-stream ideas I'm considering for my [business type] in Nigeria: [list them, with estimated cost to launch and expected monthly revenue for each]. My current monthly revenue is ₦[amount] and profit ₦[amount]. My available capital for new things is ₦[amount]. My time available for new projects is about [hours] per week. Create a 12-month roadmap that: (1) sequences the ideas logically — quick wins first, cash-generating before cash-consuming, seasonal items at the right time, (2) shows for each quarter what launches, what it costs, and what it should bring in, (3) sets a go/no-go checkpoint for each idea, (4) keeps my total risk within my capital, and (5) projects my monthly revenue by month 12 if things go reasonably well. Present it as a quarter-by-quarter table plus a short explanation.

**Real example (filled in):**

> Ideas for my unisex salon in Ikeja: a hair-products retail line (launch cost ₦80,000, expected ₦120,000/month), a Monday-morning discounted slot (₦0, ₦60,000/month), a 4-week braiding class (₦30,000, ₦200,000 per batch), home-service barbing (₦45,000, ₦90,000/month), a bridal package for wedding season (₦20,000, ₦150,000/month in Nov–Dec and April), and a "Salon Day" gift voucher (₦5,000, ₦50,000/month). Current revenue ₦850,000, profit ₦280,000, capital available ₦200,000, time about 6 hours a week. Create a 12-month roadmap: sequence with quick wins first and seasonal items timed right, quarter-by-quarter table with costs and expected income, go/no-go checkpoints, total risk within my capital, and projected revenue by month 12.

**Naija tip:** One new stream per quarter is the pace that works — enough to grow noticeably, slow enough to do each one properly. Start with the **free or near-free wins** (the Monday slot, the vouchers) to build momentum and cash, then fund the bigger launches from that cash rather than from loans. Review the roadmap every quarter with Prompt 4.20's monthly review beside it. A business with a roadmap stops reacting and starts compounding.

---

## Part 5 Checkpoint

Before moving to Part 6, make sure these five are **done**:

1. You have a list of at least 10 adjacent ideas, ranked, with one chosen to test first. *(5.1)*
2. At least two named bundles are live and displayed. *(5.2)*
3. One new stream — premium tier, subscription, class, or home service — is in a 21-day test with a "go" threshold you wrote down. *(5.3/5.4/5.7/5.11 + 5.12)*
4. You've identified one B2B or diaspora customer group and contacted the first prospect. *(5.6/5.16)*
5. Your 12-month product roadmap exists, quarter by quarter. *(5.20)*

Revenue is now coming from more than one direction. Part 6 makes sure you actually *keep* it — pricing for profit, tracking cash, separating business money from personal money, and preparing for funding when you're ready to grow further.

**Next: Part 6 — Finance, Funding & Smart Growth (Prompts 6.1 – 6.20)**
