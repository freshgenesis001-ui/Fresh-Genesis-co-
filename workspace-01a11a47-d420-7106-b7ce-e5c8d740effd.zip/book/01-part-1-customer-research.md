# PART 1: DEEP CUSTOMER UNDERSTANDING & MARKET RESEARCH
*(Prompts 1.1 – 1.20)*

---

## Why This Part Comes First

Most small businesses in Nigeria do not fail because the owner is lazy. They fail because the owner is selling the right thing to the wrong people, at the wrong price, in the wrong place — and only finds out after the money is gone.

Market research sounds like something for big companies in Lagos with consultants and PowerPoint. It is not. Market research is simply **knowing your customer better than your competitor does.** The woman selling akara at the junction who knows that okada riders want it hot at 6:30am and office workers want it wrapped neatly at 8am is doing market research. She just does not call it that.

AI makes this faster and sharper. In the next 20 prompts, you will learn how to:

- Describe your ideal customer so clearly you can picture their face
- Find out what people actually want to buy (not what you assume)
- Understand why customers choose your competitor
- Ask the right questions without annoying anybody
- Set prices based on evidence, not fear
- Spot opportunities in your area that others are missing

**How to work through this Part:** Do not do all 20 in one day. Do Prompts 1.1, 1.2 and 1.5 first — those three alone will change how you see your business. Then come back for the rest as you need them.

**One rule before you begin:** Every prompt in this Part works better when you give the AI real details about *your* business — your location, your prices, your actual customers. Generic in, generic out. Specific in, gold out.

---

## Prompt 1.1

### Title: Build Your Ideal Customer Profile

**Use this when:** You are starting out, or you have been in business a while but still cannot say exactly who your best customer is. Also use this before spending any money on advertising.

**Copy this prompt:**

> I run a [type of business] in [town/city/area], Nigeria. My main products/services are [list them]. My typical prices are [price range]. Based on this, help me build a detailed profile of my ideal customer. Include: their likely age range, gender, occupation, income level (in naira, monthly), where they live or work in relation to my shop, what problem they are trying to solve when they buy from me, what they worry about before buying, where they spend time online (WhatsApp, Facebook, Instagram, TikTok), and what would make them choose me over a competitor. Present it as a short profile with a name, like a real person. Then tell me the 3 most important things I should change about how I sell to reach this person better.

**Real example (filled in):**

> I run a small unisex salon in Ikorodu, Lagos. My main services are braids, weaving, barbing, and pedicure. Braids cost ₦4,000–₦12,000, barbing is ₦1,500, pedicure is ₦3,000. Based on this, help me build a detailed profile of my ideal customer. Include: their likely age range, gender, occupation, income level (in naira, monthly), where they live or work in relation to my shop, what problem they are trying to solve when they buy from me, what they worry about before buying, where they spend time online, and what would make them choose me over a competitor. Present it as a short profile with a name, like a real person. Then tell me the 3 most important things I should change about how I sell to reach this person better.

*The AI will return something like "Meet Chidinma, 27, a bank contract staff who lives in Ikorodu but works on the Island, earns ₦120,000–₦180,000 monthly, wants a style that lasts 4+ weeks because she cannot afford weekly salon visits, worries about the braider being too slow or too rough, checks Instagram and WhatsApp Status for styles..." — and then give you three concrete changes.*

**Naija tip:** Do this prompt twice — once for your *best-paying* customer and once for your *most frequent* customer. In many Nigerian businesses, these are two different people. The market woman who buys ₦500 recharge card from you every day and the man who buys ₦20,000 data bundle once a month both matter, but you talk to them differently.

---

## Prompt 1.2

### Title: Find Out What Your Customers Really Want (Not What You Think)

**Use this when:** Sales are slower than expected, or you keep stocking things that do not move while customers ask for things you do not have.

**Copy this prompt:**

> I sell [products/services] in [area], Nigeria. Here is what I currently offer: [list]. Here are things customers have asked for that I don't have: [list, or say "I'm not sure"]. Here are things that sell fast: [list]. Here are things that sell slowly: [list]. Analyse this and tell me: (1) what pattern you see in what my customers actually value, (2) what they might be buying elsewhere that I could offer, (3) which slow items I should stop stocking, and (4) three questions I should ask my next 10 customers to confirm this. Keep it practical for a small Nigerian business with limited capital.

**Real example (filled in):**

> I sell provisions in a small shop in Nyanya, Abuja. Here is what I currently offer: rice, beans, garri, indomie, milk, sugar, detergent, toiletries, soft drinks. Things customers have asked for that I don't have: bread, eggs, frozen chicken, sachet tomato paste, small packs of spaghetti. Things that sell fast: indomie, sachet milk, small detergent, soft drinks. Things that sell slowly: big bags of rice, large tins of milk, expensive body cream. Analyse this and tell me: (1) what pattern you see in what my customers actually value, (2) what they might be buying elsewhere that I could offer, (3) which slow items I should stop stocking, and (4) three questions I should ask my next 10 customers to confirm this.

*The pattern the AI will likely find: your customers buy in small, daily quantities — they are budgeting day by day, not month by month. That changes everything about what you stock.*

**Naija tip:** Nigerian customers rarely complain directly; they just stop coming. So the "things customers asked for" list is your most valuable data. Start a simple note on your phone today: every time someone asks "you no get X?", write X down. After two weeks, feed that list into this prompt.

---

## Prompt 1.3

### Title: Understand Why Customers Buy From Your Competitor Instead

**Use this when:** There is a competitor nearby who seems busier than you, and you honestly do not know why.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. My main competitor is [describe them: location, size, how long they've been there, what they seem to do well]. What I've noticed about them: [prices, customer service, opening hours, product range, appearance of shop, how they advertise — whatever you know]. What I do: [same details about yourself]. Give me an honest comparison. What are the likely reasons customers choose them over me? Which of those reasons can I fix in the next 30 days without spending more than ₦[amount]? Which ones should I not even try to compete on, and what should I do instead to stand out?

**Real example (filled in):**

> I run a small restaurant (buka) in Uyo. My main competitor is a bigger buka across the road, been there 6 years, always crowded at lunchtime. What I've noticed: their food is slightly more expensive (₦1,500 vs my ₦1,200 for rice and chicken), but they have a canopy with fans, they serve fast, they have a POS that always works, and they give free water. What I do: cheaper prices, my food tastes better according to customers, but I have only 3 tables, no fan, my POS network fails often, and I sometimes run out of stew by 2pm. Give me an honest comparison. What are the likely reasons customers choose them over me? Which can I fix in 30 days without spending more than ₦100,000? Which should I not compete on, and what should I do instead?

**Naija tip:** Do not guess about your competitor — go and buy from them. Spend ₦2,000 as a customer and observe everything: how they greet you, how long you wait, how they handle change, whether they have a WhatsApp number on the wall. That ₦2,000 is the cheapest market research you will ever do. Then put what you saw into this prompt.

---

## Prompt 1.4

### Title: Write Customer Survey Questions That People Will Actually Answer

**Use this when:** You want direct feedback from customers but do not know what to ask, or your previous attempts got ignored.

**Copy this prompt:**

> I run a [business type] in Nigeria and I want to ask my customers a few questions to understand them better. I will send the questions on WhatsApp / ask them in person [choose one]. Write me 5 short, friendly questions in simple English that a busy Nigerian customer will actually answer in under 2 minutes. The questions should help me find out: what they like most, what frustrates them, what would make them buy more often, and what else they wish I sold. Avoid questions that sound like a bank form. Also write a 2-sentence opening message that makes them want to respond, and suggest a small thank-you I can offer that won't cost me much.

**Real example (filled in):**

> I run a small fashion business in Onitsha — I sew and sell ready-made gowns and two-piece sets for women, mostly ₦8,000–₦25,000. I want to ask my customers a few questions on WhatsApp. Write me 5 short, friendly questions in simple English that a busy Nigerian woman will answer in under 2 minutes. The questions should help me find out: what they like most, what frustrates them, what would make them buy more often, and what else they wish I sold. Avoid questions that sound like a bank form. Also write a 2-sentence opening message that makes them want to respond, and suggest a small thank-you that won't cost much.

**Naija tip:** Send the survey to your 15–20 most friendly customers first, not everybody. Ask on a weekday evening (7–9pm) when people are home and relaxed. And whatever you do, do not send it as a broadcast that looks like a broadcast — personalise the first line with their name. A ₦200 airtime "thank you" to the first 10 responders will get you more replies than a ₦5,000 discount voucher.

---

## Prompt 1.5

### Title: Discover the Real Problem You Solve (Your True Value)

**Use this when:** You describe your business by what you sell ("I sell shoes") instead of what customers gain. This prompt changes how you market everything.

**Copy this prompt:**

> I sell [product/service] to [type of customers] in Nigeria. Help me understand the deeper reason people buy from me. Go beyond the obvious. For example, someone buying a generator is not buying a machine — they are buying the ability to run their shop when NEPA fails, and the peace of mind that comes with it. For my business, list: (1) the surface reason people buy, (2) the practical problem underneath, (3) the emotional need underneath that, and (4) the fear or worry that buying from me removes. Then write 3 short sentences I can use to describe my business that speak to the deeper reason, not just the product. Keep the language simple, Nigerian, and natural — the kind of thing I could say to a customer or post on my WhatsApp status.

**Real example (filled in):**

> I sell and install solar-powered inverter systems for homes and small shops in Enugu, mostly to families and small business owners. Help me understand the deeper reason people buy from me. Go beyond the obvious. For my business, list: (1) the surface reason people buy, (2) the practical problem underneath, (3) the emotional need underneath that, and (4) the fear or worry that buying from me removes. Then write 3 short sentences I can use to describe my business that speak to the deeper reason. Keep the language simple, Nigerian, and natural.

*Expect answers like: "Surface: they want light. Practical: fuel is now ₦1,000+ per litre and the generator is eating their profit. Emotional: they are tired of the noise, the stress, the embarrassment of darkness when visitors come. Fear removed: the fear of another month of unpredictable expenses." And then lines like "Stop buying fuel every week. Buy light once."*

**Naija tip:** Nigerians buy solutions to stress. Fuel stress, NEPA stress, traffic stress, "what will people say" stress, school fees stress. When you know which stress you remove, your marketing writes itself. Print the best of the 3 sentences and put it on your shop signboard or WhatsApp Business "About" section.

---

## Prompt 1.6

### Title: Map Your Local Market Opportunity

**Use this when:** You want to know if your area has room for what you sell, or you are deciding whether to open a business (or a second branch) in a new location.

**Copy this prompt:**

> I am considering [starting / expanding] a [business type] in [specific area, town, state], Nigeria. Here is what I know about the area: [population feel — busy or quiet; type of residents — students, civil servants, traders, families; main landmarks — market, school, church, estate, motor park; how many similar businesses already exist; what they charge]. Based on this, give me: (1) an honest assessment of the opportunity — is there room for me or is the market crowded, (2) the specific type of customer in this area most likely to buy from me, (3) a gap or underserved need I could focus on, (4) the biggest risk I am not seeing, and (5) three things I should check in person before committing money.

**Real example (filled in):**

> I am considering starting a laundry and dry-cleaning service in Ojo, near Lagos State University (LASU). Here is what I know: very busy area, thousands of students in hostels and off-campus lodges, plus civil servants and traders. Main landmarks: LASU main gate, Iyana-Iba market, several churches. There are about 4 laundry services I've seen within 10 minutes' walk, charging around ₦200–₦300 per shirt. Based on this, give me: (1) an honest assessment — is there room or is it crowded, (2) the specific customer most likely to buy from me, (3) a gap I could focus on, (4) the biggest risk I'm not seeing, and (5) three things to check in person before committing money.

**Naija tip:** Before you sign any shop agreement, spend three different days at the location — a weekday morning, a Saturday afternoon, and a Sunday evening. Count foot traffic. Look at who is walking past and what they are carrying. Then tell the AI what you counted. Landlords will tell you the area is "very busy" — your own eyes will tell you the truth.

---

## Prompt 1.7

### Title: Understand Your Customers' Buying Habits and Timing

**Use this when:** You want to know *when* people buy, *how often*, and *what triggers* them to buy — so you can stock, staff, and advertise at the right times.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, selling to [customer type]. Help me understand the buying habits of my customers. Tell me: (1) which days of the week and times of day they are most likely to buy, and why, (2) which times of the month (salary week, end of month, mid-month) matter most for my type of business, (3) which seasons, festivals, or events in Nigeria increase or decrease demand for what I sell (e.g., Christmas, Sallah, back-to-school, rainy season, Valentine's, Easter, harvest time), (4) what everyday triggers make someone decide to buy today rather than tomorrow, and (5) how I should adjust my stock, opening hours, and promotions based on this.

**Real example (filled in):**

> I run a small phone accessories and repair kiosk in Kano, near a busy motor park, selling to commuters, traders, and young men. Help me understand the buying habits of my customers. Tell me: (1) which days and times they most likely buy, (2) which times of the month matter most, (3) which seasons, festivals or events in Nigeria increase or decrease demand — especially Sallah, Ramadan, and harmattan, (4) what everyday triggers make someone buy today rather than tomorrow, and (5) how I should adjust stock, hours, and promotions.

**Naija tip:** In Nigeria, the calendar drives cash. The 25th–30th of the month (salary time) is when people buy the things they have been postponing. The 10th–20th is when they buy small and manage. Structure your promotions around this: big-ticket offers at month-end, "small chops" pricing mid-month. And never run out of stock the week before a major festival — that is the most expensive mistake in retail.

---

## Prompt 1.8

### Title: Create Customer Segments (Group Your Customers Smartly)

**Use this when:** You have different types of customers and you are treating all of them the same way — same message, same price, same offer.

**Copy this prompt:**

> I run a [business type] in Nigeria. My customers include: [describe the different kinds of people who buy from you — e.g., students, working-class women, wholesalers, walk-in strangers, regulars, corporate clients]. Help me divide them into 3–4 clear groups (segments). For each group, tell me: what they value most, how much they typically spend, how often they buy, the best way to reach them (WhatsApp, in person, referral, Instagram), what offer would appeal to them most, and one mistake I should avoid with that group. Then tell me which group is most profitable and deserves most of my attention.

**Real example (filled in):**

> I run a small bakery in Ibadan making bread, meat pies, cakes, and small chops. My customers include: neighbours who buy bread every morning, small shop owners who buy bread in bulk to resell, people who order birthday and wedding cakes, and office workers who order small chops for events. Help me divide them into 3–4 clear groups. For each group, tell me: what they value most, how much they typically spend, how often they buy, the best way to reach them, what offer would appeal most, and one mistake to avoid. Then tell me which group is most profitable and deserves most of my attention.

**Naija tip:** After the AI gives you the segments, go into your WhatsApp Business app and create **Labels** for each group (Settings → Business tools → Labels). Label every customer chat. From that day, you can send the right message to the right people — bulk buyers get the wholesale price alert, cake customers get the "book early for December" message. This one habit separates struggling vendors from growing ones.

---

## Prompt 1.9

### Title: Turn Customer Complaints Into Business Intelligence

**Use this when:** You have received complaints (or you sense unhappiness) and you want to understand the real issue and fix it properly, not just apologise.

**Copy this prompt:**

> I run a [business type] in Nigeria. Here are the complaints and negative comments I have received recently, in the customers' own words as best I remember: [list them — include the small ones and the ones said jokingly]. Analyse these and tell me: (1) what the underlying pattern is — what is the real problem behind the complaints, (2) which complaints are about things I can fix cheaply and quickly, (3) which are signs of a bigger problem in how I run the business, (4) which complaints I should not take too seriously, and (5) a simple plan for what to fix first, second, and third. Be honest — do not soften the feedback.

**Real example (filled in):**

> I run a small logistics/dispatch rider business in Port Harcourt with 3 riders. Recent complaints: "Your rider came late again." "The rider was rude to my customer." "Why is your price different from what you told me on the phone?" "I couldn't reach you when I needed to track the package." "Your rider's bike broke down and my customer waited 2 hours." "Please, do you have a female rider? My customer is a woman living alone." Analyse these and tell me: (1) the underlying pattern, (2) which I can fix cheaply and quickly, (3) which are signs of a bigger problem, (4) which I should not take too seriously, and (5) a plan for what to fix first, second, and third. Be honest.

**Naija tip:** In Nigeria, the customer who complains to your face is doing you a favour — most people just tell 10 other people and never come back. Treat every complaint as free consulting. Keep a "Complaint Book" (a WhatsApp chat with yourself works fine). Run this prompt once a month with everything in that book. The businesses that grow are the ones that fix things before customers give up.

---

## Prompt 1.10

### Title: Research a New Product Before You Stock It

**Use this when:** A supplier is pushing you to buy a new item, or you saw something trending and are tempted to invest, but you want to check before committing money.

**Copy this prompt:**

> I am thinking of adding [new product/service] to my [business type] in [area], Nigeria. It would cost me ₦[cost price] to buy/produce and I plan to sell at ₦[selling price]. My existing customers are [describe them]. Help me evaluate this decision. Tell me: (1) does this product fit what my current customers are already buying — will they want it, (2) who else in my area might buy it, (3) what is the realistic demand — is this a fast-moving item or a slow one, (4) what could go wrong — spoilage, competition, price drops, fake versions in the market, seasonality, (5) how many units I should buy for a first test, and (6) how I will know within 2–3 weeks whether to continue or stop.

**Real example (filled in):**

> I am thinking of adding hair growth oils and edge control products to my cosmetics shop in Benin City. The oils cost me ₦2,500 each and I plan to sell at ₦4,500. My existing customers are mostly women aged 20–40 who buy makeup, perfumes, and skincare. Help me evaluate this. Tell me: (1) does this fit what my customers already buy, (2) who else in my area might buy it, (3) realistic demand — fast or slow mover, (4) what could go wrong — fakes, competition, price drops, (5) how many units for a first test, and (6) how I'll know within 2–3 weeks whether to continue or stop.

**Naija tip:** Never let a supplier's "this thing dey sell like pure water" replace your own test. The rule is simple: **test with the smallest quantity the supplier will sell you**, even if the unit price is higher. Losing ₦5,000 on a failed test is business. Losing ₦150,000 on a carton of something nobody wanted is a wound. And in Nigeria, always ask the AI about fakes — for many product categories (cosmetics, phone accessories, drinks), fake versions are your real competitor.

---

## Prompt 1.11

### Title: Estimate What Customers Are Willing to Pay

**Use this when:** You are setting or reviewing prices and you want a sensible range based on your customer type and market, not guesswork or fear of losing customers.

**Copy this prompt:**

> I sell [product/service] in [area], Nigeria. My cost to produce/buy one unit is ₦[amount]. My customers are mainly [describe: income level, occupation, type]. Competitors charge between ₦[low] and ₦[high]. My product is [better / same / simpler] than theirs because [reason]. Help me think through pricing. Tell me: (1) a realistic price range my customers would accept, and why, (2) whether I should price at the low, middle, or high end of that range, based on how I described my product and customers, (3) how to test two different prices without confusing customers, (4) how to explain a higher price so customers see the value instead of arguing, and (5) any signs that would tell me my price is too high or too low.

**Real example (filled in):**

> I make and sell zobo and tiger nut drinks in 50cl bottles in Jos. My cost per bottle is about ₦280 (ingredients, bottle, label, gas). My customers are students, office workers, and church members. Competitors charge ₦300–₦500. My product is better because I use no artificial sweetener, it's properly chilled, and my bottles are sealed with a printed label. Help me think through pricing. Tell me: (1) a realistic price range, (2) low, middle or high end, (3) how to test two prices without confusing customers, (4) how to explain a higher price so customers see the value, and (5) signs that my price is too high or too low.

**Naija tip:** The fear of "customers will run" makes many Nigerian business owners underprice and then go broke slowly. Here is the reality: customers who only came for cheap price will leave the moment someone cheaper appears anyway. Price for the customer who values quality, then make sure quality is visible (packaging, cleanliness, presentation). A ₦500 zobo in a sealed, labelled bottle looks worth ₦500. The same zobo in a reused water bottle looks worth ₦200.

---

## Prompt 1.12

### Title: Find Out Where Your Customers Spend Time (Online and Offline)

**Use this when:** You want to advertise or promote, but you are not sure whether to focus on WhatsApp, Instagram, Facebook, TikTok, flyers, radio, or church/mosque announcements.

**Copy this prompt:**

> My business is [type] in [area], Nigeria. My typical customer is [age range, gender, occupation, income level, lifestyle]. Help me figure out where these customers spend their time and attention, both online and offline. Rank the following by how likely I am to reach my customers there, and explain why: WhatsApp Status, WhatsApp groups, Facebook, Instagram, TikTok, church/mosque announcements, market/street presence, referrals from existing customers, flyers/posters, local radio, estate/community groups. Then tell me the ONE channel I should focus on first, and the TWO I should ignore for now so I don't waste money and energy.

**Real example (filled in):**

> My business is a poultry farm in Abeokuta selling live chickens and eggs. My typical customers are two groups: women aged 30–55 who buy for their families, and small food vendors/restaurants who buy eggs and chicken in bulk. Help me figure out where these customers spend their time and attention. Rank these by how likely I am to reach them: WhatsApp Status, WhatsApp groups, Facebook, Instagram, TikTok, church/mosque announcements, market presence, referrals, flyers, local radio, estate/community groups. Then tell me the ONE channel to focus on first, and TWO I should ignore for now.

**Naija tip:** For most Nigerian small businesses, the honest answer is WhatsApp first — it is where your existing customers already are, and it costs nothing. TikTok and Instagram are for when you have something visual and time to be consistent. Do not spread yourself thin. One channel done every day beats five channels done once a month. And never underestimate the church/mosque/community group announcement — for family-focused products, it still outsells social media in many towns.

---

## Prompt 1.13

### Title: Check Demand Before You Start a Business (The Reality Test)

**Use this when:** You have a business idea and you are excited about it, but you have not yet spent money. This is the prompt that saves people from expensive mistakes.

**Copy this prompt:**

> I want to start a [business idea] in [area], Nigeria. My reason for believing it will work: [your reasons]. My budget is ₦[amount]. I would be selling to [customer type]. Play the role of a tough but fair business adviser. Tell me: (1) the honest strengths of this idea, (2) the three biggest reasons it could fail — be specific to Nigeria and my area, (3) what evidence I should gather before spending any money, and exactly how to gather it cheaply, (4) a way I could test the idea with less than 20% of my budget, and (5) what results from that test would mean "go ahead" versus "stop or change the plan." Do not encourage me just to be nice.

**Real example (filled in):**

> I want to start a home-cooked food delivery business in Lekki, Lagos — healthy Nigerian meals delivered to offices and homes. My reason for believing it will work: many young professionals there are too busy to cook and are tired of unhealthy fast food. My budget is ₦400,000. I would be selling to workers aged 25–40 earning ₦200k+ monthly. Play the role of a tough but fair business adviser. Tell me: (1) honest strengths, (2) the three biggest reasons it could fail — specific to Lagos, (3) what evidence to gather before spending, and how to gather it cheaply, (4) how to test with less than ₦80,000, and (5) what test results mean "go" versus "stop." Do not encourage me just to be nice.

**Naija tip:** Nigerians are polite — your friends and family will tell you your idea is "very good" because they love you, not because they will buy. The only real evidence is **people paying money**. Before you rent a shop or buy equipment, try to get 10 people to pre-pay or place a deposit. If you cannot find 10 people to pay ₦2,000 in advance, you will not find 100 people to pay after you have spent ₦400,000.

---

## Prompt 1.14

### Title: Analyse Your Best Customers and Find More Like Them

**Use this when:** You have been in business for a while and want to grow by finding more of the customers who already love you, rather than chasing everyone.

**Copy this prompt:**

> I run a [business type] in Nigeria. Here are my 5–10 best customers — the ones who buy most often, spend the most, or refer others: [for each, describe what you know: rough age, occupation, where they live/work, what they buy, how they found you, why they keep coming]. Analyse these people and tell me: (1) what they have in common — the pattern I may not have noticed, (2) a description of the "type" of person most likely to become a great customer for me, (3) where I can find more people like them in my area, (4) what message or offer would attract people like them, and (5) which of my current marketing efforts are probably attracting the wrong people and should be dropped.

**Real example (filled in):**

> I run a small interior décor and curtain-making business in Asaba. My best customers: (1) a woman in her 40s, banker, lives in a new estate, found me through her neighbour, has ordered 3 times; (2) a young couple who just built their house, found me on Instagram, spent ₦350k; (3) a school proprietor who did all classrooms and office, found me through church; (4) a hotel manager who orders replacement curtains twice a year; (5) a doctor who just moved to Asaba, referred by customer 1; (6) a woman who runs a lounge, found me via WhatsApp Status. Analyse these and tell me: (1) what they have in common, (2) the type most likely to become a great customer, (3) where to find more like them, (4) what message would attract them, and (5) which marketing efforts are probably attracting the wrong people.

**Naija tip:** In Nigeria, your best customers are usually connected to other potential best customers — same estate, same church, same office, same alumni group. The pattern this prompt reveals often points to one or two "communities" where your business should become the known name. Once you see it, ask your best customers directly: "Who else in your estate is building or renovating?" They will tell you.

---

## Prompt 1.15

### Title: Understand What Stops People From Buying (Objection Research)

**Use this when:** People show interest, ask questions, price your product — and then disappear. You want to understand the invisible reasons they did not buy.

**Copy this prompt:**

> I sell [product/service] in Nigeria to [customer type], priced at ₦[price]. Many people ask about it or show interest but do not buy. Here is what happens typically: [describe — e.g., they ask price and go quiet; they say "I'll come back"; they ask too many questions; they say it's expensive; they ask for discount and then vanish]. Help me understand the real reasons behind this. List the 6–8 most likely hidden objections — the things customers are thinking but not saying — such as trust, money timing, fear of fakes, not understanding the value, comparing with a cheaper option, waiting for a spouse's approval, etc. For each one, tell me how to spot it and one simple thing I can say or do to address it before they walk away.

**Real example (filled in):**

> I sell quality second-hand (UK-used) laptops in Aba, priced ₦120,000–₦250,000, to students, young professionals, and small business owners. Many people ask about it or show interest but do not buy. Typically: they ask price on WhatsApp and go quiet; they ask "is it original?"; they ask if I have a warranty; they say they'll "check other places and come back"; some ask for a payment plan. Help me understand the real reasons behind this. List the 6–8 most likely hidden objections, and for each, tell me how to spot it and one simple thing I can say or do to address it before they walk away.

**Naija tip:** The number one hidden objection in Nigeria is **trust** — "Will this person scam me? Is this thing original? If it spoils, will they pick my call?" Price is often what customers *say*, but trust is what they *feel*. Anything that builds trust (real customer video reviews, a written warranty on paper, a physical address, a business name registered with CAC, consistent WhatsApp Status posts for months) reduces price resistance more than a discount does.

---

## Prompt 1.16

### Title: Create a Simple Customer Journey Map

**Use this when:** You want to see your business through the customer's eyes — from the moment they first hear of you to the moment they come back or refer a friend — and find the weak points.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Walk me through my customer's journey step by step, from their point of view: (1) how they first hear about me, (2) how they check whether I'm trustworthy, (3) how they contact me or find my shop, (4) what happens during the purchase, (5) what happens after they pay — delivery, usage, any problems, (6) what makes them come back or not, and (7) what makes them tell a friend or not. Here is how my business currently works at each stage: [describe honestly]. For each step, tell me where I might be losing customers without knowing, and one cheap improvement I can make. Then tell me which single step, if fixed, would bring the biggest improvement in sales.

**Real example (filled in):**

> I run a small catering business in Kaduna doing event food for weddings, naming ceremonies, and office parties. Here is how my business works: people usually hear of me at events where I cooked; they get my number from the host; they call or WhatsApp me; I send a price list as a photo; if they agree, they pay 70% deposit to my account; on the day I cook and deliver with hired hands; after the event I rarely follow up. Walk me through my customer's journey from their point of view across all 7 stages. For each step, tell me where I might be losing customers without knowing, and one cheap improvement. Then tell me which single step, if fixed, would bring the biggest improvement in sales.

**Naija tip:** Most Nigerian small businesses lose the most customers at two points: **the first WhatsApp reply** (slow, cold, or just "how many you want?") and **after payment** (silence). A warm, fast first reply and a simple "Thank you ma, hope everything went well? Please keep my number for next time" after the job will bring more repeat business than any advertising. It is free. Do it.

---

## Prompt 1.17

### Title: Analyse Market Trends Affecting Your Business

**Use this when:** You want to understand what is changing in Nigeria — prices, habits, technology, competition — and how it will affect your business in the next 6–12 months.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Based on what is generally known about the Nigerian economy and consumer behaviour, help me think through the trends that could affect my business over the next 6–12 months. Consider: fuel and transport costs, naira exchange rate and import prices, changes in how people shop (online, WhatsApp, delivery), new competitors or business models, what young people are doing differently, and any government policy directions relevant to my sector. For each trend, tell me: is it a threat or an opportunity for me, how soon it will matter, and one practical thing I can do now to prepare. Be honest about what you are unsure of — I will verify important details myself.

**Real example (filled in):**

> I run a small electronics shop in Owerri selling phones, chargers, power banks, small speakers, and rechargeable fans. Help me think through the trends that could affect my business over the next 6–12 months. Consider: fuel and transport costs, the naira and import prices, changes in how people shop (online, WhatsApp, delivery), new competitors like Jumia or Instagram vendors, what young people are doing differently, and any government policy directions for my sector. For each trend, tell me: threat or opportunity, how soon it matters, and one practical thing I can do now. Be honest about what you are unsure of.

**Naija tip:** This is one prompt where you must **check before you trust**. The AI does not know today's exchange rate, this week's fuel price, or last month's CBN circular. Use it for *thinking* — to spot the shape of what's coming — then confirm specific numbers with real sources (news, your suppliers, your bank). The trend that has affected almost every Nigerian small business recently is simple: customers are buying smaller quantities more often. Plan for that.

---

## Prompt 1.18

### Title: Understand a Customer Group You Don't Know Well

**Use this when:** You want to start selling to a new type of customer — a different age group, income level, religion, region, or profession — and you do not want to make embarrassing or expensive mistakes.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, and I currently serve mostly [current customer type]. I want to start selling to [new customer group — e.g., university students, corporate offices, Northern Muslim women, retirees, expatriates, Gen Z, Igbo traders, church groups]. I do not know this group well. Help me understand them respectfully and practically. Tell me: (1) what they typically value when buying [my type of product/service], (2) how they prefer to be approached and communicated with, (3) cultural, religious, or social considerations I must respect, (4) mistakes outsiders commonly make with this group, (5) what price sensitivity to expect, and (6) how to earn their trust as a newcomer. If there are things that vary a lot within this group, say so.

**Real example (filled in):**

> I run a modest-fashion and hijab business in Ilorin, currently serving mostly Muslim women aged 25–45. I want to start selling to university students at UNILORIN and Kwara State University — young women aged 17–24. I do not know this group well. Help me understand them respectfully and practically. Tell me: (1) what they value when buying modest fashion, (2) how they prefer to be approached, (3) cultural or social considerations, (4) mistakes older sellers commonly make with them, (5) price sensitivity, and (6) how to earn their trust as a newcomer.

**Naija tip:** Nigeria is not one market — it is hundreds. What works in Aba may fail in Sokoto; what a 45-year-old wants is not what a 20-year-old wants. Use this prompt to prepare, then **find one or two real people from that group and ask them to check your plan**. Pay them a small "consultation fee" (₦2,000–₦5,000 or a free product). Their 20 minutes of honest feedback is worth more than 20 pages of AI output.

---

## Prompt 1.19

### Title: Research Your Competitors' Pricing and Offers Systematically

**Use this when:** You want a clear picture of what everyone in your market is charging and offering, so you can position yourself intelligently rather than guessing.

**Copy this prompt:**

> I sell [product/service] in [area], Nigeria. I have gathered this information about competitors: [for each competitor: name or description, their prices for the same or similar items, any extras they offer — delivery, warranty, discount, packaging, credit — and what customers say about them]. Organise this into a clear comparison table with columns for: competitor, price, extras, strengths, weaknesses. Then tell me: (1) where I currently sit compared to them, (2) whether the market is competing mainly on price, quality, service, or convenience, (3) an open position no one is occupying that I could take, (4) what I should charge and what I should include to be clearly different, and (5) how to explain my position to customers in one simple sentence.

**Real example (filled in):**

> I sell school uniforms and sportswear to primary and secondary schools in Ilesa. Competitor info: (A) Big tailor near the market — ₦6,500 per uniform set, 2-week delivery, sometimes late, good quality; (B) A woman who imports ready-made from Lagos — ₦5,000 per set, sizes are often off, no adjustments; (C) A new shop with a machine embroidery for school logos — ₦7,500, 1-week delivery, very neat, but only does bulk orders of 20+. I charge ₦6,000, take 10 days, do adjustments free, no embroidery. Organise this into a comparison table. Then tell me: (1) where I sit, (2) what the market is competing on, (3) an open position I could take, (4) what I should charge and include, and (5) how to explain my position in one sentence.

**Naija tip:** Gather this data the Nigerian way — send a friend or relative to "price" each competitor as a customer, on WhatsApp and in person. Ask about delivery, discount for bulk, and what happens if there's a problem. Do this every 3 months; prices in Nigeria move fast and a competitor's "extras" change often. And remember: the goal is not to be the cheapest. The goal is to be the obvious choice for a specific kind of customer.

---

## Prompt 1.20

### Title: Summarise Everything Into a One-Page Customer & Market Brief

**Use this when:** You have done several of the prompts above and want to bring all the insights into one simple document you can look at every week and share with anyone helping you (staff, family, partner).

**Copy this prompt:**

> I have been researching my customers and market for my [business type] in [area], Nigeria. Here is what I have learned so far: [paste or summarise your findings — ideal customer profile, what they want, why they buy, main competitors, pricing insights, best channels to reach them, main objections, opportunities spotted]. Turn all of this into a clear one-page Customer & Market Brief with these sections: (1) Who my customer is (3–4 lines), (2) What they really want and fear, (3) Where to find them, (4) My competitors and my position, (5) My price and why, (6) The top 3 opportunities I should act on in the next 90 days, and (7) The 3 things I must stop doing. Use simple language a staff member with only secondary school education could understand. Keep it to one page.

**Real example (filled in):**

> I have been researching my customers and market for my frozen foods shop (chicken, turkey, fish, sausages) in Warri. What I've learned: my ideal customer is a working mother, 30–50, buying weekly on Saturdays, who values freshness and honest weighing more than the lowest price. Her fear is buying meat that has been thawed and refrozen. Main competitors: two other cold rooms nearby — one is cheaper but their light goes off often, the other is bigger but the staff are rude. My prices are mid-range. Best channel is WhatsApp Status and referrals from church women. Main objection: "Is your freezer always on?" Opportunities: a Saturday morning pre-order via WhatsApp, a small home delivery service, and portioned packs for single people. Turn this into a one-page Customer & Market Brief with the 7 sections. Use simple language. Keep it to one page.

**Naija tip:** Print this brief. Paste it inside your shop (where customers cannot see it) or save it as your phone wallpaper for a week. Read it before every big decision — new stock, new price, new staff, new advert. When you find yourself about to do something that contradicts the brief, stop and ask why. Redo this prompt every 90 days; your customers change, and so should your understanding of them.

---

## Part 1 Checkpoint

Before you move on to Part 2, make sure you can answer these five questions **without thinking too hard**:

1. Who is my ideal customer? (Name, age, job, income, what they fear.)
2. What is the real problem I solve for them — beyond the product?
3. Why do some people buy from my competitor instead of me?
4. Where do my customers spend their time and attention?
5. What is the one opportunity I will act on in the next 30 days?

If you can answer all five, you already know your market better than most businesses in your area. Now let us go and get those customers — cheaply.

**Next: Part 2 — Low-Cost Marketing That Actually Works in Naija (Prompts 2.1 – 2.20)**
