# LISTING & LAUNCH KIT
*AI Made Simple for Nigerian Small-Business Owners — Book 1*

Use this for Selar, Paystack Storefront, Gumroad, Bizflex, Instagram, and WhatsApp. Copy exactly; fill only the [brackets].

---

## 1. PRICING

| Channel | Launch price (first 14 days) | Regular price | Notes |
|---|---|---|---|
| Nigeria (Paystack / Selar / Bizflex / WhatsApp) | **₦5,000** | **₦7,500** | Launch price collects the first 20–30 testimonials fast |
| International (Flutterwave USD / Gumroad) | **$7** | **$9** | Diaspora buyers gifting to family businesses at home |
| Bundle: this book + Beginner-Friendly AI Prompt Workbook | ₦9,500 / $12 | ₦12,000 / $15 | "The Business AI Starter Pack" |

**Anchor line for every listing:** *"Less than the cost of one day's generator fuel — and it pays for itself with one extra sale."*

---

## 2. PRODUCT TITLE (max clarity for search)

**Primary:**
AI Made Simple for Nigerian Small-Business Owners — 120 Copy-Paste AI Prompts + 15 Business Tools (PDF)

**Short (Instagram/Bizflex, under 60 chars):**
AI Made Simple for Naija Business Owners (120 Prompts)

---

## 3. PRODUCT DESCRIPTION (Selar / Paystack / Gumroad — long form)

**Grow your business with AI — even if you've never used it before.**

You already work harder than most people can imagine. NEPA, fuel, POS charges, haggling customers, WhatsApp vendors undercutting you, and a naira that won't sit still. You don't need more hustle. You need a tireless assistant who writes your messages, does your maths, rehearses your negotiations and plans your week — for free, inside the WhatsApp you already use.

That assistant is AI. This book shows you exactly what to type.

**What you get (131-page PDF, phone-friendly):**

✅ **120 ready-to-copy prompts** across 6 Parts — just fill the [brackets] and paste into Meta AI, ChatGPT, Gemini or DeepSeek
✅ **A real Nigerian example for every prompt** — salons, bukas, POS agents, tailors, poultry farms, provisions shops, phone repairers, bakeries, and more, from Kano to Aba to Lagos
✅ **A "Naija tip" with every prompt** — the local angle no foreign book knows
✅ **15 ready-to-use tools** — 90-Day Revenue Tracker, Expense Tracker, Daily Sales Sheet (POS-friendly), NEPA & Generator Calculator, 60 WhatsApp Status hooks, 40 follow-up messages, Referral Card, Business Proposal Template, Risk & Survival Matrix and more
✅ **A week-by-week 90-Day Action Plan** so you know exactly what to do on Monday

**The six Parts:**
1. Deep Customer Understanding & Market Research — know who buys, why, and what they'll pay
2. Low-Cost Marketing That Actually Works in Naija — WhatsApp Status, referrals, testimonials, community
3. Sales, Negotiation & Closing — "e too cost", "last price?", "I'll come back" — handled
4. Operations, Automation & Cost Cutting — SOPs, Quick Replies, generator costs, stock control
5. Product Innovation & New Revenue Streams — bundles, subscriptions, classes, resellers, diaspora dollars
6. Finance, Funding & Smart Growth — true profit, break-even, cash flow, loans, grants, investors

**Designed to help you** add ₦1.5M–₦3M in revenue within 90 days and cut operating costs by 35% — by knowing your customer, marketing for free, closing more sales at better prices, and keeping the money you earn. Trackers included so you measure your own results.

**Who it's for:** shop owners, salon operators, POS agents, fashion sellers, agropreneurs, restaurant and food vendors, service businesses — anyone running a small business in Nigeria with a phone and WhatsApp.

**Who it's not for:** people looking for "AI theory", or a get-rich-quick scheme. This is work — made faster.

**Format:** PDF, instant download after payment. Read on any phone. Print any page.

> *"No tech jargon. No laptop needed. If you can send a WhatsApp message, you can use this book."*

**Questions?** WhatsApp +234 902 190 6332.

---

## 4. SHORT DESCRIPTION (Bizflex / Instagram bio link / under 300 chars)

120 copy-paste AI prompts + 15 tools for Nigerian small businesses. Real Naija examples, WhatsApp-first, no laptop needed. Know your customer, market for free, close more sales, cut costs 35%, keep your profit. 131-page PDF. ₦5,000 launch price.

---

## 5. TAGS / KEYWORDS

Nigeria small business · AI prompts · ChatGPT for business · Meta AI WhatsApp · WhatsApp marketing Nigeria · small business Nigeria · SME Nigeria · business growth · Naija business · sales scripts · cost cutting · POS business · salon business · fashion business Nigeria · agribusiness · ebook Nigeria · digital product · Fresh Genesis

---

## 6. FAQ (paste under the listing)

**Do I need a laptop?** No. Everything works on a phone. Meta AI inside WhatsApp is enough.
**Do I need to pay for AI?** No. Meta AI, ChatGPT free, Gemini and DeepSeek are all free.
**Is this only for big businesses?** No — it was written for kiosks, market stalls, salons, POS points, one-woman fashion brands and food vendors. Examples start from ₦500 sales.
**How do I get the file?** Instant download after payment (Selar/Paystack/Gumroad). If you pay by transfer via WhatsApp, the PDF is sent to your WhatsApp within minutes during business hours.
**Can I print it?** Yes — print any page for your shop wall or staff.
**Refunds?** Digital product — no refunds once downloaded. Read the free sample first (see below).
**Is the ₦1.5M–₦3M guaranteed?** No. It's a target with a plan and trackers. Results depend on your business and your execution.

---

## 7. FREE SAMPLE (lead magnet)

Give away **Prompts 1.1, 2.2 and 3.3** (customer profile, 30-day Status plan, negotiation floor) as a 5-page PDF titled *"3 AI Prompts Every Naija Business Owner Should Try This Week."* Deliver via WhatsApp when someone sends **"SAMPLE"**. Follow up on Day 2 and Day 5 with the launch offer.

---

## 8. LAUNCH MESSAGES

### A. WhatsApp Status — 7-day launch sequence

**Day −3 (teaser):** I've been working on something for every Nigerian business owner who has ever said "AI is not for people like me." Launching Monday. 👀

**Day −1:** Tomorrow: 120 copy-paste AI prompts, written for Naija businesses — salons, POS, food, fashion, provisions, farms. Real examples. WhatsApp-first. Launch price for 14 days only.

**Day 0 (launch):** It's here 🎉 *AI Made Simple for Nigerian Small-Business Owners* — 120 prompts + 15 tools + a 90-day plan. Launch price ₦5,000 (regular ₦7,500). Reply **"BOOK"** to order. First 20 buyers get the Prompt Workbook free.

**Day 1 (proof):** Page 47: how to answer "e too cost" without dropping your price. Page 61: your negotiation floor. Page 88: the NEPA calculator that shows your true generator cost. Reply "BOOK".

**Day 2 (social proof):** [Screenshot of first buyer's message] — "I used prompt 3.5 this morning and closed two orders that had gone quiet." This is why I wrote it. Reply "BOOK".

**Day 4 (objection):** "I don't have a laptop." You don't need one. Every prompt works in Meta AI inside WhatsApp — the app you're reading this on. Reply "BOOK".

**Day 6 (urgency, honest):** Launch price ends Sunday night. After that it's ₦7,500. If you've been meaning to, this is the week. Reply "BOOK".

### B. Direct message to warm contacts (personalised)

> Hi [Name], it's [Your name]. I've just published a book I think will genuinely help your [business type]: 120 ready-to-paste AI prompts built for Nigerian businesses — writing your Status posts, handling "last price", cutting generator costs, knowing your real profit. It's ₦5,000 this week (₦7,500 after). Want me to send the sample first? No pressure at all.

### C. Order-handling Quick Replies

| Shortcut | Message |
|---|---|
| /book | Thank you! The book is ₦5,000 (launch price). Pay here: https://paystack.shop/pay/7eipl558t6 — or transfer to [account]. Send your receipt and I'll deliver the PDF to this chat right away. 🙏 |
| /bookusd | For international cards: $7 via https://flutterwave.com/pay/nahf6maetqjs — send a screenshot and the PDF comes straight to this chat. |
| /delivered | Here's your copy 📘 Start with Prompts 1.1, 2.2 and 3.3 this week. Save this number for updates, and please send me your first win — I mean it! |
| /sample | Here's the free 3-prompt sample 📄 Try one today. The full book (120 prompts + 15 tools) is ₦5,000 this week — reply "BOOK" when ready. |

---

## 9. INSTAGRAM / FACEBOOK CAPTION

New book for every Naija business owner 📘

**AI Made Simple for Nigerian Small-Business Owners**
120 copy-paste prompts. 15 tools. One 90-day plan.

For the salon owner, the POS agent, the fashion seller, the buka, the provisions shop, the farmer.
✔ Write your Status posts in 2 minutes
✔ Answer "e too cost" without dropping price
✔ Know your true generator cost — and cut it
✔ Find your real profit (most people are shocked)
✔ Works in Meta AI on WhatsApp. No laptop.

₦5,000 launch price (14 days) · Link in bio · or DM "BOOK"

#NaijaBusiness #SmallBusinessNigeria #AIforBusiness #WhatsAppMarketing #LagosBusiness #AbujaBusiness #PortHarcourtBusiness #NigerianEntrepreneur #SMENigeria #FreshGenesis

---

## 10. UPLOAD CHECKLIST

- [ ] PDF: `book/PDF/AI-Made-Simple-Nigerian-Small-Business-Owners.pdf` (131 pages)
- [ ] Cover image: `book/cover/cover.png` (1600×2400)
- [ ] Selar: create product → digital → upload PDF → price ₦5,000 (schedule change to ₦7,500 on day 15) → paste long description + FAQ → tags → enable affiliate at 30% (resellers/agents sell for you)
- [ ] Paystack Storefront: add product with the same copy; link: existing pay page for WhatsApp orders
- [ ] Gumroad: price $7 → description → tags; confirm payout setup (Grey USD account for ACH) before first sale
- [ ] Bizflex: add product listing + payment link (store currently shows "no items")
- [ ] Fresh Genesis website: product card live (see `fresh-genesis-website/`)
- [ ] Free sample PDF made (3 prompts) and saved as a Quick Reply attachment
- [ ] Quick Replies /book /bookusd /delivered /sample saved in WhatsApp Business
- [ ] First 5 testimonials collected → added to listing within 7 days
