# PART 3: SALES, NEGOTIATION & CLOSING MORE DEALS
*(Prompts 3.1 – 3.20)*

---

## Where the Money Actually Leaks

Part 1 taught you who your customer is. Part 2 brought them to your WhatsApp. Now comes the moment most Nigerian businesses quietly lose money: the conversation between "how much?" and "I've paid."

Think about last week. How many people asked for price and went silent? How many said "last price?" and you dropped ₦1,000 too fast? How many said "I'll come back" and never did? How many bought one item when they would happily have bought two, if only you had asked?

That gap — between enquiry and payment — is where your ₦1.5M–₦3M is hiding. You do not need more customers to find it. You need to **convert more of the ones you already have, at a price that protects your profit.**

Selling well in Nigeria has its own rules:

- **Haggling is culture, not insult.** The customer expects a dance. You must know your floor before the music starts.
- **Trust closes more sales than discounts.** "Is it original?" is the real question behind most objections.
- **Relationship beats transaction.** The seller who remembers your name and your child's school sells to you for ten years.
- **Silence is not "no".** It is usually "not yet" — salary, spouse, or a competitor's price.

In this Part, AI becomes your sales coach. It will write your scripts, prepare your answers, rehearse difficult customers with you, and help you set a negotiation floor that keeps you profitable.

**Start with 3.1, 3.3 and 3.6** — your core script, the "last price" strategy, and the trust-builders. Then use the rest as situations arise.

---

## Prompt 3.1

### Title: Write Your Core Sales Conversation Script (WhatsApp and In Person)

**Use this when:** Every sales conversation feels improvised, or you and your staff answer the same enquiry in five different ways.

**Copy this prompt:**

> I sell [product/service] in [area], Nigeria, at ₦[price/range]. My customers are [describe]. What makes me different: [your edge]. Write me a natural, step-by-step sales conversation script for when someone enquires — one version for WhatsApp chat and one for a face-to-face customer in my shop. Each script should: (1) open warmly and get their name, (2) ask 2–3 quick questions to understand what they actually need, (3) recommend the right option and explain the value before stating price, (4) state the price with confidence and one reason it's worth it, (5) handle the first objection, and (6) close by asking for the order or the next step. Keep it conversational — Nigerian English, short messages, no long paragraphs. Mark which lines to adapt.

**Real example (filled in):**

> I sell solar-powered rechargeable lanterns and small home solar kits in Minna, Niger State, ₦8,500–₦95,000. My customers are families in areas with poor electricity, small shop owners, and students. What makes me different: I test every unit before sale, offer a 6-month replacement warranty, and install the bigger kits myself. Write me a step-by-step sales conversation script — one for WhatsApp, one for face-to-face — that opens warmly, asks 2–3 questions to understand their need, recommends the right option and explains value before price, states price confidently, handles the first objection, and closes by asking for the order. Conversational Nigerian English, short messages.

**Naija tip:** The single most profitable line in the script is step 2: **ask questions before you quote.** "Is it for your shop or your house? How many hours of light do you need at night?" Two questions change you from a price-list into an adviser — and advisers get less haggling. Save the WhatsApp version as **Quick Replies** in WhatsApp Business (Business tools → Quick replies) so you and your staff send the same quality answer every time.

---

## Prompt 3.2

### Title: Handle "It's Too Expensive" Without Dropping Your Price

**Use this when:** "Ah, it's too much" or "e too cost" is the most common thing you hear, and your reflex is to discount immediately.

**Copy this prompt:**

> I sell [product/service] at ₦[price] in Nigeria. My cost is ₦[cost] so my margin is roughly [amount or %]. Customers often say "it's too expensive" or "e too cost." Give me 8 different ways to respond that protect my price, each 1–3 sentences: (1) reframing the price per day/week/use, (2) comparing to the cost of the problem or the cheaper alternative failing, (3) explaining what's included that others leave out, (4) offering a smaller option instead of a discount, (5) asking what budget they had in mind, (6) sharing a quick customer story, (7) acknowledging the price and standing firm politely, and (8) a payment-plan or deposit option. Then tell me which two to use first and when to simply let a customer go.

**Real example (filled in):**

> I sell quality school bags and lunch boxes in Ilorin — bags ₦12,000–₦18,000, my cost is about ₦8,000–₦11,000, so I make ₦4,000–₦7,000 per bag. Parents often say "ah, ₦15,000 for school bag? E too cost." Give me 8 different ways to respond that protect my price: reframing per term/per year, comparing to buying two cheap ₦6,000 bags that tear by second term, explaining the padded straps and waterproof base, offering a smaller size, asking their budget, a quick customer story, standing firm politely, and a deposit option. Then tell me which two to use first and when to let the customer go.

**Naija tip:** "E too cost" is often an **opening move**, not a verdict. Never answer it with a number — answer it with value, then silence. Let them speak next. And know your **walk-away price** before the conversation starts (see 3.3). Many Nigerian sellers lose 20–30% of their profit not to competition, but to their own panic in the first ten seconds after "e too cost."

---

## Prompt 3.3

### Title: Set Your Negotiation Floor and "Last Price" Strategy

**Use this when:** "Last price?" is a daily question, and you don't have a clear system — so you decide based on mood, and sometimes sell at a loss.

**Copy this prompt:**

> I run a [business type] in Nigeria. For my main products, here are the cost prices and my normal selling prices: [list 3–6 items with cost and selling price]. My monthly fixed costs (rent, generator, staff, transport, data) total about ₦[amount], and I sell roughly [number] items per month. Help me build a simple negotiation system: (1) calculate the true minimum price per item that still covers my share of fixed costs and leaves at least [X]% profit, (2) set three price levels for each item — opening price, "good customer" price, and absolute floor, (3) tell me what to ask for in exchange for any discount (buy two, pay now, refer a friend, collect a testimonial, pay cash), (4) give me 5 natural ways to say "this is my last price" that sound firm but friendly, and (5) a rule for when I should walk away from a sale.

**Real example (filled in):**

> I run a small phone and accessories shop in Onitsha. Main items — Type-C charger: cost ₦2,200, sell ₦3,500; power bank 20,000mAh: cost ₦11,000, sell ₦16,000; earpiece: cost ₦1,500, sell ₦2,500; tempered glass: cost ₦400, sell ₦1,000; phone case: cost ₦1,200, sell ₦2,500. Monthly fixed costs are about ₦180,000 and I sell roughly 400 items a month. Help me build a negotiation system: true minimum price per item that covers fixed costs plus at least 15% profit, three price levels per item (opening, good-customer, floor), what to ask for in exchange for any discount, 5 friendly ways to say "this is my last price," and a walk-away rule.

**Naija tip:** Write the floor prices on a small card taped under your counter or saved in your phone notes. When a customer pushes, you glance, you know, you stop shaking. And adopt the golden Naija rule: **never give a discount for free.** "Okay, I'll do ₦15,000 — but you'll take the case with it" or "…but you'll send me one customer this week." The discount then becomes a sale, not a loss.

---

## Prompt 3.4

### Title: Turn "I'll Come Back" and "Let Me Think About It" Into a Sale

**Use this when:** Customers leave with a polite promise and rarely return.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price]. Customers frequently say "I'll come back," "let me think about it," "let me ask my husband/wife," or "I'll call you." Help me handle this properly. Give me: (1) three gentle questions to ask at that moment to uncover the real hesitation (money, trust, need, permission, comparison), (2) what to say for each of those real reasons, (3) a respectful way to create a reason to decide today — without fake pressure, (4) what to do before they leave so I can follow up (get their number, send them something), and (5) a 3-step follow-up plan over the next 7 days. Keep the tone warm and relaxed — Nigerian customers dislike pushy sellers.

**Real example (filled in):**

> I sell made-to-measure men's suits and native wear in Abuja, ₦45,000–₦150,000. Customers come, get measured or look at fabrics, then say "let me think about it" or "I'll discuss with my wife." Help me handle this properly: three gentle questions to uncover the real hesitation, what to say for each real reason, a respectful way to create a reason to decide today (for example, tailoring slots for the wedding season), what to do before they leave so I can follow up, and a 3-step follow-up plan over 7 days. Warm and relaxed tone.

**Naija tip:** "Let me ask my husband/wife" is a real reason in Nigeria — respect it and **arm them for that conversation**: "No problem, ma. Let me send you the photo and a short note on why this fabric lasts, so you can show him." You just turned your customer into your salesperson. And always get the number *before* they leave: "Let me send you the picture on WhatsApp so you have it" is the easiest way to ask.

---

## Prompt 3.5

### Title: Reply to Price Enquiries on WhatsApp So People Actually Buy

**Use this when:** You reply "₦15,000" to "how much?" and the chat dies. Every day.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price]. When people message "how much?" or "price?", I reply with the price and they usually go quiet. Write me 5 better reply templates (each under 60 words) that: state the price clearly, add one line of value or reassurance, and end with a question or next step that keeps the chat alive. Include versions for: (1) a single product, (2) a product with options/sizes, (3) a service that needs details before quoting, (4) an item currently on offer, and (5) a customer who has enquired before. Then give me 3 follow-up lines if they read it and don't reply within 24 hours.

**Real example (filled in):**

> I sell customised cakes in Lagos Island — ₦15,000 for 8 inches, ₦25,000 for 10 inches, more for tiers or fondant. When people message "how much for cake?" I reply with the price and they go quiet. Write me 5 better reply templates under 60 words: single product, product with sizes, a service that needs details first (event date, design, servings), an item on offer, and a returning enquirer. Each states price, adds one line of value or reassurance, and ends with a question or next step. Then 3 follow-up lines for when they read and don't reply within 24 hours.

**Naija tip:** Never let your price be the last word in a message. Price, then value, then a **question that's easy to answer**: "₦15,000 for 8 inches, feeds about 15 people — and I deliver on the day so it arrives fresh. What date is the celebration?" A question about *their* event pulls them into planning with you, and people rarely abandon a plan they've started.

---

## Prompt 3.6

### Title: Build Trust Fast With a Stranger ("Is It Original? Are You Real?")

**Use this when:** New customers — especially online — hesitate because they don't know you, fear fakes, or fear being scammed.

**Copy this prompt:**

> I sell [product/service] in Nigeria, mostly to people who find me online and have never met me. They often worry: is it original, is this person real, what if I pay and nothing arrives, what if it spoils. Give me: (1) a list of 10 trust signals I can put in place this week at little or no cost (for example, real photos, video proof, a business name, a physical address, policies, reviews), (2) the exact words to reassure a hesitant customer at the moment of doubt, in 3 short versions, (3) a simple, fair policy on payment before delivery vs. pay on delivery that protects both me and the customer, and (4) how to handle a customer who says "I've been scammed before" — turning it into a reason to trust me.

**Real example (filled in):**

> I sell original perfumes and designer body sprays online from Lagos, ₦18,000–₦85,000, delivering nationwide. Customers who find me on Instagram and WhatsApp worry: is it original, is this person real, what if I pay and nothing arrives. Give me: 10 trust signals I can set up this week cheaply, the exact words to reassure a hesitant customer in 3 short versions, a fair payment-before-delivery vs. pay-on-delivery policy that protects both sides, and how to handle "I've been scammed before."

**Naija tip:** The fastest trust-builders in Nigeria: **a short video of you holding the actual item, showing the batch code**, a **registered business name** (CAC registration is now affordable and can be done online), a **business bank account in that name** (customers notice when the account name matches), and **screenshots of delivery confirmations** from other cities. Have a "Proof" folder ready to forward in one tap.

---

## Prompt 3.7

### Title: Upsell and Cross-Sell Without Sounding Greedy

**Use this when:** Customers buy one item and you never suggest anything else — leaving 20–40% extra revenue on the table.

**Copy this prompt:**

> I run a [business type] in Nigeria. Here are my products/services and prices: [list]. For each of my main items, suggest: (1) one natural "goes with it" add-on I should offer (cross-sell), (2) one "better version" I could suggest (upsell), and (3) the exact one-sentence line to suggest it in a helpful, not pushy, way — at the right moment (after they've decided, not before). Then design two simple bundles that increase the average sale while giving the customer a real saving, and write the line for offering the bundle. Finally, tell me the one mistake to avoid when upselling to Nigerian customers.

**Real example (filled in):**

> I run a small barbing and grooming shop in Enugu. Services and prices: haircut ₦2,500; haircut + beard shaping ₦3,500; hair dye ₦4,000; facial scrub ₦3,000; home service ₦6,000. Products: beard oil ₦3,500, hair sponge ₦1,500, aftershave ₦2,500, durag ₦2,000. For each main service, suggest one natural add-on, one better version, and the exact helpful one-sentence line to suggest it at the right moment. Design two bundles that increase the average sale with a real saving, and write the offer line. Tell me the one mistake to avoid when upselling to Nigerian customers.

**Naija tip:** Upsell **after the yes**, never before. Once the customer has committed to the haircut, "Should I shape the beard too? Just ₦1,000 extra today" feels like service, not pressure. And use the **"most people" line**: "Most people who buy this power bank take the fast-charge cable too — you want it?" Nigerians are comforted by what others do. Aim to add ₦500–₦2,000 to every third sale; over a month, that's rent.

---

## Prompt 3.8

### Title: Recover Abandoned Orders and Unpaid Invoices Politely

**Use this when:** Someone agreed to buy, you sent account details, and… nothing. Or a customer owes you and you're afraid to sound rude.

**Copy this prompt:**

> I run a [business type] in Nigeria. Two situations keep happening: (A) a customer says "send account details," I send them, and they never pay; (B) a customer collected goods or a service on credit and is late paying ₦[amount]. Write me: for (A), a 3-message sequence over 5 days — friendly reminder, value/scarcity nudge, final gentle close; for (B), a 4-message sequence over 3 weeks that gets firmer each time but stays respectful — including what to say on a phone call and when to stop selling to them. Each message under 60 words. Also give me a policy statement I can post or send to prevent both problems in future.

**Real example (filled in):**

> I run a small building materials shop in Ibadan — cement, rods, tiles, paint. Situation A: contractors say "send account," I send, and no payment comes. Situation B: a regular contractor collected ₦240,000 worth of cement on credit 3 weeks ago and has gone quiet. Write me a 3-message sequence over 5 days for A, and a 4-message sequence over 3 weeks for B that gets firmer but stays respectful, including a phone-call script and when to stop selling to him. Each message under 60 words. Plus a credit-and-payment policy statement I can send to customers to prevent this in future.

**Naija tip:** In Nigeria, debt messages work best when they **give the debtor a way to save face**: "Oga Musa, I know things are tight — can you send ₦100,000 today and the balance by Friday?" A part-payment plan recovers far more than an ultimatum. And write your credit policy *now*, while you're not angry: "Credit only for customers with 3+ paid orders, maximum ₦50,000, 7 days." Post it. Then it's the policy saying no, not you.

---

## Prompt 3.9

### Title: Handle the 12 Most Common Objections in Your Business

**Use this when:** You want to be ready for every "but…" a customer might raise, so nothing catches you off guard.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price] to [customer type]. List the 12 most common objections customers in my business are likely to raise — price, trust, timing, quality, comparison, delivery, warranty, "let me ask someone," "I saw it cheaper," and any specific to my product. For each objection: (1) what the customer is really thinking, (2) a short, natural response that acknowledges their concern first, then answers it, and (3) a question to ask afterwards to move the conversation forward. Format it as a table I can print and keep by my phone: Objection | What they really mean | My response | My follow-up question.

**Real example (filled in):**

> I sell inverter batteries and installation in Port Harcourt, ₦180,000–₦650,000 for complete setups, to households and small offices. List the 12 most common objections — price, trust, timing, quality/fake batteries, "my neighbour's inverter spoiled quickly," comparing to generator cost, warranty, "let me ask my husband," "I saw it cheaper at Mile 1 market," installation fears, maintenance, and any others. For each: what they're really thinking, a short response that acknowledges then answers, and a follow-up question. Format as a printable table.

**Naija tip:** Print the table. Give a copy to every staff member. Rehearse it out loud — literally read the objection and answer it, until the answers come out naturally. Nigerian customers can smell hesitation; a seller who answers "what if it spoils?" instantly and calmly is believed. A seller who pauses is doubted, however honest they are.

---

## Prompt 3.10

### Title: Practise a Difficult Customer Conversation With AI (Role-Play)

**Use this when:** You have a tough conversation coming — a big client, a difficult negotiation, a complaint — and you want to rehearse before the real thing.

**Copy this prompt:**

> I want to practise a sales conversation. Play the role of a [type of customer — e.g., tough Nigerian market woman buying in bulk, a busy corporate buyer, a suspicious first-time online customer, an angry customer whose order was late]. I am a [your business] selling [product] at ₦[price]. Be realistic — haggle, doubt me, raise real objections, use natural Nigerian expressions, and don't make it easy. I will respond as myself. After every 3 exchanges, pause and give me brief feedback on what I did well and what I should change, then continue. At the end, give me a score out of 10 and the three biggest improvements I should make.

**Real example (filled in):**

> I want to practise a sales conversation. Play the role of a tough Igbo trader in Onitsha main market who wants to buy 50 pieces of my ladies' handbags for resale and is famous for negotiating hard. I sell handbags at ₦6,500 retail; my wholesale floor is ₦4,800 and my cost is ₦3,900. Be realistic — haggle, claim other suppliers are cheaper, ask for credit, use natural Nigerian expressions, and don't make it easy. I'll respond as myself. After every 3 exchanges, pause and give me feedback, then continue. At the end, score me out of 10 and give my three biggest improvements.

**Naija tip:** This is one of the most powerful uses of AI in this whole book and almost nobody does it. Ten minutes of role-play before a big negotiation is worth more than an hour of worrying. Do it in Meta AI on WhatsApp — it feels like chatting with a real person. Practise the customer you *fear* most. After three sessions, the real one will feel easy.

---

## Prompt 3.11

### Title: Write a Persuasive Quotation or Proposal for a Bigger Client

**Use this when:** A school, church, company, hotel, or government office asks for a quotation, and you want to look professional and win it.

**Copy this prompt:**

> A [type of organisation] in Nigeria has asked me for a quotation/proposal for [what they want]. My business is [type]. Details: [quantities, specifications, timeline, my prices, what's included, delivery, payment terms]. Write me a professional but simple one-page quotation/proposal that includes: a short introduction of my business and why we're reliable, a clear breakdown of items and prices in a table (with VAT note if applicable), what's included and not included, delivery/completion timeline, payment terms (deposit and balance), validity period of the quote, a warranty or guarantee line, and a polite closing that asks for the order. Also give me a short cover message for sending it by WhatsApp or email.

**Real example (filled in):**

> A private secondary school in Owerri has asked me for a quotation for 120 sets of school uniforms (shirts and trousers/skirts) plus 120 sports kits. My business is a tailoring and uniform production workshop. Details: uniforms ₦9,500 per set, sports kits ₦6,000 per set, fabric and embroidery of the school crest included, delivery in 4 weeks from deposit, 60% deposit and 40% on delivery, free size adjustments for 2 weeks after delivery. Write me a professional one-page quotation with an intro, price table, inclusions/exclusions, timeline, payment terms, 14-day validity, guarantee line, and a polite close. Plus a short cover message for WhatsApp/email.

**Naija tip:** Institutional buyers in Nigeria judge you on **presentation and reliability**, not just price. A clean PDF quotation with your business name, CAC number, address, and a validity date beats a WhatsApp voice note every time. Always include the validity period — prices move — and always ask for a deposit; institutions are notoriously slow to pay balances, and the deposit funds your materials. Convert the AI's text to PDF using your phone (Google Docs → Share → Save as PDF).

---

## Prompt 3.12

### Title: Sell to Bulk Buyers, Resellers and Wholesale Customers

**Use this when:** You want to move from selling one-by-one to selling in tens and hundreds to people who resell.

**Copy this prompt:**

> I sell [product] at ₦[retail price] with a cost of ₦[cost]. I want to attract bulk buyers and resellers in Nigeria. Help me: (1) design a wholesale price structure with 3 tiers (e.g., 10+, 50+, 100+ units) that stays profitable for me and attractive to resellers, (2) set minimum order rules and payment terms for wholesale, (3) write a short wholesale offer message I can send to potential resellers — market traders, Instagram vendors, shop owners — that shows them the profit they can make, (4) list where to find resellers in Nigeria for my kind of product, and (5) tell me how to protect my retail business from being undercut by my own resellers.

**Real example (filled in):**

> I produce liquid soap, bleach, and air freshener in Kaduna. Liquid soap 1 litre: retail ₦1,200, cost ₦550. Bleach 1 litre: retail ₦900, cost ₦400. I want to attract bulk buyers and resellers. Help me design a 3-tier wholesale price structure (12+, 50+, 100+ units) that stays profitable, set minimum order and payment rules, write a wholesale offer message that shows resellers the profit they can make, list where to find resellers for household products in Northern Nigeria, and tell me how to protect my retail price from being undercut.

**Naija tip:** Resellers in Nigeria care about one number: **"how much will I make per piece?"** Lead with it: "You buy at ₦750, sell at ₦1,200 — ₦450 profit per bottle, and my soap doesn't water down." Then protect yourself with a **recommended retail price** and a rule that resellers selling below it lose their wholesale rate. One serious reseller in a big market can outsell your shop; find three.

---

## Prompt 3.13

### Title: Close More Sales at the Point of Payment (Reduce Drop-Off at "Send Account Details")

**Use this when:** The customer says yes, you send your bank details, and a surprising number never complete payment.

**Copy this prompt:**

> I sell [product/service] in Nigeria. Many customers agree to buy, I send bank/transfer details, and then 30–40% never pay. Help me fix the payment moment. Tell me: (1) the likely reasons people drop off at this exact point, (2) how to word the payment message so it feels safe, clear and urgent — including what to put in it (account name matching business name, amount, what happens after payment, delivery time), (3) how to offer multiple payment options (transfer, POS, payment link, USSD, pay on delivery) without confusing people, (4) a message to send 2 hours later if payment hasn't arrived, and (5) a confirmation message after payment that makes them feel good about the decision and sets up the next purchase.

**Real example (filled in):**

> I sell fitness equipment and supplements in Lagos — dumbbells, resistance bands, whey protein, ₦8,000–₦120,000 — mostly to young professionals on Instagram and WhatsApp. Customers agree to buy, I send transfer details, and about a third never pay. Help me fix the payment moment: likely reasons for drop-off, how to word the payment message so it feels safe, clear and urgent, how to offer transfer, POS, payment link and pay on delivery without confusion, a 2-hour follow-up if no payment, and a post-payment confirmation that makes them feel good and sets up the next purchase.

**Naija tip:** Three things kill payment in Nigeria: **bank app network failure** ("I'll do it later" → forgets), **account name not matching** the business (fear), and **no deadline**. Fix all three: offer a Paystack or Flutterwave payment link *and* transfer details, make sure the account name matches your business name, and add a soft deadline — "I'll hold it for you till 6pm." Then confirm receipt fast, with warmth: "Received, thank you Tolu! Your order is being packed now." That message is the beginning of the next sale.

---

## Prompt 3.14

### Title: Write Sales Messages for Different Customer Moods and Situations

**Use this when:** You want ready-made messages for the recurring situations in your sales day — first-time buyer, returning customer, big spender, price-only shopper, someone referred by a friend.

**Copy this prompt:**

> I sell [product/service] in Nigeria. Write me short sales messages (each under 50 words) for these 8 situations: (1) a first-time customer who seems nervous, (2) a returning customer I haven't heard from in a while, (3) someone referred by an existing customer, (4) a customer who only ever asks about price and discounts, (5) a big spender who deserves VIP treatment, (6) a customer who complained last time but has come back, (7) someone who bought from a competitor and was disappointed, and (8) a customer buying a gift for someone else. Each message should match the mood, sound like a real Nigerian seller, and end with a clear next step.

**Real example (filled in):**

> I run a small jewellery and accessories business in Abuja — gold-plated sets, watches, and beads, ₦5,000–₦60,000. Write me short sales messages under 50 words for: a nervous first-time buyer, a returning customer I haven't heard from in months, someone referred by a friend, a price-and-discount-only shopper, a big spender who deserves VIP treatment, a customer who complained last time but came back, someone disappointed by a competitor's fake gold, and a man buying a gift for his wife. Match the mood, sound like a real Nigerian seller, end with a clear next step.

**Naija tip:** The referred customer is your **highest-converting lead** — treat them like royalty from the first line: "Ah, Ngozi's friend! You're welcome. Anyone Ngozi sends, I take special care of." You've just borrowed years of trust in one sentence. Save all 8 messages as Quick Replies; the seconds you save add up, and the consistency builds your reputation.

---

## Prompt 3.15

### Title: Sell a Service (Not a Product) Convincingly

**Use this when:** You sell something people can't touch before paying — tailoring, catering, cleaning, repairs, consulting, design, tutoring, event planning — and they hesitate because they can't see it yet.

**Copy this prompt:**

> I offer [service] in [area], Nigeria, at ₦[price/range]. Customers can't see the result before paying, so they hesitate. Help me sell this service better. Give me: (1) how to describe my service in terms of the outcome and relief the customer gets, not the tasks I do, (2) 5 forms of proof I can show before they pay — past work, process, guarantees, testimonials, a small paid trial, (3) how to structure my pricing so it feels safe — deposit, milestones, or satisfaction guarantee, (4) how to set clear expectations up front so there are no disputes later (what's included, timeline, revisions, what's extra), and (5) a short consultation script for the first conversation that positions me as the expert and ends in a booking.

**Real example (filled in):**

> I offer event planning and coordination in Benin City for weddings, birthdays and burials, ₦150,000–₦800,000 depending on scale. Customers hesitate because they can't see the result before paying. Help me sell better: describe the service as outcome and relief (not tasks), 5 forms of proof to show before payment, safe pricing structure with deposits and milestones, how to set clear expectations up front to avoid disputes, and a short first-consultation script that positions me as the expert and ends in a booking.

**Naija tip:** Service buyers in Nigeria are buying **peace of mind** and fear **disappearing acts**. Two things close them: a **process they can see** ("Here's exactly what happens from today to the event day, step by step") and **milestone payments** ("30% to start, 40% two weeks before, 30% on the day"). The milestone structure makes them feel in control — and it protects your cash flow.

---

## Prompt 3.16

### Title: Handle Haggling in a Physical Market or Shop (Face-to-Face)

**Use this when:** You sell in a market, roadside shop, or kiosk where haggling is intense and constant, and you want to keep both your customers and your margin.

**Copy this prompt:**

> I sell [product] from a [market stall / shop / kiosk] in [area], Nigeria. Face-to-face haggling is constant and intense. My prices: [items with cost and normal selling price]. Help me handle it like a master trader: (1) how to open the price conversation to leave room without looking dishonest, (2) 6 phrases in natural Nigerian English/Pidgin to hold my price with humour and warmth, (3) how to read whether a customer is a serious buyer or a time-waster, (4) the "give something small" technique — what to add instead of cutting price, (5) how to handle a customer who insults the product to lower the price, and (6) how to end a failed negotiation so they still come back another day.

**Real example (filled in):**

> I sell women's shoes and bags from a shop in Balogun Market, Lagos. Haggling is intense all day. Prices: flat sandals cost ₦3,500, sell ₦6,000; block heels cost ₦6,000, sell ₦10,000; handbags cost ₦5,500, sell ₦9,500. Help me handle it like a master trader: how to open the price conversation, 6 warm and funny phrases in Nigerian English/Pidgin to hold my price, how to tell a serious buyer from a time-waster, what to add instead of cutting price, how to handle a customer who insults the shoe to lower the price, and how to end a failed negotiation so they still come back.

**Naija tip:** The masters of Balogun, Ariaria, Kurmi and Wuse market all do the same three things: they **smile while saying no**, they **add instead of subtract** ("I no fit reduce, but I go give you this small purse join"), and they **never chase a leaving customer more than two steps**. If they come back — and they often do — the price is the price. Let the AI give you the words, but practise the smile in the mirror.

---

## Prompt 3.17

### Title: Create Urgency and Scarcity Honestly

**Use this when:** Customers like your product but keep postponing, and you want to give them a genuine reason to decide now — without lying.

**Copy this prompt:**

> I sell [product/service] in Nigeria. Customers often like it but delay buying. Give me 8 honest ways to create urgency or scarcity that are true for my business — such as limited stock, price increases coming (import/fuel costs), seasonal deadlines, production slots, delivery cut-offs, early-bird pricing, bonus for first buyers, or limited customisation slots. For each, write the exact 1–2 sentence message. Then tell me which fake-urgency tactics to avoid because Nigerian customers see through them and lose trust, and how to handle a customer who says "you said the price would go up last month and it didn't."

**Real example (filled in):**

> I sell imported children's toys and educational kits in Lagos, ₦4,000–₦45,000. Parents often like the items but delay buying. Give me 8 honest ways to create urgency that are true for my business — limited import quantities, customs and dollar-rate price changes, Christmas and birthday deadlines, delivery cut-off days, early-bird bundles. Write the exact message for each. Tell me which fake-urgency tactics to avoid, and how to answer a parent who says "you said the price would go up last month and it didn't."

**Naija tip:** In Nigeria right now, the most honest urgency is also the most powerful: **"This price is based on the stock I already bought. My next stock will cost more."** It's true, everyone knows why, and it respects the customer's intelligence. Never say "only 2 left" when there are 20 — Nigerians talk, and you only get caught once.

---

## Prompt 3.18

### Title: Handle a Complaint or Refund Request So the Customer Stays

**Use this when:** Something went wrong — late delivery, wrong item, damaged goods, poor service — and you want to fix it without losing the customer or your shirt.

**Copy this prompt:**

> I run a [business type] in Nigeria. A customer is complaining about [what went wrong] and is [angry / disappointed / asking for a refund / threatening to post about it]. The facts: [what actually happened, whose fault it was, what it would cost me to fix]. Help me respond. Give me: (1) a first message that calms them down and shows I take it seriously, without admitting fault I'm not sure of, (2) three fair resolution options — from cheapest for me to most generous — and when to use each, (3) how to deliver the resolution so they feel valued, (4) a follow-up message a week later to confirm they're happy, and (5) a simple refund and replacement policy I can publish so future complaints are easier to handle.

**Real example (filled in):**

> I run an online thrift (okrika) clothing business in Ibadan. A customer received a jacket that has a small stain I didn't notice, paid ₦9,500 including delivery, and is angry — she's threatening to post about it on Twitter. Facts: it was my mistake, a replacement jacket would cost me about ₦4,000, a refund would cost me ₦9,500 plus the return delivery. Help me respond: a first message that calms her and shows I take it seriously, three fair resolution options from cheapest to most generous, how to deliver the resolution so she feels valued, a follow-up a week later, and a refund/replacement policy I can publish.

**Naija tip:** A complaint handled brilliantly creates a **more loyal customer than one who never had a problem** — because now they have proof you're honest. Respond within one hour, apologise sincerely once (not ten times), fix it fast, and add something small ("I've added a free scarf for the inconvenience"). Then ask, gently, for a review after they're happy. Many of the best testimonials in Nigeria start with "I had an issue, but the way they handled it…"

---

## Prompt 3.19

### Title: Train Your Staff or Sales Assistant to Sell Like You

**Use this when:** You sell well, but your staff say "we don't have" and "the price is ₦5,000" and lose the customers you worked hard to bring in.

**Copy this prompt:**

> I run a [business type] in Nigeria with [number] staff who deal with customers. They currently [describe the problems — cold greetings, giving discounts too fast, not suggesting alternatives, not following up, rude on the phone]. Create a simple one-page sales guide for them with: (1) the 5 rules of serving customers in my shop, (2) the greeting and the closing line to use every time, (3) what to do when we don't have what the customer wants, (4) the discount rule — what they can and cannot offer without asking me, (5) how to handle an angry customer, and (6) a 10-minute daily role-play they can do with each other. Write it in very simple English a school-leaver can understand, and add a short quiz of 5 questions to test them.

**Real example (filled in):**

> I run a small pharmacy and provisions store in Ikorodu with 3 staff. Problems: they greet customers coldly or not at all, tell customers "we don't have" without offering alternatives, give discounts too quickly to avoid arguments, and are sometimes impatient with older customers. Create a one-page sales guide: 5 rules for serving customers, the greeting and closing line, what to do when we don't have an item, the discount rule (nothing above ₦200 without asking me), handling an angry customer, and a 10-minute daily role-play. Very simple English, plus a 5-question quiz.

**Naija tip:** Your staff sell the way they are treated. Train them, but also **pay a small commission** (even ₦50–₦100 per upsell or 1% of sales above a target). The moment your shop girl earns from suggesting the beard oil, she'll suggest it to everyone. Print the one-page guide, paste it in the back room, and do the 10-minute role-play every Monday morning. Consistency in a Nigerian shop is a competitive advantage because so few bother.

---

## Prompt 3.20

### Title: Review Your Sales Conversations and Find Your Leaks

**Use this when:** You want to know exactly where in your sales process customers are dropping off, and what to fix first.

**Copy this prompt:**

> Here are the numbers from my [business type] in Nigeria over the last [30] days: enquiries/first messages received: [number]; people who got a price: [number]; people who agreed to buy: [number]; people who actually paid: [number]; average sale: ₦[amount]; discounts given: roughly ₦[total]; repeat customers: [number]. Here are 3 real conversations that didn't end in a sale, copied here: [paste them, removing names]. Analyse this like an experienced sales coach. Tell me: (1) where the biggest drop-off is and what it's costing me in naira, (2) what I did wrong in the failed conversations — be specific and honest, (3) what I did right, (4) the two changes that would most increase my paid sales next month, and (5) a target for each stage of the funnel for next month.

**Real example (filled in):**

> Numbers from my online shoe business in Lagos over the last 30 days: enquiries: 140; people who got a price: 140; agreed to buy: 46; actually paid: 29; average sale ₦14,000; discounts given roughly ₦48,000 total; repeat customers: 6. Here are 3 real conversations that didn't end in a sale: [pasted]. Analyse this as an experienced sales coach. Tell me where the biggest drop-off is and what it costs me, what I did wrong in the failed chats, what I did right, the two changes that would most increase paid sales next month, and a target for each stage next month.

**Naija tip:** Most Nigerian business owners have never counted their funnel — and the first time they do, they find that **fixing the "agreed but didn't pay" step alone** adds 20–40% to revenue with zero extra marketing. Copy 3 failed chats into the AI every month; it will see patterns you're too close to notice. Track the numbers in the Daily Sales Record Sheet (Bonus 11). What you measure, you close.

---

## Part 3 Checkpoint

Before moving to Part 4, confirm these five are **done**:

1. You have a core sales script saved as Quick Replies, and your staff use it. *(3.1)*
2. You know the **floor price** of every major item, written down. *(3.3)*
3. Your "Proof" folder exists — real photos, videos, screenshots, CAC/business name. *(3.6)*
4. You have upsell lines and at least two bundles ready. *(3.7)*
5. You've counted your funnel for one month: enquiries → priced → agreed → paid. *(3.20)*

More enquiries are now becoming more paid orders — at better prices. Now the risk is that success eats you alive: long hours, staff issues, waste, and costs that quietly rise. Part 4 fixes that.

**Next: Part 4 — Operations, Automation & Cost Cutting (Prompts 4.1 – 4.20)**
