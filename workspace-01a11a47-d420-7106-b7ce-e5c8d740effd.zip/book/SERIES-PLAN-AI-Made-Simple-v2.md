# AI MADE SIMPLE — 7-Book Series Plan (v2, improved)
*A Fresh Genesis publication*

---

## PART A — CRITIQUE OF v1 (what was wrong and why it matters)

### 1. The headline claim is false — and it will hurt you
v1 says "All 7 eBooks – Complete & Ready-to-Copy… 100% ready-to-copy, actionable, includes prompts + real examples + checklists + templates."
**Reality:** these are seven tables of contents. Only Book 1 exists, and only its Front Matter, Part 1 and Part 2 are written. If this document is used as a sales page, listing, or investor/partner brief, it is a misrepresentation. If it is an internal plan, call it a plan. Never let marketing language leak into production documents — you will lose track of what is actually finished.

### 2. Book 1 contradicts the version you already approved
| Item | Approved (in `00-front-matter.md`) | v1 says |
|---|---|---|
| Subtitle | *120 Practical Prompts to Grow Your Business With AI — Even If You've Never Used It Before* | *How to Use AI to Grow Your Business, Cut Costs & Make More Money* |
| Bonus section | **15 named bonuses** (1–15) | "8 Templates + 7 Tools" but only 8 listed |
| Front matter | Includes *Which AI to Use* and *Check Before You Trust It* | Both missing |
| Ending | Back Matter | "Conclusion" |
One product, one spec. v2 below uses the approved version.

### 3. The outcome promises are over-stated and some are risky
- "Double your monthly income within 60 days" (Book 2)
- "3x more interview invitations within 30–45 days" (Book 4)
- "3x more content in half the time" = a 6× productivity claim (Book 5)
- "One full grade band while studying 40% less" (Book 7)

Specific numeric guarantees you cannot control invite refunds, bad reviews, and (for a paid product sold in Nigeria and abroad) consumer-protection complaints. Keep the numbers — they sell — but frame them as **targets with a mechanism** ("designed to help you… by doing X, Y, Z") and back each with a tracker so the reader can measure it themselves. v2 does this for every book.

### 4. Prompt counts are arbitrary and inconsistent
120, 110, 115, 105, 120, 110, 115 — and inside books, Parts run 15, 17, 18, 19, 20, 21. There is no reason Book 3 Part 6 has 21 prompts and Book 4 Part 3 has 15. It looks unplanned. A series needs a **signature**: "6 Parts × 20 Prompts = 120" is memorable and already committed for Book 1. v2 standardises all seven at 120.

### 5. Production reality is missing
795 prompts × ~330 words per full entry ≈ **260,000 words** — roughly three long novels — before bonuses, intros, and design. At the current pace (one Part per session), that is 42+ writing sessions plus editing. The plan needs a **release order and a "ship one, sell one" rule**, not a claim that all seven exist. v2 includes a phased roadmap.

### 6. Three content items create ethical or credibility problems
- **Book 7, Part 3: "avoid AI-detection traps."** This teaches students to disguise AI-written work. It is academic dishonesty, it contradicts the book's own "golden rule of using AI ethically," and it is exactly the kind of line that gets a product removed from a platform or torn apart in a review. **Removed** in v2 and replaced with "use AI to understand, then write it yourself."
- **Book 3, Part 6: "predicted questions" for WAEC/NECO/JAMB.** Nobody can predict exam questions; promising it damages the author's authority. **Renamed** to "high-probability topic analysis from past questions."
- **Book 6, Part 5: "ChatGPT for upskilling."** Never name one tool in a title — the series promise is tool-agnostic (Meta AI, ChatGPT, Gemini, DeepSeek). **Fixed.**

### 7. The market lane is muddled
Book 1 is unapologetically Nigerian. Books 2–7 say "Nigeria + global", "global + Nigerian", "Nigeria & abroad". A book that tries to speak to a Lagos NYSC member and a Toronto career-switcher in the same breath speaks to neither. **Decision made in v2:** every book is **Nigerian-first, diaspora-ready** — Nigerian examples and money, with explicit sections for those working with or moving to international markets. That is also the audience your payment links (Paystack ₦ + Flutterwave $) already serve.

### 8. Missing series infrastructure
v1 has no: series brand, price ladder, bundle plan, common front matter, cross-sell strategy, delivery format for the "ready-to-copy" promise, or trademark check on the title. All added below.

### 9. "Ready-to-copy" in a PDF is a broken promise
Copying prompts out of a PDF on a phone is painful — line breaks, page numbers, and quotes get mangled. If copy-paste is the core value, each book needs a **companion Prompt Library** (Google Doc or Notion page, link inside the PDF) where every prompt sits in a clean copy box. This is cheap to make and becomes a strong buying reason.

### 10. Series standards are absent
Book 1 has a defined 6-part prompt format, a "Which AI to Use" section, and a "Check Before You Trust It" honesty section. None of the other six carry them. A series must feel like a series. v2 defines the standards once and applies them to all seven.

---

## PART B — SERIES STANDARDS (apply to every book)

**Series name:** *AI Made Simple* — by Fresh Genesis
> ⚠️ Action item: search Amazon KDP, Gumroad, Selar and Google for "AI Made Simple" before launch. The phrase is generic and probably in use. If crowded, publish as **"AI Made Simple for Nigerians"** series or **"Fresh Genesis: AI Made Simple"** and always pair the series name with the audience in the title.

**Positioning line (all covers/listings):**
*No tech jargon. No laptop needed. If you can send a WhatsApp message, you can use this book.*

**Structure of every book:**
1. Cover & Title Page
2. What's Inside at a Glance (one table)
3. Introduction (who it's for, the target outcome, what it is not)
4. How to Use This Book
5. Which AI to Use (Meta AI in WhatsApp first; ChatGPT, Gemini, DeepSeek as alternatives)
6. Check Before You Trust It (honesty note — tailored per book: money, law, health, exams, academic integrity)
7. **Parts 1–6 × 20 prompts = 120 prompts**
8. Bonus Section — **10 tools** (Book 1 keeps its approved 15 as the flagship)
9. Your Action Plan (30/60/90 days, matched to the book's outcome)
10. Back Matter — tracker, glossary, "what to read next" (cross-sell), how to reach Fresh Genesis

**Every prompt uses the approved 6-line entry:**
Prompt number → Title → *Use this when:* → *Copy this prompt:* → *Real example (filled in):* → *Local tip:* ("Naija tip" in Book 1; "Naija tip" or "Pro tip" elsewhere as fits)

**Every Part ends with a Checkpoint** (5 things the reader must have *done*).

**Outcome language rule:** "Designed to help you [outcome] within [time] by [mechanism]. Use the tracker at the back to measure your own progress." Never "guaranteed."

**Delivery format per book:**
- PDF (phone-friendly, 6×9 layout, large type)
- Companion Prompt Library (Google Doc/Notion, copy boxes) — link on page 2
- Bonus tools as editable Google Sheets/Docs where relevant

**Price ladder (suggested):**
- Single book: **₦7,500 / $9**
- Any 3: **₦18,000 / $22**
- Complete 7-book library: **₦35,000 / $45**
- Book 1 launch price: ₦5,000 / $7 for the first 14 days, to collect testimonials

**Release order (ship one, sell one, fund the next):**
1. Book 1 — Small-Business Owners *(in production: Front Matter, Parts 1–2 done)*
2. Book 4 — Job Seekers *(largest, most urgent Nigerian audience; cheapest to market)*
3. Book 7 — Students *(WAEC/JAMB seasonality — time it to Jan–Apr)*
4. Book 2 — Freelancers & Remote Workers
5. Book 5 — Content Creators
6. Book 3 — Teachers & Tutors *(time to Aug–Sep, new session)*
7. Book 6 — Busy Professionals
Then: the 7-Book Library bundle.

---

## PART C — THE SEVEN BOOKS (v2)

### BOOK 1 — AI Made Simple for Nigerian Small-Business Owners
**Subtitle:** *120 Practical Prompts to Grow Your Business With AI — Even If You've Never Used It Before*
**Audience:** Shop owners, salon operators, POS agents, fashion sellers, agropreneurs, restaurant owners, and service businesses in Nigeria.
**Target outcome:** Designed to help you generate an extra ₦1.5M–₦3M in revenue within 90 days and cut marketing and operating costs by at least 35% — by knowing your customer, marketing on WhatsApp for free, closing more sales, and cutting waste. Measured with the 90-Day Revenue Growth Tracker.
**Status:** Front Matter ✅ · Part 1 ✅ · Part 2 ✅ · Parts 3–6, Bonus, Back Matter ⏳
**File:** `01 - AI Made Simple - Nigerian Small-Business Owners.pdf`

**Contents**
- Part 1: Deep Customer Understanding & Market Research (1.1–1.20)
- Part 2: Low-Cost Marketing That Actually Works in Naija (2.1–2.20)
- Part 3: Sales, Negotiation & Closing More Deals (3.1–3.20)
- Part 4: Operations, Automation & Cost Cutting (4.1–4.20)
- Part 5: Product Innovation & New Revenue Streams (5.1–5.20)
- Part 6: Finance, Funding & Smart Growth (6.1–6.20)
- Bonus Section (15): 90-Day Revenue Growth Tracker · Monthly Business Expense Tracker · Customer Avatar & Persona Builder · Social Media Content Calendar · AI Prompt Cheat Sheet · WhatsApp Business Profile Optimizer · Price List Generator · Business Proposal Template (Banks/Investors) · WhatsApp Status Sales Hook Bank · NEPA & Generator Expense Calculator · Daily Sales Record Sheet (POS-Friendly) · Customer Follow-Up Message Bank · Referral Reward Card Template · Business Name, Catchphrase & Slogan Creator · Risk & Survival Decision Matrix for Naija Businesses
- Your 90-Day Action Plan · Back Matter

---

### BOOK 2 — AI Made Simple for Freelancers & Remote Workers
**Subtitle:** *120 Prompts to Land Better Clients, Charge More and Work Fewer Hours — From Nigeria to the World*
**Audience:** Writers, designers, virtual assistants, developers, social media managers, video editors and other independent professionals in Nigeria selling to local and international clients.
**Target outcome:** Designed to help you raise your monthly income by 50–100% within 90 days by positioning for premium clients, sending proposals that get replies, pricing in dollars where possible, and delivering faster with AI. Measured with the 90-Day Income Tracker.
**Lane fix:** Adds a dedicated chapter on the realities of earning abroad from Nigeria — payment platforms (Payoneer, Grey, Flutterwave), time zones, trust signals for foreign clients, and pricing in USD vs ₦.
**File:** `02 - AI Made Simple - Freelancers and Remote Workers.pdf`

**Contents**
- Part 1: Positioning & Attracting High-Paying Clients (1.1–1.20)
- Part 2: Proposals, Pitches & Cold Outreach That Get Replies (2.1–2.20) — Upwork, Fiverr, Contra, LinkedIn, email, WhatsApp
- Part 3: Pricing, Negotiation & Contracts (3.1–3.20) — value pricing, packages, retainers, deposits, scope creep, USD/₦
- Part 4: Delivery, Productivity & AI Workflows (4.1–4.20)
- Part 5: Personal Brand & Proof (5.1–5.20) — LinkedIn, case studies, testimonials, portfolio storytelling
- Part 6: Money, Getting Paid Abroad & Sustainable Growth (6.1–6.20) — invoices, international payments, tax basics (with honesty note), savings, currency risk
- Bonus (10): Winning Proposal Template Pack · Client Onboarding Checklist · Rate Card & Package Builder · Contract Clause Generator · Scope-Creep Response Scripts · LinkedIn Profile Optimizer Pack · Portfolio Case-Study Template · Getting-Paid-From-Abroad Checklist (Nigeria) · Client Red-Flag Checklist · 90-Day Income Tracker

---

### BOOK 3 — AI Made Simple for Teachers & Tutors
**Subtitle:** *120 Prompts to Cut Lesson Prep by Two-Thirds, Engage Every Student and Grow Your Teaching Income*
**Audience:** Primary and secondary teachers, private/lesson tutors, tutorial-centre operators and lecturers in Nigeria (WAEC/NECO/JAMB curriculum context).
**Target outcome:** Designed to help you cut lesson-preparation time by 65–75% within one term while improving student engagement and results — by generating plans, materials, assessments and feedback with AI, then adapting them to your class. Measured with the Weekly Prep-Time Log.
**Fix:** "Predicted questions" replaced with "high-probability topic analysis from past questions." Adds an honesty note on AI errors in subject content — always check against the syllabus and textbook.
**File:** `03 - AI Made Simple - Teachers and Tutors.pdf`

**Contents**
- Part 1: Fast, Effective Lesson Planning (1.1–1.20) — objectives, Bloom's, 40/80-min plans, schemes of work, differentiation
- Part 2: Engaging Teaching Materials (2.1–2.20) — notes, worksheets, diagrams, mnemonics, real-life Nigerian examples, low-resource teaching aids
- Part 3: Assessment, Marking & Feedback (3.1–3.20) — objective/essay questions, marking schemes, rubrics, comment banks, error analysis
- Part 4: Reaching Every Learner (4.1–4.20) — remediation, extension, slow learners, high flyers, large classes, mixed-ability
- Part 5: Classroom Management & Parent Communication (5.1–5.20) — routines, behaviour, parent messages (English + Pidgin), open day, complaints
- Part 6: Exam Preparation & Growing Your Teaching Income (6.1–6.20) — WAEC/NECO/JAMB revision, past-question analysis, mocks, tutorial-centre marketing and pricing, online tutoring
- Bonus (10): Lesson Plan Template (Nigerian curriculum) · Scheme of Work Creator · Rubric & Marking Guide Pack · Parent-Teacher Message Templates (English + Pidgin) · Student Progress Tracker · Quiz & Classroom Game Prompt Pack · End-of-Term Report Comment Bank · Past-Question Analysis Worksheet · Tutorial Centre Pricing Sheet · Weekly Prep-Time Log

---

### BOOK 4 — AI Made Simple for Job Seekers
**Subtitle:** *120 Prompts to Get More Interviews, Answer With Confidence and Negotiate a Better Offer — in Nigeria or Abroad*
**Audience:** Fresh graduates, NYSC members, career switchers, unemployed and under-employed professionals, and Nigerians applying for remote or international roles.
**Target outcome:** Designed to help you multiply your interview invitations (many readers see 2–3× within 45 days) by tailoring every CV to the role, beating ATS filters, fixing LinkedIn, and rehearsing answers with AI. Measured with the 45-Day Application Tracker.
**Lane fix:** Split guidance into "Nigerian employers" and "International/remote employers" wherever conventions differ (CV length, photos, referees, salary talk).
**File:** `04 - AI Made Simple - Job Seekers.pdf`

**Contents**
- Part 1: CVs & Cover Letters That Beat the ATS (1.1–1.20)
- Part 2: LinkedIn & Personal Positioning (2.1–2.20)
- Part 3: Company, Role & Salary Research (3.1–3.20)
- Part 4: Interview Preparation & AI Mock Interviews (4.1–4.20) — STAR, behavioural, technical, case, panel, video
- Part 5: Offers, Salary Negotiation & Red Flags (5.1–5.20) — incl. spotting job scams common in Nigeria
- Part 6: Skill Gaps, Portfolios & Career Switching (6.1–6.20)
- Bonus (10): ATS-Optimized CV Template (Nigeria + International) · Cover Letter Builder · STAR Answer Builder · Elevator Pitch Creator · Mock Interview Question Bank by Industry · Follow-Up & Thank-You Email Templates · Salary Negotiation Script · Job-Scam Red-Flag Checklist · 30-Day Skill Sprint Planner · 45-Day Application Tracker

---

### BOOK 5 — AI Made Simple for Content Creators
**Subtitle:** *120 Prompts to Create More Content in Less Time, Grow a Real Audience and Get Paid*
**Audience:** YouTubers, TikTokers, Instagram Reels creators, X thread writers, bloggers, skit makers and faceless-channel creators in Nigeria and the diaspora.
**Target outcome:** Designed to help you double your publishing output within 60 days without doubling your hours — by building a content system (ideas → scripts → batching → repurposing) — and to open at least two income streams from that content. Measured with the 90-Day Content & Income Tracker.
**Fix:** "3× in half the time" softened to a defensible "double output, same hours."
**File:** `05 - AI Made Simple - Content Creators.pdf`

**Contents**
- Part 1: Niche, Strategy & Ideas That Travel (1.1–1.20)
- Part 2: Hooks, Scripts & Storytelling (2.1–2.20)
- Part 3: Video, Reels & Shorts Production (3.1–3.20) — shot lists, B-roll, retention, thumbnails, titles, AI visuals
- Part 4: Captions, Threads & Written Content (4.1–4.20)
- Part 5: Repurposing, Batching & Systems (5.1–5.20)
- Part 6: Growth, Community & Monetization (6.1–6.20) — brand deals (₦ and $ rate guidance), affiliate, digital products, UGC, YouTube Partner, sponsorship outreach
- Bonus (10): 90-Day Content Calendar · Hook & CTA Bank · Repurposing Matrix (1 → 12) · Thumbnail & Title Prompt Pack · Brand Deal Pitch + Rate Card Template · Audience Persona Builder · Batching Day Checklist · Sponsorship Email Sequence · Monetization Idea Checklist · Content & Income Tracker

---

### BOOK 6 — AI Made Simple for Busy Professionals
**Subtitle:** *120 Prompts to Reclaim 8–12 Hours a Week, Write Better, Decide Faster and Get Promoted*
**Audience:** Corporate staff, managers and team leads, bankers, HR, lawyers, consultants, doctors, accountants and civil servants with demanding roles.
**Target outcome:** Designed to help you reclaim 8–12 hours a week within 30 days by automating emails, reports, meeting notes and planning with AI — and use that time for higher-value work and career growth. Measured with the Weekly Time-Reclaimed Log.
**Fix:** Adds a "Confidentiality & Company Data" honesty note — what never to paste into a public AI (client data, salaries, unreleased figures). Tool names removed from part titles.
**File:** `06 - AI Made Simple - Busy Professionals.pdf`

**Contents**
- Part 1: Email & Communication Mastery (1.1–1.20)
- Part 2: Meetings — Prep, Notes & Follow-Through (2.1–2.20)
- Part 3: Reports, Presentations & Documents (3.1–3.20)
- Part 4: Priorities, Projects & Calendar (4.1–4.20)
- Part 5: Rapid Learning & Decision-Making (5.1–5.20)
- Part 6: Career Growth, Leadership & Balance (6.1–6.20) — appraisals, promotion case, difficult conversations, boundaries
- Bonus (10): Executive Summary Generator · Meeting Agenda + Minutes Template · One-Page Report Template · Weekly Review & Planning Template · Decision Framework (Pros/Cons + 10-Year Lens) · Email Template Library · Promotion Case Builder · Difficult-Conversation Script Pack · Safe-Use-of-AI-at-Work Checklist · Weekly Time-Reclaimed Log

---

### BOOK 7 — AI Made Simple for Students
**Subtitle:** *120 Prompts to Understand Faster, Study Smarter, Score Higher and Win Scholarships — Honestly*
**Audience:** SS1–SS3 students, JAMB candidates, university, polytechnic and college-of-education students, and postgraduates in Nigeria and abroad.
**Target outcome:** Designed to help you raise your grades by at least one band (e.g., C → B) within one term while cutting study hours by up to 40% — by replacing cramming with AI-assisted understanding, active recall and spaced repetition. Measured with the Term Grade & Study-Hours Tracker.
**Fix:** "Avoid AI-detection traps" removed. Part 3 rebuilt around **"Use AI to understand, then write it yourself"** with a full Academic Integrity section — how to use AI legitimately, how to cite AI where required, and what counts as cheating in Nigerian and foreign institutions.
**File:** `07 - AI Made Simple - Students.pdf`

**Contents**
- Part 1: Notes & Concept Mastery (1.1–1.20) — Cornell, mind maps, Feynman, formulas, tough topics
- Part 2: Exam Preparation & Active Recall (2.1–2.20) — WAEC/NECO/JAMB and university exams, past questions, mistake journal, spaced repetition
- Part 3: Essays, Assignments & Projects — With Integrity (3.1–3.20) — breaking down questions, outlining, drafting in your own words, citations (APA/MLA), editing with AI
- Part 4: Research Skills & Final-Year Projects (4.1–4.20)
- Part 5: Time, Focus & Anti-Procrastination (5.1–5.20)
- Part 6: Scholarships, Internships & Early Career (6.1–6.20) — personal statements, SOPs, student CV, cold emails to lecturers, interview prep
- Bonus (10): Personalized Study Timetable Generator · Active Recall + Spaced Repetition System · WAEC/JAMB/NECO Revision Prompt Pack · Essay & Literature Review Outline Templates · Citation Quick Guide · Pomodoro + AI Study Session Templates · Scholarship Essay Prompt Pack · Academic Integrity Checklist · Burnout Recovery Checklist · Term Grade & Study-Hours Tracker

---

## PART D — IMMEDIATE ACTION LIST

1. Finish Book 1 (Parts 3–6, Bonus, Back Matter) before touching Book 2–7. ✅ In progress.
2. Run the title search ("AI Made Simple" on KDP, Gumroad, Selar, Google) — decide series brand.
3. Build the Book 1 companion Prompt Library (Google Doc) — this is the "ready-to-copy" promise.
4. Add Book 1 to the Fresh Genesis website as a product (₦5,000 / $7 launch → ₦7,500 / $9).
5. Collect 10 testimonials from Book 1 buyers before starting Book 4.
6. Reuse Book 1's front matter, "Which AI to Use", and "Check Before You Trust It" as templates for all others — adapt, don't rewrite.
