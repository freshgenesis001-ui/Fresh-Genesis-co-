# BONUS SECTION: 15 READY-TO-USE TOOLS
*(Bonus 1 – 8 in this file; Bonus 9 – 15 in the next)*

---

## How to Use the Bonus Section

Everything in the six Parts asked you to *think*. This section gives you things to *use* — today, from your phone.

Each bonus is one of three types:

- **📋 Template** — copy the layout into a notebook, Google Sheet or Google Doc, and fill it in.
- **🤖 Prompt Pack** — paste into Meta AI, ChatGPT, Gemini or DeepSeek and answer its questions.
- **📊 Calculator / Tracker** — a table with simple formulas you fill weekly or monthly.

**Setting up the trackers on your phone (2 minutes):** open the free Google Sheets app → new blank sheet → type the column headings exactly as shown → save. Or draw the table in a ruled notebook — it works just as well. Whichever you choose, **the tool only works if you fill it in.**

Every template uses ₦ and Nigerian realities. Adapt any wording to your business.

---

## BONUS 1 📊 — 90-Day Revenue Growth Tracker

**What it does:** Tracks whether you are on course for the extra ₦1.5M–₦3M, week by week, so you can correct early instead of discovering a miss on day 90.

**How to use:** Fill in your baseline (average monthly revenue for the 3 months before you started). Divide your 90-day extra-revenue target by 13 to get a weekly target. Every Sunday, fill in one row.

### Setup

| Item | Your figure |
|---|---|
| Baseline monthly revenue (avg. of last 3 months) | ₦ |
| Baseline weekly revenue (monthly ÷ 4.33) | ₦ |
| 90-day extra revenue target (₦1.5M–₦3M) | ₦ |
| Weekly extra target (target ÷ 13) | ₦ |
| Weekly revenue target (baseline weekly + weekly extra) | ₦ |
| Start date | |

### Weekly Tracker

| Week | Dates | Revenue this week (₦) | Target (₦) | Above/below target (₦) | Cumulative extra vs. baseline (₦) | New customers | Repeat customers | Biggest win | Biggest lesson |
|---|---|---|---|---|---|---|---|---|---|
| 1 | | | | | | | | | |
| 2 | | | | | | | | | |
| 3 | | | | | | | | | |
| 4 | | | | | | | | | |
| 5 | | | | | | | | | |
| 6 | | | | | | | | | |
| 7 | | | | | | | | | |
| 8 | | | | | | | | | |
| 9 | | | | | | | | | |
| 10 | | | | | | | | | |
| 11 | | | | | | | | | |
| 12 | | | | | | | | | |
| 13 | | | | | | | | | |
| **Total** | | | | | | | | | |

**Formulas (Google Sheets):** Above/below = `revenue − target`. Cumulative extra = previous cumulative + `(revenue − baseline weekly)`.

### Monthly Checkpoints

| Checkpoint | Target cumulative extra | Actual | On track? (Y/N) | What to change |
|---|---|---|---|---|
| Day 30 | ⅓ of target | | | |
| Day 60 | ⅔ of target | | | |
| Day 90 | Full target | | | |

**The Sunday question:** *"If I'm below target — is it fewer enquiries (marketing problem, Part 2), fewer conversions (sales problem, Part 3), or smaller sales (bundle/upsell problem, Parts 3 & 5)?"* Fix the one that applies.

---

## BONUS 2 📊 — Monthly Business Expense Tracker

**What it does:** Shows where every naira goes, month by month, and whether you are hitting the 35% cost reduction.

**How to use:** Record expenses daily (or from receipts weekly). Total each category at month-end. Compare against your baseline month.

### Categories & Monthly Totals

| Category | Baseline month (₦) | Month 1 (₦) | Month 2 (₦) | Month 3 (₦) | Change vs. baseline (%) | Notes / action |
|---|---|---|---|---|---|---|
| Stock / raw materials | | | | | | |
| Rent (monthly share) | | | | | | |
| Staff salaries & commissions | | | | | | |
| Generator fuel & servicing | | | | | | |
| Electricity (grid) | | | | | | |
| Gas / water | | | | | | |
| Transport & market runs | | | | | | |
| Delivery / dispatch | | | | | | |
| Packaging | | | | | | |
| Data & airtime | | | | | | |
| POS, bank & transfer charges | | | | | | |
| Marketing (printing, ads, gifts) | | | | | | |
| Repairs & maintenance | | | | | | |
| Waste / spoilage / returns | | | | | | |
| Levies, dues & permits | | | | | | |
| Loan repayment | | | | | | |
| Owner's salary (fixed) | | | | | | |
| Other | | | | | | |
| **TOTAL** | | | | | | |
| **Total excluding stock & owner's salary** | | | | | | |
| **Revenue** | | | | | | |
| **Expenses as % of revenue** | | | | | | |

**Your 35% target** applies to *operating* costs (the "excluding stock & owner's salary" line). Stock rises when sales rise — that's good.

### Daily Expense Log (feeds the table above)

| Date | Item | Category | Amount (₦) | Paid from (till / bank / personal) | Receipt? |
|---|---|---|---|---|---|

**Red flags to watch:** generator > 10% of revenue · waste > 3% of revenue · bank/POS charges > 1.5% of revenue · "Other" > 5% (means you're not categorising).

---

## BONUS 3 🤖 — Customer Avatar & Persona Builder

**What it does:** Produces a one-page profile of your ideal customer you can print and share with staff. Deeper than Prompt 1.1 — it interviews you first.

**Prompt (paste in full):**

> I want to build a detailed customer avatar for my business in Nigeria. First, ask me these questions one at a time and wait for my answer before the next: (1) What do I sell and at what price range? (2) Where is my business and where do most customers come from? (3) Describe my 3 best customers — age, gender, occupation, roughly what they earn, family situation. (4) What do they say when they thank me or recommend me? (5) What do they complain or worry about before buying? (6) Where do they spend time online and offline? (7) What else do they buy regularly from other businesses? (8) What would make them stop buying from me? After my answers, produce a ONE-PAGE Customer Avatar with: a name and photo description, a 3-line life summary, income and spending habits in naira, top 3 goals, top 3 frustrations, buying triggers, objections, where to find them, how they like to be spoken to, the exact words they use, and 5 rules for my staff on serving this person. Then produce a shorter "secondary avatar" for my second most important customer type.

### Avatar Card Template (fill from the AI's output)

| Field | Details |
|---|---|
| Name & age | |
| Occupation & monthly income | |
| Lives / works | |
| Family situation | |
| What they buy from me & how often | |
| Average spend | |
| Top 3 goals | 1. 2. 3. |
| Top 3 frustrations | 1. 2. 3. |
| Buying triggers (what makes them buy today) | |
| Objections (what makes them hesitate) | |
| Where to reach them | |
| How they like to be spoken to | |
| Words they use | |
| Staff rules for serving them | 1. 2. 3. 4. 5. |

Print it. Paste it in the back room. Every new staff member reads it on day one.

---

## BONUS 4 📋 — Social Media Content Calendar (30/60/90 Days)

**What it does:** A repeatable weekly rhythm for WhatsApp Status (primary), plus Instagram/TikTok/Facebook if you use them — so you never wonder what to post.

### The Weekly Rhythm (repeat every week)

| Day | Theme | WhatsApp Status (2–3 posts) | Instagram / TikTok / Facebook (optional, 1 post) |
|---|---|---|---|
| **Monday** | Motivation & Menu/Range | Morning greeting + what's available this week + one product shot | Reel: "What's new this week" |
| **Tuesday** | Teach | One tip related to your product (care, use, choice) + product that solves it | Carousel or short tip video |
| **Wednesday** | Proof | Customer testimonial screenshot/voice note + the product they bought | Testimonial post |
| **Thursday** | Behind the Scenes | Making/packing/sourcing + a personal line about your day | Process Reel |
| **Friday** | Offer | Weekend deal, bundle or "5 slots left" + clear how-to-order | Offer graphic |
| **Saturday** | Community | Ask a question / poll / celebrate a customer / Nigerian humour | Engagement post |
| **Sunday** | Rest & Story | A gratitude post, your business story, or nothing — rest is allowed | Story-style post |

### Monthly Layers (add on top of the weekly rhythm)

| Week | Monthly feature |
|---|---|
| Week 1 | Announce this month's featured bundle or new item |
| Week 2 | Testimonial round-up (3 in a row) |
| Week 3 | Mid-month "small chops" pricing / smaller-size offer (mid-month cash is tight) |
| Week 4 | Salary-week push: premium items, bundles, pre-orders for next month |

### 90-Day Themes

| Days | Focus | Goal |
|---|---|---|
| 1–30 | **Foundation** — profile complete, daily posting habit, first testimonials | Consistency; 30+ new saved contacts |
| 31–60 | **Proof & Offers** — testimonials, bundles, referral programme launch | Conversions; referral system live |
| 61–90 | **Scale** — seasonal campaign, new product/stream launch, Reels if visual | Revenue; 90-day target |

### Content Planning Sheet

| Date | Day theme | Post 1 (caption) | Post 2 (caption) | Photo/video needed | Posted? | Replies/enquiries |
|---|---|---|---|---|---|---|

**Batch tip:** Every Sunday evening, take 15–20 photos/short videos for the week. Ask AI (Prompt 2.2) for the captions. Posting then takes 3 minutes a day.

---

## BONUS 5 🤖 — AI Prompt Cheat Sheet (Quick Reference)

**What it does:** The most useful one-line prompt starters, ready to memorise or copy — plus the rules that make every prompt work better.

### The 5 Rules of a Good Prompt

1. **Give context:** "I run a [business] in [place], Nigeria, selling [X] to [Y]."
2. **Give numbers:** prices, costs, quantities, dates. Vague in, vague out.
3. **Ask for a format:** "as a table," "in 5 bullet points," "under 60 words," "step by step."
4. **Set the tone:** "simple Nigerian English," "warm, not pushy," "honest, not flattering."
5. **Iterate:** "Make it shorter." "More practical." "Give me 3 more options." "Ask me questions first."

### Universal Fix-It Prompt (when the answer isn't right)

> *"That answer isn't quite right. I need it to be more practical for a Nigerian small business. Make it simpler, use plain English with Pidgin only if useful, give concrete examples, and avoid guesswork. Try again, using this feedback: [explain what you want changed]."*

### Quick Starters by Task

| Task | Starter |
|---|---|
| Write a message | "Write a warm WhatsApp message under 60 words to a customer who [situation]. End with a clear next step." |
| Reply to an objection | "A customer said '[objection]'. Give me 3 short replies that acknowledge, answer, and ask a follow-up question." |
| Caption a photo | "Write 3 captions under 40 words for [product, price, benefit] for Nigerian buyers. One problem-led, one story, one offer." |
| Calculate | "Calculate [what] using these numbers: [list]. Show your working. Ask me if you need a number I haven't given." |
| Plan | "Create a [7/30/90]-day plan for [goal] with no more than 5 actions per week, for a busy owner." |
| Decide | "Help me decide between [A] and [B]. List pros, cons, costs, risks, and give a recommendation with conditions." |
| Learn | "Explain [topic] to a Nigerian small-business owner with no finance background, using an example from a [business type]." |
| Role-play | "Play a [type of customer]. Be realistic and difficult. After 3 exchanges, pause and give me feedback." |
| Summarise | "Summarise these messages into a to-do list with priorities: [paste]." |
| Translate tone | "Rewrite this to sound [more polite / firmer / simpler / more professional]: [paste]." |
| Check my work | "Review this [price list / policy / message] for errors, unclear lines, and anything a Nigerian customer might misunderstand." |
| Daily assistant | "Act as my business assistant. Today I need help with: [list]. Do each clearly, one after the other." |

### Power Phrases to Add

- "…for a Nigerian small business with limited capital."
- "…in simple English a school-leaver can understand."
- "…be honest, don't just encourage me."
- "…ask me questions before answering."
- "…give me a table I can print."
- "…what am I not seeing?"

### Where to Type It

**Meta AI in WhatsApp** (free, no data-heavy app): open WhatsApp → the blue-purple circle icon → type. Or message the Meta AI contact directly. Also: ChatGPT, Gemini, DeepSeek apps or websites. Same prompts work everywhere.

---

## BONUS 6 📋 — WhatsApp Business Profile Optimizer

**What it does:** A checklist and fill-in template that turns your WhatsApp Business profile into a 24-hour salesperson.

### Step 1 — Setup Checklist

- [ ] Using **WhatsApp Business** (green icon with "B"), not regular WhatsApp
- [ ] Profile photo: clear logo or your face with product — bright, not blurry
- [ ] Business name: exactly as customers know you
- [ ] Category selected correctly
- [ ] Description filled (see template)
- [ ] Address or delivery area filled
- [ ] Business hours set
- [ ] Email / website / Instagram link added (if any)
- [ ] Catalogue: at least 5 items with photo, price, description
- [ ] Greeting message ON
- [ ] Away message ON
- [ ] At least 10 Quick Replies saved
- [ ] Labels created (New lead · Paid · Delivered · Repeat · VIP · Bulk · Owes money)
- [ ] Short link (Business tools → Short link) copied and used everywhere

### Step 2 — Profile Copy Templates (fill the brackets)

**About line (under 139 characters):**
> [What you sell] for [who] in [area] • [key promise: fresh daily / 6-month warranty / same-day delivery] • Order: just message!

**Business description (under 500 characters):**
> Welcome to [Business Name]! We [make/sell/offer] [products/services] for [customer type] in [area/nationwide]. Why customers choose us: [1], [2], [3]. 🕐 Open [days, hours]. 🚚 Delivery: [areas, timing, fee]. 💳 Pay by transfer, POS or [payment link]. 📲 To order: send the item name + quantity + delivery address. Run by [your first name] — real person, real products, since [year].

**Greeting message (first-time contacts):**
> Hello and welcome to [Business Name]! 😊 I'm [Name]. Thanks for reaching out. Tell me what you're looking for, or tap the catalogue to browse. I reply within [15 minutes] during [hours]. If it's after hours, I'll reply first thing in the morning.

**Away message:**
> Thanks for your message! We're closed right now ([hours]) but I've seen it and will reply by [time]. Meanwhile, browse our catalogue or send your order details (item, quantity, address) and I'll confirm as soon as we open. 🙏

### Step 3 — Quick Replies Starter Set

| Shortcut | Message |
|---|---|
| /price | [Item] is ₦[price]. It [one benefit]. Which [colour/size] would you like? |
| /delivery | We deliver to [areas] for ₦[fee], [timing]. Outside [city], we send by [logistics] — ₦[fee], [days]. Where are you located? |
| /pay | You can pay by transfer to [Bank, Account no., Account name] or via this link: [link]. Send your receipt and I'll confirm right away. |
| /confirm | Payment received — thank you, [Name]! 🎉 Your order is being prepared and will [be delivered/ready] by [time]. I'll update you. |
| /hours | We're open [days], [hours]. Orders sent after [time] are processed next morning. |
| /location | We're at [address / landmark]. [Map link if any]. Or we deliver to you — just send your address. |
| /outofstock | That one's sold out, but [alternative] is similar and available now at ₦[price]. Want a photo? |
| /followup | Hi [Name], just checking in — did you still want the [item]? I have [X] left. No pressure at all. |
| /bulk | For 10+ pieces, the price is ₦[wholesale]. Minimum order [X]. Would you like the full wholesale list? |
| /thanks | Thank you for your order, [Name]! If you love it, a quick review here would mean a lot 🙏 And please save my number for offers. |
| /policy | Quick note on our policy: [deposits / returns / delivery] — [1–2 lines]. Let me know if you have questions. |
| /proof | Here's proof of [authenticity/delivery/reviews]: [forward Proof folder]. We've served [X] customers across [areas]. |

### Step 4 — Weekly 10-Minute Maintenance

- [ ] Update catalogue prices / remove sold-out items
- [ ] Label every new chat
- [ ] Post 2–3 Statuses daily (Bonus 4)
- [ ] Reply to every unanswered message
- [ ] Add 1 new Quick Reply for any question you typed twice this week

---

## BONUS 7 🤖 — Price List Generator

**What it does:** Produces a clean, professional price list from your rough notes — with bulk prices, delivery, terms, and a version for WhatsApp, a version for printing, and a version for corporate clients.

**Prompt (paste in full, fill the brackets):**

> Create a professional price list for my business. Business name: [name]. What we sell: [list every item/service with price; add cost price if you want margin advice]. Bulk/wholesale prices: [if any, with minimum quantities]. Delivery: [areas, fees, timing]. Payment options: [transfer / POS / link / pay on delivery rules]. Policies: [deposit %, returns, order cut-off times, lead time for custom items]. Contact: [phone/WhatsApp, address or delivery area, Instagram]. Produce THREE versions: (1) a WhatsApp text version — clean, grouped by category, using simple symbols not heavy emojis, under 400 words, easy to read on a phone; (2) a printable A4 version with a header, category tables (Item | Description | Price | Bulk price), a policies box and contact footer, described so I can build it in Google Docs or Canva; (3) a corporate/B2B version with formal language, VAT note if applicable, payment terms (e.g., 70% deposit, 30% on delivery), and a validity period. Also flag any items where my price looks too low compared to typical Nigerian market ranges, and suggest a "featured" or "best value" label for 2 items.

### Price List Layout (printable version — structure)

```
[BUSINESS NAME]                                [Logo]
[Tagline] • [Phone/WhatsApp] • [Instagram] • [Area]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CATEGORY 1
Item                  Description             Price      Bulk (10+)
──────────────────────────────────────────────────────────────────
Item A                short desc              ₦X,XXX     ₦X,XXX
Item B  ★ Best Value  short desc              ₦X,XXX     ₦X,XXX

CATEGORY 2
...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DELIVERY: [areas & fees] • [timing]
PAYMENT: Transfer • POS • [Link]  |  Account: [Bank – No. – Name]
POLICIES: [deposit] • [returns] • [order cut-off]
Prices valid until: [date]           Save this number: [phone]
```

**Update rule:** review monthly (Prompt 6.2); always show "Prices valid until [date]" so increases are expected, not shocking.

---

## BONUS 8 🤖 📋 — Business Proposal Template (Banks / Grants / Investors)

**What it does:** The full structure of a fundable proposal, with what to write in each section, word counts, and the prompt to generate a first draft from your facts.

### Section-by-Section Structure

| # | Section | What goes in | Length |
|---|---|---|---|
| 0 | **Cover page** | Business name, logo, "Business Plan / Proposal for [purpose]", date, contact, CAC/RC number | 1 page |
| 1 | **Executive Summary** | Who you are, what you do, traction (numbers), the ask, what it will achieve, repayment/return. Write last, place first. | ½ page |
| 2 | **Business Description** | History, legal structure, location, owner background, mission, current stage | ½ page |
| 3 | **Products / Services** | What you sell, prices, what makes it different, photos | ½ page |
| 4 | **Market & Customers** | Who buys, size of the opportunity (local and realistic), trends, evidence of demand | ½–1 page |
| 5 | **Competition** | 3–5 competitors, comparison table, your advantage | ½ page |
| 6 | **Marketing & Sales** | Channels (WhatsApp, referrals, B2B), pricing strategy, retention, growth plan | ½ page |
| 7 | **Operations** | How you produce/deliver, suppliers, staff, equipment, SOPs, quality control | ½ page |
| 8 | **Management & Team** | Owner and key staff — experience, roles; advisers/mentors | ⅓ page |
| 9 | **Financials — Past** | 6–12 months revenue, costs, profit (table); bank statements as appendix | ½ page |
| 10 | **Financials — Projection** | 12-month projection (3 scenarios), break-even, key assumptions | 1 page |
| 11 | **Use of Funds** | Itemised table: item, cost, supplier/quote, expected impact | ½ page |
| 12 | **Repayment / Return** | Loan: schedule from projected cash flow. Investor: returns, exit. Grant: impact metrics (jobs, income, community) | ⅓ page |
| 13 | **Risks & Mitigation** | Top 5 risks and what you'll do about each | ⅓ page |
| 14 | **Impact** *(grants especially)* | Jobs created, women/youth employed, farmers supported, community benefit — with numbers | ⅓ page |
| 15 | **Appendix** | CAC certificate, TIN, ID, bank statements, photos, quotes, customer letters, licences (NAFDAC etc.) | as needed |

**Total: 5–8 pages** plus appendix. Longer is not better.

### Use of Funds Table (copy)

| Item | Quantity | Unit cost (₦) | Total (₦) | Supplier / quote attached | Expected impact |
|---|---|---|---|---|---|
| | | | | | |
| **TOTAL** | | | | | |

### Draft Generator Prompt

> Write a complete business proposal for [purpose: ₦X loan from Y / Z grant / investor] using the 15-section structure: cover, executive summary, business description, products, market, competition, marketing & sales, operations, team, past financials, 12-month projection, use of funds, repayment/return, risks, impact, appendix list. Here are my facts: [paste everything — history, numbers, customers, team, the ask, use of funds, expected results]. Write in clear, confident, factual English suitable for a Nigerian bank or grant reviewer. Use tables for financials and use of funds. Flag any section where my facts are too thin and tell me exactly what to add. Keep the whole document under 3,000 words.

### Before You Submit — Checklist

- [ ] Every number matches across sections (summary = financials = use of funds)
- [ ] Executive summary tailored to *this* funder's stated goals
- [ ] Evidence attached for every major claim (quotes, statements, photos)
- [ ] Read aloud once — no jargon, no filler, no "passion for excellence"
- [ ] Reviewed by one person who has received funding before
- [ ] Contact details on every page footer
- [ ] Saved as PDF, named `[BusinessName]-Proposal-[Funder]-[Date].pdf`

---

*Bonuses 9–15 continue in the next file: WhatsApp Status Sales Hook Bank · NEPA & Generator Expense Calculator · Daily Sales Record Sheet · Customer Follow-Up Message Bank · Referral Reward Card Template · Business Name, Catchphrase & Slogan Creator · Risk & Survival Decision Matrix.*
