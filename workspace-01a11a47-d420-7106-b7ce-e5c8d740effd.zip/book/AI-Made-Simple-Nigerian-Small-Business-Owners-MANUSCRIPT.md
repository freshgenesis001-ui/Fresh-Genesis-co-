# AI Made Simple for Nigerian Small-Business Owners

**Subtitle:** 120 Practical Prompts to Grow Your Business With AI — Even If You've Never Used It Before

**Who this book is for:** Shop owners, salon operators, POS agents, fashion sellers, agropreneurs, restaurant owners, and service businesses in Nigeria.

**The 90-day target:** Generate an extra ₦1.5M–₦3M in revenue within 90 days while cutting your marketing and operating costs by at least 35%.

> *No tech jargon. No laptop needed. If you can send a WhatsApp message, you can use this book.*

---

## WHAT'S INSIDE AT A GLANCE

| Section | What it does for you |
|---|---|
| **Part 1** — Customer Understanding & Market Research (Prompts 1.1–1.20) | Know exactly who your customers are, what they want, and what they'll pay — before you spend a kobo. |
| **Part 2** — Low-Cost Marketing That Actually Works in Naija (Prompts 2.1–2.20) | Get customers with WhatsApp, status ads, and word-of-mouth systems that cost little or nothing. |
| **Part 3** — Sales, Negotiation & Closing (Prompts 3.1–3.20) | Handle haggling, objections, and "I'll come back" — and turn more of them into paid sales. |
| **Part 4** — Operations, Automation & Cost Cutting (Prompts 4.1–4.20) | Save hours every week and cut at least 35% off your running costs. |
| **Part 5** — Product Innovation & New Revenue (Prompts 5.1–5.20) | Add new products and income streams from what you already have. |
| **Part 6** — Finance, Funding & Smart Growth (Prompts 6.1–6.20) | Price right, track money, and prepare for funding — sensibly and safely. |
| **Bonus Section** — 15 ready-to-use tools | Copy-paste templates: scripts, trackers, calculators, message banks, and decision frameworks. |

Every prompt follows the same six-part format:

1. **Prompt number** (e.g., Prompt 1.3)
2. **Title** — what it does in one line
3. **Use this when:** — so you can spot the right prompt in seconds
4. **Copy this prompt:** — the full prompt, ready to paste into your AI
5. **Real example (filled in)** — a Nigerian business scenario showing the prompt at work
6. **Naija tip:** — the local angle that makes the difference

---

## TABLE OF CONTENTS

### FRONT MATTER
- Cover Page & Title Page
- What's Inside at a Glance
- Introduction
- How to Use This Book
- Which AI to Use
- Check Before You Trust It
- Your 90-Day Promise

### PART 1: DEEP CUSTOMER UNDERSTANDING & MARKET RESEARCH *(Prompts 1.1 – 1.20)*
### PART 2: LOW-COST MARKETING THAT ACTUALLY WORKS IN NAIJA *(Prompts 2.1 – 2.20)*
### PART 3: SALES, NEGOTIATION & CLOSING MORE DEALS *(Prompts 3.1 – 3.20)*
### PART 4: OPERATIONS, AUTOMATION & COST CUTTING *(Prompts 4.1 – 4.20)*
### PART 5: PRODUCT INNOVATION & NEW REVENUE STREAMS *(Prompts 5.1 – 5.20)*
### PART 6: FINANCE, FUNDING & SMART GROWTH *(Prompts 6.1 – 6.20)*

### BONUS SECTION *(Bonus 1 – 15)*
1. 90-Day Revenue Growth Tracker
2. Monthly Business Expense Tracker
3. Customer Avatar & Persona Builder
4. Social Media Content Calendar
5. AI Prompt Cheat Sheet (Quick Reference)
6. WhatsApp Business Profile Optimizer
7. Price List Generator
8. Business Proposal Template (Banks / Grants / Investors)
9. WhatsApp Status Sales Hook Bank
10. NEPA & Generator Expense Calculator
11. Daily Sales Record Sheet (POS-Friendly)
12. Customer Follow-Up Message Bank
13. Referral Reward Card Template
14. Business Name, Catchphrase & Slogan Creator
15. Risk & Survival Decision Matrix for Naija Businesses

### BACK MATTER
- Your 90-Day Action Plan (Week by Week)
- Quick-Find Index: "I Need Help With…"
- Glossary: Plain-English Terms
- A Final Word from the Author
- What to Read Next — The *AI Made Simple* Series
- Copyright & Disclaimer

---

## INTRODUCTION

If you run a small business in Nigeria, you already work harder than most people can imagine. Between NEPA taking light, fuel and generator costs, market competition, WhatsApp vendors, POS charges, naira pressures, and customers haggling, your profit can vanish quietly — even on a good day.

The good news: you don't need a laptop, a degree in tech, or expensive software to put AI to work. You only need to be able to **copy, paste, and answer a few questions**.

**AI** (Artificial Intelligence) is a very fast assistant. You give it clear instructions in plain English (or Pidgin), and it gives you useful answers in seconds — answers that would otherwise take you hours, days, or a paid consultant.

This book doesn't teach AI theory. It teaches **action**. For every problem, you'll copy a ready-made **prompt** into an AI tool, then copy its answer straight back to work.

With the trackers, checklists, and templates included, your goal isn't a vague hope — it's something you can measure **week by week, for 90 days**.

---

## HOW TO USE THIS BOOK

Follow these five steps. That's it:

1. **Pick a problem.** Find the Part that solves your biggest headache right now (e.g., "not enough customers" → Part 2).
2. **Find the right prompt.** Each prompt has a title and a **"Use this when:"** line, so you can spot it in seconds.
3. **Fill the [brackets].** In every prompt you'll see words in square brackets like `[type of business]`, `[your location]`, or `[price]`. Replace *only* what's inside the brackets with your own details. Leave everything else exactly as it is.
4. **Copy and paste.** Copy the entire **"Copy this prompt:"** block into your AI, then hit Send.
5. **Put the answer to work.** Use what it gives you the same day. Don't let it sit.

**If the first answer is weak,** copy and paste this follow-up:

> *"That answer isn't quite right. I need it to be more practical for a Nigerian small business. Make it simpler, use plain English with Pidgin only if useful, give concrete examples, and avoid guesswork. Try again, using this feedback: [explain what you want changed]."*

**A very important rule:** Always fill in the `[brackets]` first. The AI needs your real business details to give you useful answers — not generic ones. The quality of the answer depends on the quality of what you put in.

---

## WHICH AI TO USE

You don't need to pay anything to get real value from this book. Here are the options, ranked for Nigerian small businesses:

| AI Tool | Free or Paid | Best For | Works Well On |
|---|---|---|---|
| **Meta AI (inside WhatsApp)** | Free | **Highly recommended for Nigerian business owners.** It lives inside WhatsApp — an app almost every Nigerian phone already has. Perfect for shop owners, market traders, salon operators, POS agents, and vendors who already do business on WhatsApp. | Any phone (Android or iPhone) |
| **Gemini** | Free, generous limits | Very solid and easy to use on mobile. | Phone, tablet, or computer |
| **ChatGPT** | Free + paid | Very popular and easy to follow; some advanced features need payment. | Phone, tablet, or computer |
| **DeepSeek** | Free | Strong free option with good reasoning; popular for business planning and writing tasks. | Phone, tablet, or computer |
| **Microsoft Copilot** | Free | Clean, practical answers. Easy to use. | Phone, tablet, or computer |

**My number one pick for most Naija business owners: Meta AI inside WhatsApp.** There's no new app to download or learn — and you're very likely already using WhatsApp for your business every single day.

> **Note:** WhatsApp's new per-message charges (from October 2026) apply only to big companies on the WhatsApp Business *Platform (API)* — not to you on the normal, free WhatsApp or WhatsApp Business app. Your AI chats in WhatsApp remain free.
>
> AI tools update from time to time. If one tool isn't giving useful answers, simply try another from the table above.

---

## CHECK BEFORE YOU TRUST IT

AI is an assistant, not an infallible expert. Treat everything it gives you as a **draft you verify**. Keep these rules in mind:

- **Finance, funding & tax (Part 6):** For bank proposals, loan discussions, tax matters, or anything involving large sums, treat AI output as a starting point only. Cross-check with your bank, accountant, auditor, or a trusted adviser before you act.
- **Contracts, terms & legal decisions:** The prompts can draft proposals, clauses, and templates. Nigerian laws and regulations change — for binding contracts or high-stakes commitments, get proper professional advice.
- **Prices, charges & POS:** Bank fees, POS charges, transport, fuel, and generator costs vary by location and change over time. Always verify today's prices in your market before committing.
- **Accuracy:** AI can occasionally guess. If a number or claim looks off, ask it to show how it arrived at the answer — or verify with a human source.
- **Local reality:** Nigeria is unique — NEPA, fuel costs, inflation, naira volatility, haggling, and market dynamics. This book leans heavily into Nigerian context, but you know your business better than any AI ever will. **You are the final decision-maker.**
- **Your business data:** Never paste sensitive private details — full account numbers, BVN, or customers' full ID details. Remove or generalise them first.

**Designed for action, not perfection.** Your goal is progress week by week over 90 days, measured with the trackers provided.

---

## YOUR 90-DAY PROMISE

Write this down somewhere you'll see it every morning:

> *"For the next 90 days, I will use at least one prompt from this book every working day, put the answer to work the same day, and track my progress every week."*

That's it. That's the whole system. The prompts in this book are powerful — but only the ones you actually use.

Now turn the page. Part 1 starts with the most important person in your business: **your customer.**


<div class='pb'></div>

# PART 1: DEEP CUSTOMER UNDERSTANDING & MARKET RESEARCH
*(Prompts 1.1 – 1.20)*

---

## Why This Part Comes First

Most small businesses in Nigeria do not fail because the owner is lazy. They fail because the owner is selling the right thing to the wrong people, at the wrong price, in the wrong place — and only finds out after the money is gone.

Market research sounds like something for big companies in Lagos with consultants and PowerPoint. It is not. Market research is simply **knowing your customer better than your competitor does.** The woman selling akara at the junction who knows that okada riders want it hot at 6:30am and office workers want it wrapped neatly at 8am is doing market research. She just does not call it that.

AI makes this faster and sharper. In the next 20 prompts, you will learn how to:

- Describe your ideal customer so clearly you can picture their face
- Find out what people actually want to buy (not what you assume)
- Understand why customers choose your competitor
- Ask the right questions without annoying anybody
- Set prices based on evidence, not fear
- Spot opportunities in your area that others are missing

**How to work through this Part:** Do not do all 20 in one day. Do Prompts 1.1, 1.2 and 1.5 first — those three alone will change how you see your business. Then come back for the rest as you need them.

**One rule before you begin:** Every prompt in this Part works better when you give the AI real details about *your* business — your location, your prices, your actual customers. Generic in, generic out. Specific in, gold out.

---

## Prompt 1.1

### Title: Build Your Ideal Customer Profile

**Use this when:** You are starting out, or you have been in business a while but still cannot say exactly who your best customer is. Also use this before spending any money on advertising.

**Copy this prompt:**

> I run a [type of business] in [town/city/area], Nigeria. My main products/services are [list them]. My typical prices are [price range]. Based on this, help me build a detailed profile of my ideal customer. Include: their likely age range, gender, occupation, income level (in naira, monthly), where they live or work in relation to my shop, what problem they are trying to solve when they buy from me, what they worry about before buying, where they spend time online (WhatsApp, Facebook, Instagram, TikTok), and what would make them choose me over a competitor. Present it as a short profile with a name, like a real person. Then tell me the 3 most important things I should change about how I sell to reach this person better.

**Real example (filled in):**

> I run a small unisex salon in Ikorodu, Lagos. My main services are braids, weaving, barbing, and pedicure. Braids cost ₦4,000–₦12,000, barbing is ₦1,500, pedicure is ₦3,000. Based on this, help me build a detailed profile of my ideal customer. Include: their likely age range, gender, occupation, income level (in naira, monthly), where they live or work in relation to my shop, what problem they are trying to solve when they buy from me, what they worry about before buying, where they spend time online, and what would make them choose me over a competitor. Present it as a short profile with a name, like a real person. Then tell me the 3 most important things I should change about how I sell to reach this person better.

*The AI will return something like "Meet Chidinma, 27, a bank contract staff who lives in Ikorodu but works on the Island, earns ₦120,000–₦180,000 monthly, wants a style that lasts 4+ weeks because she cannot afford weekly salon visits, worries about the braider being too slow or too rough, checks Instagram and WhatsApp Status for styles..." — and then give you three concrete changes.*

**Naija tip:** Do this prompt twice — once for your *best-paying* customer and once for your *most frequent* customer. In many Nigerian businesses, these are two different people. The market woman who buys ₦500 recharge card from you every day and the man who buys ₦20,000 data bundle once a month both matter, but you talk to them differently.

---

## Prompt 1.2

### Title: Find Out What Your Customers Really Want (Not What You Think)

**Use this when:** Sales are slower than expected, or you keep stocking things that do not move while customers ask for things you do not have.

**Copy this prompt:**

> I sell [products/services] in [area], Nigeria. Here is what I currently offer: [list]. Here are things customers have asked for that I don't have: [list, or say "I'm not sure"]. Here are things that sell fast: [list]. Here are things that sell slowly: [list]. Analyse this and tell me: (1) what pattern you see in what my customers actually value, (2) what they might be buying elsewhere that I could offer, (3) which slow items I should stop stocking, and (4) three questions I should ask my next 10 customers to confirm this. Keep it practical for a small Nigerian business with limited capital.

**Real example (filled in):**

> I sell provisions in a small shop in Nyanya, Abuja. Here is what I currently offer: rice, beans, garri, indomie, milk, sugar, detergent, toiletries, soft drinks. Things customers have asked for that I don't have: bread, eggs, frozen chicken, sachet tomato paste, small packs of spaghetti. Things that sell fast: indomie, sachet milk, small detergent, soft drinks. Things that sell slowly: big bags of rice, large tins of milk, expensive body cream. Analyse this and tell me: (1) what pattern you see in what my customers actually value, (2) what they might be buying elsewhere that I could offer, (3) which slow items I should stop stocking, and (4) three questions I should ask my next 10 customers to confirm this.

*The pattern the AI will likely find: your customers buy in small, daily quantities — they are budgeting day by day, not month by month. That changes everything about what you stock.*

**Naija tip:** Nigerian customers rarely complain directly; they just stop coming. So the "things customers asked for" list is your most valuable data. Start a simple note on your phone today: every time someone asks "you no get X?", write X down. After two weeks, feed that list into this prompt.

---

## Prompt 1.3

### Title: Understand Why Customers Buy From Your Competitor Instead

**Use this when:** There is a competitor nearby who seems busier than you, and you honestly do not know why.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. My main competitor is [describe them: location, size, how long they've been there, what they seem to do well]. What I've noticed about them: [prices, customer service, opening hours, product range, appearance of shop, how they advertise — whatever you know]. What I do: [same details about yourself]. Give me an honest comparison. What are the likely reasons customers choose them over me? Which of those reasons can I fix in the next 30 days without spending more than ₦[amount]? Which ones should I not even try to compete on, and what should I do instead to stand out?

**Real example (filled in):**

> I run a small restaurant (buka) in Uyo. My main competitor is a bigger buka across the road, been there 6 years, always crowded at lunchtime. What I've noticed: their food is slightly more expensive (₦1,500 vs my ₦1,200 for rice and chicken), but they have a canopy with fans, they serve fast, they have a POS that always works, and they give free water. What I do: cheaper prices, my food tastes better according to customers, but I have only 3 tables, no fan, my POS network fails often, and I sometimes run out of stew by 2pm. Give me an honest comparison. What are the likely reasons customers choose them over me? Which can I fix in 30 days without spending more than ₦100,000? Which should I not compete on, and what should I do instead?

**Naija tip:** Do not guess about your competitor — go and buy from them. Spend ₦2,000 as a customer and observe everything: how they greet you, how long you wait, how they handle change, whether they have a WhatsApp number on the wall. That ₦2,000 is the cheapest market research you will ever do. Then put what you saw into this prompt.

---

## Prompt 1.4

### Title: Write Customer Survey Questions That People Will Actually Answer

**Use this when:** You want direct feedback from customers but do not know what to ask, or your previous attempts got ignored.

**Copy this prompt:**

> I run a [business type] in Nigeria and I want to ask my customers a few questions to understand them better. I will send the questions on WhatsApp / ask them in person [choose one]. Write me 5 short, friendly questions in simple English that a busy Nigerian customer will actually answer in under 2 minutes. The questions should help me find out: what they like most, what frustrates them, what would make them buy more often, and what else they wish I sold. Avoid questions that sound like a bank form. Also write a 2-sentence opening message that makes them want to respond, and suggest a small thank-you I can offer that won't cost me much.

**Real example (filled in):**

> I run a small fashion business in Onitsha — I sew and sell ready-made gowns and two-piece sets for women, mostly ₦8,000–₦25,000. I want to ask my customers a few questions on WhatsApp. Write me 5 short, friendly questions in simple English that a busy Nigerian woman will answer in under 2 minutes. The questions should help me find out: what they like most, what frustrates them, what would make them buy more often, and what else they wish I sold. Avoid questions that sound like a bank form. Also write a 2-sentence opening message that makes them want to respond, and suggest a small thank-you that won't cost much.

**Naija tip:** Send the survey to your 15–20 most friendly customers first, not everybody. Ask on a weekday evening (7–9pm) when people are home and relaxed. And whatever you do, do not send it as a broadcast that looks like a broadcast — personalise the first line with their name. A ₦200 airtime "thank you" to the first 10 responders will get you more replies than a ₦5,000 discount voucher.

---

## Prompt 1.5

### Title: Discover the Real Problem You Solve (Your True Value)

**Use this when:** You describe your business by what you sell ("I sell shoes") instead of what customers gain. This prompt changes how you market everything.

**Copy this prompt:**

> I sell [product/service] to [type of customers] in Nigeria. Help me understand the deeper reason people buy from me. Go beyond the obvious. For example, someone buying a generator is not buying a machine — they are buying the ability to run their shop when NEPA fails, and the peace of mind that comes with it. For my business, list: (1) the surface reason people buy, (2) the practical problem underneath, (3) the emotional need underneath that, and (4) the fear or worry that buying from me removes. Then write 3 short sentences I can use to describe my business that speak to the deeper reason, not just the product. Keep the language simple, Nigerian, and natural — the kind of thing I could say to a customer or post on my WhatsApp status.

**Real example (filled in):**

> I sell and install solar-powered inverter systems for homes and small shops in Enugu, mostly to families and small business owners. Help me understand the deeper reason people buy from me. Go beyond the obvious. For my business, list: (1) the surface reason people buy, (2) the practical problem underneath, (3) the emotional need underneath that, and (4) the fear or worry that buying from me removes. Then write 3 short sentences I can use to describe my business that speak to the deeper reason. Keep the language simple, Nigerian, and natural.

*Expect answers like: "Surface: they want light. Practical: fuel is now ₦1,000+ per litre and the generator is eating their profit. Emotional: they are tired of the noise, the stress, the embarrassment of darkness when visitors come. Fear removed: the fear of another month of unpredictable expenses." And then lines like "Stop buying fuel every week. Buy light once."*

**Naija tip:** Nigerians buy solutions to stress. Fuel stress, NEPA stress, traffic stress, "what will people say" stress, school fees stress. When you know which stress you remove, your marketing writes itself. Print the best of the 3 sentences and put it on your shop signboard or WhatsApp Business "About" section.

---

## Prompt 1.6

### Title: Map Your Local Market Opportunity

**Use this when:** You want to know if your area has room for what you sell, or you are deciding whether to open a business (or a second branch) in a new location.

**Copy this prompt:**

> I am considering [starting / expanding] a [business type] in [specific area, town, state], Nigeria. Here is what I know about the area: [population feel — busy or quiet; type of residents — students, civil servants, traders, families; main landmarks — market, school, church, estate, motor park; how many similar businesses already exist; what they charge]. Based on this, give me: (1) an honest assessment of the opportunity — is there room for me or is the market crowded, (2) the specific type of customer in this area most likely to buy from me, (3) a gap or underserved need I could focus on, (4) the biggest risk I am not seeing, and (5) three things I should check in person before committing money.

**Real example (filled in):**

> I am considering starting a laundry and dry-cleaning service in Ojo, near Lagos State University (LASU). Here is what I know: very busy area, thousands of students in hostels and off-campus lodges, plus civil servants and traders. Main landmarks: LASU main gate, Iyana-Iba market, several churches. There are about 4 laundry services I've seen within 10 minutes' walk, charging around ₦200–₦300 per shirt. Based on this, give me: (1) an honest assessment — is there room or is it crowded, (2) the specific customer most likely to buy from me, (3) a gap I could focus on, (4) the biggest risk I'm not seeing, and (5) three things to check in person before committing money.

**Naija tip:** Before you sign any shop agreement, spend three different days at the location — a weekday morning, a Saturday afternoon, and a Sunday evening. Count foot traffic. Look at who is walking past and what they are carrying. Then tell the AI what you counted. Landlords will tell you the area is "very busy" — your own eyes will tell you the truth.

---

## Prompt 1.7

### Title: Understand Your Customers' Buying Habits and Timing

**Use this when:** You want to know *when* people buy, *how often*, and *what triggers* them to buy — so you can stock, staff, and advertise at the right times.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, selling to [customer type]. Help me understand the buying habits of my customers. Tell me: (1) which days of the week and times of day they are most likely to buy, and why, (2) which times of the month (salary week, end of month, mid-month) matter most for my type of business, (3) which seasons, festivals, or events in Nigeria increase or decrease demand for what I sell (e.g., Christmas, Sallah, back-to-school, rainy season, Valentine's, Easter, harvest time), (4) what everyday triggers make someone decide to buy today rather than tomorrow, and (5) how I should adjust my stock, opening hours, and promotions based on this.

**Real example (filled in):**

> I run a small phone accessories and repair kiosk in Kano, near a busy motor park, selling to commuters, traders, and young men. Help me understand the buying habits of my customers. Tell me: (1) which days and times they most likely buy, (2) which times of the month matter most, (3) which seasons, festivals or events in Nigeria increase or decrease demand — especially Sallah, Ramadan, and harmattan, (4) what everyday triggers make someone buy today rather than tomorrow, and (5) how I should adjust stock, hours, and promotions.

**Naija tip:** In Nigeria, the calendar drives cash. The 25th–30th of the month (salary time) is when people buy the things they have been postponing. The 10th–20th is when they buy small and manage. Structure your promotions around this: big-ticket offers at month-end, "small chops" pricing mid-month. And never run out of stock the week before a major festival — that is the most expensive mistake in retail.

---

## Prompt 1.8

### Title: Create Customer Segments (Group Your Customers Smartly)

**Use this when:** You have different types of customers and you are treating all of them the same way — same message, same price, same offer.

**Copy this prompt:**

> I run a [business type] in Nigeria. My customers include: [describe the different kinds of people who buy from you — e.g., students, working-class women, wholesalers, walk-in strangers, regulars, corporate clients]. Help me divide them into 3–4 clear groups (segments). For each group, tell me: what they value most, how much they typically spend, how often they buy, the best way to reach them (WhatsApp, in person, referral, Instagram), what offer would appeal to them most, and one mistake I should avoid with that group. Then tell me which group is most profitable and deserves most of my attention.

**Real example (filled in):**

> I run a small bakery in Ibadan making bread, meat pies, cakes, and small chops. My customers include: neighbours who buy bread every morning, small shop owners who buy bread in bulk to resell, people who order birthday and wedding cakes, and office workers who order small chops for events. Help me divide them into 3–4 clear groups. For each group, tell me: what they value most, how much they typically spend, how often they buy, the best way to reach them, what offer would appeal most, and one mistake to avoid. Then tell me which group is most profitable and deserves most of my attention.

**Naija tip:** After the AI gives you the segments, go into your WhatsApp Business app and create **Labels** for each group (Settings → Business tools → Labels). Label every customer chat. From that day, you can send the right message to the right people — bulk buyers get the wholesale price alert, cake customers get the "book early for December" message. This one habit separates struggling vendors from growing ones.

---

## Prompt 1.9

### Title: Turn Customer Complaints Into Business Intelligence

**Use this when:** You have received complaints (or you sense unhappiness) and you want to understand the real issue and fix it properly, not just apologise.

**Copy this prompt:**

> I run a [business type] in Nigeria. Here are the complaints and negative comments I have received recently, in the customers' own words as best I remember: [list them — include the small ones and the ones said jokingly]. Analyse these and tell me: (1) what the underlying pattern is — what is the real problem behind the complaints, (2) which complaints are about things I can fix cheaply and quickly, (3) which are signs of a bigger problem in how I run the business, (4) which complaints I should not take too seriously, and (5) a simple plan for what to fix first, second, and third. Be honest — do not soften the feedback.

**Real example (filled in):**

> I run a small logistics/dispatch rider business in Port Harcourt with 3 riders. Recent complaints: "Your rider came late again." "The rider was rude to my customer." "Why is your price different from what you told me on the phone?" "I couldn't reach you when I needed to track the package." "Your rider's bike broke down and my customer waited 2 hours." "Please, do you have a female rider? My customer is a woman living alone." Analyse these and tell me: (1) the underlying pattern, (2) which I can fix cheaply and quickly, (3) which are signs of a bigger problem, (4) which I should not take too seriously, and (5) a plan for what to fix first, second, and third. Be honest.

**Naija tip:** In Nigeria, the customer who complains to your face is doing you a favour — most people just tell 10 other people and never come back. Treat every complaint as free consulting. Keep a "Complaint Book" (a WhatsApp chat with yourself works fine). Run this prompt once a month with everything in that book. The businesses that grow are the ones that fix things before customers give up.

---

## Prompt 1.10

### Title: Research a New Product Before You Stock It

**Use this when:** A supplier is pushing you to buy a new item, or you saw something trending and are tempted to invest, but you want to check before committing money.

**Copy this prompt:**

> I am thinking of adding [new product/service] to my [business type] in [area], Nigeria. It would cost me ₦[cost price] to buy/produce and I plan to sell at ₦[selling price]. My existing customers are [describe them]. Help me evaluate this decision. Tell me: (1) does this product fit what my current customers are already buying — will they want it, (2) who else in my area might buy it, (3) what is the realistic demand — is this a fast-moving item or a slow one, (4) what could go wrong — spoilage, competition, price drops, fake versions in the market, seasonality, (5) how many units I should buy for a first test, and (6) how I will know within 2–3 weeks whether to continue or stop.

**Real example (filled in):**

> I am thinking of adding hair growth oils and edge control products to my cosmetics shop in Benin City. The oils cost me ₦2,500 each and I plan to sell at ₦4,500. My existing customers are mostly women aged 20–40 who buy makeup, perfumes, and skincare. Help me evaluate this. Tell me: (1) does this fit what my customers already buy, (2) who else in my area might buy it, (3) realistic demand — fast or slow mover, (4) what could go wrong — fakes, competition, price drops, (5) how many units for a first test, and (6) how I'll know within 2–3 weeks whether to continue or stop.

**Naija tip:** Never let a supplier's "this thing dey sell like pure water" replace your own test. The rule is simple: **test with the smallest quantity the supplier will sell you**, even if the unit price is higher. Losing ₦5,000 on a failed test is business. Losing ₦150,000 on a carton of something nobody wanted is a wound. And in Nigeria, always ask the AI about fakes — for many product categories (cosmetics, phone accessories, drinks), fake versions are your real competitor.

---

## Prompt 1.11

### Title: Estimate What Customers Are Willing to Pay

**Use this when:** You are setting or reviewing prices and you want a sensible range based on your customer type and market, not guesswork or fear of losing customers.

**Copy this prompt:**

> I sell [product/service] in [area], Nigeria. My cost to produce/buy one unit is ₦[amount]. My customers are mainly [describe: income level, occupation, type]. Competitors charge between ₦[low] and ₦[high]. My product is [better / same / simpler] than theirs because [reason]. Help me think through pricing. Tell me: (1) a realistic price range my customers would accept, and why, (2) whether I should price at the low, middle, or high end of that range, based on how I described my product and customers, (3) how to test two different prices without confusing customers, (4) how to explain a higher price so customers see the value instead of arguing, and (5) any signs that would tell me my price is too high or too low.

**Real example (filled in):**

> I make and sell zobo and tiger nut drinks in 50cl bottles in Jos. My cost per bottle is about ₦280 (ingredients, bottle, label, gas). My customers are students, office workers, and church members. Competitors charge ₦300–₦500. My product is better because I use no artificial sweetener, it's properly chilled, and my bottles are sealed with a printed label. Help me think through pricing. Tell me: (1) a realistic price range, (2) low, middle or high end, (3) how to test two prices without confusing customers, (4) how to explain a higher price so customers see the value, and (5) signs that my price is too high or too low.

**Naija tip:** The fear of "customers will run" makes many Nigerian business owners underprice and then go broke slowly. Here is the reality: customers who only came for cheap price will leave the moment someone cheaper appears anyway. Price for the customer who values quality, then make sure quality is visible (packaging, cleanliness, presentation). A ₦500 zobo in a sealed, labelled bottle looks worth ₦500. The same zobo in a reused water bottle looks worth ₦200.

---

## Prompt 1.12

### Title: Find Out Where Your Customers Spend Time (Online and Offline)

**Use this when:** You want to advertise or promote, but you are not sure whether to focus on WhatsApp, Instagram, Facebook, TikTok, flyers, radio, or church/mosque announcements.

**Copy this prompt:**

> My business is [type] in [area], Nigeria. My typical customer is [age range, gender, occupation, income level, lifestyle]. Help me figure out where these customers spend their time and attention, both online and offline. Rank the following by how likely I am to reach my customers there, and explain why: WhatsApp Status, WhatsApp groups, Facebook, Instagram, TikTok, church/mosque announcements, market/street presence, referrals from existing customers, flyers/posters, local radio, estate/community groups. Then tell me the ONE channel I should focus on first, and the TWO I should ignore for now so I don't waste money and energy.

**Real example (filled in):**

> My business is a poultry farm in Abeokuta selling live chickens and eggs. My typical customers are two groups: women aged 30–55 who buy for their families, and small food vendors/restaurants who buy eggs and chicken in bulk. Help me figure out where these customers spend their time and attention. Rank these by how likely I am to reach them: WhatsApp Status, WhatsApp groups, Facebook, Instagram, TikTok, church/mosque announcements, market presence, referrals, flyers, local radio, estate/community groups. Then tell me the ONE channel to focus on first, and TWO I should ignore for now.

**Naija tip:** For most Nigerian small businesses, the honest answer is WhatsApp first — it is where your existing customers already are, and it costs nothing. TikTok and Instagram are for when you have something visual and time to be consistent. Do not spread yourself thin. One channel done every day beats five channels done once a month. And never underestimate the church/mosque/community group announcement — for family-focused products, it still outsells social media in many towns.

---

## Prompt 1.13

### Title: Check Demand Before You Start a Business (The Reality Test)

**Use this when:** You have a business idea and you are excited about it, but you have not yet spent money. This is the prompt that saves people from expensive mistakes.

**Copy this prompt:**

> I want to start a [business idea] in [area], Nigeria. My reason for believing it will work: [your reasons]. My budget is ₦[amount]. I would be selling to [customer type]. Play the role of a tough but fair business adviser. Tell me: (1) the honest strengths of this idea, (2) the three biggest reasons it could fail — be specific to Nigeria and my area, (3) what evidence I should gather before spending any money, and exactly how to gather it cheaply, (4) a way I could test the idea with less than 20% of my budget, and (5) what results from that test would mean "go ahead" versus "stop or change the plan." Do not encourage me just to be nice.

**Real example (filled in):**

> I want to start a home-cooked food delivery business in Lekki, Lagos — healthy Nigerian meals delivered to offices and homes. My reason for believing it will work: many young professionals there are too busy to cook and are tired of unhealthy fast food. My budget is ₦400,000. I would be selling to workers aged 25–40 earning ₦200k+ monthly. Play the role of a tough but fair business adviser. Tell me: (1) honest strengths, (2) the three biggest reasons it could fail — specific to Lagos, (3) what evidence to gather before spending, and how to gather it cheaply, (4) how to test with less than ₦80,000, and (5) what test results mean "go" versus "stop." Do not encourage me just to be nice.

**Naija tip:** Nigerians are polite — your friends and family will tell you your idea is "very good" because they love you, not because they will buy. The only real evidence is **people paying money**. Before you rent a shop or buy equipment, try to get 10 people to pre-pay or place a deposit. If you cannot find 10 people to pay ₦2,000 in advance, you will not find 100 people to pay after you have spent ₦400,000.

---

## Prompt 1.14

### Title: Analyse Your Best Customers and Find More Like Them

**Use this when:** You have been in business for a while and want to grow by finding more of the customers who already love you, rather than chasing everyone.

**Copy this prompt:**

> I run a [business type] in Nigeria. Here are my 5–10 best customers — the ones who buy most often, spend the most, or refer others: [for each, describe what you know: rough age, occupation, where they live/work, what they buy, how they found you, why they keep coming]. Analyse these people and tell me: (1) what they have in common — the pattern I may not have noticed, (2) a description of the "type" of person most likely to become a great customer for me, (3) where I can find more people like them in my area, (4) what message or offer would attract people like them, and (5) which of my current marketing efforts are probably attracting the wrong people and should be dropped.

**Real example (filled in):**

> I run a small interior décor and curtain-making business in Asaba. My best customers: (1) a woman in her 40s, banker, lives in a new estate, found me through her neighbour, has ordered 3 times; (2) a young couple who just built their house, found me on Instagram, spent ₦350k; (3) a school proprietor who did all classrooms and office, found me through church; (4) a hotel manager who orders replacement curtains twice a year; (5) a doctor who just moved to Asaba, referred by customer 1; (6) a woman who runs a lounge, found me via WhatsApp Status. Analyse these and tell me: (1) what they have in common, (2) the type most likely to become a great customer, (3) where to find more like them, (4) what message would attract them, and (5) which marketing efforts are probably attracting the wrong people.

**Naija tip:** In Nigeria, your best customers are usually connected to other potential best customers — same estate, same church, same office, same alumni group. The pattern this prompt reveals often points to one or two "communities" where your business should become the known name. Once you see it, ask your best customers directly: "Who else in your estate is building or renovating?" They will tell you.

---

## Prompt 1.15

### Title: Understand What Stops People From Buying (Objection Research)

**Use this when:** People show interest, ask questions, price your product — and then disappear. You want to understand the invisible reasons they did not buy.

**Copy this prompt:**

> I sell [product/service] in Nigeria to [customer type], priced at ₦[price]. Many people ask about it or show interest but do not buy. Here is what happens typically: [describe — e.g., they ask price and go quiet; they say "I'll come back"; they ask too many questions; they say it's expensive; they ask for discount and then vanish]. Help me understand the real reasons behind this. List the 6–8 most likely hidden objections — the things customers are thinking but not saying — such as trust, money timing, fear of fakes, not understanding the value, comparing with a cheaper option, waiting for a spouse's approval, etc. For each one, tell me how to spot it and one simple thing I can say or do to address it before they walk away.

**Real example (filled in):**

> I sell quality second-hand (UK-used) laptops in Aba, priced ₦120,000–₦250,000, to students, young professionals, and small business owners. Many people ask about it or show interest but do not buy. Typically: they ask price on WhatsApp and go quiet; they ask "is it original?"; they ask if I have a warranty; they say they'll "check other places and come back"; some ask for a payment plan. Help me understand the real reasons behind this. List the 6–8 most likely hidden objections, and for each, tell me how to spot it and one simple thing I can say or do to address it before they walk away.

**Naija tip:** The number one hidden objection in Nigeria is **trust** — "Will this person scam me? Is this thing original? If it spoils, will they pick my call?" Price is often what customers *say*, but trust is what they *feel*. Anything that builds trust (real customer video reviews, a written warranty on paper, a physical address, a business name registered with CAC, consistent WhatsApp Status posts for months) reduces price resistance more than a discount does.

---

## Prompt 1.16

### Title: Create a Simple Customer Journey Map

**Use this when:** You want to see your business through the customer's eyes — from the moment they first hear of you to the moment they come back or refer a friend — and find the weak points.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Walk me through my customer's journey step by step, from their point of view: (1) how they first hear about me, (2) how they check whether I'm trustworthy, (3) how they contact me or find my shop, (4) what happens during the purchase, (5) what happens after they pay — delivery, usage, any problems, (6) what makes them come back or not, and (7) what makes them tell a friend or not. Here is how my business currently works at each stage: [describe honestly]. For each step, tell me where I might be losing customers without knowing, and one cheap improvement I can make. Then tell me which single step, if fixed, would bring the biggest improvement in sales.

**Real example (filled in):**

> I run a small catering business in Kaduna doing event food for weddings, naming ceremonies, and office parties. Here is how my business works: people usually hear of me at events where I cooked; they get my number from the host; they call or WhatsApp me; I send a price list as a photo; if they agree, they pay 70% deposit to my account; on the day I cook and deliver with hired hands; after the event I rarely follow up. Walk me through my customer's journey from their point of view across all 7 stages. For each step, tell me where I might be losing customers without knowing, and one cheap improvement. Then tell me which single step, if fixed, would bring the biggest improvement in sales.

**Naija tip:** Most Nigerian small businesses lose the most customers at two points: **the first WhatsApp reply** (slow, cold, or just "how many you want?") and **after payment** (silence). A warm, fast first reply and a simple "Thank you ma, hope everything went well? Please keep my number for next time" after the job will bring more repeat business than any advertising. It is free. Do it.

---

## Prompt 1.17

### Title: Analyse Market Trends Affecting Your Business

**Use this when:** You want to understand what is changing in Nigeria — prices, habits, technology, competition — and how it will affect your business in the next 6–12 months.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Based on what is generally known about the Nigerian economy and consumer behaviour, help me think through the trends that could affect my business over the next 6–12 months. Consider: fuel and transport costs, naira exchange rate and import prices, changes in how people shop (online, WhatsApp, delivery), new competitors or business models, what young people are doing differently, and any government policy directions relevant to my sector. For each trend, tell me: is it a threat or an opportunity for me, how soon it will matter, and one practical thing I can do now to prepare. Be honest about what you are unsure of — I will verify important details myself.

**Real example (filled in):**

> I run a small electronics shop in Owerri selling phones, chargers, power banks, small speakers, and rechargeable fans. Help me think through the trends that could affect my business over the next 6–12 months. Consider: fuel and transport costs, the naira and import prices, changes in how people shop (online, WhatsApp, delivery), new competitors like Jumia or Instagram vendors, what young people are doing differently, and any government policy directions for my sector. For each trend, tell me: threat or opportunity, how soon it matters, and one practical thing I can do now. Be honest about what you are unsure of.

**Naija tip:** This is one prompt where you must **check before you trust**. The AI does not know today's exchange rate, this week's fuel price, or last month's CBN circular. Use it for *thinking* — to spot the shape of what's coming — then confirm specific numbers with real sources (news, your suppliers, your bank). The trend that has affected almost every Nigerian small business recently is simple: customers are buying smaller quantities more often. Plan for that.

---

## Prompt 1.18

### Title: Understand a Customer Group You Don't Know Well

**Use this when:** You want to start selling to a new type of customer — a different age group, income level, religion, region, or profession — and you do not want to make embarrassing or expensive mistakes.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, and I currently serve mostly [current customer type]. I want to start selling to [new customer group — e.g., university students, corporate offices, Northern Muslim women, retirees, expatriates, Gen Z, Igbo traders, church groups]. I do not know this group well. Help me understand them respectfully and practically. Tell me: (1) what they typically value when buying [my type of product/service], (2) how they prefer to be approached and communicated with, (3) cultural, religious, or social considerations I must respect, (4) mistakes outsiders commonly make with this group, (5) what price sensitivity to expect, and (6) how to earn their trust as a newcomer. If there are things that vary a lot within this group, say so.

**Real example (filled in):**

> I run a modest-fashion and hijab business in Ilorin, currently serving mostly Muslim women aged 25–45. I want to start selling to university students at UNILORIN and Kwara State University — young women aged 17–24. I do not know this group well. Help me understand them respectfully and practically. Tell me: (1) what they value when buying modest fashion, (2) how they prefer to be approached, (3) cultural or social considerations, (4) mistakes older sellers commonly make with them, (5) price sensitivity, and (6) how to earn their trust as a newcomer.

**Naija tip:** Nigeria is not one market — it is hundreds. What works in Aba may fail in Sokoto; what a 45-year-old wants is not what a 20-year-old wants. Use this prompt to prepare, then **find one or two real people from that group and ask them to check your plan**. Pay them a small "consultation fee" (₦2,000–₦5,000 or a free product). Their 20 minutes of honest feedback is worth more than 20 pages of AI output.

---

## Prompt 1.19

### Title: Research Your Competitors' Pricing and Offers Systematically

**Use this when:** You want a clear picture of what everyone in your market is charging and offering, so you can position yourself intelligently rather than guessing.

**Copy this prompt:**

> I sell [product/service] in [area], Nigeria. I have gathered this information about competitors: [for each competitor: name or description, their prices for the same or similar items, any extras they offer — delivery, warranty, discount, packaging, credit — and what customers say about them]. Organise this into a clear comparison table with columns for: competitor, price, extras, strengths, weaknesses. Then tell me: (1) where I currently sit compared to them, (2) whether the market is competing mainly on price, quality, service, or convenience, (3) an open position no one is occupying that I could take, (4) what I should charge and what I should include to be clearly different, and (5) how to explain my position to customers in one simple sentence.

**Real example (filled in):**

> I sell school uniforms and sportswear to primary and secondary schools in Ilesa. Competitor info: (A) Big tailor near the market — ₦6,500 per uniform set, 2-week delivery, sometimes late, good quality; (B) A woman who imports ready-made from Lagos — ₦5,000 per set, sizes are often off, no adjustments; (C) A new shop with a machine embroidery for school logos — ₦7,500, 1-week delivery, very neat, but only does bulk orders of 20+. I charge ₦6,000, take 10 days, do adjustments free, no embroidery. Organise this into a comparison table. Then tell me: (1) where I sit, (2) what the market is competing on, (3) an open position I could take, (4) what I should charge and include, and (5) how to explain my position in one sentence.

**Naija tip:** Gather this data the Nigerian way — send a friend or relative to "price" each competitor as a customer, on WhatsApp and in person. Ask about delivery, discount for bulk, and what happens if there's a problem. Do this every 3 months; prices in Nigeria move fast and a competitor's "extras" change often. And remember: the goal is not to be the cheapest. The goal is to be the obvious choice for a specific kind of customer.

---

## Prompt 1.20

### Title: Summarise Everything Into a One-Page Customer & Market Brief

**Use this when:** You have done several of the prompts above and want to bring all the insights into one simple document you can look at every week and share with anyone helping you (staff, family, partner).

**Copy this prompt:**

> I have been researching my customers and market for my [business type] in [area], Nigeria. Here is what I have learned so far: [paste or summarise your findings — ideal customer profile, what they want, why they buy, main competitors, pricing insights, best channels to reach them, main objections, opportunities spotted]. Turn all of this into a clear one-page Customer & Market Brief with these sections: (1) Who my customer is (3–4 lines), (2) What they really want and fear, (3) Where to find them, (4) My competitors and my position, (5) My price and why, (6) The top 3 opportunities I should act on in the next 90 days, and (7) The 3 things I must stop doing. Use simple language a staff member with only secondary school education could understand. Keep it to one page.

**Real example (filled in):**

> I have been researching my customers and market for my frozen foods shop (chicken, turkey, fish, sausages) in Warri. What I've learned: my ideal customer is a working mother, 30–50, buying weekly on Saturdays, who values freshness and honest weighing more than the lowest price. Her fear is buying meat that has been thawed and refrozen. Main competitors: two other cold rooms nearby — one is cheaper but their light goes off often, the other is bigger but the staff are rude. My prices are mid-range. Best channel is WhatsApp Status and referrals from church women. Main objection: "Is your freezer always on?" Opportunities: a Saturday morning pre-order via WhatsApp, a small home delivery service, and portioned packs for single people. Turn this into a one-page Customer & Market Brief with the 7 sections. Use simple language. Keep it to one page.

**Naija tip:** Print this brief. Paste it inside your shop (where customers cannot see it) or save it as your phone wallpaper for a week. Read it before every big decision — new stock, new price, new staff, new advert. When you find yourself about to do something that contradicts the brief, stop and ask why. Redo this prompt every 90 days; your customers change, and so should your understanding of them.

---

## Part 1 Checkpoint

Before you move on to Part 2, make sure you can answer these five questions **without thinking too hard**:

1. Who is my ideal customer? (Name, age, job, income, what they fear.)
2. What is the real problem I solve for them — beyond the product?
3. Why do some people buy from my competitor instead of me?
4. Where do my customers spend their time and attention?
5. What is the one opportunity I will act on in the next 30 days?

If you can answer all five, you already know your market better than most businesses in your area. Now let us go and get those customers — cheaply.

**Next: Part 2 — Low-Cost Marketing That Actually Works in Naija (Prompts 2.1 – 2.20)**


<div class='pb'></div>

# PART 2: LOW-COST MARKETING THAT ACTUALLY WORKS IN NAIJA
*(Prompts 2.1 – 2.20)*

---

## Why Most Small-Business Marketing in Nigeria Fails

It is not because owners don't try. It is because they copy what big brands do — flashy graphics, giveaways, "follow us on all platforms" — without the budget or the team to sustain it. Two weeks later the Instagram page is dead, the flyers are in the gutter, and the owner concludes that "marketing doesn't work."

Marketing that works for a small Nigerian business follows three rules:

1. **It costs little or nothing.** WhatsApp Status, referrals, community presence, and honest word-of-mouth beat paid ads at this stage.
2. **It is consistent.** One post every day for 90 days beats ten posts in one week and silence for a month.
3. **It sounds like a person, not a company.** Nigerians buy from people they know, like, and trust — not from logos.

In this Part, you will use AI to write your WhatsApp Status posts, broadcast messages, captions, flyers, referral offers, and customer follow-ups — fast, in your own voice, without hiring anybody. You already did the customer research in Part 1. Now we use it.

**Work through it like this:** Start with Prompts 2.1, 2.2 and 2.8. They set up your WhatsApp presence, your daily content, and your referral engine — the three pillars. The rest are tools you pull out as needed.

---

## Prompt 2.1

### Title: Write a WhatsApp Business Profile That Sells While You Sleep

**Use this when:** Your WhatsApp Business "About", description, and catalogue are empty or half-done, and new contacts cannot tell in 5 seconds what you sell and why they should trust you.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. I sell [products/services] to [customer type]. What makes me different: [your edge — quality, speed, price, warranty, experience, etc.]. My opening hours are [hours] and I deliver [where / how]. Write me: (1) a short "About" line for WhatsApp Business (under 139 characters), (2) a full business description (under 500 characters) that says what I sell, who it's for, why to trust me, and how to order, (3) five product/service catalogue entries with a title (under 40 characters) and a 2-line description each, and (4) a friendly greeting message that sends automatically when someone messages me for the first time. Use simple, warm, confident Nigerian English. No corporate jargon.

**Real example (filled in):**

> I run a small bakery in Ibadan. I sell fresh bread, meat pies, chin chin, and custom birthday cakes to families, small shop owners, and event planners. What makes me different: baked fresh every morning by 6am, no preservatives, I deliver within Bodija and Agbowo, and cakes are ready in 48 hours. Opening hours 6am–8pm Monday to Saturday. Write me: (1) a short "About" line under 139 characters, (2) a full business description under 500 characters, (3) five catalogue entries with a title under 40 characters and a 2-line description each, and (4) a friendly automatic greeting message for first-time contacts. Simple, warm, confident Nigerian English.

**Naija tip:** Set up the greeting message and the "away message" in WhatsApp Business (Business tools → Greeting message / Away message). Many Nigerian customers message at 11pm; a warm automatic reply that says "I've seen your message, I'll respond by 7am" keeps them from moving to the next vendor. Also put your **real name and face** in the profile photo or the description — "Mama Tobi's Bakery, run by Funke" — because people trust a face more than a logo.

---

## Prompt 2.2

### Title: Create 30 Days of WhatsApp Status Posts in One Sitting

**Use this when:** You know you should be posting daily but you run out of ideas by day 3, or all your posts are just "buy this, ₦5,000."

**Copy this prompt:**

> I run a [business type] in Nigeria selling [products/services] to [customer type]. Create a 30-day WhatsApp Status content plan for me. Each day should have: the post type, a short caption (under 40 words), and what photo or video I should take with my phone. Mix these post types across the month: product showcase, customer testimonial, behind-the-scenes, tip or advice related to my business, a question that invites replies, a limited offer, a "before and after", a personal story, and a reminder of how to order. Only about 1 in 3 posts should directly sell. The tone should be friendly, real, and Nigerian — not like a big company. Present it as a table: Day | Post type | Caption | Photo/video to take.

**Real example (filled in):**

> I run a small skincare business in Abuja selling natural black soap, shea butter cream, and turmeric face scrub to women aged 22–40. Create a 30-day WhatsApp Status content plan. Each day: post type, a short caption under 40 words, and what photo or video to take with my phone. Mix product showcase, customer testimonial, behind-the-scenes, skincare tips, questions that invite replies, a limited offer, before-and-after, personal story, and how-to-order reminders. Only about 1 in 3 posts should directly sell. Friendly, real, Nigerian tone. Present as a table: Day | Post type | Caption | Photo/video to take.

**Naija tip:** Post between **7–9am** and **7–10pm** — those are the hours Nigerians scroll Status. Post 2–4 times a day, not 15 (people mute vendors who flood). Once a week, post something that has nothing to do with selling — your child's school event, a Nigerian joke, a Sunday prayer — because customers buy from *people*, and Status is where they get to know you as one. Save the AI's table as a note on your phone and tick each day off.

---

## Prompt 2.3

### Title: Write a Broadcast Message That People Don't Ignore

**Use this when:** You want to send a message to many customers at once — new stock, a promo, a festive offer — and you want it to be read and acted on, not deleted.

**Copy this prompt:**

> I want to send a WhatsApp broadcast to my customers about [what: new stock / promo / festive offer / restock / price change / new service]. Details: [product, price, offer, deadline, how to order]. My customers are [describe them]. Write me 3 versions of the message, each under 80 words: (1) a warm, personal version that sounds like I'm writing to one friend, (2) a short, urgent version with a clear deadline, and (3) a version that starts with a benefit or a question instead of the product. Each should end with one clear action: reply, call, or click. Don't use ALL CAPS or too many emojis — a maximum of 3. Nigerian English, simple and natural.

**Real example (filled in):**

> I want to send a WhatsApp broadcast to my customers about new stock of Ankara fabric — 20 fresh designs just arrived from Kano, ₦4,500 per 6 yards, first 15 customers get free delivery within Ilorin, offer ends Sunday. Order by replying "ANKARA" or calling 0902 190 6332. My customers are women aged 25–55 who sew for church, weddings, and aso-ebi. Write me 3 versions under 80 words each: (1) warm and personal, (2) short and urgent with deadline, (3) starting with a benefit or question. Each ends with one clear action. Maximum 3 emojis. Nigerian English.

**Naija tip:** WhatsApp broadcasts only reach people who have **saved your number**. That is why Prompt 2.1 and every receipt, invoice, or delivery note should say "Save my number as [Business Name] so you don't miss offers." Also: send broadcasts to labelled segments (from Part 1, Prompt 1.8), not to everybody. The bulk buyer does not need the ₦4,500 retail message — send them the wholesale price.

---

## Prompt 2.4

### Title: Write Product Captions That Make People Ask "How Much?"

**Use this when:** You post products and get zero replies, or your captions are just the product name and price.

**Copy this prompt:**

> Write 5 different captions for this product: [product name, what it does, key features, price, who it's for]. Each caption should be under 50 words and use a different angle: (1) the problem it solves, (2) a mini-story of a customer using it, (3) a surprising fact or comparison, (4) a direct offer with urgency, and (5) a question that makes the reader think about their own situation. Make each one end with a soft call to action like "Send me a DM" or "Reply 'YES' for price." The language should be natural Nigerian English, with light Pidgin only if it sounds better. No hashtags.

**Real example (filled in):**

> Write 5 different captions for this product: rechargeable standing fan, 16 inches, lasts 8–12 hours on one charge, has LED light and USB phone charging port, ₦38,000, for families and small shop owners who are tired of heat when NEPA takes light. Each caption under 50 words with a different angle: (1) problem it solves, (2) mini-story of a customer, (3) surprising fact or comparison, (4) direct offer with urgency, (5) a question that makes the reader think. Soft call to action at the end of each. Natural Nigerian English, light Pidgin only if it sounds better. No hashtags.

**Naija tip:** The caption that usually wins in Nigeria is the **comparison to a known pain**: "This fan runs 10 hours on one charge — that's one night of sleep without generator noise or ₦3,000 of fuel." Numbers + a familiar pain = replies. Test two captions on the same product on different days and notice which gets more "how much?" — then use that angle for everything.

---

## Prompt 2.5

### Title: Design a Flyer or Poster That Works (Without a Designer)

**Use this when:** You need a flyer for the neighbourhood, a poster for your shop front, or a graphic for Status — and you plan to make it yourself in Canva or a phone app.

**Copy this prompt:**

> I need a [flyer / shop poster / WhatsApp Status graphic] for my [business type] in [area], Nigeria. The goal is to [get people to visit / call / order / try a new service]. My audience is [customer type]. Write me the exact text for the design: (1) a headline of 5–8 words that stops people, (2) a sub-headline of one sentence that explains the benefit, (3) 3 bullet points of what I offer or why to choose me, (4) the offer or reason to act now, and (5) the contact line with phone/WhatsApp and location or delivery area. Then give me simple design instructions: what colours to use, what one photo to feature, where to place each text element, and what to avoid so it doesn't look crowded or cheap.

**Real example (filled in):**

> I need a flyer for my mobile car wash service in Gwarinpa, Abuja. The goal is to get estate residents to book a first wash. My audience is car owners aged 28–55 who are busy and don't want to queue at a car wash. Write the exact text: (1) a headline of 5–8 words, (2) a one-sentence sub-headline, (3) 3 bullet points, (4) the offer — first wash ₦3,000 instead of ₦4,500 this month, (5) contact line with WhatsApp 0902 190 6332 and "We come to your house." Then give simple design instructions: colours, one photo to feature, layout, and what to avoid.

**Naija tip:** One headline, one photo, one offer, one phone number. That is a flyer. Anything more and nobody reads it. Use your **real photo** (your actual product, your actual van, your actual shop) — stock images scream "not real." Print 200 flyers first (₦8,000–₦15,000 at most print shops), not 2,000, and hand them out yourself with a smile at the estate gate on Saturday morning. Track how many people mention the flyer. If fewer than 5 in 200 respond, change the offer, not the paper.

---

## Prompt 2.6

### Title: Write Your Business Story (People Buy From People)

**Use this when:** You want customers to feel connected to you — for your WhatsApp description, Instagram bio, a pinned Status, or the "About Us" on a simple website.

**Copy this prompt:**

> Help me write my business story in a way that builds trust and connection with Nigerian customers. Facts about me: [how and why you started, what problem you saw, a struggle you overcame, what you believe about your product or service, how long you've been doing it, what customers say]. Write 3 versions: (1) a 2-sentence version for a bio, (2) a 100-word version for WhatsApp Business description or pinned Status, and (3) a 250-word version for a website or flyer back page. The tone should be humble, honest, and warm — not boastful. Avoid clichés like "passion for excellence." Make it sound like a real Nigerian person telling their story, not a company.

**Real example (filled in):**

> Help me write my business story. Facts: I started my catfish farm in Ikorodu in 2021 after I lost my job at a hotel during COVID. I began with one small tank and ₦60,000 borrowed from my sister. The first batch nearly all died because I didn't understand water changes. I learnt from YouTube and an older farmer in the area. Today I have 6 tanks, supply 3 restaurants and 2 markets, and I smoke fish for people who want it dry. I believe fish should be fresh, fairly priced, and properly weighed. Customers say my fish are "always alive and always the size you promised." Write 3 versions: 2-sentence bio, 100-word description, and 250-word website version. Humble, honest, warm. No clichés.

**Naija tip:** Nigerians deeply respect the story of hustle and honesty — "I started with ₦60,000 and one tank" earns more trust than "we are the leading aquaculture solutions provider." Tell the true story, including one failure. Then pin the 100-word version as a WhatsApp Status highlight or post it on the first Monday of every month. New contacts will read it, and old customers will forward it when recommending you.

---

## Prompt 2.7

### Title: Get Customer Testimonials (And Turn Them Into Marketing)

**Use this when:** You have happy customers but no proof to show new ones — no reviews, screenshots, or videos.

**Copy this prompt:**

> I run a [business type] in Nigeria. I want to collect testimonials from happy customers and use them in my marketing. Write me: (1) a short, polite WhatsApp message asking a satisfied customer for a testimonial, making it easy for them by suggesting 2–3 things they could mention, (2) a follow-up for those who agree but haven't sent it after 3 days, (3) a message asking permission to use their words and first name (or a nickname) publicly, and (4) three ways to turn a simple text testimonial into a Status post or graphic that looks credible, not fake. Also tell me how to ask for a 15-second voice note or video testimonial without making the customer uncomfortable.

**Real example (filled in):**

> I run a small event decoration business in Enugu — balloon décor, backdrops, and table setups for birthdays and weddings. I want to collect testimonials. Write me: (1) a short polite WhatsApp message asking a satisfied customer for a testimonial with 2–3 suggested things to mention, (2) a follow-up for those who agree but haven't sent after 3 days, (3) a message asking permission to use their words and first name publicly, and (4) three ways to turn a text testimonial into a credible Status post. Also tell me how to ask for a 15-second voice note or video testimonial without making them uncomfortable.

**Naija tip:** The best time to ask is **within 24 hours of the moment they were happiest** — right after the event, right after the delivery arrived, right when they said "thank you so much." Screenshot every unprompted "thank you" or "the thing is so fine" message (crop out the phone number). A folder of 20 real screenshots is worth more than any advert in Nigeria — because everybody knows you can't easily fake 20 different WhatsApp chats.

---

## Prompt 2.8

### Title: Build a Referral System That Actually Brings Customers

**Use this when:** Most of your customers come by word of mouth, but you have no system to make it happen faster and more often.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. My average sale is ₦[amount] and my profit per sale is roughly ₦[amount]. Design a simple referral programme I can run through WhatsApp with no app or software. Include: (1) what reward to give the referrer and whether the new customer should also get something — with 3 options at different cost levels, (2) exactly how customers will refer (what they say, what they send, how I track it without confusion), (3) the message I send to existing customers announcing the programme, (4) the message I send to thank a referrer and deliver their reward, and (5) how to avoid the common problems — people claiming referrals that aren't real, forgetting to reward, or the reward eating all my profit.

**Real example (filled in):**

> I run a home cleaning service in Lekki, Lagos. Average sale is ₦25,000 per cleaning, profit roughly ₦10,000. Design a simple referral programme I can run through WhatsApp. Include: (1) what reward to give the referrer and the new customer, with 3 options at different cost levels, (2) exactly how customers will refer and how I track it, (3) the announcement message, (4) the thank-you-and-reward message, and (5) how to avoid fake claims, forgetting rewards, or the reward eating my profit.

**Naija tip:** Nigerians refer naturally — but they refer **faster** when there is something in it and when it is **easy**. The easiest system: "Tell your friend to mention your name when they book. After their first payment, you get ₦2,500 airtime / a free product / ₦3,000 off your next order." Airtime is the most-loved reward in Nigeria because it's instant and universally useful. Send the reward the same day — a delayed reward kills the programme.

---

## Prompt 2.9

### Title: Write Follow-Up Messages for People Who Asked But Didn't Buy

**Use this when:** You have a list of people who asked "how much?" and disappeared. This is money sitting in your chat list.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price]. Many people asked for the price on WhatsApp and then went quiet. Write me a 3-message follow-up sequence I can send them: (1) Day 2 — a gentle, no-pressure check-in that offers help or answers a common worry, (2) Day 5 — a message that adds value (a tip, a testimonial, or a photo idea) and reminds them the item is available, (3) Day 10 — a final message with a small incentive or a reason to act now, and a graceful "no wahala if it's not for you now." Each message under 50 words. Should feel human, never desperate or pushy. Also give me one line I can use if they reply "it's too expensive."

**Real example (filled in):**

> I sell wigs and hair bundles in Port Harcourt, ₦35,000–₦120,000. Many people asked for price on WhatsApp and went quiet. Write me a 3-message follow-up sequence: (1) Day 2 gentle check-in offering help or answering a common worry (like "is it human hair?"), (2) Day 5 value message — a care tip, testimonial, or styling idea, and a reminder it's available, (3) Day 10 final message with a small incentive and a graceful "no wahala." Each under 50 words, human, never desperate. Also one line for when they reply "it's too expensive."

**Naija tip:** In Nigeria, "I'll get back to you" usually means one of three things: no money *yet*, waiting for salary, or checking elsewhere. A gentle Day 5 message that lands around the 25th–28th of the month (salary time) converts remarkably well. Never send "Hello? Are you still interested?" — it sounds like a debt collector. Send value instead: "Just posted a video of how this wig looks after 3 washes — thought you'd want to see."

---

## Prompt 2.10

### Title: Launch a New Product or Service Without a Budget

**Use this when:** You are introducing something new and you want buzz, pre-orders, or first customers using only your existing contacts and WhatsApp.

**Copy this prompt:**

> I am launching [new product/service] for my [business type] in [area], Nigeria, on [date]. Price: ₦[amount]. Who it's for: [customer type]. Why it's valuable: [key benefits]. Create a 7-day launch plan using only WhatsApp Status, broadcasts, and personal messages — zero ad spend. For each day give me: the goal, what to post on Status (with a caption), and any direct messages to send. Include a teaser phase, a pre-order or early-bird offer, the launch-day announcement, social proof from first buyers, and a final "closing soon" push. Also suggest one small, cheap incentive for the first 10 buyers.

**Real example (filled in):**

> I am launching a weekly "Soup Pot" subscription for my food business in Yaba, Lagos, on Monday next week — customers get a 2-litre pot of egusi, efo riro, or ogbono delivered every Saturday for ₦7,500/week. It's for busy workers and students who don't have time to cook soup. Benefits: home taste, fresh ingredients, saves 3 hours every weekend, cheaper than eating out. Create a 7-day launch plan using only WhatsApp Status, broadcasts, and personal messages — zero ad spend. Include teaser, early-bird offer, launch-day announcement, social proof, and closing push. Suggest one cheap incentive for the first 10 subscribers.

**Naija tip:** Get **5 people to pay before you announce publicly** — friends, loyal customers, family who will genuinely use the thing. Then your launch-day post can honestly say "5 spots already gone" and include a real screenshot of a payment or a happy message. Nigerians move when they see other Nigerians moving. Nobody wants to be the first — everybody wants to be the sixth.

---

## Prompt 2.11

### Title: Create Instagram / TikTok Content Ideas You Can Film With Your Phone

**Use this when:** Your product is visual (food, fashion, beauty, décor, crafts) and you want to grow on Instagram or TikTok without a camera crew or editing skills.

**Copy this prompt:**

> I run a [business type] in Nigeria selling [products] to [audience]. Give me 15 short-video ideas (15–45 seconds each) I can film alone with my phone for Instagram Reels or TikTok. For each: the idea, a hook for the first 3 seconds (spoken or on-screen text), what to show, and a caption. Mix: process/behind-the-scenes, before-and-after, "things people don't know about [my product]", customer reactions, day-in-the-life, common mistakes people make, price reveal, and packaging an order. Ideas should suit Nigerian viewers — use situations, humour, and references they'll recognise. Tell me which 3 to film first.

**Real example (filled in):**

> I run a small shoemaking business in Aba — handmade leather sandals, loafers, and slides for men, ₦8,000–₦25,000. Audience: Nigerian men 22–45 who want quality made-in-Nigeria shoes, and women buying for husbands/boyfriends. Give me 15 short-video ideas I can film alone with my phone. For each: idea, 3-second hook, what to show, caption. Mix process, before-and-after, things people don't know about Aba-made shoes, customer reactions, day-in-the-life, common mistakes, price reveal, packaging an order. Suit Nigerian viewers. Tell me which 3 to film first.

**Naija tip:** The **process video** is king for Nigerian makers — people are amazed to watch a sandal, a cake, or a gown come to life, and it quietly kills the "is it original / is it really handmade?" objection. Film in natural daylight, hold the phone steady, and add trending Nigerian audio (Afrobeats, a viral skit sound). Post 3–4 times a week for 8 weeks before you judge results. Consistency beats quality at the start.

---

## Prompt 2.12

### Title: Write Festive and Seasonal Campaigns (Christmas, Sallah, Easter, Back-to-School, Valentine's)

**Use this when:** A season or festival is coming and you want a plan — not just a "Happy Sallah" graphic on the day.

**Copy this prompt:**

> [Festival/season] is coming in [number] weeks. I run a [business type] in [area], Nigeria, selling [products/services]. Create a simple 3-week campaign plan for me. Include: (1) what to offer — a bundle, gift pack, pre-order, or special edition that fits this season and my products, (2) the pricing and any early-bird deal, (3) a week-by-week plan for WhatsApp Status and broadcasts with sample captions, (4) how to handle the rush — order cut-off date, deposits, delivery planning, (5) a message for after the festival to thank buyers and keep them coming back. Consider Nigerian realities like travel, salary timing, and price increases in the market.

**Real example (filled in):**

> Christmas is coming in 5 weeks. I run a small frozen foods and grocery shop in Warri, selling chicken, turkey, fish, rice, oil, and drinks. Create a 3-week campaign plan. Include: (1) what to offer — hampers, bulk deals, or pre-order packs for families, (2) pricing and early-bird deal, (3) week-by-week plan for WhatsApp Status and broadcasts with captions, (4) how to handle the rush — cut-off dates, deposits, delivery, (5) a thank-you message for after Christmas. Consider people travelling to villages, salary and bonus timing, and market prices going up in December.

**Naija tip:** In Nigeria, the money for December is spent between the **20th and 24th**; for Sallah, in the 5 days before. Start marketing **3 weeks early** and collect deposits — it protects you from price spikes in the market (buy your stock at today's price with their money) and locks the customer in before your competitor's post appears. And "pre-order to secure your turkey" sells better than "turkey available."

---

## Prompt 2.13

### Title: Reply to Comments and DMs in a Way That Converts

**Use this when:** People comment "how much?", "DM price", "still available?", or "is it original?" and your replies aren't leading to sales.

**Copy this prompt:**

> I sell [product/service] in Nigeria. Give me smart, friendly replies to these common comments and DMs that lead toward a sale instead of ending the conversation: (1) "How much?" (2) "Send price." (3) "Is it original?" (4) "Still available?" (5) "Location?" (6) "Do you deliver to [far city]?" (7) "Last price?" (8) "I'll get back to you." (9) "Do you have it in another colour/size?" (10) "Can I pay on delivery?" Each reply should be 1–3 sentences, answer the question, and include a next step or question that keeps them engaged. Sound like a real, warm Nigerian seller — not a robot or a hype man.

**Real example (filled in):**

> I sell affordable men's native wear (senator, kaftan, agbada) in Kaduna, ₦15,000–₦60,000, and deliver nationwide through GIG and dispatch riders. Give me smart, friendly replies to: "How much?", "Send price", "Is it original fabric?", "Still available?", "Location?", "Do you deliver to Lagos?", "Last price?", "I'll get back to you", "Do you have it in another colour/size?", and "Can I pay on delivery?" Each 1–3 sentences, answers the question, and includes a next step. Warm Nigerian seller tone, not a robot or hype man.

**Naija tip:** Never reply "DM for price" publicly — it annoys Nigerians and looks like you're hiding something. State the price and immediately add a question: "₦18,000 with free delivery in Kaduna. Which colour do you like — navy or wine?" The question moves them from spectator to participant. For "pay on delivery," have a clear policy (e.g., "POD within Kaduna only; outside Kaduna, ₦2,000 commitment fee") and state it kindly — it filters out unserious buyers.

---

## Prompt 2.14

### Title: Partner With Other Local Businesses (Cross-Promotion)

**Use this when:** You want to reach new customers through businesses that serve the same people but don't compete with you.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, serving [customer type]. Suggest 8 types of local businesses that serve the same customers but don't compete with me, and for each, one specific partnership idea — such as flyer exchange, a joint bundle, referral commission, sharing each other's Status, or a small event. Then write me: (1) a short, respectful WhatsApp or in-person opening line to approach a business owner about partnering, (2) a simple description of the deal that makes it clearly fair for both sides, and (3) how to test the partnership for 30 days and measure if it's working. Keep everything low-cost and simple enough to manage on WhatsApp.

**Real example (filled in):**

> I run a children's clothing and school-uniform shop in Ikeja, Lagos, serving parents of kids aged 2–14. Suggest 8 types of local businesses that serve the same parents but don't compete with me — e.g., crèches, children's barbers, paediatric clinics, party planners — with one specific partnership idea each. Then write: (1) a respectful opening line to approach the owner, (2) a simple, fair deal description, and (3) how to test it for 30 days and measure results.

**Naija tip:** In Nigeria, partnerships work when they are **personal and small**. Don't propose a "strategic alliance" — propose "I'll keep your flyers at my counter and mention you to every parent; you do the same for me. Let's try it till end of month." Bring something when you go — a small gift or a sample. Relationship first, business second. The crèche owner who likes you will send you 20 parents in one term.

---

## Prompt 2.15

### Title: Market Your Business Through Church, Mosque and Community Groups (Respectfully)

**Use this when:** You belong to a church, mosque, estate association, alumni group, or trade union, and you want to promote your business without being the annoying person who spams the group.

**Copy this prompt:**

> I run a [business type] in Nigeria and I'm a member of [type of community: church, mosque, estate WhatsApp group, alumni group, professional association, women's fellowship, etc.]. I want to grow my business through this community without offending anyone or seeming like I only came to sell. Give me: (1) 5 respectful, low-key ways to make my business known within the community, (2) how often I should mention my business in the group chat, and what kind of messages are acceptable, (3) a short introduction message for the group that presents my business humbly and offers members something special, (4) how to serve community members so well that they become my sales team, and (5) mistakes that make people mute or resent business owners in such groups.

**Real example (filled in):**

> I run a small travel and visa consultancy in Lagos and I'm an active member of my church's young adults' fellowship (about 300 members, active WhatsApp group) and my estate's residents' group. I want to grow through these communities without being annoying. Give me: (1) 5 respectful ways to make my business known, (2) how often to mention it and what messages are acceptable, (3) a humble introduction message with a special offer for members, (4) how to serve members so well they become my sales team, and (5) mistakes that make people mute or resent business owners in such groups.

**Naija tip:** The rule is **serve first, sell rarely**. Answer questions in the group generously, for free, without pitching. When someone asks "does anyone know a good travel agent?" — let another member recommend you. That happens when you have been quietly helpful for weeks. Post your business once a month at most in general groups, and always with a members-only benefit. Never send private DMs to group members who haven't spoken to you — that's the fastest way to get reported to the admin.

---

## Prompt 2.16

### Title: Run a Small, Smart Giveaway or Promo That Brings Real Customers

**Use this when:** You want to run a giveaway or promotion but you've seen others attract only freebie-hunters who never buy.

**Copy this prompt:**

> I run a [business type] in Nigeria selling [products] at around ₦[price range]. I want to run a giveaway or promotion with a budget of no more than ₦[amount] that attracts people who are likely to become paying customers — not just freebie-hunters. Design it for me: (1) what to give away (something only a real potential customer would want), (2) the entry rule that gets me something useful — a saved contact, a referral, a testimonial, a small purchase, or a question answered, (3) the announcement message and the winner announcement message, (4) how long it should run, and (5) how to follow up with everyone who entered but didn't win, to turn them into customers. Make it simple to run on WhatsApp alone.

**Real example (filled in):**

> I run a small perfume and body-mist business in Ibadan, products ₦4,000–₦18,000. I want to run a giveaway with a budget of no more than ₦20,000 that attracts real potential customers. Design it: (1) what to give away, (2) an entry rule that gets me something useful — saved contacts, referrals, testimonials, or a small purchase, (3) announcement and winner-announcement messages, (4) how long it runs, and (5) how to follow up with everyone who didn't win. Simple to run on WhatsApp alone.

**Naija tip:** The smartest Nigerian giveaway entry rule is **"buy anything, even ₦1,000, to enter"** or **"send me the name of someone who'd love this, and I'll message them with your greeting."** Both filter out professional freebie-hunters. And the real prize of a giveaway is not the winner — it's the **50 people who now have your number saved and just got a "sorry you didn't win, here's ₦1,000 off this week" message**. That is where the sales are.

---

## Prompt 2.17

### Title: Turn One-Time Buyers Into Repeat Customers

**Use this when:** People buy once and vanish. You're spending all your energy finding new customers instead of keeping the ones you have.

**Copy this prompt:**

> I run a [business type] in Nigeria. Customers typically buy [product/service] and then I don't hear from them for [how long / never]. The natural repeat cycle for my product is roughly [every week / month / 3 months / occasion-based]. Design a simple repeat-customer system I can run on WhatsApp: (1) what to say and do right after the first purchase to set up the next one, (2) a reminder message timed to when they'd naturally need me again, (3) a small loyalty reward after 3 or 5 purchases that doesn't kill my margin, (4) a "we miss you" message for customers who haven't bought in a long time, and (5) how to keep track of all this using only WhatsApp labels, a notebook, or a simple phone spreadsheet.

**Real example (filled in):**

> I run a barbing salon in Surulere, Lagos. Customers get a cut (₦2,500–₦5,000) and many don't return regularly — some come back in 2 weeks, some disappear for months, some go to whichever barber is nearest. Natural repeat cycle is 2–3 weeks. Design a repeat-customer system on WhatsApp: (1) what to say and do right after the cut, (2) a reminder timed for 2–3 weeks later, (3) a loyalty reward after 5 cuts, (4) a "we miss you" message for those gone 2+ months, and (5) how to track it simply.

**Naija tip:** It costs 5–7 times more to get a new customer than to keep one — and in Nigeria, where trust is slow to build, a customer who has already paid you once is gold. The simplest loyalty tool is still the **paper card with 5 boxes** ("5th cut free" / "5th order gets free delivery"). It works because Nigerians love a visible progress and a promised reward. Combine it with a WhatsApp reminder, and you have a system.

---

## Prompt 2.18

### Title: Write an Ad Script for Radio or a Voice Note Advert

**Use this when:** You want to advertise on local radio (still powerful in many Nigerian towns), or create a short voice note/audio advert to send on WhatsApp or play in your shop.

**Copy this prompt:**

> Write me a [30 / 45 / 60]-second [radio / voice note] advert script for my [business type] in [area], Nigeria. We sell [products/services] to [audience]. Key things to mention: [main benefit, one offer, phone number, location or delivery area]. The script should: start with a hook that grabs attention in the first 5 seconds, sound like a real conversation or a relatable situation, be in simple Nigerian English (a little Pidgin is fine if it fits), repeat the phone number twice, and end with a clear call to action. Give me 2 versions: one with a single speaker, and one as a short dialogue between two people. Mark where a jingle or sound effect could go.

**Real example (filled in):**

> Write me a 45-second radio advert script for my agro-input shop in Makurdi, Benue State. We sell improved seeds, fertiliser, herbicides, and knapsack sprayers to farmers. Key things: original products only (no fake fertiliser), fair prices, free advice on which seed suits which soil, phone 0902 190 6332, located opposite Wurukum Market. Hook in first 5 seconds, relatable situation, simple Nigerian English with a little Pidgin, phone number twice, clear call to action. Two versions: single speaker and a short dialogue. Mark jingle/sound effect spots.

**Naija tip:** Local radio in towns like Makurdi, Ilorin, Sokoto, or Owerri can cost as little as ₦3,000–₦15,000 per slot and reaches people who are never on Instagram. Ask the station for their **early morning (6–8am) and evening (5–7pm) local-language slots** — those are when traders and farmers listen. Better still, record the script as a **WhatsApp voice note** first (free), send it to 50 customers, and see who responds before paying the radio station.

---

## Prompt 2.19

### Title: Create a Simple Monthly Marketing Plan You'll Actually Follow

**Use this when:** You do marketing "when you remember" and want a simple, realistic routine that fits around running the business.

**Copy this prompt:**

> I run a [business type] in Nigeria. I have about [number] hours per week for marketing and a monthly budget of ₦[amount, or 0]. My main channels are [WhatsApp Status, broadcasts, Instagram, referrals, community groups — pick yours]. Create a simple monthly marketing plan I can realistically follow. Include: (1) a daily 15-minute routine, (2) a weekly 1-hour task, (3) two monthly activities (like a promo, a partnership, or a testimonial round-up), (4) what to track each week to know if it's working — using numbers I can count myself, such as new contacts saved, replies, orders, referrals, and (5) a simple rule for what to do if a month's results are poor. Make it fit a busy person who also serves customers all day.

**Real example (filled in):**

> I run a small pharmacy/patent medicine store in Nsukka. I have about 4 hours per week for marketing and a budget of ₦10,000 monthly. Main channels: WhatsApp Status, broadcasts to labelled customers, and my church women's group. Create a simple monthly marketing plan: (1) daily 15-minute routine, (2) weekly 1-hour task, (3) two monthly activities, (4) what to track each week using numbers I can count myself, and (5) a rule for what to do if results are poor. Fit a busy person serving customers all day.

**Naija tip:** Marketing that fits in 15 minutes a day gets done. Marketing that needs a "free afternoon" never happens in Nigeria. The 15-minute routine: post 2 Statuses, reply to every pending message, send 3 follow-ups or thank-yous, save 2 new numbers with proper names. That's it. Do it while your food is warming or in the quiet hour after lunch. Track one number above all: **how many new people messaged you this week**. If it's going up, keep going.

---

## Prompt 2.20

### Title: Review Your Marketing Honestly and Fix What's Not Working

**Use this when:** You've been marketing for a month or more and want to know what to keep, what to change, and what to stop — based on evidence, not feelings.

**Copy this prompt:**

> Here is a summary of my marketing for the past [30 / 60 / 90] days for my [business type] in Nigeria: [what you did — channels, how often, any promos]. Here are the results I can count: [new contacts, enquiries/replies, orders, revenue, referrals, testimonials collected, money spent]. Here is what felt like it worked and what felt like a waste: [your honest impressions]. Analyse this like an experienced marketing adviser who understands Nigerian small businesses. Tell me: (1) what is clearly working and should get more of my time, (2) what is clearly not working and should stop, (3) what I can't judge yet and should test properly, (4) the one change most likely to increase enquiries next month, and (5) a simpler plan for the next 30 days based on all of this.

**Real example (filled in):**

> Summary of my marketing for the past 60 days for my small furniture-making workshop in Nnewi: posted on WhatsApp Status almost daily (about 45 days), sent 4 broadcasts, posted on Instagram 8 times, printed 300 flyers and shared at two estates, asked 6 customers for referrals. Results: 38 new contacts saved, 22 enquiries, 7 orders worth ₦1.1M total, 3 referrals, 4 testimonials, ₦18,000 spent (flyers + data). Felt like: Status got most enquiries; flyers got 1 call; Instagram got likes but no orders; referrals brought the two biggest orders. Analyse this as an experienced marketing adviser. Tell me: (1) what's working, (2) what to stop, (3) what to test properly, (4) the one change most likely to increase enquiries next month, and (5) a simpler 30-day plan.

**Naija tip:** Most Nigerian small businesses discover the same thing when they finally count: **80% of orders come from 20% of the marketing effort** — usually WhatsApp Status plus referrals. Doing this review once a month gives you permission to stop the things that only feel productive (endless Instagram posting, flyers nobody reads) and double down on what pays. Write the numbers in the Bonus tracker at the back of this book. What you count, you improve.

---

## Part 2 Checkpoint

Before moving to Part 3, make sure you have **done** (not just read) these five things:

1. Your WhatsApp Business profile is complete — About, description, catalogue, greeting message. *(Prompt 2.1)*
2. You have at least 14 days of Status content planned and are posting daily. *(Prompt 2.2)*
3. You have a folder of at least 5 real testimonials or screenshots. *(Prompt 2.7)*
4. Your referral offer exists and at least 10 customers know about it. *(Prompt 2.8)*
5. Your 3-message follow-up sequence is saved and you've sent it to everyone who "went quiet" this month. *(Prompt 2.9)*

If those five are in place, enquiries will rise. The next challenge is turning enquiries into money — handling "last price?", "I'll come back", and "it's too expensive" without losing the sale or your profit.

**Next: Part 3 — Sales, Negotiation & Closing More Deals (Prompts 3.1 – 3.20)**


<div class='pb'></div>

# PART 3: SALES, NEGOTIATION & CLOSING MORE DEALS
*(Prompts 3.1 – 3.20)*

---

## Where the Money Actually Leaks

Part 1 taught you who your customer is. Part 2 brought them to your WhatsApp. Now comes the moment most Nigerian businesses quietly lose money: the conversation between "how much?" and "I've paid."

Think about last week. How many people asked for price and went silent? How many said "last price?" and you dropped ₦1,000 too fast? How many said "I'll come back" and never did? How many bought one item when they would happily have bought two, if only you had asked?

That gap — between enquiry and payment — is where your ₦1.5M–₦3M is hiding. You do not need more customers to find it. You need to **convert more of the ones you already have, at a price that protects your profit.**

Selling well in Nigeria has its own rules:

- **Haggling is culture, not insult.** The customer expects a dance. You must know your floor before the music starts.
- **Trust closes more sales than discounts.** "Is it original?" is the real question behind most objections.
- **Relationship beats transaction.** The seller who remembers your name and your child's school sells to you for ten years.
- **Silence is not "no".** It is usually "not yet" — salary, spouse, or a competitor's price.

In this Part, AI becomes your sales coach. It will write your scripts, prepare your answers, rehearse difficult customers with you, and help you set a negotiation floor that keeps you profitable.

**Start with 3.1, 3.3 and 3.6** — your core script, the "last price" strategy, and the trust-builders. Then use the rest as situations arise.

---

## Prompt 3.1

### Title: Write Your Core Sales Conversation Script (WhatsApp and In Person)

**Use this when:** Every sales conversation feels improvised, or you and your staff answer the same enquiry in five different ways.

**Copy this prompt:**

> I sell [product/service] in [area], Nigeria, at ₦[price/range]. My customers are [describe]. What makes me different: [your edge]. Write me a natural, step-by-step sales conversation script for when someone enquires — one version for WhatsApp chat and one for a face-to-face customer in my shop. Each script should: (1) open warmly and get their name, (2) ask 2–3 quick questions to understand what they actually need, (3) recommend the right option and explain the value before stating price, (4) state the price with confidence and one reason it's worth it, (5) handle the first objection, and (6) close by asking for the order or the next step. Keep it conversational — Nigerian English, short messages, no long paragraphs. Mark which lines to adapt.

**Real example (filled in):**

> I sell solar-powered rechargeable lanterns and small home solar kits in Minna, Niger State, ₦8,500–₦95,000. My customers are families in areas with poor electricity, small shop owners, and students. What makes me different: I test every unit before sale, offer a 6-month replacement warranty, and install the bigger kits myself. Write me a step-by-step sales conversation script — one for WhatsApp, one for face-to-face — that opens warmly, asks 2–3 questions to understand their need, recommends the right option and explains value before price, states price confidently, handles the first objection, and closes by asking for the order. Conversational Nigerian English, short messages.

**Naija tip:** The single most profitable line in the script is step 2: **ask questions before you quote.** "Is it for your shop or your house? How many hours of light do you need at night?" Two questions change you from a price-list into an adviser — and advisers get less haggling. Save the WhatsApp version as **Quick Replies** in WhatsApp Business (Business tools → Quick replies) so you and your staff send the same quality answer every time.

---

## Prompt 3.2

### Title: Handle "It's Too Expensive" Without Dropping Your Price

**Use this when:** "Ah, it's too much" or "e too cost" is the most common thing you hear, and your reflex is to discount immediately.

**Copy this prompt:**

> I sell [product/service] at ₦[price] in Nigeria. My cost is ₦[cost] so my margin is roughly [amount or %]. Customers often say "it's too expensive" or "e too cost." Give me 8 different ways to respond that protect my price, each 1–3 sentences: (1) reframing the price per day/week/use, (2) comparing to the cost of the problem or the cheaper alternative failing, (3) explaining what's included that others leave out, (4) offering a smaller option instead of a discount, (5) asking what budget they had in mind, (6) sharing a quick customer story, (7) acknowledging the price and standing firm politely, and (8) a payment-plan or deposit option. Then tell me which two to use first and when to simply let a customer go.

**Real example (filled in):**

> I sell quality school bags and lunch boxes in Ilorin — bags ₦12,000–₦18,000, my cost is about ₦8,000–₦11,000, so I make ₦4,000–₦7,000 per bag. Parents often say "ah, ₦15,000 for school bag? E too cost." Give me 8 different ways to respond that protect my price: reframing per term/per year, comparing to buying two cheap ₦6,000 bags that tear by second term, explaining the padded straps and waterproof base, offering a smaller size, asking their budget, a quick customer story, standing firm politely, and a deposit option. Then tell me which two to use first and when to let the customer go.

**Naija tip:** "E too cost" is often an **opening move**, not a verdict. Never answer it with a number — answer it with value, then silence. Let them speak next. And know your **walk-away price** before the conversation starts (see 3.3). Many Nigerian sellers lose 20–30% of their profit not to competition, but to their own panic in the first ten seconds after "e too cost."

---

## Prompt 3.3

### Title: Set Your Negotiation Floor and "Last Price" Strategy

**Use this when:** "Last price?" is a daily question, and you don't have a clear system — so you decide based on mood, and sometimes sell at a loss.

**Copy this prompt:**

> I run a [business type] in Nigeria. For my main products, here are the cost prices and my normal selling prices: [list 3–6 items with cost and selling price]. My monthly fixed costs (rent, generator, staff, transport, data) total about ₦[amount], and I sell roughly [number] items per month. Help me build a simple negotiation system: (1) calculate the true minimum price per item that still covers my share of fixed costs and leaves at least [X]% profit, (2) set three price levels for each item — opening price, "good customer" price, and absolute floor, (3) tell me what to ask for in exchange for any discount (buy two, pay now, refer a friend, collect a testimonial, pay cash), (4) give me 5 natural ways to say "this is my last price" that sound firm but friendly, and (5) a rule for when I should walk away from a sale.

**Real example (filled in):**

> I run a small phone and accessories shop in Onitsha. Main items — Type-C charger: cost ₦2,200, sell ₦3,500; power bank 20,000mAh: cost ₦11,000, sell ₦16,000; earpiece: cost ₦1,500, sell ₦2,500; tempered glass: cost ₦400, sell ₦1,000; phone case: cost ₦1,200, sell ₦2,500. Monthly fixed costs are about ₦180,000 and I sell roughly 400 items a month. Help me build a negotiation system: true minimum price per item that covers fixed costs plus at least 15% profit, three price levels per item (opening, good-customer, floor), what to ask for in exchange for any discount, 5 friendly ways to say "this is my last price," and a walk-away rule.

**Naija tip:** Write the floor prices on a small card taped under your counter or saved in your phone notes. When a customer pushes, you glance, you know, you stop shaking. And adopt the golden Naija rule: **never give a discount for free.** "Okay, I'll do ₦15,000 — but you'll take the case with it" or "…but you'll send me one customer this week." The discount then becomes a sale, not a loss.

---

## Prompt 3.4

### Title: Turn "I'll Come Back" and "Let Me Think About It" Into a Sale

**Use this when:** Customers leave with a polite promise and rarely return.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price]. Customers frequently say "I'll come back," "let me think about it," "let me ask my husband/wife," or "I'll call you." Help me handle this properly. Give me: (1) three gentle questions to ask at that moment to uncover the real hesitation (money, trust, need, permission, comparison), (2) what to say for each of those real reasons, (3) a respectful way to create a reason to decide today — without fake pressure, (4) what to do before they leave so I can follow up (get their number, send them something), and (5) a 3-step follow-up plan over the next 7 days. Keep the tone warm and relaxed — Nigerian customers dislike pushy sellers.

**Real example (filled in):**

> I sell made-to-measure men's suits and native wear in Abuja, ₦45,000–₦150,000. Customers come, get measured or look at fabrics, then say "let me think about it" or "I'll discuss with my wife." Help me handle this properly: three gentle questions to uncover the real hesitation, what to say for each real reason, a respectful way to create a reason to decide today (for example, tailoring slots for the wedding season), what to do before they leave so I can follow up, and a 3-step follow-up plan over 7 days. Warm and relaxed tone.

**Naija tip:** "Let me ask my husband/wife" is a real reason in Nigeria — respect it and **arm them for that conversation**: "No problem, ma. Let me send you the photo and a short note on why this fabric lasts, so you can show him." You just turned your customer into your salesperson. And always get the number *before* they leave: "Let me send you the picture on WhatsApp so you have it" is the easiest way to ask.

---

## Prompt 3.5

### Title: Reply to Price Enquiries on WhatsApp So People Actually Buy

**Use this when:** You reply "₦15,000" to "how much?" and the chat dies. Every day.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price]. When people message "how much?" or "price?", I reply with the price and they usually go quiet. Write me 5 better reply templates (each under 60 words) that: state the price clearly, add one line of value or reassurance, and end with a question or next step that keeps the chat alive. Include versions for: (1) a single product, (2) a product with options/sizes, (3) a service that needs details before quoting, (4) an item currently on offer, and (5) a customer who has enquired before. Then give me 3 follow-up lines if they read it and don't reply within 24 hours.

**Real example (filled in):**

> I sell customised cakes in Lagos Island — ₦15,000 for 8 inches, ₦25,000 for 10 inches, more for tiers or fondant. When people message "how much for cake?" I reply with the price and they go quiet. Write me 5 better reply templates under 60 words: single product, product with sizes, a service that needs details first (event date, design, servings), an item on offer, and a returning enquirer. Each states price, adds one line of value or reassurance, and ends with a question or next step. Then 3 follow-up lines for when they read and don't reply within 24 hours.

**Naija tip:** Never let your price be the last word in a message. Price, then value, then a **question that's easy to answer**: "₦15,000 for 8 inches, feeds about 15 people — and I deliver on the day so it arrives fresh. What date is the celebration?" A question about *their* event pulls them into planning with you, and people rarely abandon a plan they've started.

---

## Prompt 3.6

### Title: Build Trust Fast With a Stranger ("Is It Original? Are You Real?")

**Use this when:** New customers — especially online — hesitate because they don't know you, fear fakes, or fear being scammed.

**Copy this prompt:**

> I sell [product/service] in Nigeria, mostly to people who find me online and have never met me. They often worry: is it original, is this person real, what if I pay and nothing arrives, what if it spoils. Give me: (1) a list of 10 trust signals I can put in place this week at little or no cost (for example, real photos, video proof, a business name, a physical address, policies, reviews), (2) the exact words to reassure a hesitant customer at the moment of doubt, in 3 short versions, (3) a simple, fair policy on payment before delivery vs. pay on delivery that protects both me and the customer, and (4) how to handle a customer who says "I've been scammed before" — turning it into a reason to trust me.

**Real example (filled in):**

> I sell original perfumes and designer body sprays online from Lagos, ₦18,000–₦85,000, delivering nationwide. Customers who find me on Instagram and WhatsApp worry: is it original, is this person real, what if I pay and nothing arrives. Give me: 10 trust signals I can set up this week cheaply, the exact words to reassure a hesitant customer in 3 short versions, a fair payment-before-delivery vs. pay-on-delivery policy that protects both sides, and how to handle "I've been scammed before."

**Naija tip:** The fastest trust-builders in Nigeria: **a short video of you holding the actual item, showing the batch code**, a **registered business name** (CAC registration is now affordable and can be done online), a **business bank account in that name** (customers notice when the account name matches), and **screenshots of delivery confirmations** from other cities. Have a "Proof" folder ready to forward in one tap.

---

## Prompt 3.7

### Title: Upsell and Cross-Sell Without Sounding Greedy

**Use this when:** Customers buy one item and you never suggest anything else — leaving 20–40% extra revenue on the table.

**Copy this prompt:**

> I run a [business type] in Nigeria. Here are my products/services and prices: [list]. For each of my main items, suggest: (1) one natural "goes with it" add-on I should offer (cross-sell), (2) one "better version" I could suggest (upsell), and (3) the exact one-sentence line to suggest it in a helpful, not pushy, way — at the right moment (after they've decided, not before). Then design two simple bundles that increase the average sale while giving the customer a real saving, and write the line for offering the bundle. Finally, tell me the one mistake to avoid when upselling to Nigerian customers.

**Real example (filled in):**

> I run a small barbing and grooming shop in Enugu. Services and prices: haircut ₦2,500; haircut + beard shaping ₦3,500; hair dye ₦4,000; facial scrub ₦3,000; home service ₦6,000. Products: beard oil ₦3,500, hair sponge ₦1,500, aftershave ₦2,500, durag ₦2,000. For each main service, suggest one natural add-on, one better version, and the exact helpful one-sentence line to suggest it at the right moment. Design two bundles that increase the average sale with a real saving, and write the offer line. Tell me the one mistake to avoid when upselling to Nigerian customers.

**Naija tip:** Upsell **after the yes**, never before. Once the customer has committed to the haircut, "Should I shape the beard too? Just ₦1,000 extra today" feels like service, not pressure. And use the **"most people" line**: "Most people who buy this power bank take the fast-charge cable too — you want it?" Nigerians are comforted by what others do. Aim to add ₦500–₦2,000 to every third sale; over a month, that's rent.

---

## Prompt 3.8

### Title: Recover Abandoned Orders and Unpaid Invoices Politely

**Use this when:** Someone agreed to buy, you sent account details, and… nothing. Or a customer owes you and you're afraid to sound rude.

**Copy this prompt:**

> I run a [business type] in Nigeria. Two situations keep happening: (A) a customer says "send account details," I send them, and they never pay; (B) a customer collected goods or a service on credit and is late paying ₦[amount]. Write me: for (A), a 3-message sequence over 5 days — friendly reminder, value/scarcity nudge, final gentle close; for (B), a 4-message sequence over 3 weeks that gets firmer each time but stays respectful — including what to say on a phone call and when to stop selling to them. Each message under 60 words. Also give me a policy statement I can post or send to prevent both problems in future.

**Real example (filled in):**

> I run a small building materials shop in Ibadan — cement, rods, tiles, paint. Situation A: contractors say "send account," I send, and no payment comes. Situation B: a regular contractor collected ₦240,000 worth of cement on credit 3 weeks ago and has gone quiet. Write me a 3-message sequence over 5 days for A, and a 4-message sequence over 3 weeks for B that gets firmer but stays respectful, including a phone-call script and when to stop selling to him. Each message under 60 words. Plus a credit-and-payment policy statement I can send to customers to prevent this in future.

**Naija tip:** In Nigeria, debt messages work best when they **give the debtor a way to save face**: "Oga Musa, I know things are tight — can you send ₦100,000 today and the balance by Friday?" A part-payment plan recovers far more than an ultimatum. And write your credit policy *now*, while you're not angry: "Credit only for customers with 3+ paid orders, maximum ₦50,000, 7 days." Post it. Then it's the policy saying no, not you.

---

## Prompt 3.9

### Title: Handle the 12 Most Common Objections in Your Business

**Use this when:** You want to be ready for every "but…" a customer might raise, so nothing catches you off guard.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price] to [customer type]. List the 12 most common objections customers in my business are likely to raise — price, trust, timing, quality, comparison, delivery, warranty, "let me ask someone," "I saw it cheaper," and any specific to my product. For each objection: (1) what the customer is really thinking, (2) a short, natural response that acknowledges their concern first, then answers it, and (3) a question to ask afterwards to move the conversation forward. Format it as a table I can print and keep by my phone: Objection | What they really mean | My response | My follow-up question.

**Real example (filled in):**

> I sell inverter batteries and installation in Port Harcourt, ₦180,000–₦650,000 for complete setups, to households and small offices. List the 12 most common objections — price, trust, timing, quality/fake batteries, "my neighbour's inverter spoiled quickly," comparing to generator cost, warranty, "let me ask my husband," "I saw it cheaper at Mile 1 market," installation fears, maintenance, and any others. For each: what they're really thinking, a short response that acknowledges then answers, and a follow-up question. Format as a printable table.

**Naija tip:** Print the table. Give a copy to every staff member. Rehearse it out loud — literally read the objection and answer it, until the answers come out naturally. Nigerian customers can smell hesitation; a seller who answers "what if it spoils?" instantly and calmly is believed. A seller who pauses is doubted, however honest they are.

---

## Prompt 3.10

### Title: Practise a Difficult Customer Conversation With AI (Role-Play)

**Use this when:** You have a tough conversation coming — a big client, a difficult negotiation, a complaint — and you want to rehearse before the real thing.

**Copy this prompt:**

> I want to practise a sales conversation. Play the role of a [type of customer — e.g., tough Nigerian market woman buying in bulk, a busy corporate buyer, a suspicious first-time online customer, an angry customer whose order was late]. I am a [your business] selling [product] at ₦[price]. Be realistic — haggle, doubt me, raise real objections, use natural Nigerian expressions, and don't make it easy. I will respond as myself. After every 3 exchanges, pause and give me brief feedback on what I did well and what I should change, then continue. At the end, give me a score out of 10 and the three biggest improvements I should make.

**Real example (filled in):**

> I want to practise a sales conversation. Play the role of a tough Igbo trader in Onitsha main market who wants to buy 50 pieces of my ladies' handbags for resale and is famous for negotiating hard. I sell handbags at ₦6,500 retail; my wholesale floor is ₦4,800 and my cost is ₦3,900. Be realistic — haggle, claim other suppliers are cheaper, ask for credit, use natural Nigerian expressions, and don't make it easy. I'll respond as myself. After every 3 exchanges, pause and give me feedback, then continue. At the end, score me out of 10 and give my three biggest improvements.

**Naija tip:** This is one of the most powerful uses of AI in this whole book and almost nobody does it. Ten minutes of role-play before a big negotiation is worth more than an hour of worrying. Do it in Meta AI on WhatsApp — it feels like chatting with a real person. Practise the customer you *fear* most. After three sessions, the real one will feel easy.

---

## Prompt 3.11

### Title: Write a Persuasive Quotation or Proposal for a Bigger Client

**Use this when:** A school, church, company, hotel, or government office asks for a quotation, and you want to look professional and win it.

**Copy this prompt:**

> A [type of organisation] in Nigeria has asked me for a quotation/proposal for [what they want]. My business is [type]. Details: [quantities, specifications, timeline, my prices, what's included, delivery, payment terms]. Write me a professional but simple one-page quotation/proposal that includes: a short introduction of my business and why we're reliable, a clear breakdown of items and prices in a table (with VAT note if applicable), what's included and not included, delivery/completion timeline, payment terms (deposit and balance), validity period of the quote, a warranty or guarantee line, and a polite closing that asks for the order. Also give me a short cover message for sending it by WhatsApp or email.

**Real example (filled in):**

> A private secondary school in Owerri has asked me for a quotation for 120 sets of school uniforms (shirts and trousers/skirts) plus 120 sports kits. My business is a tailoring and uniform production workshop. Details: uniforms ₦9,500 per set, sports kits ₦6,000 per set, fabric and embroidery of the school crest included, delivery in 4 weeks from deposit, 60% deposit and 40% on delivery, free size adjustments for 2 weeks after delivery. Write me a professional one-page quotation with an intro, price table, inclusions/exclusions, timeline, payment terms, 14-day validity, guarantee line, and a polite close. Plus a short cover message for WhatsApp/email.

**Naija tip:** Institutional buyers in Nigeria judge you on **presentation and reliability**, not just price. A clean PDF quotation with your business name, CAC number, address, and a validity date beats a WhatsApp voice note every time. Always include the validity period — prices move — and always ask for a deposit; institutions are notoriously slow to pay balances, and the deposit funds your materials. Convert the AI's text to PDF using your phone (Google Docs → Share → Save as PDF).

---

## Prompt 3.12

### Title: Sell to Bulk Buyers, Resellers and Wholesale Customers

**Use this when:** You want to move from selling one-by-one to selling in tens and hundreds to people who resell.

**Copy this prompt:**

> I sell [product] at ₦[retail price] with a cost of ₦[cost]. I want to attract bulk buyers and resellers in Nigeria. Help me: (1) design a wholesale price structure with 3 tiers (e.g., 10+, 50+, 100+ units) that stays profitable for me and attractive to resellers, (2) set minimum order rules and payment terms for wholesale, (3) write a short wholesale offer message I can send to potential resellers — market traders, Instagram vendors, shop owners — that shows them the profit they can make, (4) list where to find resellers in Nigeria for my kind of product, and (5) tell me how to protect my retail business from being undercut by my own resellers.

**Real example (filled in):**

> I produce liquid soap, bleach, and air freshener in Kaduna. Liquid soap 1 litre: retail ₦1,200, cost ₦550. Bleach 1 litre: retail ₦900, cost ₦400. I want to attract bulk buyers and resellers. Help me design a 3-tier wholesale price structure (12+, 50+, 100+ units) that stays profitable, set minimum order and payment rules, write a wholesale offer message that shows resellers the profit they can make, list where to find resellers for household products in Northern Nigeria, and tell me how to protect my retail price from being undercut.

**Naija tip:** Resellers in Nigeria care about one number: **"how much will I make per piece?"** Lead with it: "You buy at ₦750, sell at ₦1,200 — ₦450 profit per bottle, and my soap doesn't water down." Then protect yourself with a **recommended retail price** and a rule that resellers selling below it lose their wholesale rate. One serious reseller in a big market can outsell your shop; find three.

---

## Prompt 3.13

### Title: Close More Sales at the Point of Payment (Reduce Drop-Off at "Send Account Details")

**Use this when:** The customer says yes, you send your bank details, and a surprising number never complete payment.

**Copy this prompt:**

> I sell [product/service] in Nigeria. Many customers agree to buy, I send bank/transfer details, and then 30–40% never pay. Help me fix the payment moment. Tell me: (1) the likely reasons people drop off at this exact point, (2) how to word the payment message so it feels safe, clear and urgent — including what to put in it (account name matching business name, amount, what happens after payment, delivery time), (3) how to offer multiple payment options (transfer, POS, payment link, USSD, pay on delivery) without confusing people, (4) a message to send 2 hours later if payment hasn't arrived, and (5) a confirmation message after payment that makes them feel good about the decision and sets up the next purchase.

**Real example (filled in):**

> I sell fitness equipment and supplements in Lagos — dumbbells, resistance bands, whey protein, ₦8,000–₦120,000 — mostly to young professionals on Instagram and WhatsApp. Customers agree to buy, I send transfer details, and about a third never pay. Help me fix the payment moment: likely reasons for drop-off, how to word the payment message so it feels safe, clear and urgent, how to offer transfer, POS, payment link and pay on delivery without confusion, a 2-hour follow-up if no payment, and a post-payment confirmation that makes them feel good and sets up the next purchase.

**Naija tip:** Three things kill payment in Nigeria: **bank app network failure** ("I'll do it later" → forgets), **account name not matching** the business (fear), and **no deadline**. Fix all three: offer a Paystack or Flutterwave payment link *and* transfer details, make sure the account name matches your business name, and add a soft deadline — "I'll hold it for you till 6pm." Then confirm receipt fast, with warmth: "Received, thank you Tolu! Your order is being packed now." That message is the beginning of the next sale.

---

## Prompt 3.14

### Title: Write Sales Messages for Different Customer Moods and Situations

**Use this when:** You want ready-made messages for the recurring situations in your sales day — first-time buyer, returning customer, big spender, price-only shopper, someone referred by a friend.

**Copy this prompt:**

> I sell [product/service] in Nigeria. Write me short sales messages (each under 50 words) for these 8 situations: (1) a first-time customer who seems nervous, (2) a returning customer I haven't heard from in a while, (3) someone referred by an existing customer, (4) a customer who only ever asks about price and discounts, (5) a big spender who deserves VIP treatment, (6) a customer who complained last time but has come back, (7) someone who bought from a competitor and was disappointed, and (8) a customer buying a gift for someone else. Each message should match the mood, sound like a real Nigerian seller, and end with a clear next step.

**Real example (filled in):**

> I run a small jewellery and accessories business in Abuja — gold-plated sets, watches, and beads, ₦5,000–₦60,000. Write me short sales messages under 50 words for: a nervous first-time buyer, a returning customer I haven't heard from in months, someone referred by a friend, a price-and-discount-only shopper, a big spender who deserves VIP treatment, a customer who complained last time but came back, someone disappointed by a competitor's fake gold, and a man buying a gift for his wife. Match the mood, sound like a real Nigerian seller, end with a clear next step.

**Naija tip:** The referred customer is your **highest-converting lead** — treat them like royalty from the first line: "Ah, Ngozi's friend! You're welcome. Anyone Ngozi sends, I take special care of." You've just borrowed years of trust in one sentence. Save all 8 messages as Quick Replies; the seconds you save add up, and the consistency builds your reputation.

---

## Prompt 3.15

### Title: Sell a Service (Not a Product) Convincingly

**Use this when:** You sell something people can't touch before paying — tailoring, catering, cleaning, repairs, consulting, design, tutoring, event planning — and they hesitate because they can't see it yet.

**Copy this prompt:**

> I offer [service] in [area], Nigeria, at ₦[price/range]. Customers can't see the result before paying, so they hesitate. Help me sell this service better. Give me: (1) how to describe my service in terms of the outcome and relief the customer gets, not the tasks I do, (2) 5 forms of proof I can show before they pay — past work, process, guarantees, testimonials, a small paid trial, (3) how to structure my pricing so it feels safe — deposit, milestones, or satisfaction guarantee, (4) how to set clear expectations up front so there are no disputes later (what's included, timeline, revisions, what's extra), and (5) a short consultation script for the first conversation that positions me as the expert and ends in a booking.

**Real example (filled in):**

> I offer event planning and coordination in Benin City for weddings, birthdays and burials, ₦150,000–₦800,000 depending on scale. Customers hesitate because they can't see the result before paying. Help me sell better: describe the service as outcome and relief (not tasks), 5 forms of proof to show before payment, safe pricing structure with deposits and milestones, how to set clear expectations up front to avoid disputes, and a short first-consultation script that positions me as the expert and ends in a booking.

**Naija tip:** Service buyers in Nigeria are buying **peace of mind** and fear **disappearing acts**. Two things close them: a **process they can see** ("Here's exactly what happens from today to the event day, step by step") and **milestone payments** ("30% to start, 40% two weeks before, 30% on the day"). The milestone structure makes them feel in control — and it protects your cash flow.

---

## Prompt 3.16

### Title: Handle Haggling in a Physical Market or Shop (Face-to-Face)

**Use this when:** You sell in a market, roadside shop, or kiosk where haggling is intense and constant, and you want to keep both your customers and your margin.

**Copy this prompt:**

> I sell [product] from a [market stall / shop / kiosk] in [area], Nigeria. Face-to-face haggling is constant and intense. My prices: [items with cost and normal selling price]. Help me handle it like a master trader: (1) how to open the price conversation to leave room without looking dishonest, (2) 6 phrases in natural Nigerian English/Pidgin to hold my price with humour and warmth, (3) how to read whether a customer is a serious buyer or a time-waster, (4) the "give something small" technique — what to add instead of cutting price, (5) how to handle a customer who insults the product to lower the price, and (6) how to end a failed negotiation so they still come back another day.

**Real example (filled in):**

> I sell women's shoes and bags from a shop in Balogun Market, Lagos. Haggling is intense all day. Prices: flat sandals cost ₦3,500, sell ₦6,000; block heels cost ₦6,000, sell ₦10,000; handbags cost ₦5,500, sell ₦9,500. Help me handle it like a master trader: how to open the price conversation, 6 warm and funny phrases in Nigerian English/Pidgin to hold my price, how to tell a serious buyer from a time-waster, what to add instead of cutting price, how to handle a customer who insults the shoe to lower the price, and how to end a failed negotiation so they still come back.

**Naija tip:** The masters of Balogun, Ariaria, Kurmi and Wuse market all do the same three things: they **smile while saying no**, they **add instead of subtract** ("I no fit reduce, but I go give you this small purse join"), and they **never chase a leaving customer more than two steps**. If they come back — and they often do — the price is the price. Let the AI give you the words, but practise the smile in the mirror.

---

## Prompt 3.17

### Title: Create Urgency and Scarcity Honestly

**Use this when:** Customers like your product but keep postponing, and you want to give them a genuine reason to decide now — without lying.

**Copy this prompt:**

> I sell [product/service] in Nigeria. Customers often like it but delay buying. Give me 8 honest ways to create urgency or scarcity that are true for my business — such as limited stock, price increases coming (import/fuel costs), seasonal deadlines, production slots, delivery cut-offs, early-bird pricing, bonus for first buyers, or limited customisation slots. For each, write the exact 1–2 sentence message. Then tell me which fake-urgency tactics to avoid because Nigerian customers see through them and lose trust, and how to handle a customer who says "you said the price would go up last month and it didn't."

**Real example (filled in):**

> I sell imported children's toys and educational kits in Lagos, ₦4,000–₦45,000. Parents often like the items but delay buying. Give me 8 honest ways to create urgency that are true for my business — limited import quantities, customs and dollar-rate price changes, Christmas and birthday deadlines, delivery cut-off days, early-bird bundles. Write the exact message for each. Tell me which fake-urgency tactics to avoid, and how to answer a parent who says "you said the price would go up last month and it didn't."

**Naija tip:** In Nigeria right now, the most honest urgency is also the most powerful: **"This price is based on the stock I already bought. My next stock will cost more."** It's true, everyone knows why, and it respects the customer's intelligence. Never say "only 2 left" when there are 20 — Nigerians talk, and you only get caught once.

---

## Prompt 3.18

### Title: Handle a Complaint or Refund Request So the Customer Stays

**Use this when:** Something went wrong — late delivery, wrong item, damaged goods, poor service — and you want to fix it without losing the customer or your shirt.

**Copy this prompt:**

> I run a [business type] in Nigeria. A customer is complaining about [what went wrong] and is [angry / disappointed / asking for a refund / threatening to post about it]. The facts: [what actually happened, whose fault it was, what it would cost me to fix]. Help me respond. Give me: (1) a first message that calms them down and shows I take it seriously, without admitting fault I'm not sure of, (2) three fair resolution options — from cheapest for me to most generous — and when to use each, (3) how to deliver the resolution so they feel valued, (4) a follow-up message a week later to confirm they're happy, and (5) a simple refund and replacement policy I can publish so future complaints are easier to handle.

**Real example (filled in):**

> I run an online thrift (okrika) clothing business in Ibadan. A customer received a jacket that has a small stain I didn't notice, paid ₦9,500 including delivery, and is angry — she's threatening to post about it on Twitter. Facts: it was my mistake, a replacement jacket would cost me about ₦4,000, a refund would cost me ₦9,500 plus the return delivery. Help me respond: a first message that calms her and shows I take it seriously, three fair resolution options from cheapest to most generous, how to deliver the resolution so she feels valued, a follow-up a week later, and a refund/replacement policy I can publish.

**Naija tip:** A complaint handled brilliantly creates a **more loyal customer than one who never had a problem** — because now they have proof you're honest. Respond within one hour, apologise sincerely once (not ten times), fix it fast, and add something small ("I've added a free scarf for the inconvenience"). Then ask, gently, for a review after they're happy. Many of the best testimonials in Nigeria start with "I had an issue, but the way they handled it…"

---

## Prompt 3.19

### Title: Train Your Staff or Sales Assistant to Sell Like You

**Use this when:** You sell well, but your staff say "we don't have" and "the price is ₦5,000" and lose the customers you worked hard to bring in.

**Copy this prompt:**

> I run a [business type] in Nigeria with [number] staff who deal with customers. They currently [describe the problems — cold greetings, giving discounts too fast, not suggesting alternatives, not following up, rude on the phone]. Create a simple one-page sales guide for them with: (1) the 5 rules of serving customers in my shop, (2) the greeting and the closing line to use every time, (3) what to do when we don't have what the customer wants, (4) the discount rule — what they can and cannot offer without asking me, (5) how to handle an angry customer, and (6) a 10-minute daily role-play they can do with each other. Write it in very simple English a school-leaver can understand, and add a short quiz of 5 questions to test them.

**Real example (filled in):**

> I run a small pharmacy and provisions store in Ikorodu with 3 staff. Problems: they greet customers coldly or not at all, tell customers "we don't have" without offering alternatives, give discounts too quickly to avoid arguments, and are sometimes impatient with older customers. Create a one-page sales guide: 5 rules for serving customers, the greeting and closing line, what to do when we don't have an item, the discount rule (nothing above ₦200 without asking me), handling an angry customer, and a 10-minute daily role-play. Very simple English, plus a 5-question quiz.

**Naija tip:** Your staff sell the way they are treated. Train them, but also **pay a small commission** (even ₦50–₦100 per upsell or 1% of sales above a target). The moment your shop girl earns from suggesting the beard oil, she'll suggest it to everyone. Print the one-page guide, paste it in the back room, and do the 10-minute role-play every Monday morning. Consistency in a Nigerian shop is a competitive advantage because so few bother.

---

## Prompt 3.20

### Title: Review Your Sales Conversations and Find Your Leaks

**Use this when:** You want to know exactly where in your sales process customers are dropping off, and what to fix first.

**Copy this prompt:**

> Here are the numbers from my [business type] in Nigeria over the last [30] days: enquiries/first messages received: [number]; people who got a price: [number]; people who agreed to buy: [number]; people who actually paid: [number]; average sale: ₦[amount]; discounts given: roughly ₦[total]; repeat customers: [number]. Here are 3 real conversations that didn't end in a sale, copied here: [paste them, removing names]. Analyse this like an experienced sales coach. Tell me: (1) where the biggest drop-off is and what it's costing me in naira, (2) what I did wrong in the failed conversations — be specific and honest, (3) what I did right, (4) the two changes that would most increase my paid sales next month, and (5) a target for each stage of the funnel for next month.

**Real example (filled in):**

> Numbers from my online shoe business in Lagos over the last 30 days: enquiries: 140; people who got a price: 140; agreed to buy: 46; actually paid: 29; average sale ₦14,000; discounts given roughly ₦48,000 total; repeat customers: 6. Here are 3 real conversations that didn't end in a sale: [pasted]. Analyse this as an experienced sales coach. Tell me where the biggest drop-off is and what it costs me, what I did wrong in the failed chats, what I did right, the two changes that would most increase paid sales next month, and a target for each stage next month.

**Naija tip:** Most Nigerian business owners have never counted their funnel — and the first time they do, they find that **fixing the "agreed but didn't pay" step alone** adds 20–40% to revenue with zero extra marketing. Copy 3 failed chats into the AI every month; it will see patterns you're too close to notice. Track the numbers in the Daily Sales Record Sheet (Bonus 11). What you measure, you close.

---

## Part 3 Checkpoint

Before moving to Part 4, confirm these five are **done**:

1. You have a core sales script saved as Quick Replies, and your staff use it. *(3.1)*
2. You know the **floor price** of every major item, written down. *(3.3)*
3. Your "Proof" folder exists — real photos, videos, screenshots, CAC/business name. *(3.6)*
4. You have upsell lines and at least two bundles ready. *(3.7)*
5. You've counted your funnel for one month: enquiries → priced → agreed → paid. *(3.20)*

More enquiries are now becoming more paid orders — at better prices. Now the risk is that success eats you alive: long hours, staff issues, waste, and costs that quietly rise. Part 4 fixes that.

**Next: Part 4 — Operations, Automation & Cost Cutting (Prompts 4.1 – 4.20)**


<div class='pb'></div>

# PART 4: OPERATIONS, AUTOMATION & COST CUTTING
*(Prompts 4.1 – 4.20)*

---

## The Part Where You Stop Being the Business

There is a stage every Nigerian small business reaches: sales are coming in, but the owner is exhausted. You open the shop, reply the messages, chase the supplier, pay the generator man, argue with the POS network, train the new girl, count the money at night, and start again at 6am. The business is growing — but it is growing around *you*, and you cannot be everywhere.

Meanwhile, money leaks quietly: fuel that costs more every month, stock that expires, data that finishes too fast, staff who waste, rent that eats a third of your profit, small mistakes that cost big.

This Part has one goal: **cut at least 35% off your running costs and save 10+ hours a week** — without lowering quality or firing anyone unfairly. That 35% is not magic. It comes from:

- Writing down how things should be done, once, so you stop repeating yourself (SOPs)
- Letting WhatsApp Business and simple templates do your repetitive typing
- Attacking your five biggest expenses with a plan, not a sigh
- Tracking stock and cash so nothing "disappears"
- Building simple systems that work when you are not there

None of it needs a laptop or a consultant. It needs your phone, this Part, and one honest week of looking at your numbers.

**Start with 4.1, 4.5 and 4.9** — your expense audit, your first SOP, and your WhatsApp automation. Those three alone can recover the 35%.

---

## Prompt 4.1

### Title: Audit Your Expenses and Find the 35% You Can Cut

**Use this when:** You feel money is leaking but you cannot say exactly where. Do this first — everything else in this Part builds on it.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Here are my monthly expenses as best I know them: [list every one with amount — rent, generator fuel, electricity bill, staff salaries, transport/delivery, data/airtime, packaging, stock purchases, POS charges, bank charges, repairs, cleaning, security, levies/association dues, waste/spoilage, personal withdrawals, others]. My monthly revenue is roughly ₦[amount]. Analyse this like an experienced Nigerian business accountant. Tell me: (1) which expenses are unusually high for my type of business, (2) the 5 biggest opportunities to cut costs without hurting sales or quality, with an estimated naira saving for each, (3) which costs I should NOT cut because they drive revenue, (4) hidden costs I probably forgot to list, and (5) a 30-day cost-cutting plan in order of easiest and biggest first.

**Real example (filled in):**

> I run a small restaurant (buka) in Uyo. Monthly expenses: rent ₦45,000; generator fuel ₦95,000; electricity ₦12,000; 3 staff ₦105,000 total; foodstuff purchases ₦380,000; gas ₦38,000; packaging/takeaway packs ₦42,000; water ₦8,000; transport to market ₦24,000; data/airtime ₦9,000; POS charges about ₦6,000; waste (food that spoils or is left over) roughly ₦35,000; repairs ₦10,000; association dues ₦3,000; my own withdrawals ₦80,000. Revenue is roughly ₦950,000. Analyse this like an experienced Nigerian business accountant: what's unusually high, the 5 biggest cost-cutting opportunities with naira savings, what NOT to cut, hidden costs I forgot, and a 30-day plan.

**Naija tip:** Do this with **real numbers, not guesses** — spend one week writing down every kobo that leaves the business, including "small" things like ₦200 bike fares and the ₦500 you gave the LASTMA man. Most owners discover two shocks: their **generator costs more than their rent**, and their **personal withdrawals are not tracked at all**. Both are fixable. Do this audit every quarter; costs in Nigeria creep up while you're busy.

---

## Prompt 4.2

### Title: Cut Your Generator, Fuel and Power Costs

**Use this when:** Fuel and generator costs are eating your profit — which, for most Nigerian businesses today, they are.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. My power situation: NEPA/grid gives about [hours] per day; I run a [generator size] generator for about [hours] daily, costing roughly ₦[amount] per month in fuel plus ₦[amount] in servicing. The things I actually need power for are: [list — fridge/freezer, lights, fans, POS charging, clippers, blender, sewing machine, etc.]. Help me cut this cost by at least 30%. Tell me: (1) which of my power uses actually need the generator and which can run on smaller alternatives, (2) whether a solar/inverter setup makes sense for me and roughly what size and budget — with a payback calculation against my fuel spend, (3) 8 practical habits that reduce fuel use immediately, (4) how to schedule generator use around my busiest hours, and (5) any low-cost equipment swaps (e.g., LED bulbs, DC fans, energy-efficient fridge) worth considering.

**Real example (filled in):**

> I run a frozen foods shop in Abeokuta. NEPA gives about 6–8 hours a day, unpredictable. I run a 3.5kVA generator about 8 hours daily, costing about ₦110,000 monthly in fuel and ₦8,000 in servicing. I need power for: 2 chest freezers, 1 standing fridge, lights, a fan, and POS charging. Help me cut this cost by at least 30%: which uses need the generator versus alternatives, whether solar/inverter makes sense and what size/budget with payback against ₦110,000 monthly fuel, 8 habits that reduce fuel use immediately, how to schedule generator hours, and low-cost equipment swaps.

**Naija tip:** The freezer trick every frozen-foods seller should know: **a full freezer stays cold far longer than a half-empty one** — fill gaps with bottles of water, keep the lid shut, and you can run the generator in 2-hour blocks instead of continuously. Also ask the AI to do the **solar payback maths** with your real fuel figure: at ₦100,000+ per month in fuel, many setups pay for themselves in under 18 months. Treat *Check Before You Trust It* seriously here — get 2–3 real quotes from installers before spending.

---

## Prompt 4.3

### Title: Write a Standard Operating Procedure (SOP) for Any Task

**Use this when:** You keep explaining the same thing to staff, or things go wrong the moment you step out. This prompt lets you write your business down.

**Copy this prompt:**

> Write a simple Standard Operating Procedure (SOP) for [the task — e.g., opening the shop, taking a customer order, packaging a delivery, closing and cashing up, receiving stock from a supplier, handling a return]. My business is a [type] in Nigeria. Details of how I want it done: [describe your way, including any rules, tools, timings, or common mistakes]. Format the SOP as: purpose (1 line), who does it, when it happens, materials needed, numbered steps in very simple English (each step one action), common mistakes and how to avoid them, and what "done properly" looks like. Keep it to one page so it can be printed and pasted on the wall. Add 3 quick check questions I can ask staff to confirm they understand.

**Real example (filled in):**

> Write a simple SOP for closing the shop and cashing up at the end of the day. My business is a small supermarket in Enugu with 2 staff. How I want it done: count cash and compare with the sales record and POS printout, write any difference and the reason, put the cash in the safe, photograph the sales page and send it to me on WhatsApp, switch off the freezers' display lights but not the freezers, check the back door and windows, switch off the generator properly (let it cool first), lock up and send me a "closed" message with the time. Common mistakes: forgetting to record the POS total separately, leaving the fan on, not photographing the record. Format as a one-page SOP with numbered steps and 3 check questions.

**Naija tip:** Write an SOP for the **five tasks that annoy you most** to repeat — that's usually opening, closing, order-taking, delivery packing, and stock receiving. Print them, paste them where the task happens (closing SOP by the door, packing SOP by the packing table). A business with five one-page SOPs can survive the owner being away for a week. That's the beginning of freedom.

---

## Prompt 4.4

### Title: Design a Simple Stock Control System (Stop Things "Disappearing")

**Use this when:** You don't know exactly what you have, stock runs out unexpectedly, items expire, or you suspect stock is walking out the door.

**Copy this prompt:**

> I run a [business type] in Nigeria with about [number] different items in stock. Currently I track stock by [describe — memory, a notebook, nothing]. Problems: [running out of fast-sellers, over-stocking slow items, expiry/spoilage, suspected theft, not knowing profit per item]. Design me a simple stock control system I can run with a notebook or a free phone app (e.g., Google Sheets), including: (1) what to record for each item and how often to count, (2) a reorder rule — when and how much to reorder for fast, medium, and slow items, (3) how to spot theft or unexplained losses quickly, (4) how to handle items with expiry dates (first in, first out), (5) a 15-minute daily routine and a 1-hour weekly routine, and (6) a simple table layout I can copy into a notebook or spreadsheet.

**Real example (filled in):**

> I run a cosmetics and skincare shop in Aba with about 180 different items. Currently I track stock mostly from memory and a rough notebook. Problems: my fast-moving creams run out and customers leave; some expensive serums have expired unsold; I sometimes count and find fewer items than I expect; I don't really know which items make me the most profit. Design a simple stock control system I can run with a notebook or Google Sheets: what to record and how often to count, reorder rules for fast/medium/slow items, how to spot theft or losses quickly, first-in-first-out for expiry items, a 15-minute daily and 1-hour weekly routine, and a simple table layout.

**Naija tip:** Start with your **top 20 items by sales** — not all 180. Those 20 probably bring 70% of your money; control them first. Do a **surprise count** of 10 random items once a week; when staff know the count can come any day, "disappearance" drops dramatically. And put a small sticker with the arrival month on every expiry-sensitive item — the oldest goes to the front, always.

---

## Prompt 4.5

### Title: Automate Your WhatsApp Replies and Save Hours a Day

**Use this when:** You spend 2–4 hours daily typing the same answers — prices, location, delivery, opening hours, "is it available?"

**Copy this prompt:**

> I run a [business type] in Nigeria and I answer the same customer questions on WhatsApp all day. My details: [products/services and prices, location or delivery areas, opening hours, delivery fees and times, payment methods, return/refund policy, how to order]. Set up my WhatsApp Business automation for me: (1) a greeting message for new contacts, (2) an away message for after hours, (3) 12 Quick Replies with a short shortcut name for each (e.g., /price, /delivery, /location, /pay, /hours, /order, /thanks, /followup, /outofstock, /bulk, /return, /proof) and the full text, and (4) a suggested catalogue structure. Each reply should be warm, clear, under 60 words, and end with a next step. Also tell me which questions I should NOT automate and must answer personally.

**Real example (filled in):**

> I run a small bakery and small-chops business in Port Harcourt. Details: bread ₦1,200–₦1,800, meat pie ₦700, small chops tray ₦12,000–₦35,000, custom cakes from ₦18,000; I deliver within GRA, Rumuola, D-Line and Woji for ₦1,500–₦2,500, same day if ordered before 12 noon; open 7am–8pm Mon–Sat; payment by transfer or Paystack link; cakes need 48 hours' notice and 60% deposit; no refunds on custom cakes once baked. Set up my WhatsApp Business automation: greeting, away message, 12 Quick Replies with shortcuts and full text, and a catalogue structure. Tell me which questions I should not automate.

**Naija tip:** Quick Replies are free, live inside WhatsApp Business, and most Nigerian vendors have never opened the menu (Business tools → Quick replies). Type the shortcut, press send: 3 seconds instead of 90. With 100 messages a day, that's **over two hours saved daily**. But never automate the *human* moments — a complaint, a big order, a nervous first-timer. Those get your real voice, fast.

---

## Prompt 4.6

### Title: Create Professional Invoices, Receipts and Price Lists

**Use this when:** You send prices as random voice notes and blurry photos, and customers (especially corporate ones) don't take you seriously.

**Copy this prompt:**

> I run a [business type] in Nigeria. Business name: [name]. Contact: [phone/WhatsApp, address or delivery area]. Products/services and prices: [list]. Payment details: [bank/POS/payment link]. Create for me: (1) a clean price list layout I can type into Google Docs or Canva — grouped by category, with any bulk prices, delivery fees, and terms at the bottom, (2) an invoice template with all the fields a Nigerian customer or company would expect (invoice number, date, customer details, item table, subtotal, delivery, VAT line if applicable, total, payment details, due date, terms), (3) a simple receipt template, and (4) a short note on what makes an invoice look professional versus amateur, and how to number and file them so I can track who has paid.

**Real example (filled in):**

> I run a printing and branding business in Kaduna — flyers, banners, business cards, branded T-shirts and mugs. Business name: [my business name]. Contact: 0902 190 6332, delivery within Kaduna and by waybill nationwide. Prices: A5 flyers (100 pcs) ₦8,000; roll-up banner ₦35,000; business cards (100) ₦6,500; branded T-shirt ₦6,000 each (min 10); branded mug ₦3,500 (min 12). Payment by transfer or Paystack link; 70% deposit on order. Create a price list layout, an invoice template with all the fields a Nigerian company expects, a receipt template, and a note on professional vs. amateur invoices and how to number and file them.

**Naija tip:** A numbered invoice PDF with your business name and account details does three things at once: it makes companies pay faster, it makes tax and record-keeping possible, and it quietly says "this is a real business." Free tools: Google Docs (make a template, duplicate it each time), Canva, or the free invoicing feature in many Nigerian business banking apps (Moniepoint, Kuda Business, etc.). Number invoices by month — 2026-09-001 — so you can find anything in seconds.

---

## Prompt 4.7

### Title: Write Job Descriptions and Hire the Right Staff

**Use this when:** You need to hire a shop assistant, cook, tailor, rider, or apprentice — and your last hires didn't work out.

**Copy this prompt:**

> I need to hire a [role] for my [business type] in [area], Nigeria. Salary budget: ₦[amount] per month. The person will [main duties]. What went wrong with previous hires: [e.g., lateness, dishonesty, rude to customers, left after 2 months, couldn't use a phone/POS]. Help me hire better. Give me: (1) a clear, short job description I can post on WhatsApp Status, community groups, or tell people by word of mouth, (2) the 5 qualities that matter most for this role — and how to test for each in an interview, (3) 8 interview questions including 2 practical tests they must do on the spot, (4) red flags to watch for, (5) a simple 2-week trial arrangement and what to observe, and (6) a one-page agreement covering duties, salary, hours, conduct, and what leads to dismissal.

**Real example (filled in):**

> I need to hire a shop assistant for my boutique in Asaba. Salary budget: ₦45,000 per month. She will attend to customers, take payments by POS and transfer, post on WhatsApp Status, keep the shop tidy, and record sales in a notebook. Previous hires: one was frequently late, one was caught keeping change, one was rude to customers and left after 6 weeks. Help me hire better: a short job description to post, the 5 qualities that matter most and how to test each, 8 interview questions with 2 practical tests (e.g., handle a mock customer, count change correctly), red flags, a 2-week trial plan, and a one-page agreement.

**Naija tip:** **Test, don't ask.** Anybody can say they're honest and hardworking. Instead: give them ₦3,000 in mixed notes and ask them to make change for a ₦1,250 sale; hand them a phone and ask them to write a Status caption for a dress; play an annoying customer and watch their face. Fifteen minutes of practical testing tells you more than a certificate. Always take a guarantor's details and verify them by phone — it is normal in Nigeria and it protects you.

---

## Prompt 4.8

### Title: Train Staff Fast With a One-Week Onboarding Plan

**Use this when:** A new person has started, and you don't have time to stand beside them all day.

**Copy this prompt:**

> I've hired a new [role] for my [business type] in Nigeria. Create a 5-day onboarding plan that gets them working confidently by the end of week one. For each day: what to teach (in order of importance), how to teach it in under 30 minutes, a task they must do alone that day, and how I'll check it. Include: our products/services and prices, how we greet and serve customers, how we handle money and POS, our SOPs for [list your key tasks], what to do when they don't know something, our rules on phone use, punctuality and honesty, and how they'll be evaluated after 2 weeks. Write it so I can hand it to them as a checklist they tick off.

**Real example (filled in):**

> I've hired a new kitchen assistant/server for my small restaurant in Ilorin. Create a 5-day onboarding plan covering: our menu and prices, portion sizes and how we plate, how we greet and serve, hygiene rules (hand washing, hair covering, handling money then food), taking orders and using the POS, our opening and closing SOPs, what to do if a customer complains, phone use during work, punctuality, and how she'll be evaluated after 2 weeks. For each day: what to teach, how to teach it in under 30 minutes, a task she does alone, and how I check it. Write it as a checklist she can tick.

**Naija tip:** The first week decides whether a staff member becomes an asset or a headache. Most Nigerian owners "onboard" by shouting corrections for a month. Instead: **teach one thing, watch them do it, praise what's right, correct what's wrong — then move on**. Pair the new hire with your best staff for the week, and give that senior staff ₦2,000 extra for doing it well. Culture is taught, not hoped for.

---

## Prompt 4.9

### Title: Reduce Waste, Spoilage and Returns

**Use this when:** You throw away food, fabric, materials, or expired stock; or products come back damaged; and it's quietly costing you tens of thousands monthly.

**Copy this prompt:**

> I run a [business type] in Nigeria. Waste I currently experience: [describe — leftover food, spoiled perishables, off-cuts, expired products, damaged goods in delivery, printing errors, customer returns] costing me roughly ₦[amount] per month. How I currently buy and use materials: [describe quantities, frequency, storage]. Help me cut this waste by at least half. Tell me: (1) the root causes, (2) 8 practical changes in how I buy, store, prepare, or package, (3) how to turn some waste into a product or a sale (e.g., end-of-day discounts, smaller portions, off-cut products), (4) how to forecast daily or weekly demand better so I produce or buy closer to what sells, and (5) a simple waste log I can keep for 2 weeks to find the real numbers.

**Real example (filled in):**

> I run a fruit juice and smoothie stand in Lagos (Yaba). Waste: fruits that go bad before use, roughly 15–20% of what I buy; juice made in the morning that isn't sold by evening; cups and packaging spoiled by rain and rough storage. Roughly ₦45,000 per month lost. I buy fruits every 2 days at Mile 12, store them in baskets in the shop, and make juice in big batches each morning. Help me cut waste by at least half: root causes, 8 practical changes in buying, storing, preparing, and packaging, how to turn waste into sales (end-of-day deals, frozen smoothie packs, fruit cups), how to forecast demand day by day, and a 2-week waste log.

**Naija tip:** Every ₦1 of waste you cut is **pure profit** — you already paid for it. The two highest-return moves in food businesses: **make in smaller batches more often** instead of one big morning batch, and run a **"5pm special"** on WhatsApp Status for whatever is left (₦300 off — you still make more than throwing it away). For non-food businesses, most waste comes from **unclear order specifications** — fix the order form and returns drop.

---

## Prompt 4.10

### Title: Negotiate Better Prices With Your Suppliers

**Use this when:** You accept supplier prices as given, or you've never asked for better terms, credit, or delivery — and your margins are suffering.

**Copy this prompt:**

> I run a [business type] in Nigeria. My main suppliers and what I buy: [list suppliers, items, roughly how much I spend with each monthly, how long I've bought from them, how I pay]. Help me negotiate better. Tell me: (1) what I can realistically ask for — price reduction, bulk discount, credit terms, free delivery, better payment timing, returns on unsold stock, priority during scarcity, (2) how to prepare — what numbers to have ready and how to find out what others pay, (3) a respectful negotiation script for a face-to-face or WhatsApp conversation with a supplier I've used for a long time, (4) how to approach a new supplier to create healthy competition without burning the old relationship, and (5) the risks of pushing too hard in the Nigerian market and how to avoid them.

**Real example (filled in):**

> I run a small provisions and drinks shop in Kano. Main suppliers: a drinks distributor (₦280,000 monthly, 2 years, cash on delivery); a rice/grain wholesaler at Dawanau (₦150,000 monthly, 3 years, cash); a toiletries wholesaler in Sabon Gari (₦90,000 monthly, 1 year, cash). Help me negotiate better: what I can realistically ask for from each, how to prepare and find what others pay, a respectful script for the drinks distributor I've used for 2 years, how to approach a second drinks supplier without damaging the relationship, and the risks of pushing too hard.

**Naija tip:** Suppliers give better terms to customers who are **predictable and loyal** — pay on time, buy regularly, and tell them your growth plans. Then ask: "Oga, I've been buying ₦280k every month for two years without fail. What can you do for me on price or credit?" Most Nigerian owners never ask, and suppliers never volunteer. A 5% supplier discount on ₦500,000 monthly purchases is ₦300,000 a year — for one conversation.

---

## Prompt 4.11

### Title: Cut Delivery and Transport Costs

**Use this when:** Delivery fees, dispatch riders, waybills, or your own transport to market are eating your margin — or customers complain your delivery is too expensive.

**Copy this prompt:**

> I run a [business type] in [city], Nigeria. My delivery/transport situation: [how you deliver — own bike/car, dispatch riders, waybill/logistics companies, public transport to market; typical volumes per day/week; what it costs monthly; what you charge customers; common problems like late riders, damaged goods, failed deliveries]. Help me cut these costs and improve reliability. Tell me: (1) whether I'm under-charging customers for delivery and what a fair delivery fee structure looks like by zone, (2) how to batch and schedule deliveries to reduce trips, (3) how to negotiate a better arrangement with dispatch riders or logistics companies, (4) when it makes sense to get my own rider or bike versus outsourcing, with a simple cost comparison, and (5) how to reduce failed deliveries and damaged items.

**Real example (filled in):**

> I run an online fashion store in Lagos, shipping about 8–12 orders a day within Lagos and 10–15 a week to other states. I use different dispatch riders found on Instagram for Lagos (₦2,000–₦4,500 per trip, I charge customers ₦2,500 flat) and GIG/waybill for other states. Problems: riders arrive late or cancel, some customers don't pick calls and the rider returns, I lose money on far deliveries like Ikorodu and Badagry. Monthly delivery cost is roughly ₦380,000. Help me: fair zoned delivery fees for Lagos, how to batch deliveries by area and day, how to negotiate a fixed arrangement with 1–2 reliable riders, own rider vs. outsourcing cost comparison, and reducing failed deliveries.

**Naija tip:** Two changes fix most delivery problems in Lagos and Abuja: **zone-based pricing** (Island / Mainland / Outskirts — never one flat fee) and **"Tuesday & Friday for far zones"** batching. Add a rule that far deliveries are **paid before dispatch**, and failed-delivery losses nearly vanish. If you're sending 8+ packages a day, a fixed retainer with one reliable rider (₦60,000–₦90,000/month) usually beats per-trip pricing — do the maths with the AI.

---

## Prompt 4.12

### Title: Plan Your Week So the Business Doesn't Eat Your Life

**Use this when:** You work 14 hours a day and still feel behind; everything feels urgent; you have no time to think, market, or rest.

**Copy this prompt:**

> I run a [business type] in Nigeria, [alone / with X staff]. Here is what a typical day looks like for me: [describe from waking to sleeping, honestly]. My biggest time-wasters: [e.g., replying messages all day, going to market myself, chasing suppliers, fixing staff mistakes, NEPA/generator issues]. Things I never get time for: [marketing, records, planning, family, rest]. Design a realistic weekly schedule for me that: (1) groups similar tasks into blocks (messages, market runs, records, marketing), (2) identifies which tasks I should delegate or systemise, and to whom, (3) protects 1 hour a day for owner's work (planning, marketing, numbers), (4) includes fixed times for rest and family, and (5) gives me a 10-minute end-of-day routine. Then tell me the ONE change that would give me the most time back.

**Real example (filled in):**

> I run a tailoring and fashion design business in Owerri with 2 apprentices and 1 tailor. Typical day: wake 5:30, market for fabrics/threads 3 times a week, in the shop by 8, cutting and sewing all day while replying WhatsApp constantly, customers dropping by unannounced for measurements or corrections, generator wahala, home by 9pm, then replying messages till midnight. Time-wasters: constant interruptions, market trips, redoing apprentices' mistakes. Never get time for: posting on Status regularly, doing my accounts, resting on Sundays. Design a realistic weekly schedule with task blocks, what to delegate to whom, 1 hour daily for owner's work, fixed rest time, a 10-minute end-of-day routine, and the ONE change that gives me the most time back.

**Naija tip:** For most Nigerian owners, the one change is **fixed hours for WhatsApp** — three blocks a day (e.g., 8am, 1pm, 7pm), with an away message explaining it. Customers adjust within a week and actually respect you more. The second change: **appointment-only measurements/consultations** ("Tuesdays and Thursdays, 10am–2pm"). A business that runs on your rhythm, not everyone else's, is a business you can grow.

---

## Prompt 4.13

### Title: Build a Simple Daily Sales & Cash Record (That Staff Can Keep)

**Use this when:** You don't know your exact daily sales, cash doesn't match at the end of the day, or you can't tell how much profit you made last week.

**Copy this prompt:**

> I run a [business type] in Nigeria and I want a simple daily record that my staff (school-leaver level) can keep accurately. Design a one-page daily record sheet that captures: opening cash, each sale or a sales tally by product/category, payment type (cash / POS / transfer), expenses paid from the till with reason, closing cash, and a reconciliation line showing whether the cash matches. Then: (1) explain how to fill it in simple steps, (2) add a weekly summary sheet that totals sales, expenses, and gross profit, (3) suggest a 5-minute end-of-day check I do by looking at the sheet, and (4) show me how this could live in a free Google Sheet with columns and one or two simple formulas — or in a notebook if I prefer.

**Real example (filled in):**

> I run a small pharmacy in Nsukka with 2 staff. I want a one-page daily record they can keep accurately capturing opening cash, sales tallies by category (drugs, toiletries, baby products, drinks), payment type (cash / POS / transfer), expenses paid from the till with reason, closing cash, and whether the cash matches. Explain how to fill it in simple steps, add a weekly summary that totals sales, expenses, and gross profit, suggest a 5-minute end-of-day check, and show me how to set it up in a free Google Sheet with simple formulas — or in a notebook.

**Naija tip:** Cash that "doesn't balance" is the most common silent loss in Nigerian shops, and it's rarely one big theft — it's ₦500 here, ₦1,200 there, unrecorded "expenses," and change errors. A one-page sheet that **must balance before anyone goes home** ends it. Photograph the sheet daily to WhatsApp — it's your backup and your audit trail. (Bonus 11 in this book gives you a ready-made version.)

---

## Prompt 4.14

### Title: Handle Customer Enquiries and Support Faster With Templates

**Use this when:** Beyond price questions, you get "where is my order?", "how do I use this?", "can I change my order?", "you sent the wrong size" — and each one takes 10 minutes to handle.

**Copy this prompt:**

> I run a [business type] in Nigeria. The support situations I handle repeatedly are: [list — order status, delivery delays, how-to-use questions, order changes, wrong item, damaged item, request for refund, out of stock, payment not confirmed, customer can't find rider]. For each, write a short reply template (under 70 words) that: acknowledges the customer, gives clear information or the next step, and where relevant sets a time expectation. Also give me: (1) a simple internal rule for how fast to reply during and after hours, (2) which situations I should escalate to a phone call rather than text, and (3) a one-line closing I can use to end support chats positively.

**Real example (filled in):**

> I run an online store selling kitchen gadgets and home items across Nigeria. Repeated support situations: "where is my order?" (Lagos and interstate), delivery delayed by logistics company, "how do I use this air fryer/blender?", customer wants to change item after payment, wrong item sent, item arrived damaged, refund request, item out of stock after payment, payment made but not yet confirmed, and customer can't reach the rider. Write a short reply template for each under 70 words. Add a response-time rule, which situations need a phone call, and a positive one-line closing.

**Naija tip:** The single most valuable support habit in Nigeria is the **proactive update**: send the tracking or rider's number *before* the customer asks. "Your order left with GIG today, waybill number XXXX, expect it Thursday." That message prevents five "where is my order?" messages. Save every template as a Quick Reply and reply within 15 minutes in business hours — speed is the cheapest premium service you can offer.

---

## Prompt 4.15

### Title: Reduce Bank, POS and Transaction Charges

**Use this when:** You're losing thousands monthly to POS charges, transfer fees, SMS alerts, and failed-transaction wahala — and you've never added it up.

**Copy this prompt:**

> I run a [business type] in Nigeria. My monthly payment activity: roughly [number] cash sales, [number] POS card payments, [number] transfers received, [number] transfers sent to suppliers; total monthly revenue about ₦[amount]. I currently use [bank names / POS provider / fintech apps]. Charges I've noticed: [POS %, transfer fees, SMS alert fees, maintenance fees, stamp duty, failed transactions]. Help me cut these costs. Tell me: (1) roughly what I'm likely paying in total charges per month and per year, (2) which type of account or provider tends to suit a small business with my pattern (I'll verify current fees myself), (3) practical habits that cut charges — batching supplier payments, using the right channel for the right amount, avoiding failed transactions, (4) how to handle customers who want to pay by POS for tiny amounts, and (5) how to keep a monthly record of charges so I can see them.

**Real example (filled in):**

> I run a small restaurant in Abuja. Monthly: about 900 cash sales, 350 POS card payments, 200 transfers received, 40 transfers sent to suppliers; revenue about ₦1.4M. I use a traditional bank account, a POS from a fintech, and I sometimes receive into my personal account. Charges I've noticed: POS deductions per transaction, ₦10–₦50 per transfer, SMS alert fees, monthly maintenance, stamp duty on some deposits, and occasional failed POS transactions that take days to reverse. Help me estimate my total charges monthly and yearly, what kind of account/provider suits my pattern, practical habits to cut charges, how to handle ₦300 POS payments, and how to keep a monthly charges record.

**Naija tip:** Fees change often in Nigeria — this is a **Check Before You Trust It** prompt. Use the AI for structure and habits, then confirm actual current fees with the providers. Two habits save most owners money immediately: **separate business and personal accounts** (personal-account mixing is where charges and confusion multiply), and **pay suppliers in one batch on one day** instead of dribbling transfers all week.

---

## Prompt 4.16

### Title: Create Checklists for Quality Control (Get It Right Every Time)

**Use this when:** Mistakes reach customers — wrong sizes, missing items, a badly finished product, unclean tables — and each one costs you a customer or a redo.

**Copy this prompt:**

> I run a [business type] in Nigeria. Quality problems that reach customers: [list — wrong item packed, missing part, poor finishing, dirty presentation, late delivery, incorrect measurements, spelling errors on prints, food not hot, etc.]. Create quality-control checklists for the 3 most important points in my process: (1) before starting work/production, (2) before packaging or handing over, and (3) after delivery/service. Each checklist should be 6–10 tick-box items in very simple English, printable on half a page. Then tell me who should own each checklist, how to make staff actually use them (not just tick blindly), and a simple way to track how many mistakes we make per week so I can see improvement.

**Real example (filled in):**

> I run a small printing and branding shop in Ibadan. Quality problems that reach customers: spelling errors on flyers and banners, wrong colours from what was approved, prints cut crookedly, T-shirt prints peeling after a wash, orders delivered late, and packages missing items. Create quality-control checklists for: before starting a job (artwork approval, spelling check, colour confirmation), before packaging/handover, and after delivery. 6–10 tick-box items each, very simple English. Tell me who owns each checklist, how to make staff use them properly, and how to track mistakes per week.

**Naija tip:** The **"customer confirmation screenshot"** rule prevents most disputes in print, tailoring, cake and design businesses: no job starts until the customer has replied "Approved" to the final design, size, or spelling on WhatsApp. Screenshot it. Then when "but I said blue" arrives, you have peace and proof. Reward the staff member with the fewest errors each month — ₦2,000 and public praise — and watch quality rise.

---

## Prompt 4.17

### Title: Use AI as Your Personal Assistant for Daily Admin

**Use this when:** You want to use AI for the small daily tasks that pile up — drafting messages, calculating, summarising, making lists, converting units, planning your day.

**Copy this prompt:**

> Act as my business assistant. I run a [business type] in Nigeria. Today I need help with these small tasks: [list — e.g., calculate my profit on these 5 sales; draft a message to a late supplier; make a shopping list for the market with quantities for 40 plates of jollof; convert this USD price to naira at ₦[rate]; summarise these customer messages into a to-do list; write a polite reminder to a customer; plan my day given these 6 things I must do]. Do each task clearly, one after the other, and keep the answers short and practical. Where you need a number I haven't given, ask me instead of guessing.

**Real example (filled in):**

> Act as my business assistant. I run a small catering business in Lagos. Today I need help with: (1) calculate ingredients and quantities for 80 plates of jollof rice with chicken and 80 plates of fried rice, (2) estimate the cost using these prices: bag of rice ₦95,000 (50kg), chicken ₦4,200/kg, tomato paste ₦1,200 per tin, vegetable oil ₦3,500 per litre, seasoning and spices ₦8,000 total, gas ₦5,000, (3) draft a polite WhatsApp message to my chicken supplier who is 2 days late on delivery, (4) turn these six things into a time-blocked plan for tomorrow: market run, cooking from 6am, delivery by 12 noon, staff payment, posting on Status, calling two prospects, and (5) suggest a price per plate that gives me at least 40% margin. Ask me if you need any number I haven't given.

**Naija tip:** This is the "quiet superpower" prompt. Meta AI in WhatsApp is now your **free personal assistant** — for calculations, quantities, drafts, reminders, and planning — and it never gets tired at 11pm. Start every morning with "Act as my business assistant. Today I need help with…" and list everything on your mind. Ten minutes of this can replace an hour of mental juggling.

---

## Prompt 4.18

### Title: Decide Whether to Buy Equipment, Rent, or Outsource

**Use this when:** You're considering a big purchase — a freezer, industrial sewing machine, delivery bike, oven, printing machine, generator, car — and want to think it through properly.

**Copy this prompt:**

> I run a [business type] in Nigeria and I'm considering [buying / renting / outsourcing] [equipment or capability]. Details: purchase price ₦[amount]; alternative option (renting, hiring, outsourcing) costs ₦[amount] per [use/month]; I'd use it about [frequency]; expected extra revenue or savings it would bring ₦[amount] per month; my available cash is ₦[amount]; maintenance and running costs would be roughly ₦[amount]. Help me decide. Give me: (1) a simple payback calculation — how many months to recover the cost, (2) a comparison of buy vs. rent vs. outsource over 12 and 24 months, (3) the risks I might be ignoring (breakdowns, theft, power needs, fakes, resale value, demand dropping), (4) questions I should ask before buying, and (5) your honest recommendation — with the conditions under which it changes.

**Real example (filled in):**

> I run a small bakery in Jos and I'm considering buying an industrial deck oven for ₦850,000. Currently I use two small gas ovens that limit me to about 150 loaves a day; the big oven would allow 400+ loaves. Renting oven time at a bigger bakery costs ₦25,000 per day. I'd use it 6 days a week. Expected extra revenue is ₦350,000–₦500,000 per month if I can sell the extra loaves. My available cash is ₦1.1M. Running costs: extra gas ₦40,000 monthly, servicing ₦10,000. Help me decide: payback calculation, buy vs. rent vs. outsource over 12 and 24 months, risks I'm ignoring, questions to ask before buying, and your honest recommendation with conditions.

**Naija tip:** The question is never "can I afford it?" — it's "**can I sell what it produces?**" Many Nigerian bakers, tailors and printers buy capacity before they have demand, then the machine sits idle while the loan collects interest. Prove demand first (pre-orders, a reseller who commits, a month of turning customers away), then buy. And always keep at least 2 months of running costs in cash after any big purchase — that's your NEPA-and-wahala buffer.

---

## Prompt 4.19

### Title: Write Clear Policies for Your Business (Returns, Delivery, Deposits, Credit)

**Use this when:** Every dispute becomes a personal argument because nothing is written down — and customers assume whatever suits them.

**Copy this prompt:**

> I run a [business type] in Nigeria. I need clear, fair policies I can post on my WhatsApp, Status, price list, and shop wall for: (1) returns, exchanges and refunds, (2) delivery — areas, fees, timelines, and what happens if the customer is unreachable, (3) deposits and cancellations for custom or pre-ordered items, (4) credit — who qualifies and terms, (5) warranty or guarantee (if relevant), and (6) how complaints are handled and how fast. My current practice and problems: [describe]. Write each policy in 3–5 short, plain sentences — firm but friendly, protecting me while being fair to customers. Then give me a one-paragraph "Our Promise" statement I can post above the policies so they don't feel cold.

**Real example (filled in):**

> I run a custom furniture-making workshop in Nnewi. My current practice: I take 60% deposit, deliver in 3–4 weeks, and offer free minor repairs for 3 months. Problems: customers cancel after I've bought wood and want the full deposit back; customers change designs midway and refuse to pay extra; some collect and pay the balance in "instalments" that stretch for months; customers claim damage weeks after delivery. Write clear, fair policies for returns/exchanges, delivery, deposits and cancellations, credit/balance payment, warranty, and complaints — 3–5 plain sentences each, firm but friendly. Plus a one-paragraph "Our Promise" statement.

**Naija tip:** Post policies **before** the problem, and they protect you. Mention them **after** the problem, and they sound like excuses. Send the relevant policy line with every order confirmation: "Reminder: custom orders need 60% deposit which covers materials and is non-refundable once work starts." Nigerian customers respect clear rules stated kindly — what they resent is surprise.

---

## Prompt 4.20

### Title: Monthly Operations Review — What to Fix, Stop and Improve

**Use this when:** You want a simple monthly habit that keeps costs down and operations tight, without needing an accountant or a consultant.

**Copy this prompt:**

> Here is my operations summary for [month] for my [business type] in Nigeria: revenue ₦[amount]; total expenses ₦[amount] broken down as [list main categories]; last month's expenses were ₦[amount]; stock-outs of fast-sellers: [number/instances]; waste or spoilage: ₦[amount]; customer complaints: [number and types]; late deliveries or missed deadlines: [number]; staff issues: [describe]; hours I personally worked per week: [number]; things that went well: [list]. Review this like an experienced operations manager. Tell me: (1) whether my costs as a percentage of revenue are healthy for my type of business, (2) the three biggest operational problems this month and their likely root causes, (3) what to fix first, what to stop doing, and what to improve, (4) one system or SOP I should create this month, and (5) three targets for next month I can actually measure.

**Real example (filled in):**

> Operations summary for August for my mini-supermarket in Uyo: revenue ₦2.1M; expenses ₦1.72M (stock ₦1.25M, rent ₦60k, staff ₦150k, generator ₦120k, transport ₦35k, POS/bank charges ₦18k, misc ₦87k); last month's expenses were ₦1.6M; stock-outs of fast sellers: 7 times (sachet milk, indomie, pure water); waste: ₦28k in expired items; complaints: 4 (2 about a rude staff, 2 about wrong change); late supplier deliveries: 3; staff issues: one staff late 6 times; I worked about 78 hours a week; went well: new Status posting brought 20+ new customers. Review this as an experienced operations manager: are my cost percentages healthy, the three biggest problems and root causes, what to fix/stop/improve, one SOP to create this month, and three measurable targets for next month.

**Naija tip:** Do this on the **first Sunday of every month**, with a cup of tea and honesty. It takes 30 minutes. The owners who do it every month are the ones whose costs go *down* while revenue goes *up* — the 35% saving in this book's promise is found here, one month at a time. Keep every month's review in a single note; after six months, you will see patterns that no one else in your market can see.

---

## Part 4 Checkpoint

Before moving to Part 5, make sure these five are **done**:

1. You've completed a full expense audit with real numbers and have a 30-day cut plan. *(4.1)*
2. At least three SOPs are written, printed and on the wall. *(4.3)*
3. Your WhatsApp Business greeting, away message and 12 Quick Replies are live. *(4.5)*
4. A daily sales & cash sheet is in use and balances every night. *(4.13)*
5. Your policies (deposits, delivery, returns, credit) are written and posted. *(4.19)*

With costs down and systems running, you've stopped the leaks. Now the business can carry more weight — and it's time to add new products, new offers and new income streams on top of the foundation you've built.

**Next: Part 5 — Product Innovation & New Revenue Streams (Prompts 5.1 – 5.20)**


<div class='pb'></div>

# PART 5: PRODUCT INNOVATION & NEW REVENUE STREAMS
*(Prompts 5.1 – 5.20)*

---

## More Money From What You Already Have

By now you know your customer (Part 1), you can reach them cheaply (Part 2), you can close them (Part 3), and your costs are under control (Part 4). Now we grow the top line — and we do it the smart way.

The mistake most Nigerian business owners make when they want more income is to start something completely new: the hairdresser opens a provisions shop, the tailor starts selling phones. New business, new customers, new problems, new capital — and the old business suffers.

The smarter path is **adjacent growth**: new products, offers and income streams that sit next to what you already do, sell to customers you already have, and use skills, space, stock and trust you already own. A salon that adds a hair-products line. A caterer who sells frozen soup packs. A tailor who teaches a Saturday sewing class. A printer who sells digital templates. A poultry farmer who offers a monthly egg subscription.

Every idea in this Part is filtered through four questions:

1. **Do my existing customers want it?**
2. **Can I test it for under ₦50,000?**
3. **Does it use what I already have?**
4. **Does it improve my margin, my cash flow, or both?**

Some of these streams will be small — an extra ₦40,000 a month. Some will become bigger than your original business. You won't know which until you test. That's what the prompts are for.

**Start with 5.1, 5.2 and 5.7** — the idea generator, the bundle builder, and the "sell the knowledge" prompt. Between them, most businesses find their next ₦500,000.

---

## Prompt 5.1

### Title: Generate New Product and Service Ideas From What You Already Have

**Use this when:** You want to grow revenue but don't know what to add — and you want ideas that fit your business, not random ones.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. What I currently sell: [list]. My customers are: [describe]. What I already have that could be used differently: [skills, equipment, space, suppliers, stock, staff, time slots when I'm quiet, relationships]. What customers often ask for that I don't offer: [list]. Generate 15 ideas for new products, services or income streams that: use what I already have, appeal to my existing customers, and can be tested for under ₦50,000. For each, give: the idea in one line, who buys it, estimated price, why it fits my business, and a difficulty score out of 5. Then rank the top 5 by likely profit and ease, and tell me which ONE to test first.

**Real example (filled in):**

> I run a unisex salon in Ikeja, Lagos. I currently sell braiding, weaving, wig installation, barbing, nails, and pedicure. Customers are women 20–45 and men 18–40, mostly working class and young professionals. What I have: 3 stylists with strong skills, a shop that's quiet Monday–Wednesday mornings, a good supplier of hair and products, a WhatsApp list of about 400 customers, and a small back room. Customers often ask: where to buy good wigs, how to maintain braids, whether I do home service, and whether I can train their younger sister. Generate 15 ideas that use what I have, appeal to my customers, and cost under ₦50,000 to test. Give price, buyer, fit, and difficulty for each. Rank the top 5 and tell me which one to test first.

**Naija tip:** The best ideas usually come from the **"customers often ask for"** list — they are already telling you what to sell. The second best come from your **quiet hours**: a salon empty on Monday mornings is wasted rent, so fill it with a training class, a discounted "Monday Madness" slot, or a product-sales morning. Never launch more than one new idea at a time; test it for 30 days, then decide.

---

## Prompt 5.2

### Title: Create Bundles and Packages That Raise Your Average Sale

**Use this when:** Customers buy one item at a time and your average sale is stuck. Bundles are the fastest, cheapest revenue lever in any business.

**Copy this prompt:**

> I run a [business type] in Nigeria. Products/services and prices: [list with cost prices if possible]. My average sale is currently ₦[amount]. Design 5 bundles or packages that increase the average sale while giving customers a real reason to choose the bundle. For each bundle: a catchy Nigerian-friendly name, what's included, the individual total, the bundle price, the customer's saving, my profit on the bundle versus selling items separately, and who it's perfect for. Include: a starter bundle, a premium bundle, a gift bundle, a seasonal or occasion bundle, and a "buy more, save more" quantity deal. Then write the one-line pitch for each and tell me where to display them.

**Real example (filled in):**

> I run a natural skincare business in Abuja. Products and cost/selling prices: black soap ₦1,200/₦2,500; shea butter cream ₦1,500/₦3,500; turmeric face scrub ₦1,300/₦3,000; rosewater toner ₦900/₦2,500; lip balm ₦400/₦1,200; body oil ₦1,600/₦4,000. Average sale is ₦3,200. Design 5 bundles that raise the average sale: a starter bundle, a premium bundle, a gift bundle, a seasonal bundle (e.g., harmattan skin rescue), and a "buy more, save more" deal. For each: catchy name, contents, individual total, bundle price, customer saving, my profit vs. separate sales, ideal buyer, one-line pitch. Tell me where to display them.

**Naija tip:** Nigerians love a **named package** — "The Glow-Up Box," "Harmattan Rescue Kit," "Bride's Prep Set" — far more than "3 items for ₦8,000." The name makes it a *thing* people ask for by name. Price bundles so the saving is visible (show the "was ₦9,000, now ₦7,500") but your profit per transaction still rises. And always have one **premium bundle** — some customers want to spend more, and you should let them.

---

## Prompt 5.3

### Title: Add a Premium Version of What You Already Sell

**Use this when:** You sell at one price point, and some customers would happily pay more for something better, faster or more exclusive — but you've never offered it.

**Copy this prompt:**

> I run a [business type] in Nigeria and currently sell [main product/service] at ₦[price]. Help me create a premium version that some customers will pay 50–150% more for. Suggest: (1) 6 ways to make it genuinely premium — better materials, faster delivery, personalisation, exclusive access, extra service, superior packaging, guarantee, priority slots, (2) the best combination of 2–3 of these for my type of customer, (3) a name and a price for the premium version, (4) how to present standard and premium side by side so the premium looks attractive without making the standard look bad, and (5) how to test whether customers want it before investing heavily.

**Real example (filled in):**

> I run a cake business in Enugu and currently sell an 8-inch buttercream birthday cake at ₦18,000. Help me create a premium version customers will pay 50–150% more for. Suggest 6 ways to make it genuinely premium (e.g., fondant finishing, custom toppers, same-day priority, a matching cupcake box, luxury packaging with a personal card, delivery with a photographer moment), the best 2–3 for my customers (young professionals and mothers celebrating children's birthdays), a name and price, how to present standard vs. premium side by side, and how to test demand before investing.

**Naija tip:** There is always a customer who wants **"the best one you have."** If you don't have a "best one," they buy it elsewhere. The premium tier also does something quiet: it makes your standard price feel reasonable ("₦18,000? That's the *normal* one"). Present three options where possible — Good, Better, Best — and most Nigerians pick the middle. That's fine: you've just raised your average sale.

---

## Prompt 5.4

### Title: Launch a Subscription or Repeat-Order Plan

**Use this when:** Your product is consumed regularly (food, eggs, water, toiletries, hair care, drinks, data, cleaning) and you want predictable weekly or monthly income instead of hoping people come back.

**Copy this prompt:**

> I run a [business type] in Nigeria selling [product/service] that customers typically buy every [frequency]. Design a subscription or standing-order plan for me. Include: (1) 2–3 plan options (e.g., weekly, fortnightly, monthly) with what's delivered and a price that rewards commitment but protects my margin, (2) how to collect payment in Nigeria simply — upfront monthly transfer, standing instruction, or a payment link — and how to handle missed payments, (3) how to manage delivery days and communicate schedules on WhatsApp, (4) the launch message to existing customers, (5) how to handle pauses, changes and cancellations without stress, and (6) how many subscribers I need for this to be worth running.

**Real example (filled in):**

> I run a poultry farm in Ogun State selling crates of eggs (₦4,800 per crate) and live/dressed chickens to families, restaurants and small shops in Abeokuta and Sango. Customers typically buy eggs weekly or fortnightly. Design an egg (and optional chicken) subscription: 2–3 plan options with pricing, how to collect payment monthly in Nigeria and handle missed payments, delivery-day scheduling on WhatsApp, the launch message to my existing customers, how to handle pauses and cancellations, and how many subscribers make it worthwhile.

**Naija tip:** Subscriptions work in Nigeria when they are **prepaid** ("pay ₦18,000 for 4 weekly crates, save ₦1,200") and delivered on a **fixed day** ("Every Saturday morning"). Prepayment gives you cash flow to buy feed or stock; the fixed day makes delivery cheap. Start with 10 loyal customers — it feels small but it's ₦180,000 guaranteed on the first of the month, before you sell anything else.

---

## Prompt 5.5

### Title: Create Seasonal and Festive Products That Sell Out

**Use this when:** You want to make the most of Christmas, Sallah, Easter, Valentine's, Mother's Day, back-to-school, Detty December, harmattan, rainy season — with products designed for the moment.

**Copy this prompt:**

> I run a [business type] in Nigeria. The next big occasion is [festival/season] in [number] weeks. Suggest 8 seasonal products, packages or services that fit both my business and the occasion — gift-ready, occasion-specific, or solving a seasonal problem. For each: name, contents, price, cost estimate, who buys it, and how many I should make/stock for a first run. Then tell me: the ideal timing to announce, open pre-orders, and stop taking orders; how to package it so it looks gift-worthy on a small budget; and how to sell leftover stock after the occasion without looking desperate.

**Real example (filled in):**

> I run a small honey, spices and natural foods business in Kano. The next big occasion is Sallah in 6 weeks. Suggest 8 seasonal products or packages that fit — for example Sallah gift hampers, ram-seasoning spice packs, a "Sallah Kitchen Box", corporate gift boxes for offices, a date-and-honey gift set. For each: name, contents, price, cost, buyer, first-run quantity. Tell me when to announce, open pre-orders and close orders; how to package gift-worthy on a small budget; and how to sell leftovers after Sallah.

**Naija tip:** Seasonal products have a **3-week selling window** — miss it and you're holding stock for a year. Announce 4 weeks out, take **pre-orders with deposits** 3 weeks out, and close orders 5 days before the day. Corporate gift hampers are the hidden goldmine: one company ordering 30 hampers at ₦15,000 is ₦450,000 from a single WhatsApp conversation. Ask the AI to write that corporate pitch too.

---

## Prompt 5.6

### Title: Find Under-Served Customers Your Business Could Serve

**Use this when:** Your current market feels saturated and you want to find a group nobody is serving properly — with what you already do, slightly adapted.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, currently serving [current customers]. Identify 6 customer groups in my area or online that are probably under-served for my type of product/service — for example: corporate clients, schools, churches/mosques, estates, hospitals, hotels, students, the elderly, people with specific dietary or cultural needs, diaspora Nigerians buying for family at home, other businesses (B2B). For each group: what they'd need from me that's slightly different, how big the opportunity might be, how to reach them, what objection they'd have, and one small adaptation I'd need to make. Then pick the best two and outline a 30-day plan to win the first customer in each.

**Real example (filled in):**

> I run a laundry and dry-cleaning business in Wuse, Abuja, currently serving individual walk-in customers and a few families. Identify 6 under-served groups I could serve — such as hotels and guest houses, hospitals and clinics (staff uniforms and linen), salons and spas (towels), corporate offices, estates, and diaspora Nigerians who want laundry service arranged for elderly parents in Abuja. For each: what they'd need that's different, opportunity size, how to reach them, likely objection, one adaptation. Pick the best two and give me a 30-day plan to win the first customer in each.

**Naija tip:** **B2B is the fastest way to multiply revenue** without multiplying marketing — one hotel is 50 families' worth of laundry. To win them: offer a **free trial week**, show up in person with a one-page proposal (Prompt 3.11), and emphasise reliability over price. And don't ignore the diaspora angle: Nigerians abroad pay in dollars for anyone who reliably takes care of their parents' food, laundry, medicine or errands back home.

---

## Prompt 5.7

### Title: Turn Your Skill or Knowledge Into a Paid Class, Workshop or Training

**Use this when:** People keep asking "can you teach me?" — and you've been giving it away for free.

**Copy this prompt:**

> I run a [business type] in Nigeria and I'm skilled at [what you do well]. People often ask me to teach them. Help me create a paid training offer. Give me: (1) 3 formats to consider — a one-day physical workshop, a 4-week weekend class, an online WhatsApp/Zoom class — with pros and cons for my situation, (2) a course outline for the best format: sessions, what's taught in each, what students go home able to do, (3) pricing for Nigeria (with an early-bird and a payment-plan option) and how many students I need per batch, (4) what to include (materials, certificate, starter kit, WhatsApp support group) to justify the price, (5) the announcement message for WhatsApp Status, and (6) how to turn graduates into future customers, suppliers, or staff.

**Real example (filled in):**

> I run a small-chops and finger-foods business in Port Harcourt and I'm very good at making puff-puff, samosa, spring rolls, and mini-pies with consistent quality. People often ask me to teach them. Help me create a paid training offer: 3 formats with pros and cons, a course outline for the best one (sessions, skills, outcomes), Nigerian pricing with early-bird and payment plan and minimum students per batch, what to include to justify the price, the WhatsApp Status announcement, and how to turn graduates into customers, suppliers, or staff.

**Naija tip:** In Nigeria, **skills training is a huge market** — youths, NYSC members, housewives and retirees all want a "handwork." A one-day physical class at ₦15,000–₦35,000 with 10–15 students can earn more than a week of sales. Add a **certificate** (make one in Canva) and a **starter kit**; both raise the perceived value enormously. Photograph every class — those photos market the next batch.

---

## Prompt 5.8

### Title: Create a Digital Product You Can Sell Repeatedly

**Use this when:** You want income that doesn't require your hands every time — an eBook, template pack, recipe guide, price list, checklist, video course, or planner based on what you already know.

**Copy this prompt:**

> I run a [business type] in Nigeria and I know a lot about [your expertise]. Help me create a digital product I can sell repeatedly with no extra production cost. Suggest 5 digital product ideas (eBook, guide, template, checklist, mini video course, planner, recipe pack, price calculator), each with: title, who buys it, what problem it solves, price in naira (and USD for diaspora buyers), and how long it would take me to create with AI's help. Pick the best one and give me: a full outline, how to create it using free tools (Google Docs, Canva, phone video), how to deliver it after payment (Selar, Paystack link + WhatsApp, Gumroad), and a launch plan for my existing WhatsApp contacts.

**Real example (filled in):**

> I run a home tutoring and lesson-teaching business in Lagos and I know a lot about helping SS3 students pass WAEC Mathematics and preparing JAMB candidates. Help me create a digital product I can sell repeatedly: 5 ideas (e.g., "WAEC Maths: 50 Must-Know Questions Explained", a JAMB 8-week study planner, a parent's guide to supporting a WAEC candidate, a video mini-course on the 10 hardest topics), each with title, buyer, problem solved, naira and USD price, and time to create with AI's help. Pick the best one and give me a full outline, how to create it with free tools, how to deliver after payment, and a launch plan for my WhatsApp contacts.

**Naija tip:** You are reading a digital product right now — proof the model works. Selar and Paystack storefronts handle Nigerian payments and automatic delivery; Gumroad works for international buyers. Price digital products in Nigeria between ₦2,000 and ₦15,000 for most audiences, and always create a **free mini-version** (2 pages, one checklist) to give away on Status — it's the best advert for the paid one.

---

## Prompt 5.9

### Title: Add Complementary Products Your Customers Already Buy Elsewhere

**Use this when:** Your customers leave your shop and go to buy something related from someone else — money that could have been yours.

**Copy this prompt:**

> I run a [business type] in Nigeria selling [products/services] to [customers]. Think about the complete journey of my customer around my product — what they buy before, alongside, and after. List 12 complementary products or services my customers probably buy from someone else right now. For each: how it relates to what I sell, estimated price and margin, whether I should stock it, resell it on commission, or partner with a supplier, and the risk (space, capital, spoilage, expertise). Then choose the best 4 to add first, estimate the extra monthly revenue if just 20% of my customers buy them, and write the line I'd use to introduce each at the point of sale.

**Real example (filled in):**

> I run a phone sales and repair shop in Ilorin selling new and UK-used phones and doing screen and battery repairs, to students, traders and young workers. List 12 complementary products or services my customers currently buy elsewhere — e.g., screen protectors, cases, chargers, power banks, earphones, memory cards, SIM registration help, data subscriptions, phone insurance, laptop repair referrals, phone swap/trade-in, and software setup. For each: relationship to my sales, price and margin, stock vs. commission vs. partner, and risk. Choose the best 4, estimate extra monthly revenue if 20% of my roughly 300 monthly customers buy them, and write my point-of-sale line for each.

**Naija tip:** The moment someone buys a phone from you, they are in **buying mode** — "You'll need a screen protector and case for this one; I'll give you both for ₦3,000 instead of ₦4,000" converts more than half the time. Attach rate is the metric: how many of your phone buyers also buy an accessory? Move it from 20% to 60% and you may double your profit without one extra customer.

---

## Prompt 5.10

### Title: Explore Print-on-Demand, Branded Merchandise and Custom Items

**Use this when:** You have a brand, a following, a church/school/community, or a design skill — and want to sell branded T-shirts, mugs, caps, tote bags, notebooks, or custom items without holding stock.

**Copy this prompt:**

> I run a [business type / community / creative brand] in Nigeria with [audience size and type]. I'm interested in selling branded or custom merchandise. Help me: (1) suggest 8 merchandise items that would sell to my audience, with realistic Nigerian production costs and selling prices, (2) explain how to run this without holding stock — pre-orders in batches, local printers who do small runs, or print-on-demand services accessible from Nigeria, (3) identify occasions and campaigns that drive merch sales (anniversaries, events, church programmes, school colours, "Naija pride" moments, staff uniforms for other businesses), (4) design ideas or slogans that would resonate with my audience, and (5) a pre-order launch plan that ensures I collect money before I print.

**Real example (filled in):**

> I run a fitness bootcamp in Lekki with about 120 active members and 3,000 Instagram followers. I want to sell branded merchandise. Help me: suggest 8 items with Nigerian production costs and prices (e.g., dri-fit tees, caps, gym towels, water bottles, resistance bands, tote bags), how to run it with pre-orders and small-batch local printers, occasions that drive sales (bootcamp anniversary, 30-day challenge completion, December fitness fest), design and slogan ideas that resonate with Lagos fitness people, and a pre-order launch plan so I collect money before printing.

**Naija tip:** The rule for merchandise in Nigeria is **never print before you collect**. Run a 10-day pre-order window, hit your minimum (usually 20–30 pieces for a good unit price), then print. Also look sideways: your printing contact can also produce **staff uniforms and branded items for other small businesses** — that's a B2B revenue stream on top of your own merch, with zero extra skills.

---

## Prompt 5.11

### Title: Offer Home Service, Delivery or Mobile Versions of Your Business

**Use this when:** Customers say "can you come to my house?" or "can you deliver?" — and you've been saying no, or doing it without a proper price.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Customers ask for [home service / delivery / mobile version]. Help me design this as a proper, profitable offer. Include: (1) what to charge — a pricing structure by distance/zone or by service level that covers transport, time and the premium of convenience, (2) which of my services suit home/mobile delivery and which don't, (3) scheduling rules — days, hours, minimum order, advance booking, deposits, (4) what equipment or packaging I need to do it well, (5) safety and reliability measures for me and the customer, and (6) the message announcing this new option to my customers, positioning it as premium convenience, not a favour.

**Real example (filled in):**

> I run a barbing salon in Surulere, Lagos. Customers — especially busy professionals, fathers with young sons, and elderly men — keep asking if I can come to their houses. Help me design a proper home-service offer: pricing by zone (Surulere / Yaba–Ikoyi / Lekki–Ajah) that covers transport and time with a convenience premium, which services suit home visits (haircuts, beard, kids' cuts) versus not, scheduling rules with advance booking and deposit, the kit I need (portable clippers, cape, sterilising spray, mirror, power bank), safety measures, and a launch message positioning it as premium convenience.

**Naija tip:** Home service should cost **at least 2× the shop price** — you're selling time and convenience, and the customers who ask can afford it. Bundle for households: "Dad + 2 sons home cut: ₦12,000." Sunday mornings and weekday evenings are your golden slots. Ask for a **deposit on booking** to eliminate no-shows, and carry a power bank — every mobile Nigerian business runs on one.

---

## Prompt 5.12

### Title: Test a New Product Idea Cheaply Before Investing

**Use this when:** You have an idea from any of the prompts above and want to validate it with real customers and real money in 2–3 weeks — before you spend big.

**Copy this prompt:**

> I want to test this new product/service idea for my [business type] in Nigeria: [describe the idea, intended price, and who it's for]. Design a 21-day low-cost test for me. Include: (1) the smallest version of the idea I can offer (minimum viable version) and what it will cost to prepare, (2) how to offer it to my existing customers and measure genuine interest — pre-orders, deposits, waitlist replies, not just "nice idea" comments, (3) a simple scoring system: what numbers mean "go big," "adjust and retest," or "drop it," (4) a day-by-day plan for the 21 days including what to post and who to message, and (5) the 3 questions to ask people who showed interest but didn't buy.

**Real example (filled in):**

> I want to test this idea for my provisions shop in Nyanya, Abuja: a "Monthly Foodstuff Box" for young families — a fixed box of rice, beans, garri, oil, seasoning, spaghetti and tomato paste at ₦28,000, paid at month-start and delivered within Nyanya. Design a 21-day low-cost test: the smallest version I can offer and its prep cost, how to measure genuine interest with pre-orders and deposits (not just comments), a scoring system for "go big / adjust / drop," a day-by-day 21-day plan with posts and messages, and 3 questions to ask people who were interested but didn't buy.

**Naija tip:** The Nigerian validation rule is simple and unforgiving: **"like" is not "buy."** Fifty fire emojis on a Status mean nothing; five deposits of ₦5,000 mean everything. Set your "go" threshold before you start (e.g., 10 paid pre-orders in 21 days) and honour it. If you hit it — scale. If you don't — you've lost ₦20,000 and gained a lesson, not lost ₦400,000 and gained a warehouse.

---

## Prompt 5.13

### Title: Collaborate With Another Business on a Joint Product

**Use this when:** You want a new product but lack a skill, ingredient or audience — and another local business has exactly what you're missing.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. I want to create a joint product or offer with another business. What I bring: [skills, product, audience, space, equipment]. What I lack: [what you need]. Suggest 6 types of businesses I could partner with and, for each, a specific joint product or package, who buys it, how we'd price and split revenue fairly, and who handles what. Then write: (1) a short, respectful proposal message to send to a potential partner, (2) a simple one-page agreement covering money split, responsibilities, timelines, customer ownership, and how to end the partnership peacefully, and (3) how to launch the joint product to both of our customer bases.

**Real example (filled in):**

> I run a bakery in Benin City. What I bring: quality cakes and pastries, a shop on a busy road, and 600 WhatsApp contacts. What I lack: drinks, decoration, photography, and event coordination. Suggest 6 businesses I could partner with — e.g., a zobo/smoothie maker, a balloon decorator, a photographer, an event planner, a flower seller, a gift-box maker — each with a specific joint product (like a "Birthday-in-a-Box": cake + drinks + balloons + a 15-minute photoshoot), buyer, pricing and revenue split, and responsibilities. Write a respectful proposal message, a one-page agreement, and a joint launch plan.

**Naija tip:** Partnerships in Nigeria collapse over **money and credit** — who got paid, who did more, whose customer is it. Write it down before the first sale, however friendly you are: "Customer pays me, I pay you your ₦X within 24 hours, screenshot as proof." Start with a **one-event or one-month trial**. If it works, extend. If it doesn't, you both walk away without a fight.

---

## Prompt 5.14

### Title: Add a Small Rental or Hire Income Stream

**Use this when:** You own equipment, space, tools, or items that sit idle part of the time — and other people would pay to use them.

**Copy this prompt:**

> I run a [business type] in Nigeria and I own [list assets — equipment, machines, space, vehicles, tools, chairs/canopies, cameras, generators, freezers, decor items, sound systems] that are idle about [percentage] of the time. Help me create a rental or hire income stream: (1) which assets are worth renting out and which are too risky, (2) fair daily/hourly rental prices in my area, (3) how to protect the asset — deposits, ID and guarantor, condition checklist with photos, a simple agreement, (4) who would rent them and how to reach those people, (5) how to schedule rentals without disrupting my own business, and (6) estimated monthly income if the assets are rented just 4–6 times a month.

**Real example (filled in):**

> I run an event catering business in Ibadan and I own 150 plastic chairs, 20 tables, 3 canopies, 2 large coolers, 6 chafing dishes, a 5kVA generator, and a small sound system, which sit idle about 70% of the time. Help me create a rental income stream: which assets to rent out and which are too risky, fair daily prices in Ibadan, how to protect them (deposits, ID, condition checklist, agreement), who rents such items and how to reach them, scheduling around my own events, and estimated monthly income at 4–6 rentals per month.

**Naija tip:** Rental income is **almost pure profit** — you already own the asset. The risks are damage and non-return; solve both with a **refundable deposit (30–50% of replacement value)**, a photocopy of the renter's ID, and time-stamped photos at handover and return. Your own customers are your first rental market: "Booking a caterer? We also rent chairs and canopies — one call, less stress."

---

## Prompt 5.15

### Title: Improve an Existing Product Based on Customer Feedback

**Use this when:** You have a product that sells okay but could sell far better with the right adjustments — and you want to make those adjustments intelligently.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[price]. It sells [okay / slowly / well but with complaints]. Feedback I've collected from customers: [list positives and negatives]. What competitors do differently: [if known]. Help me improve it. Give me: (1) the 5 most valuable improvements ranked by impact on sales versus cost to implement, (2) which improvements I could charge more for and which are simply expected, (3) 3 packaging or presentation changes that raise perceived value cheaply, (4) how to announce the improved version so existing customers rebuy and new customers notice, and (5) how to measure whether the improvement actually worked over 30 days.

**Real example (filled in):**

> I sell homemade peanut butter and groundnut snacks in Jos at ₦2,500 per 500g jar. It sells okay. Feedback: customers love the taste and that there's no added sugar; complaints include the jar lid leaks in transit, the label looks homemade, some want a smaller size for trying, others want a crunchy version, and some worry about shelf life. Competitors use branded plastic jars with nutritional info and sell in supermarkets. Help me improve: the 5 most valuable improvements ranked by impact vs. cost, which I can charge more for, 3 cheap packaging/presentation changes, how to announce the improved version, and how to measure results over 30 days.

**Naija tip:** In Nigeria, **packaging is often the whole difference** between "market" and "supermarket" pricing. The same peanut butter in a leak-proof jar with a printed label, an expiry date and a NAFDAC number can sell for double — and get into shops. Fix the complaint that costs you the most repeat sales first (the leaky lid), then the one that limits new buyers (the smaller trial size). Announce it as "New & Improved — you asked, we listened," and credit your customers publicly.

---

## Prompt 5.16

### Title: Sell to Nigerians Abroad (Diaspora Revenue in Dollars)

**Use this when:** You want customers who pay in foreign currency — Nigerians in the UK, US, Canada, Europe or the Gulf buying for family at home or wanting a taste of home.

**Copy this prompt:**

> I run a [business type] in [city], Nigeria. Help me build a revenue stream from Nigerians abroad. Tell me: (1) which of my products or services diaspora Nigerians would pay for — either delivered to their family here (gifts, food, care packages, services for parents, event catering, tailoring for occasions) or shipped/delivered to them abroad (if feasible), (2) how to price in USD/GBP fairly and get paid (payment links that accept foreign cards, and what to check about fees and settlement), (3) how to build trust remotely — photo/video proof of delivery, live video calls, references, (4) where and how to reach diaspora Nigerians — WhatsApp groups, Facebook community groups, Instagram, alumni and hometown associations, and (5) a simple offer and message to start with.

**Real example (filled in):**

> I run a food and catering business in Enugu. Help me build a diaspora revenue stream: which products diaspora Nigerians would pay for (e.g., weekly cooked meals delivered to their elderly parents in Enugu, Christmas food packages for family, event catering when they come home for burials and weddings, or vacuum-sealed dried foods like crayfish, ogbono and egusi shipped abroad if feasible), how to price in USD/GBP and get paid with links that accept foreign cards, how to build trust remotely with photo and video proof, where to reach diaspora Nigerians from Enugu/Anambra area, and a simple starter offer and message.

**Naija tip:** The diaspora market has one powerful driver: **guilt and love for parents back home**. "Weekly hot meals for Mama in Enugu, $60/month, with a photo every delivery" sells itself in London and Houston. Your Flutterwave or Paystack link already accepts foreign cards — check the settlement details and fees first (*Check Before You Trust It*). Join hometown and alumni groups abroad and let satisfied clients recommend you; one diaspora referral chain can be worth ₦2M a year.

---

## Prompt 5.17

### Title: Create a Loyalty Programme That Increases Lifetime Value

**Use this when:** You want existing customers to buy more often and spend more over time — and you want a simple system, not an app.

**Copy this prompt:**

> I run a [business type] in Nigeria. Average customer spends ₦[amount] per visit and buys about [frequency]. Design a simple loyalty programme I can run with a paper card, WhatsApp, or a notebook: (1) 3 programme options — stamp card, points, tiered VIP (silver/gold), or a surprise-reward system — with pros and cons for my business, (2) the reward structure for the best option that increases visits by at least 25% while costing me under 5% of revenue, (3) how customers join and track progress, (4) messages to announce it, remind people of their progress, and celebrate when they earn a reward, and (5) how to measure if it's actually working after 60 days.

**Real example (filled in):**

> I run a small restaurant in Lagos (Ikeja) serving lunch to office workers. Average customer spends ₦2,800 per visit and buys about twice a week. Design a simple loyalty programme I can run with a paper card or WhatsApp: 3 options with pros and cons, the reward structure for the best one that increases visits by 25% while costing under 5% of revenue, how customers join and track progress, announcement/reminder/celebration messages, and how to measure success after 60 days.

**Naija tip:** Keep it **stupid-simple**: "Buy 7 lunches, the 8th is free." A paper card with a stamp is still the most effective loyalty tool in Nigeria — visible, tangible, no data needed. Add a **surprise** occasionally ("Today, every Gold member gets free drink") — unexpected generosity is remembered and talked about far more than the scheduled reward.

---

## Prompt 5.18

### Title: Turn Your Business Into a Brand Others Want to Sell (Distributors & Agents)

**Use this when:** You make something — food, soap, drinks, fashion, cosmetics, crafts — and want it sold in more places than you can personally reach.

**Copy this prompt:**

> I produce [product] in [city], Nigeria, currently selling directly to customers at ₦[price] with a cost of ₦[cost]. I want other people to sell it for me — agents, distributors, shops, market sellers, online vendors. Help me design a reseller programme: (1) the pricing ladder — my cost, distributor price, retailer price, recommended retail price — with margin for everyone, (2) minimum orders and payment terms for each level, (3) how to recruit resellers and what kind of person makes a good one, (4) what support to give them — product photos, captions, sales training, marketing materials, (5) rules to protect my brand — consistent pricing, territory, quality, no dilution, and (6) a simple reseller agreement and the recruitment message.

**Real example (filled in):**

> I produce a range of natural hair-care products (shampoo, deep conditioner, hair growth oil) in Ibadan, selling directly at ₦3,500–₦6,000 with costs of ₦1,400–₦2,300. I want salons, beauty-supply shops, Instagram vendors and student agents to sell for me. Help me design a reseller programme: pricing ladder with margin for everyone, minimum orders and payment terms per level, how to recruit resellers and who makes a good one, what support to give them, rules to protect my brand and pricing, and a simple reseller agreement plus the recruitment message.

**Naija tip:** Nigeria runs on **agent networks** — from telecom recharge to cosmetics to bread. Students and stay-at-home mothers make excellent agents when the margin is clear and the starter pack is affordable (₦15,000–₦30,000). Give them a **ready-made sales kit** (photos, captions, a price list, a testimonial video) so they can start selling the same day. Protect your brand with one non-negotiable rule: sell below the RRP and you lose reseller status.

---

## Prompt 5.19

### Title: Build a Second Income Stream That Runs Alongside Your Main Business

**Use this when:** You want an additional, semi-passive stream — affiliate commissions, referral fees, agency for a bigger brand, POS services, a small side product — that doesn't distract from your core business.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria, and I have [describe assets — daily foot traffic, a customer list of X, a shop location, delivery routes, a following, spare counter space, relationships with certain groups]. Suggest 8 side income streams that could run alongside my business with under 3 hours a week of my attention — e.g., becoming an agent for a bigger brand, POS/bill-payment services, referral fees from complementary businesses, affiliate links for products my customers buy, renting shelf or wall space, small commission sales. For each: how it works, estimated monthly income, what it requires, risks, and whether it strengthens or distracts from my main business. Rank them and tell me which one to start this month.

**Real example (filled in):**

> I run a busy pharmacy in Ikorodu with about 120 walk-in customers daily, a WhatsApp list of 800, a small counter area, and good relationships with local clinics and mothers' groups. Suggest 8 side income streams that could run alongside with under 3 hours a week — e.g., POS/bill payments, insurance or HMO agent, baby-product brand agency, health-supplement affiliate, renting shelf space to a cosmetics brand, referral fees from a diagnostic lab, selling a small baby-care digital guide. For each: how it works, estimated monthly income, requirements, risks, and whether it strengthens or distracts. Rank and tell me which to start this month.

**Naija tip:** The best side stream is the one that **serves the same customer, in the same visit**. Foot traffic is an asset most shop owners undervalue — 120 people a day walking past your counter is an audience brands and services will pay to reach. But protect your core: if the side hustle starts taking your attention or confusing your customers about what you are, cut it. Focus is also a revenue strategy.

---

## Prompt 5.20

### Title: Build Your 12-Month Product & Revenue Roadmap

**Use this when:** You've generated ideas from this Part and want to turn them into an orderly plan — what to launch when, so you grow without overwhelming yourself or your cash.

**Copy this prompt:**

> Here are the new product, service and revenue-stream ideas I'm considering for my [business type] in Nigeria: [list them, with estimated cost to launch and expected monthly revenue for each]. My current monthly revenue is ₦[amount] and profit ₦[amount]. My available capital for new things is ₦[amount]. My time available for new projects is about [hours] per week. Create a 12-month roadmap that: (1) sequences the ideas logically — quick wins first, cash-generating before cash-consuming, seasonal items at the right time, (2) shows for each quarter what launches, what it costs, and what it should bring in, (3) sets a go/no-go checkpoint for each idea, (4) keeps my total risk within my capital, and (5) projects my monthly revenue by month 12 if things go reasonably well. Present it as a quarter-by-quarter table plus a short explanation.

**Real example (filled in):**

> Ideas for my unisex salon in Ikeja: a hair-products retail line (launch cost ₦80,000, expected ₦120,000/month), a Monday-morning discounted slot (₦0, ₦60,000/month), a 4-week braiding class (₦30,000, ₦200,000 per batch), home-service barbing (₦45,000, ₦90,000/month), a bridal package for wedding season (₦20,000, ₦150,000/month in Nov–Dec and April), and a "Salon Day" gift voucher (₦5,000, ₦50,000/month). Current revenue ₦850,000, profit ₦280,000, capital available ₦200,000, time about 6 hours a week. Create a 12-month roadmap: sequence with quick wins first and seasonal items timed right, quarter-by-quarter table with costs and expected income, go/no-go checkpoints, total risk within my capital, and projected revenue by month 12.

**Naija tip:** One new stream per quarter is the pace that works — enough to grow noticeably, slow enough to do each one properly. Start with the **free or near-free wins** (the Monday slot, the vouchers) to build momentum and cash, then fund the bigger launches from that cash rather than from loans. Review the roadmap every quarter with Prompt 4.20's monthly review beside it. A business with a roadmap stops reacting and starts compounding.

---

## Part 5 Checkpoint

Before moving to Part 6, make sure these five are **done**:

1. You have a list of at least 10 adjacent ideas, ranked, with one chosen to test first. *(5.1)*
2. At least two named bundles are live and displayed. *(5.2)*
3. One new stream — premium tier, subscription, class, or home service — is in a 21-day test with a "go" threshold you wrote down. *(5.3/5.4/5.7/5.11 + 5.12)*
4. You've identified one B2B or diaspora customer group and contacted the first prospect. *(5.6/5.16)*
5. Your 12-month product roadmap exists, quarter by quarter. *(5.20)*

Revenue is now coming from more than one direction. Part 6 makes sure you actually *keep* it — pricing for profit, tracking cash, separating business money from personal money, and preparing for funding when you're ready to grow further.

**Next: Part 6 — Finance, Funding & Smart Growth (Prompts 6.1 – 6.20)**


<div class='pb'></div>

# PART 6: FINANCE, FUNDING & SMART GROWTH
*(Prompts 6.1 – 6.20)*

---

## The Part That Decides Whether You Keep the Money

You can do everything in Parts 1–5 perfectly and still end the year with nothing. It happens to Nigerian businesses every day: sales are strong, the shop is busy, and yet there is no money in the account. The owner cannot say what the profit was last month, whether the ₦8,000 dress actually makes money after delivery and returns, or where the ₦300,000 that "should be there" went.

This Part is about **keeping what you earn, knowing your numbers, and growing on solid ground.** Specifically:

- Pricing so every sale is actually profitable — after *all* costs
- Knowing your break-even, your real profit, and your cash position every week
- Separating business money from personal money (the number one silent killer)
- Managing debtors, savings, and the "small small" that leaks away
- Preparing for funding — grants, loans, investors — only when it makes sense, with proposals that get read
- Growing (a second branch, more staff, more stock) with a plan, not a prayer

**A word before you start — read "Check Before You Trust It" again.** This Part deals with money, tax, loans and legal matters. AI is an excellent thinking partner and calculator; it is **not** your accountant, lawyer, tax adviser or bank. Interest rates, tax rules, grant conditions and bank fees change and vary. Use every prompt here to *understand and prepare*, then confirm specifics with a qualified professional or the institution itself before you sign anything or pay anyone.

**Start with 6.1, 6.3 and 6.5** — true costing, break-even, and separating your money. Those three prevent most business deaths in Nigeria.

---

## Prompt 6.1

### Title: Calculate the True Cost and Real Profit of Each Product

**Use this when:** You "know" your profit is the selling price minus what you paid the supplier — and you've never included transport, packaging, delivery, waste, POS charges, your time, or rent.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[selling price]. Here is everything I can think of that goes into it: purchase/production cost ₦[amount]; transport to get it ₦[amount]; packaging ₦[amount]; delivery cost I absorb ₦[amount]; POS/transfer charges roughly [%]; average discount I give ₦[amount]; waste, returns or spoilage roughly [%]; time I or staff spend per unit [minutes] at a labour cost of ₦[amount] per hour; my monthly fixed costs are ₦[amount] and I sell about [number] units of all products per month. Calculate: (1) the true cost per unit including a fair share of fixed costs, (2) my real profit per unit and real profit margin, (3) how that compares to the profit I *thought* I was making, (4) the minimum price I should never sell below, and (5) three ways to raise the real margin without raising the price.

**Real example (filled in):**

> I sell ready-to-wear women's gowns in Lagos at ₦12,000. Costs: fabric and tailoring ₦6,500; transport to the tailor and market ₦300 per gown on average; packaging (nylon, tag, thank-you card) ₦250; I absorb delivery about half the time, average ₦900 per gown; POS/transfer charges about 1.5%; average discount ₦700; returns/exchange costs roughly 5%; my time per gown on posting, chatting and packing about 40 minutes at ₦1,500/hour; monthly fixed costs (rent, data, generator, assistant) ₦145,000 and I sell about 90 gowns a month. Calculate my true cost per gown, real profit and margin, how it compares to the ₦5,500 I thought I was making, my minimum price, and three ways to raise the margin without raising the price.

**Naija tip:** Almost every Nigerian owner who does this for the first time discovers their real profit is **30–50% lower** than they thought — the "small" costs add up to thousands. That's not bad news; it's the beginning of being profitable on purpose. Do this for your **top 5 products** today. Then look at the cheapest one — it's often not worth selling at all, and dropping it can *raise* your profit.

---

## Prompt 6.2

### Title: Set Prices for Profit (Not Just to Compete)

**Use this when:** You set prices by copying the person next to you, or by "what customers will accept," and your margins are thin.

**Copy this prompt:**

> I run a [business type] in Nigeria. Using the true costs from my products [paste or list true cost per unit], my monthly fixed costs of ₦[amount], and a target of [X]% net profit, help me set proper prices. Give me: (1) a price for each product that hits my profit target, (2) a comparison to current market prices [list them] and advice on where I'm too low, too high, or fine, (3) a pricing strategy — cost-plus, value-based, tiered, or psychological pricing (₦4,990 vs ₦5,000) — that suits my customers, (4) which products to use as "attraction" prices and which are my profit-makers, (5) how to raise prices on existing customers without losing them — timing, wording, and a message template, and (6) how often to review prices given inflation and exchange-rate changes.

**Real example (filled in):**

> I run a small bakery in Kaduna. True cost per unit: family loaf ₦780, small loaf ₦420, meat pie ₦380, chin chin (500g) ₦650, birthday cake 8" ₦7,200. Monthly fixed costs ₦210,000. Target net profit 25%. Market prices: family loaf ₦1,200–₦1,500, small loaf ₦600–₦800, meat pie ₦600–₦800, chin chin ₦1,200–₦1,500, cake ₦15,000–₦25,000. Give me a price for each that hits my target, a comparison with the market, the best pricing strategy for my customers, which products attract and which make profit, how to raise prices on existing customers with a message template, and how often to review given flour and sugar price changes.

**Naija tip:** Raise prices **in small steps, with notice, and with a reason people understand**: "From Monday, family loaf becomes ₦1,400 — flour has gone up 30% since March. Thank you for staying with us." Nigerians accept honest increases; they resent silent ones. And use **attraction pricing** deliberately: keep one visible item (the small loaf) competitively priced to bring people in, and make your money on the cakes and chin chin they add.

---

## Prompt 6.3

### Title: Find Your Break-Even Point (How Much You Must Sell to Survive)

**Use this when:** You don't know the exact daily or monthly sales figure below which you're losing money — so you can't tell a good month from a dangerous one.

**Copy this prompt:**

> I run a [business type] in Nigeria. My monthly fixed costs are: [list: rent, salaries, generator/fuel, data, transport, loan repayment, insurance, subscriptions, levies, your own basic salary]. My products/services and their price and variable cost per unit: [list]. My typical sales mix is roughly [percentages or numbers per product]. Calculate: (1) my monthly break-even in naira and in units, (2) my daily break-even (for the days I'm open), (3) the sales level I need to earn ₦[target profit] per month, (4) how much a 10% price increase or a 10% cost reduction would change my break-even, and (5) a simple "danger signal" rule I can check each week to know if I'm on track.

**Real example (filled in):**

> I run a small restaurant in Owerri, open 26 days a month. Fixed costs: rent ₦50,000; 3 staff ₦120,000; generator and fuel ₦85,000; gas ₦30,000; data and airtime ₦8,000; transport ₦20,000; loan repayment ₦40,000; my own salary ₦100,000. Products: rice and chicken plate (price ₦1,800, variable cost ₦1,050), swallow and soup (₦2,200, ₦1,250), drinks (₦500, ₦320), small chops pack (₦1,500, ₦800). Sales mix: 45% rice plates, 30% swallow, 20% drinks, 5% small chops. Calculate my monthly and daily break-even, sales needed for ₦250,000 profit, the effect of a 10% price increase or 10% cost cut, and a weekly danger-signal rule.

**Naija tip:** Your **daily break-even number** is the most important number in your business. Write it on the wall in the back room: "We need ₦68,000 a day to break even." Now every staff member understands why 3pm with ₦30,000 in the till is a problem, not a rest break. Recalculate it whenever rent, fuel, or salaries change — in Nigeria, that's every few months.

---

## Prompt 6.4

### Title: Build a Simple Weekly Cash-Flow Forecast

**Use this when:** You have "profit" on paper but never seem to have cash when rent, salaries or a big stock purchase is due.

**Copy this prompt:**

> I run a [business type] in Nigeria. Help me build a simple 8-week cash-flow forecast I can keep in a notebook or Google Sheet. My starting cash is ₦[amount]. Expected weekly cash in: [sales estimates by week, plus any money owed to me and when it should arrive]. Expected cash out by week: [stock purchases and dates, rent and date, salaries and date, generator/fuel, loan repayment date, supplier payments, big one-off items coming up]. Show me: (1) a week-by-week table of cash in, cash out, and closing balance, (2) any week where I go negative or dangerously low, and by how much, (3) 5 practical moves to fix those weeks — timing of purchases, collecting debts, deposits from customers, negotiating supplier dates, (4) how much buffer I should aim to keep, and (5) how to update this every Monday in 10 minutes.

**Real example (filled in):**

> I run a building materials shop in Abuja (Kubwa). Starting cash ₦420,000. Expected weekly sales: ₦650k, ₦700k, ₦550k, ₦800k, ₦600k, ₦650k, ₦900k, ₦700k; a contractor owes me ₦380,000 due in week 3. Cash out: cement and rods restock ₦900k in week 1 and ₦1.1M in week 5; rent ₦600k due week 4; salaries ₦180k weeks 4 and 8; generator ₦25k weekly; loan repayment ₦120k in weeks 2 and 6; new delivery tricycle ₦850k planned for week 6. Show me the 8-week table, the weeks I go negative, 5 practical fixes, the buffer I should keep, and a 10-minute Monday update routine.

**Naija tip:** **Profit is an opinion; cash is a fact.** A Nigerian business rarely dies of losses — it dies the week it can't pay rent or restock despite being "profitable." The two fastest fixes: **collect deposits before big jobs** and **pay suppliers on the day after your best sales day**, not before. Once you can see 8 weeks ahead, you stop panicking and start planning — and you'll never again buy a tricycle in the same week rent is due.

---

## Prompt 6.5

### Title: Separate Business Money From Personal Money (Pay Yourself a Salary)

**Use this when:** You take money from the till for school fees, contributions, and family needs, and you honestly can't say how much the business made versus how much you spent.

**Copy this prompt:**

> I run a [business type] in Nigeria. Currently business and personal money are mixed: [describe — one account, taking from the till, paying family from sales, using business money for personal emergencies]. My business makes roughly ₦[revenue] per month with about ₦[profit] profit. My personal and family needs are about ₦[amount] per month. Help me separate them properly: (1) a simple account structure (which accounts to open and what each is for — operating, savings/tax, personal), (2) how to decide a fair, fixed owner's salary and when to pay it, (3) what to do when a personal emergency hits and the money is in the business, (4) how to handle family and community requests for money from "the business," and (5) a 30-day transition plan from mixed to separated, including the conversation I may need to have with my spouse or family.

**Real example (filled in):**

> I run a provisions and drinks shop in Enugu. Currently everything is mixed: one personal bank account, I take cash from the till for school fees, church contributions, and my mother's medicine; relatives assume "the shop is doing well" and ask for help. The business does about ₦1.6M monthly with roughly ₦280,000 profit. My family needs about ₦180,000 a month. Help me: a simple account structure, how to set and pay myself a fixed salary, what to do when an emergency hits, how to handle family and community requests, and a 30-day transition plan including the conversation with my husband.

**Naija tip:** This is the single most important financial habit in this book. **Pay yourself a fixed salary on a fixed day — and nothing else leaves the business for personal use.** When family asks, the answer becomes "the business pays me a salary; I've already spent this month's" — which is true and ends the argument. Open a separate business account (most Nigerian banks and fintechs make this quick) and move to it within 30 days. Businesses that do this survive. Businesses that don't, don't.

---

## Prompt 6.6

### Title: Build a Simple Monthly Profit & Loss (Know Exactly What You Made)

**Use this when:** You want a clear, honest one-page picture every month: sales, costs, profit — without an accountant.

**Copy this prompt:**

> Help me create a simple monthly Profit & Loss statement for my [business type] in Nigeria that I can fill in with a notebook or Google Sheet. My income sources: [list]. My cost categories: [cost of goods/materials, staff, rent, power/fuel, transport/delivery, packaging, marketing, bank/POS charges, repairs, levies, owner's salary, others]. Show me: (1) a clean one-page layout with sections for revenue, cost of sales, gross profit, operating expenses, and net profit, (2) how to fill it in from my daily sales sheet and expense records in under an hour a month, (3) the 5 percentages I should calculate each month (e.g., gross margin, staff cost %, power cost %) and what healthy ranges look like for my type of business, (4) how to compare month to month and spot problems early, and (5) three questions to ask myself when I look at each month's numbers.

**Real example (filled in):**

> Help me create a simple monthly Profit & Loss for my beauty salon and product retail business in Port Harcourt. Income: hair services, nail services, product sales, training classes. Costs: hair and product purchases, 4 staff salaries and commissions, rent, generator and electricity, water, consumables (shampoo, gloves, towels laundry), marketing/data, POS and bank charges, repairs and maintenance, association levies, my own salary. Show me the one-page layout, how to fill it from my daily records in under an hour, the 5 percentages to track with healthy ranges for a salon, month-to-month comparison, and three questions to ask each month.

**Naija tip:** A one-page monthly P&L is what separates a **business** from a **hustle**. It also becomes your strongest weapon when you approach a bank, a grant, or an investor — six months of clean P&Ls answers half their questions before they ask. Fill it in on the first Sunday of every month alongside the operations review from Prompt 4.20. Same tea, same honesty, thirty extra minutes.

---

## Prompt 6.7

### Title: Manage Customers Who Owe You (Debtors) Without Killing the Relationship

**Use this when:** "I'll pay you next week" has become a serious hole in your cash — and you need a system, not more patience.

**Copy this prompt:**

> I run a [business type] in Nigeria. Money currently owed to me: [list debtors by type — e.g., 6 regular customers owing ₦180,000 total, 1 contractor owing ₦400,000 for 2 months, small credits to neighbours ₦35,000]. My total monthly sales are ₦[amount], so debts are about [X]% of a month's sales. Help me: (1) assess which debts are likely recoverable and which I should write off, (2) design a firm-but-friendly collection plan for each debtor type over the next 30 days — messages, calls, part-payment offers, and when to escalate, (3) set a credit policy going forward — who qualifies, limits, terms, and how to say no gracefully, (4) create a simple debtors' register to track everything, and (5) calculate what these debts are costing me in lost stock purchases or interest so I stay motivated to fix it.

**Real example (filled in):**

> I run a wholesale foodstuff business in Ibadan (Bodija). Owed to me: 8 retailers owing between ₦40,000 and ₦150,000 each (₦620,000 total, some for 6+ weeks); one caterer owing ₦280,000 for 3 months who keeps promising; small credits to neighbours and a church member totalling ₦60,000. Monthly sales about ₦4.2M. Help me assess which debts are recoverable, design a 30-day collection plan for each type, set a credit policy going forward with limits and how to say no gracefully, create a debtors' register, and calculate what these debts are costing me.

**Naija tip:** In Nigeria, credit is culture — you cannot refuse everyone, but you can **structure it**. The policy that works: credit only for customers with a **track record** (5+ paid purchases), a **limit** (never more than one week of their average purchases), a **date**, and a **written or WhatsApp record** ("Sent ₦85,000 goods on credit, due Friday 14th — please confirm"). That confirmation message is your evidence and your reminder. Collection tip: a **part-payment request** ("Can you do ₦100k today?") recovers far more than "pay everything now."

---

## Prompt 6.8

### Title: Build an Emergency Fund and a Savings Discipline for the Business

**Use this when:** One bad month, one broken generator, one sick week, or one family emergency could sink the business — and you have nothing put aside.

**Copy this prompt:**

> I run a [business type] in Nigeria with monthly revenue of about ₦[amount], profit of about ₦[amount], and fixed monthly costs of ₦[amount]. I currently save [nothing / an irregular amount]. Help me build a savings system: (1) how big my business emergency fund should be (in months of fixed costs) and a realistic target in naira, (2) how much to set aside weekly or monthly to get there in 6–12 months without starving the business, (3) where to keep it so it's safe, earns something, but isn't too easy to touch — with the trade-offs of options available in Nigeria (I'll verify current rates and terms myself), (4) separate "pots" I should consider — emergency, tax/levies, equipment replacement, expansion — and how to split contributions, and (5) rules for when I'm allowed to touch each pot.

**Real example (filled in):**

> I run a tailoring and fashion business in Abuja with monthly revenue of about ₦1.1M, profit about ₦320,000, and fixed costs of ₦240,000. I currently save irregularly — sometimes ₦20,000, often nothing. Help me build a savings system: how big my emergency fund should be and a naira target, how much to set aside weekly to reach it in 6–12 months, where to keep it safely with the trade-offs of Nigerian options (bank savings, fixed deposit, fintech savings apps, cooperative/ajo, treasury bills), separate pots for emergency, tax, machine replacement and expansion, and rules for touching each.

**Naija tip:** Start with **3 months of fixed costs** as your target — in the example, ₦720,000. It sounds far; at ₦15,000 a week it's 48 weeks. The trick is **automation**: a standing order or a savings-app auto-debit on the day money comes in, before you can see it. Many owners also use a **trusted ajo/cooperative** for discipline — it works, but only with people you truly trust and with records. And keep the emergency pot boring: safe beats high-yield when it's the money that keeps your doors open.

---

## Prompt 6.9

### Title: Understand Your Basic Tax and Levy Obligations (And Stop Fearing Them)

**Use this when:** You avoid the topic of tax entirely, pay random "levies" to whoever shows up, or want to formalise but fear it will cost too much.

**Copy this prompt:**

> I run a [business type] in [state], Nigeria, [registered as a business name / limited company / not registered], with annual revenue of roughly ₦[amount]. Explain in plain language: (1) the main types of taxes and levies a business like mine may be subject to in Nigeria — federal, state, and local — and which ones typically apply at my size, (2) which ones are commonly confused with each other or exploited by fake collectors, and how to identify legitimate demands, (3) the potential advantages of being registered and compliant (bank loans, grants, corporate customers, tenders), (4) simple record-keeping habits that make compliance easy and cheap, and (5) the questions I should ask a tax professional or the relevant tax office to confirm my exact obligations. Be clear about what you are not certain of — I will verify with a professional.

**Real example (filled in):**

> I run a printing and branding business in Lagos, registered as a business name with CAC, annual revenue roughly ₦14M. Explain in plain language: the main taxes and levies that may apply to a business like mine at this size (e.g., personal income tax for a business-name owner, VAT thresholds, state and local levies, signage/business premises levies), which ones fake collectors abuse and how to spot legitimate demands, the advantages of being compliant for getting corporate clients and loans, simple record-keeping habits, and the exact questions to ask a tax professional or the Lagos tax office. Be clear about what you're not certain of.

**Naija tip:** This is a **Check Before You Trust It** prompt in capital letters. Tax rules in Nigeria change (recent reforms have adjusted thresholds and exemptions for small businesses), and they differ by state and structure. Use this prompt to *understand the landscape and prepare your questions*, then spend ₦20,000–₦50,000 on one session with a real accountant. That one session typically saves multiples of its cost — in avoided penalties, avoided fake "levies," and access to opportunities that require compliance.

---

## Prompt 6.10

### Title: Decide Whether You Should Take a Loan (And What Kind)

**Use this when:** A loan offer is on the table — bank, microfinance, fintech app, cooperative, or a "friend" — and you want to think clearly before you sign.

**Copy this prompt:**

> I run a [business type] in Nigeria and I'm considering borrowing ₦[amount] for [purpose]. The loan terms offered: [interest rate and whether monthly or annual, tenure, repayment schedule, fees, collateral or guarantor requirements, lender type]. My business numbers: monthly revenue ₦[amount], monthly profit ₦[amount], current cash ₦[amount], existing debts ₦[amount]. Help me decide: (1) the total cost of this loan in naira over its life, and the true annual interest rate if it was quoted monthly, (2) whether the purpose will generate enough extra profit to repay it comfortably — show the calculation, (3) the risks specific to this type of lender in Nigeria and warning signs of a bad deal, (4) alternatives to borrowing — deposits, pre-orders, supplier credit, selling idle assets, slower growth, (5) if I do borrow, the maximum I should take and the questions to ask before signing. Be honest if this is a bad idea.

**Real example (filled in):**

> I run a frozen foods shop in Lagos and I'm considering borrowing ₦1.5M from a fintech lending app to buy a second deep freezer and stock up before December. Terms: 6% per month, 6 months, equal monthly repayments, 2% processing fee, no collateral, guarantor required. My numbers: monthly revenue ₦2.2M, profit ₦310,000, cash ₦280,000, existing debt ₦0. Help me decide: total cost of the loan and true annual rate, whether the freezer and December stock will generate enough extra profit to repay comfortably, risks with fintech lenders in Nigeria and warning signs, alternatives to borrowing, and if I borrow, the maximum amount and the questions to ask. Be honest if this is a bad idea.

**Naija tip:** The most dangerous words in Nigerian small-business lending are **"just 5% monthly"** — that is over 60% a year before fees, and it can destroy a business that makes 15% margins. Rules: **only borrow for things that make money** (stock that sells, equipment that produces), never for rent or salaries; never borrow more than you can repay from *current* profit if the plan fails; and read every line about defaults, late fees, and access to your contacts or bank account. If a lender rushes you, walk away.

---

## Prompt 6.11

### Title: Find Grants, Competitions and Support Programmes You Actually Qualify For

**Use this when:** You hear about grants and business competitions but never apply — or you apply to everything and win nothing.

**Copy this prompt:**

> I run a [business type] in [state], Nigeria. Details: [gender/age of owner, years in business, registered or not, revenue, number of staff, sector, whether it's a youth/women/agri/tech/creative business, any social impact]. Help me approach grants and support programmes strategically: (1) the *types* of programmes that typically exist for a business like mine in Nigeria — government agencies, development banks, bank foundations, corporate CSR, international organisations, business competitions, accelerators — and what each usually looks for, (2) how to check whether a programme is legitimate and current, and red flags of grant scams, (3) what I should prepare in advance so I can apply quickly when one opens — documents, numbers, a short business profile, photos, (4) how to write answers that stand out to reviewers, and (5) a realistic plan: how many to apply to per quarter and how to track them. Note that I will verify specific programme names, deadlines and criteria myself.

**Real example (filled in):**

> I run a cassava processing business (garri and fufu flour) in Ogun State. Owner: female, 34, registered business name, 3 years in business, revenue about ₦9M a year, 5 staff (4 women), agri-processing sector, we buy from 30 smallholder farmers. Help me approach grants strategically: the types of programmes that exist for a women-led agri-processing business in Nigeria and what each looks for, how to verify legitimacy and spot scams, what to prepare in advance, how to write standout answers, and a quarterly application plan. I'll verify specific programme names and deadlines myself.

**Naija tip:** Grants are won by the **prepared**, not the deserving. Keep a "Grant Folder" always ready: CAC certificate, TIN, 6 months of P&Ls, bank statements, a 1-page business profile, 10 good photos, and a 2-minute video pitch on your phone. Then when a legitimate opportunity opens with a 5-day deadline, you apply in 2 hours while everyone else scrambles. And the golden rule: **legitimate grants never ask you to pay a fee to receive money.** Never.

---

## Prompt 6.12

### Title: Write a Business Proposal or Plan That Banks, Grants and Investors Take Seriously

**Use this when:** You need a formal document — for a loan application, a grant, an investor, or a corporate partner — and you want it to read like a serious business, not a school essay.

**Copy this prompt:**

> Write a professional business plan/proposal for my [business type] in [location], Nigeria, for the purpose of [loan application / grant / investor / partnership]. Business facts: [what we do, when started, registration, owner background, team, customers, monthly revenue and profit for the past 6–12 months, key achievements, what makes us different, competitors]. The ask: ₦[amount] for [detailed use of funds], expected results [revenue, jobs, expansion], and repayment/return plan [if applicable]. Structure it with: executive summary, business description, market and customers, products/services, marketing and sales strategy, operations, management team, financial summary (past and 12-month projection table), use of funds, risks and how we'll manage them, and the ask/closing. Keep it clear, factual and confident — about 3–5 pages — with simple tables where helpful.

**Real example (filled in):**

> Write a professional business plan for my poultry farm in Ibadan for a ₦4M loan application to a development bank. Facts: started 2022, registered business name, I have a diploma in animal science and 3 staff; we run 2,000 layers producing about 55 crates daily, plus broilers at festive periods; customers are 12 shops, 3 restaurants and walk-in families; revenue averages ₦2.9M monthly with ₦520,000 profit over the past 8 months; we've never missed a supply day. The ask: ₦4M to add a 2,000-bird pen (₦2.2M), birds (₦1.4M) and feed buffer (₦400k); expected to double egg output within 6 months, adding 2 jobs; repayment over 24 months from increased profit. Structure it fully with a financial summary table and 12-month projection, use of funds, risks, and closing.

**Naija tip:** Reviewers at Nigerian banks and grant bodies read dozens of proposals — what stands out is **specific numbers, real track record, and a clear use of funds**. "₦2.2M for a 2,000-bird pen (quote attached)" beats "funds for expansion." Attach evidence: photos, supplier quotes, bank statements, customer letters. Have the AI's draft reviewed by someone who has actually received funding before you submit — and always tailor the executive summary to the specific programme's stated goals.

---

## Prompt 6.13

### Title: Create a 12-Month Financial Projection (Realistic, Not Fantasy)

**Use this when:** A funder asks for projections, or you want to see where your business could be in a year — based on believable assumptions.

**Copy this prompt:**

> Help me build a realistic 12-month financial projection for my [business type] in Nigeria. Starting point: monthly revenue ₦[amount], cost of sales [%], monthly fixed costs ₦[amount], current profit ₦[amount]. Planned changes and their timing: [e.g., new product in month 3, price increase of 8% in month 4, second staff in month 5, seasonal peaks in months 11–12, a loan repayment of ₦X monthly from month 2]. Assumptions I believe are reasonable: [growth rate, inflation on costs, seasonality]. Produce: (1) a month-by-month table with revenue, cost of sales, gross profit, fixed costs, net profit and cumulative cash, (2) a conservative, expected, and optimistic scenario, (3) the assumptions listed clearly so a funder can see them, (4) the months I should watch for cash pressure, and (5) the 3 assumptions that most affect the outcome — so I know what to track.

**Real example (filled in):**

> Build a realistic 12-month projection for my skincare production business in Lagos. Starting: monthly revenue ₦1.4M, cost of sales 42%, fixed costs ₦380,000, profit about ₦430,000. Planned: reseller programme launching month 2 (expected +₦150k/month growing to +₦500k by month 8), price increase of 8% in month 4, one extra production staff in month 5 (+₦60k), a ₦1.2M packaging-machine loan repaid at ₦120k/month from month 2, Christmas gift-set peak in months 11–12 (+40%). Assumptions: 4% monthly growth in core sales, 2% monthly inflation on materials. Produce the month-by-month table, three scenarios, listed assumptions, cash-pressure months, and the 3 assumptions that matter most.

**Naija tip:** Funders in Nigeria have seen a thousand "hockey stick" projections; **conservative and explained** builds far more trust than optimistic and vague. Always show the three scenarios — it proves you've thought about downside. And build inflation into costs; a projection that assumes flour, fuel and packaging stay flat for 12 months is not credible in Nigeria. Revisit the projection every quarter and note where reality differed — that record makes your *next* projection much stronger.

---

## Prompt 6.14

### Title: Decide Whether to Reinvest, Save or Pay Yourself More

**Use this when:** Profit is finally coming in, and you don't know how to split it between growing the business, protecting it, and enjoying it.

**Copy this prompt:**

> My [business type] in Nigeria now makes about ₦[profit] per month after paying me a salary of ₦[amount]. My emergency fund is at ₦[amount] (target ₦[amount]). Debts: ₦[amount]. Opportunities to reinvest: [list with estimated cost and expected return — more stock, equipment, staff, marketing, a second location]. Personal goals: [list — house rent, children's fees, a car, savings]. Help me create a profit-allocation rule: (1) a sensible percentage split between reinvestment, emergency/savings, debt repayment, tax set-aside, and owner's bonus at my current stage, (2) which reinvestment options give the best return for the risk, ranked, (3) when I should pay myself more versus keep reinvesting, (4) a simple rule I can apply automatically every month so I don't decide emotionally, and (5) how this split should change as the business grows.

**Real example (filled in):**

> My phone accessories and repair business in Onitsha now makes about ₦450,000 profit monthly after paying me ₦150,000 salary. Emergency fund ₦200,000 (target ₦600,000). Debt ₦0. Reinvestment options: more fast-moving stock (₦300k, could add ₦120k/month profit), a second technician (₦60k/month, could add ₦150k/month if demand holds), a small second kiosk near the polytechnic (₦900k setup, uncertain), social media ads (₦40k/month, unknown return). Personal goals: rent due in 5 months (₦700k), a used car. Help me create a profit-allocation rule with percentages, rank the reinvestments, tell me when to pay myself more, give me an automatic monthly rule, and show how it should change as I grow.

**Naija tip:** The **"profit first" habit** for Nigerian small businesses: the moment monthly profit is known, split it *immediately* by fixed percentages — e.g., 40% reinvest, 25% savings/emergency, 15% tax/levies pot, 20% owner's bonus — into separate accounts or envelopes. Deciding once and automating beats deciding every month under pressure from family, opportunities and temptation. Adjust the percentages quarterly, not weekly.

---

## Prompt 6.15

### Title: Evaluate a Second Branch, Bigger Shop or Major Expansion

**Use this when:** You're tempted to open another location, move to a bigger space, or triple your capacity — and you want a clear-headed assessment before committing.

**Copy this prompt:**

> I run a [business type] in [current location], Nigeria, and I'm considering [second branch in X / moving to a bigger shop / doubling production capacity]. Current business: revenue ₦[amount], profit ₦[amount], how long profitable, how dependent it is on me personally, staff quality. The expansion: estimated setup cost ₦[amount], monthly running cost ₦[amount], expected revenue ₦[amount] after [months], how I'd fund it, who would run it. Give me: (1) an honest readiness assessment — is my current business stable and systemised enough to survive my attention being split, (2) the financial case — payback period, break-even for the new unit, and what happens to my cash in the first 6 months, (3) the 5 biggest reasons expansions fail in Nigeria and how each applies to me, (4) a lower-risk way to test the expansion first, and (5) a go/no-go checklist with the conditions I must meet before committing.

**Real example (filled in):**

> I run a successful buka in Yaba, Lagos — revenue ₦2.6M, profit ₦480,000, profitable for 2 years, but very dependent on me (I cook the soups and manage cash), and my staff are okay but not leaders. I'm considering a second buka in Surulere: setup ₦2.8M (rent, kitchen, furniture), monthly running ₦900k, expected revenue ₦2M after 4 months, funded from ₦1.5M savings plus a ₦1.3M loan, run by my most senior staff. Give me an honest readiness assessment, the financial case with payback and break-even and first-6-months cash picture, the 5 biggest reasons expansions fail in Nigeria and how they apply to me, a lower-risk way to test first, and a go/no-go checklist.

**Naija tip:** The second branch is where many good Nigerian businesses die. The reason is almost never the market; it's that **the first branch was really the owner**, and the owner cannot be in two places. Before expanding: leave your current branch for two full weeks and see what happens. If revenue holds and nothing burns, you have a system. If it collapses — fix that first; it's cheaper than a second rent. Test with a **lower-risk version** — a delivery-only kitchen, a weekend stand, a partnership — before a full second shop.

---

## Prompt 6.16

### Title: Prepare for an Investor Conversation (Equity, Partners, Family Money)

**Use this when:** Someone — an investor, a wealthy relative, a friend, a business partner — is offering money for a share of your business, and you want to protect yourself and your business.

**Copy this prompt:**

> I run a [business type] in Nigeria, revenue ₦[amount], profit ₦[amount], [years] in business. Someone is offering ₦[amount] for [X% of the business / a profit share / a loan with conditions]. Details of the person and the offer: [describe]. Help me think clearly: (1) roughly what my business might be worth on simple, common-sense measures, and whether the offer is fair — explaining the reasoning, (2) the difference between equity, profit-share, and a loan, and which suits my situation, (3) the critical questions to ask them and the terms I must get in writing — decision rights, profit distribution, exit, what happens if things go wrong, family dynamics if applicable, (4) red flags in investor or partner deals common in Nigeria, (5) how to structure a smaller first step (a trial period or milestone-based investment), and (6) the point at which I must involve a lawyer. Be honest about what you can't judge without more information.

**Real example (filled in):**

> I run a fashion production business in Aba (ready-to-wear for boutiques), revenue ₦3.1M monthly, profit ₦620,000, 4 years in business. My uncle's friend, a businessman in Lagos, is offering ₦8M for 40% of the business — he says he'll bring "connections" but won't be involved daily. Help me think clearly: a rough common-sense sense of what my business might be worth and whether 40% for ₦8M is fair, equity vs. profit-share vs. loan for my situation, critical questions and terms to get in writing (decision rights, profit distribution, exit, disputes), red flags in such deals in Nigeria, how to structure a smaller trial step, and when I must involve a lawyer.

**Naija tip:** Never take investment money on a handshake — **especially from family or "family friends"**; those are the deals that end businesses and relationships together. Insist on a written agreement, get a lawyer (₦50,000–₦150,000 for a simple agreement is cheap insurance), and start with a **milestone-based or smaller first tranche**. And remember: 40% of your business forever, for money you could raise from profits in 13 months, is usually a bad trade. Money is the *least* valuable thing a good investor brings — ask what else they offer, and get that in writing too.

---

## Prompt 6.17

### Title: Protect Your Business Against Nigerian Risks (Inflation, Naira, Theft, Fire, Illness)

**Use this when:** You want to stop living one disaster away from closure — and build simple protections against the risks every Nigerian business faces.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Help me identify and protect against the risks most likely to hurt my business: inflation and rising costs, naira depreciation (especially if I buy imported goods), theft by staff or outsiders, fire or flood, my own illness or absence, a key staff member leaving, a key supplier failing, a major customer leaving, power failure spoiling stock, government demolition or relocation, and family or community disputes. For each risk: how likely and how damaging it is for my specific business, one or two practical, affordable protections (habits, systems, insurance, contracts, diversification, savings), and what to do in the first 24 hours if it happens. Then rank the top 5 risks I should address this month.

**Real example (filled in):**

> I run a frozen foods and drinks shop in Kano. Help me identify and protect against the risks most likely to hurt me — inflation, naira depreciation (some frozen fish and chicken prices track the dollar), staff theft, fire from the generator, power failure spoiling stock, my own illness, my only experienced staff leaving, my main fish supplier failing during Ramadan demand, a market relocation, and disputes. For each: likelihood and damage for my shop, one or two affordable protections, and what to do in the first 24 hours if it happens. Rank my top 5 risks to address this month.

**Naija tip:** Most Nigerian business protection is **cheap and boring**: a second supplier you buy 20% from (so they know you), a fire extinguisher by the generator, a full-freezer-and-bottles habit, a stock count that surprises, a written SOP so the shop runs when you're sick, and a **3-month emergency fund**. Look into simple **micro-insurance** for fire and stock — several Nigerian insurers offer affordable plans; verify terms carefully (*Check Before You Trust It*). Bonus 15 gives you a full Risk & Survival Decision Matrix.

---

## Prompt 6.18

### Title: Handle Inflation and Rising Costs Without Losing Customers

**Use this when:** Your costs rose 20–40% this year, your customers' incomes didn't, and you're squeezed between raising prices and losing sales.

**Copy this prompt:**

> I run a [business type] in Nigeria. Over the past [months], my main costs have risen: [list items and percentage increases]. My customers are [describe, including their income pressure]. My current margins are [describe]. Help me respond intelligently to inflation: (1) which costs I can offset through substitution, supplier changes, or efficiency, (2) how to adjust prices — full pass-through, partial, or phased — and what each does to my margin and likely sales, (3) "shrink or split" options — smaller sizes, portion options, tiered products — that protect access for poorer customers while keeping margins, (4) how to communicate increases honestly and keep loyalty, and (5) what to watch monthly so I'm not caught off guard again.

**Real example (filled in):**

> I run a small bakery in Enugu. Over the past 8 months: flour up 35%, sugar up 28%, butter and margarine up 40%, diesel up 25%, packaging up 20%. My customers are working families, students and small retailers who are also under pressure. Margin on family loaf has fallen from about 30% to 12%. Help me respond intelligently: costs I can offset through substitution or efficiency, how to adjust prices (full, partial, phased) and the effect on margin and sales, "shrink or split" options like smaller loaf sizes or a student loaf, how to communicate increases honestly, and what to watch monthly.

**Naija tip:** The most successful Nigerian responses to inflation share one idea: **give customers a choice instead of a shock.** Keep a smaller, cheaper option ("student loaf ₦600") beside the standard, so no one is priced out, while your standard product carries a proper margin. Review prices **monthly** now, not yearly — small regular adjustments are accepted; one big jump after months of silence causes anger. And tell the truth: "flour has gone up again" is a sentence every Nigerian understands.

---

## Prompt 6.19

### Title: Create Your Monthly Money Review Routine

**Use this when:** You want one simple monthly ritual that keeps your finances healthy — bringing together your P&L, cash flow, debtors, savings and decisions in under an hour.

**Copy this prompt:**

> Design a monthly money review routine for my [business type] in Nigeria that takes under 60 minutes and uses only my daily sales sheet, expense records, bank/POS statements, debtors' list and savings balances. Give me: (1) a step-by-step agenda with time for each step, (2) the 10 numbers I must produce each month (revenue, gross profit, net profit, key cost percentages, cash position, debtors, savings, break-even coverage, etc.) and a one-page template to record them, (3) the 5 questions to answer every month based on those numbers, (4) the decisions this review should trigger — price changes, cost cuts, collections, savings top-up, reinvestment, (5) how to compare to previous months and my 90-day target, and (6) a short prompt I can paste into AI each month with my numbers to get an instant analysis.

**Real example (filled in):**

> Design a monthly money review for my bakery and small-chops business in Port Harcourt that takes under 60 minutes, using my daily sales sheet, expense notebook, bank and POS statements, my debtors' list (3 event clients), and my savings-app balance. Give me a timed agenda, the 10 numbers to produce each month with a one-page template, the 5 questions to answer, the decisions it should trigger, comparison to previous months and my 90-day target of ₦2M extra revenue, and a short prompt I can paste into AI with my numbers each month for instant analysis.

**Naija tip:** Put it in your calendar: **first Sunday of every month, 4pm, phone on silent.** Do the operations review (4.20) and this money review together — ninety minutes that will change your business more than ninety hours of hustle. Keep every month's one-page template in one folder. In twelve months you will hold something almost no small business in your market has: a **year of clean, honest numbers** — and every bank, grant and investor will notice.

---

## Prompt 6.20

### Title: Build Your 90-Day Growth Plan (Bring It All Together)

**Use this when:** You've worked through this book and want a single, focused 90-day plan to reach the extra ₦1.5M–₦3M and the 35% cost cut — with weekly actions, not just intentions.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Current monthly revenue ₦[amount], profit ₦[amount], monthly costs ₦[amount]. My 90-day targets: extra revenue of ₦[amount] total and a cost reduction of [X]%. Here's what I've learned and decided from my research and planning: ideal customer [summary]; best marketing channels [summary]; sales fixes [summary]; cost cuts identified [summary with naira]; new products/streams to launch [summary]; financial habits to install [summary]. Turn all this into a 90-day plan: (1) three 30-day phases, each with a theme and 3–5 measurable goals, (2) a week-by-week action list (13 weeks) with no more than 5 actions per week, (3) the numbers to track weekly and the targets for each week, (4) the likely obstacles in each phase and how to handle them, and (5) a one-paragraph statement of what my business looks like on day 90 if I execute this.

**Real example (filled in):**

> I run a unisex salon in Ikeja, Lagos. Current revenue ₦850,000, profit ₦280,000, costs ₦570,000. 90-day targets: ₦1.8M extra revenue total and a 35% cost cut. What I've decided: ideal customer is a working woman 25–40 who values speed and style longevity; best channels are WhatsApp Status, referrals and Instagram Reels; sales fixes are a proper enquiry script, upsells on every service, and a deposit policy; cost cuts are generator scheduling (₦35k), supplier negotiation (₦20k), waste and product control (₦15k), fixed WhatsApp hours to free my time; new streams are a retail product line, Monday-morning slots, a braiding class and home-service barbing; financial habits are a separate account, owner's salary, daily cash sheet, monthly P&L. Turn this into a 90-day plan with three phases, a 13-week action list, weekly numbers and targets, obstacles per phase, and a day-90 statement.

**Naija tip:** Print the 13-week plan and paste it where you'll see it every morning. Tick the actions. Track the numbers in the 90-Day Revenue Growth Tracker (Bonus 1). Some weeks you'll miss — NEPA, family, a sick child; that's Nigeria, that's life. Don't restart; just do the next week. The owners who reach ₦1.5M–₦3M extra are not the ones who executed perfectly — they are the ones who **kept going for all thirteen weeks.** You've already done the hard part: you now understand your business better than 95% of your competitors. Go and prove it.

---

## Part 6 Checkpoint

Before moving to the Bonus Section, make sure these five are **done**:

1. You know the **true cost and real profit** of your top 5 products. *(6.1)*
2. Your **daily break-even number** is calculated and on the wall. *(6.3)*
3. Business and personal money are **separated**, and you pay yourself a fixed salary. *(6.5)*
4. A **monthly P&L and money review** is scheduled for the first Sunday of every month. *(6.6, 6.19)*
5. Your **90-day growth plan** is printed and week 1 has started. *(6.20)*

---

## You've Completed the 120 Prompts

Six Parts. One hundred and twenty prompts. If you have worked through them honestly, your business is now different from the one you started with:

- You **know your customer** — by name, need, and fear.
- You **market for almost nothing** — consistently, from your phone.
- You **close more sales at better prices** — with scripts, proof, and a floor.
- You **run on systems** — SOPs, automation, controlled costs.
- You **earn from more than one direction** — bundles, tiers, classes, subscriptions, resellers.
- You **keep your money** — true costs, break-even, separate accounts, monthly reviews, a plan.

Everything that follows in the Bonus Section is a ready-to-use tool that makes this faster: trackers, calculators, message banks, templates, and decision frameworks — all built for Nigerian businesses like yours.

**Next: The Bonus Section — 15 Ready-to-Use Tools (Bonus 1 – 15)**


<div class='pb'></div>

# BONUS SECTION: 15 READY-TO-USE TOOLS
*(Bonus 1 – 8 in this file; Bonus 9 – 15 in the next)*

---

## How to Use the Bonus Section

Everything in the six Parts asked you to *think*. This section gives you things to *use* — today, from your phone.

Each bonus is one of three types:

- **📋 Template** — copy the layout into a notebook, Google Sheet or Google Doc, and fill it in.
- **🤖 Prompt Pack** — paste into Meta AI, ChatGPT, Gemini or DeepSeek and answer its questions.
- **📊 Calculator / Tracker** — a table with simple formulas you fill weekly or monthly.

**Setting up the trackers on your phone (2 minutes):** open the free Google Sheets app → new blank sheet → type the column headings exactly as shown → save. Or draw the table in a ruled notebook — it works just as well. Whichever you choose, **the tool only works if you fill it in.**

Every template uses ₦ and Nigerian realities. Adapt any wording to your business.

---

## BONUS 1 📊 — 90-Day Revenue Growth Tracker

**What it does:** Tracks whether you are on course for the extra ₦1.5M–₦3M, week by week, so you can correct early instead of discovering a miss on day 90.

**How to use:** Fill in your baseline (average monthly revenue for the 3 months before you started). Divide your 90-day extra-revenue target by 13 to get a weekly target. Every Sunday, fill in one row.

### Setup

| Item | Your figure |
|---|---|
| Baseline monthly revenue (avg. of last 3 months) | ₦ |
| Baseline weekly revenue (monthly ÷ 4.33) | ₦ |
| 90-day extra revenue target (₦1.5M–₦3M) | ₦ |
| Weekly extra target (target ÷ 13) | ₦ |
| Weekly revenue target (baseline weekly + weekly extra) | ₦ |
| Start date | |

### Weekly Tracker

| Week | Dates | Revenue this week (₦) | Target (₦) | Above/below target (₦) | Cumulative extra vs. baseline (₦) | New customers | Repeat customers | Biggest win | Biggest lesson |
|---|---|---|---|---|---|---|---|---|---|
| 1 | | | | | | | | | |
| 2 | | | | | | | | | |
| 3 | | | | | | | | | |
| 4 | | | | | | | | | |
| 5 | | | | | | | | | |
| 6 | | | | | | | | | |
| 7 | | | | | | | | | |
| 8 | | | | | | | | | |
| 9 | | | | | | | | | |
| 10 | | | | | | | | | |
| 11 | | | | | | | | | |
| 12 | | | | | | | | | |
| 13 | | | | | | | | | |
| **Total** | | | | | | | | | |

**Formulas (Google Sheets):** Above/below = `revenue − target`. Cumulative extra = previous cumulative + `(revenue − baseline weekly)`.

### Monthly Checkpoints

| Checkpoint | Target cumulative extra | Actual | On track? (Y/N) | What to change |
|---|---|---|---|---|
| Day 30 | ⅓ of target | | | |
| Day 60 | ⅔ of target | | | |
| Day 90 | Full target | | | |

**The Sunday question:** *"If I'm below target — is it fewer enquiries (marketing problem, Part 2), fewer conversions (sales problem, Part 3), or smaller sales (bundle/upsell problem, Parts 3 & 5)?"* Fix the one that applies.

---

## BONUS 2 📊 — Monthly Business Expense Tracker

**What it does:** Shows where every naira goes, month by month, and whether you are hitting the 35% cost reduction.

**How to use:** Record expenses daily (or from receipts weekly). Total each category at month-end. Compare against your baseline month.

### Categories & Monthly Totals

| Category | Baseline month (₦) | Month 1 (₦) | Month 2 (₦) | Month 3 (₦) | Change vs. baseline (%) | Notes / action |
|---|---|---|---|---|---|---|
| Stock / raw materials | | | | | | |
| Rent (monthly share) | | | | | | |
| Staff salaries & commissions | | | | | | |
| Generator fuel & servicing | | | | | | |
| Electricity (grid) | | | | | | |
| Gas / water | | | | | | |
| Transport & market runs | | | | | | |
| Delivery / dispatch | | | | | | |
| Packaging | | | | | | |
| Data & airtime | | | | | | |
| POS, bank & transfer charges | | | | | | |
| Marketing (printing, ads, gifts) | | | | | | |
| Repairs & maintenance | | | | | | |
| Waste / spoilage / returns | | | | | | |
| Levies, dues & permits | | | | | | |
| Loan repayment | | | | | | |
| Owner's salary (fixed) | | | | | | |
| Other | | | | | | |
| **TOTAL** | | | | | | |
| **Total excluding stock & owner's salary** | | | | | | |
| **Revenue** | | | | | | |
| **Expenses as % of revenue** | | | | | | |

**Your 35% target** applies to *operating* costs (the "excluding stock & owner's salary" line). Stock rises when sales rise — that's good.

### Daily Expense Log (feeds the table above)

| Date | Item | Category | Amount (₦) | Paid from (till / bank / personal) | Receipt? |
|---|---|---|---|---|---|

**Red flags to watch:** generator > 10% of revenue · waste > 3% of revenue · bank/POS charges > 1.5% of revenue · "Other" > 5% (means you're not categorising).

---

## BONUS 3 🤖 — Customer Avatar & Persona Builder

**What it does:** Produces a one-page profile of your ideal customer you can print and share with staff. Deeper than Prompt 1.1 — it interviews you first.

**Prompt (paste in full):**

> I want to build a detailed customer avatar for my business in Nigeria. First, ask me these questions one at a time and wait for my answer before the next: (1) What do I sell and at what price range? (2) Where is my business and where do most customers come from? (3) Describe my 3 best customers — age, gender, occupation, roughly what they earn, family situation. (4) What do they say when they thank me or recommend me? (5) What do they complain or worry about before buying? (6) Where do they spend time online and offline? (7) What else do they buy regularly from other businesses? (8) What would make them stop buying from me? After my answers, produce a ONE-PAGE Customer Avatar with: a name and photo description, a 3-line life summary, income and spending habits in naira, top 3 goals, top 3 frustrations, buying triggers, objections, where to find them, how they like to be spoken to, the exact words they use, and 5 rules for my staff on serving this person. Then produce a shorter "secondary avatar" for my second most important customer type.

### Avatar Card Template (fill from the AI's output)

| Field | Details |
|---|---|
| Name & age | |
| Occupation & monthly income | |
| Lives / works | |
| Family situation | |
| What they buy from me & how often | |
| Average spend | |
| Top 3 goals | 1. 2. 3. |
| Top 3 frustrations | 1. 2. 3. |
| Buying triggers (what makes them buy today) | |
| Objections (what makes them hesitate) | |
| Where to reach them | |
| How they like to be spoken to | |
| Words they use | |
| Staff rules for serving them | 1. 2. 3. 4. 5. |

Print it. Paste it in the back room. Every new staff member reads it on day one.

---

## BONUS 4 📋 — Social Media Content Calendar (30/60/90 Days)

**What it does:** A repeatable weekly rhythm for WhatsApp Status (primary), plus Instagram/TikTok/Facebook if you use them — so you never wonder what to post.

### The Weekly Rhythm (repeat every week)

| Day | Theme | WhatsApp Status (2–3 posts) | Instagram / TikTok / Facebook (optional, 1 post) |
|---|---|---|---|
| **Monday** | Motivation & Menu/Range | Morning greeting + what's available this week + one product shot | Reel: "What's new this week" |
| **Tuesday** | Teach | One tip related to your product (care, use, choice) + product that solves it | Carousel or short tip video |
| **Wednesday** | Proof | Customer testimonial screenshot/voice note + the product they bought | Testimonial post |
| **Thursday** | Behind the Scenes | Making/packing/sourcing + a personal line about your day | Process Reel |
| **Friday** | Offer | Weekend deal, bundle or "5 slots left" + clear how-to-order | Offer graphic |
| **Saturday** | Community | Ask a question / poll / celebrate a customer / Nigerian humour | Engagement post |
| **Sunday** | Rest & Story | A gratitude post, your business story, or nothing — rest is allowed | Story-style post |

### Monthly Layers (add on top of the weekly rhythm)

| Week | Monthly feature |
|---|---|
| Week 1 | Announce this month's featured bundle or new item |
| Week 2 | Testimonial round-up (3 in a row) |
| Week 3 | Mid-month "small chops" pricing / smaller-size offer (mid-month cash is tight) |
| Week 4 | Salary-week push: premium items, bundles, pre-orders for next month |

### 90-Day Themes

| Days | Focus | Goal |
|---|---|---|
| 1–30 | **Foundation** — profile complete, daily posting habit, first testimonials | Consistency; 30+ new saved contacts |
| 31–60 | **Proof & Offers** — testimonials, bundles, referral programme launch | Conversions; referral system live |
| 61–90 | **Scale** — seasonal campaign, new product/stream launch, Reels if visual | Revenue; 90-day target |

### Content Planning Sheet

| Date | Day theme | Post 1 (caption) | Post 2 (caption) | Photo/video needed | Posted? | Replies/enquiries |
|---|---|---|---|---|---|---|

**Batch tip:** Every Sunday evening, take 15–20 photos/short videos for the week. Ask AI (Prompt 2.2) for the captions. Posting then takes 3 minutes a day.

---

## BONUS 5 🤖 — AI Prompt Cheat Sheet (Quick Reference)

**What it does:** The most useful one-line prompt starters, ready to memorise or copy — plus the rules that make every prompt work better.

### The 5 Rules of a Good Prompt

1. **Give context:** "I run a [business] in [place], Nigeria, selling [X] to [Y]."
2. **Give numbers:** prices, costs, quantities, dates. Vague in, vague out.
3. **Ask for a format:** "as a table," "in 5 bullet points," "under 60 words," "step by step."
4. **Set the tone:** "simple Nigerian English," "warm, not pushy," "honest, not flattering."
5. **Iterate:** "Make it shorter." "More practical." "Give me 3 more options." "Ask me questions first."

### Universal Fix-It Prompt (when the answer isn't right)

> *"That answer isn't quite right. I need it to be more practical for a Nigerian small business. Make it simpler, use plain English with Pidgin only if useful, give concrete examples, and avoid guesswork. Try again, using this feedback: [explain what you want changed]."*

### Quick Starters by Task

| Task | Starter |
|---|---|
| Write a message | "Write a warm WhatsApp message under 60 words to a customer who [situation]. End with a clear next step." |
| Reply to an objection | "A customer said '[objection]'. Give me 3 short replies that acknowledge, answer, and ask a follow-up question." |
| Caption a photo | "Write 3 captions under 40 words for [product, price, benefit] for Nigerian buyers. One problem-led, one story, one offer." |
| Calculate | "Calculate [what] using these numbers: [list]. Show your working. Ask me if you need a number I haven't given." |
| Plan | "Create a [7/30/90]-day plan for [goal] with no more than 5 actions per week, for a busy owner." |
| Decide | "Help me decide between [A] and [B]. List pros, cons, costs, risks, and give a recommendation with conditions." |
| Learn | "Explain [topic] to a Nigerian small-business owner with no finance background, using an example from a [business type]." |
| Role-play | "Play a [type of customer]. Be realistic and difficult. After 3 exchanges, pause and give me feedback." |
| Summarise | "Summarise these messages into a to-do list with priorities: [paste]." |
| Translate tone | "Rewrite this to sound [more polite / firmer / simpler / more professional]: [paste]." |
| Check my work | "Review this [price list / policy / message] for errors, unclear lines, and anything a Nigerian customer might misunderstand." |
| Daily assistant | "Act as my business assistant. Today I need help with: [list]. Do each clearly, one after the other." |

### Power Phrases to Add

- "…for a Nigerian small business with limited capital."
- "…in simple English a school-leaver can understand."
- "…be honest, don't just encourage me."
- "…ask me questions before answering."
- "…give me a table I can print."
- "…what am I not seeing?"

### Where to Type It

**Meta AI in WhatsApp** (free, no data-heavy app): open WhatsApp → the blue-purple circle icon → type. Or message the Meta AI contact directly. Also: ChatGPT, Gemini, DeepSeek apps or websites. Same prompts work everywhere.

---

## BONUS 6 📋 — WhatsApp Business Profile Optimizer

**What it does:** A checklist and fill-in template that turns your WhatsApp Business profile into a 24-hour salesperson.

### Step 1 — Setup Checklist

- [ ] Using **WhatsApp Business** (green icon with "B"), not regular WhatsApp
- [ ] Profile photo: clear logo or your face with product — bright, not blurry
- [ ] Business name: exactly as customers know you
- [ ] Category selected correctly
- [ ] Description filled (see template)
- [ ] Address or delivery area filled
- [ ] Business hours set
- [ ] Email / website / Instagram link added (if any)
- [ ] Catalogue: at least 5 items with photo, price, description
- [ ] Greeting message ON
- [ ] Away message ON
- [ ] At least 10 Quick Replies saved
- [ ] Labels created (New lead · Paid · Delivered · Repeat · VIP · Bulk · Owes money)
- [ ] Short link (Business tools → Short link) copied and used everywhere

### Step 2 — Profile Copy Templates (fill the brackets)

**About line (under 139 characters):**
> [What you sell] for [who] in [area] • [key promise: fresh daily / 6-month warranty / same-day delivery] • Order: just message!

**Business description (under 500 characters):**
> Welcome to [Business Name]! We [make/sell/offer] [products/services] for [customer type] in [area/nationwide]. Why customers choose us: [1], [2], [3]. 🕐 Open [days, hours]. 🚚 Delivery: [areas, timing, fee]. 💳 Pay by transfer, POS or [payment link]. 📲 To order: send the item name + quantity + delivery address. Run by [your first name] — real person, real products, since [year].

**Greeting message (first-time contacts):**
> Hello and welcome to [Business Name]! 😊 I'm [Name]. Thanks for reaching out. Tell me what you're looking for, or tap the catalogue to browse. I reply within [15 minutes] during [hours]. If it's after hours, I'll reply first thing in the morning.

**Away message:**
> Thanks for your message! We're closed right now ([hours]) but I've seen it and will reply by [time]. Meanwhile, browse our catalogue or send your order details (item, quantity, address) and I'll confirm as soon as we open. 🙏

### Step 3 — Quick Replies Starter Set

| Shortcut | Message |
|---|---|
| /price | [Item] is ₦[price]. It [one benefit]. Which [colour/size] would you like? |
| /delivery | We deliver to [areas] for ₦[fee], [timing]. Outside [city], we send by [logistics] — ₦[fee], [days]. Where are you located? |
| /pay | You can pay by transfer to [Bank, Account no., Account name] or via this link: [link]. Send your receipt and I'll confirm right away. |
| /confirm | Payment received — thank you, [Name]! 🎉 Your order is being prepared and will [be delivered/ready] by [time]. I'll update you. |
| /hours | We're open [days], [hours]. Orders sent after [time] are processed next morning. |
| /location | We're at [address / landmark]. [Map link if any]. Or we deliver to you — just send your address. |
| /outofstock | That one's sold out, but [alternative] is similar and available now at ₦[price]. Want a photo? |
| /followup | Hi [Name], just checking in — did you still want the [item]? I have [X] left. No pressure at all. |
| /bulk | For 10+ pieces, the price is ₦[wholesale]. Minimum order [X]. Would you like the full wholesale list? |
| /thanks | Thank you for your order, [Name]! If you love it, a quick review here would mean a lot 🙏 And please save my number for offers. |
| /policy | Quick note on our policy: [deposits / returns / delivery] — [1–2 lines]. Let me know if you have questions. |
| /proof | Here's proof of [authenticity/delivery/reviews]: [forward Proof folder]. We've served [X] customers across [areas]. |

### Step 4 — Weekly 10-Minute Maintenance

- [ ] Update catalogue prices / remove sold-out items
- [ ] Label every new chat
- [ ] Post 2–3 Statuses daily (Bonus 4)
- [ ] Reply to every unanswered message
- [ ] Add 1 new Quick Reply for any question you typed twice this week

---

## BONUS 7 🤖 — Price List Generator

**What it does:** Produces a clean, professional price list from your rough notes — with bulk prices, delivery, terms, and a version for WhatsApp, a version for printing, and a version for corporate clients.

**Prompt (paste in full, fill the brackets):**

> Create a professional price list for my business. Business name: [name]. What we sell: [list every item/service with price; add cost price if you want margin advice]. Bulk/wholesale prices: [if any, with minimum quantities]. Delivery: [areas, fees, timing]. Payment options: [transfer / POS / link / pay on delivery rules]. Policies: [deposit %, returns, order cut-off times, lead time for custom items]. Contact: [phone/WhatsApp, address or delivery area, Instagram]. Produce THREE versions: (1) a WhatsApp text version — clean, grouped by category, using simple symbols not heavy emojis, under 400 words, easy to read on a phone; (2) a printable A4 version with a header, category tables (Item | Description | Price | Bulk price), a policies box and contact footer, described so I can build it in Google Docs or Canva; (3) a corporate/B2B version with formal language, VAT note if applicable, payment terms (e.g., 70% deposit, 30% on delivery), and a validity period. Also flag any items where my price looks too low compared to typical Nigerian market ranges, and suggest a "featured" or "best value" label for 2 items.

### Price List Layout (printable version — structure)

```
[BUSINESS NAME]                                [Logo]
[Tagline] • [Phone/WhatsApp] • [Instagram] • [Area]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CATEGORY 1
Item                  Description             Price      Bulk (10+)
──────────────────────────────────────────────────────────────────
Item A                short desc              ₦X,XXX     ₦X,XXX
Item B  ★ Best Value  short desc              ₦X,XXX     ₦X,XXX

CATEGORY 2
...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DELIVERY: [areas & fees] • [timing]
PAYMENT: Transfer • POS • [Link]  |  Account: [Bank – No. – Name]
POLICIES: [deposit] • [returns] • [order cut-off]
Prices valid until: [date]           Save this number: [phone]
```

**Update rule:** review monthly (Prompt 6.2); always show "Prices valid until [date]" so increases are expected, not shocking.

---

## BONUS 8 🤖 📋 — Business Proposal Template (Banks / Grants / Investors)

**What it does:** The full structure of a fundable proposal, with what to write in each section, word counts, and the prompt to generate a first draft from your facts.

### Section-by-Section Structure

| # | Section | What goes in | Length |
|---|---|---|---|
| 0 | **Cover page** | Business name, logo, "Business Plan / Proposal for [purpose]", date, contact, CAC/RC number | 1 page |
| 1 | **Executive Summary** | Who you are, what you do, traction (numbers), the ask, what it will achieve, repayment/return. Write last, place first. | ½ page |
| 2 | **Business Description** | History, legal structure, location, owner background, mission, current stage | ½ page |
| 3 | **Products / Services** | What you sell, prices, what makes it different, photos | ½ page |
| 4 | **Market & Customers** | Who buys, size of the opportunity (local and realistic), trends, evidence of demand | ½–1 page |
| 5 | **Competition** | 3–5 competitors, comparison table, your advantage | ½ page |
| 6 | **Marketing & Sales** | Channels (WhatsApp, referrals, B2B), pricing strategy, retention, growth plan | ½ page |
| 7 | **Operations** | How you produce/deliver, suppliers, staff, equipment, SOPs, quality control | ½ page |
| 8 | **Management & Team** | Owner and key staff — experience, roles; advisers/mentors | ⅓ page |
| 9 | **Financials — Past** | 6–12 months revenue, costs, profit (table); bank statements as appendix | ½ page |
| 10 | **Financials — Projection** | 12-month projection (3 scenarios), break-even, key assumptions | 1 page |
| 11 | **Use of Funds** | Itemised table: item, cost, supplier/quote, expected impact | ½ page |
| 12 | **Repayment / Return** | Loan: schedule from projected cash flow. Investor: returns, exit. Grant: impact metrics (jobs, income, community) | ⅓ page |
| 13 | **Risks & Mitigation** | Top 5 risks and what you'll do about each | ⅓ page |
| 14 | **Impact** *(grants especially)* | Jobs created, women/youth employed, farmers supported, community benefit — with numbers | ⅓ page |
| 15 | **Appendix** | CAC certificate, TIN, ID, bank statements, photos, quotes, customer letters, licences (NAFDAC etc.) | as needed |

**Total: 5–8 pages** plus appendix. Longer is not better.

### Use of Funds Table (copy)

| Item | Quantity | Unit cost (₦) | Total (₦) | Supplier / quote attached | Expected impact |
|---|---|---|---|---|---|
| | | | | | |
| **TOTAL** | | | | | |

### Draft Generator Prompt

> Write a complete business proposal for [purpose: ₦X loan from Y / Z grant / investor] using the 15-section structure: cover, executive summary, business description, products, market, competition, marketing & sales, operations, team, past financials, 12-month projection, use of funds, repayment/return, risks, impact, appendix list. Here are my facts: [paste everything — history, numbers, customers, team, the ask, use of funds, expected results]. Write in clear, confident, factual English suitable for a Nigerian bank or grant reviewer. Use tables for financials and use of funds. Flag any section where my facts are too thin and tell me exactly what to add. Keep the whole document under 3,000 words.

### Before You Submit — Checklist

- [ ] Every number matches across sections (summary = financials = use of funds)
- [ ] Executive summary tailored to *this* funder's stated goals
- [ ] Evidence attached for every major claim (quotes, statements, photos)
- [ ] Read aloud once — no jargon, no filler, no "passion for excellence"
- [ ] Reviewed by one person who has received funding before
- [ ] Contact details on every page footer
- [ ] Saved as PDF, named `[BusinessName]-Proposal-[Funder]-[Date].pdf`

---

*Bonuses 9–15 continue in the next file: WhatsApp Status Sales Hook Bank · NEPA & Generator Expense Calculator · Daily Sales Record Sheet · Customer Follow-Up Message Bank · Referral Reward Card Template · Business Name, Catchphrase & Slogan Creator · Risk & Survival Decision Matrix.*


<div class='pb'></div>

# BONUS SECTION: 15 READY-TO-USE TOOLS
*(Bonus 9 – 15)*

---

## BONUS 9 📋 — WhatsApp Status Sales Hook Bank

**What it does:** 60 ready-made opening lines for Status posts, grouped by purpose. A hook is the first line people see — it decides whether they tap or skip. Copy, fill the brackets, post.

**How to use:** Pick a hook that matches today's theme (Bonus 4). Add one photo or short video and a clear way to order. Rotate categories so your Status never feels like one long advert.

### A. Problem-First Hooks (they feel the pain, you have the fix)

1. Tired of [problem]? This is what I tell all my customers…
2. NEPA don take light again? Here's how my [product] keeps you going.
3. If your [item] keeps [spoiling / tearing / fading] by the second month, read this.
4. You're paying ₦[X] every week on [problem]. This costs ₦[Y] once.
5. Still queuing for [service] on Saturdays? We come to you.
6. The reason your [product] doesn't last: [common mistake]. Fix →
7. Stop buying [cheap alternative] every month. Buy this once.
8. This is for everyone who has ever been disappointed by [bad experience].

### B. Proof & Trust Hooks

9. Another happy customer in [area] 🙏 (swipe for her message)
10. She was scared it was fake. See what she said after using it for 2 weeks →
11. 47 deliveries this month. Zero complaints. Here's how we do it.
12. "I've been buying from you since 2023" — messages like this keep me going.
13. Before ➡️ After. Same client, 3 weeks apart.
14. Delivered to Kano, Enugu, Lagos and Abuja this week. Where next?
15. Unboxing video from a customer in [city] — I didn't even ask her to send this.
16. The batch code on every bottle. Check it yourself. That's how confident we are.

### C. Offer & Urgency Hooks (honest only)

17. Salary week special: [offer] — ends Sunday night.
18. My next stock lands at a higher price. Buy at today's price till [date].
19. Only [X] pieces of this colour came in. [Y] gone already.
20. First 10 orders today get [free delivery / free gift]. Reply "ME".
21. Pre-orders for [season/festival] close on [date]. After that, no promise.
22. Buy 2, get the 3rd at half price — this week only.
23. I have [X] slots left for [service] this weekend.
24. Price goes up Monday. You've been warned with love. ❤️

### D. Curiosity & Story Hooks

25. I almost didn't post this…
26. A customer asked me yesterday: "[interesting question]". My answer:
27. Three years ago I started this business with ₦[amount]. Today…
28. The mistake I made in my first month that cost me ₦[amount].
29. Why I refuse to sell [cheap version] even though it's more profitable.
30. What happens in my kitchen/workshop at 5am (video)
31. Guess how many of these we made today? (answer at the end)
32. My most expensive item — and why people buy it anyway.

### E. Question & Engagement Hooks

33. Quick one: which colour should I restock? 🔴 or 🔵 — reply!
34. What's the one thing you wish [product] did better? I'm listening.
35. Be honest: how often do you [related habit]?
36. Naming my new [product] — vote: A, B or C?
37. Who else is tired of [relatable Nigerian frustration]? 🙋‍♀️
38. What are you cooking/wearing/planning this weekend? Let me help.
39. Tag a friend who needs to see this (screenshot and send!).
40. If you could only buy one thing from me this month, what would it be?

### F. Value & Teach Hooks

41. 3 ways to make your [product] last twice as long:
42. How to spot fake [product] in 10 seconds:
43. What ₦5,000 gets you at my shop vs. the big supermarket:
44. The right way to store [product] during rainy season.
45. Pro tip from [X] years of doing this:
46. Don't buy [product] until you check these 3 things.
47. The difference between ₦3,000 and ₦8,000 [product] — explained.
48. What I wish every customer knew before ordering.

### G. Seasonal & Occasion Hooks

49. Detty December is coming. Is your [product/plan] ready?
50. Back-to-school checklist — tick what you already have ✅
51. Sallah/Christmas/Easter orders now open. Pre-order and rest.
52. Harmattan is here. Your [skin/hair/car/generator] needs this.
53. Valentine's is [X] days away. Don't be that person who forgot.
54. Rainy season = [problem]. Solution below ☔
55. End of the month. Treat yourself — you worked for it.
56. New month, new stock, same honest prices. 🙏

### H. Personal & Human Hooks

57. Not selling anything today. Just grateful for every one of you.
58. Small business, real person. This is me, [name], behind every order.
59. My daughter helped pack orders today (photo). Family business in action.
60. Sunday rest. Back tomorrow with fresh stock. Have a blessed day.

**Rules:** max 3 emojis · one hook per post · always end with how to order ("Reply 'YES'", "Send 'PRICE'", "Tap to chat") · never post a fake urgency hook.

---

## BONUS 10 📊 — NEPA & Generator Expense Calculator

**What it does:** Shows exactly what your power costs per month and per year, what each appliance costs to run, and whether solar/inverter pays off — so you can make the decision with numbers, not fear.

### Part A — What You Spend Now

| Item | Your figure |
|---|---|
| Generator size (kVA) | |
| Fuel type (petrol / diesel) | |
| Fuel price per litre (₦) | |
| Litres used per hour (typical: 1kVA≈0.4L, 2.5kVA≈0.8L, 3.5kVA≈1L, 5kVA≈1.4L, 7kVA≈2L — check yours) | |
| Hours generator runs per day | |
| Days per month | |
| **Monthly fuel cost** = litres/hr × hrs/day × days × price | ₦ |
| Servicing & oil per month | ₦ |
| Repairs per month (average) | ₦ |
| Grid electricity bill per month | ₦ |
| **TOTAL MONTHLY POWER COST** | ₦ |
| **TOTAL YEARLY POWER COST** (× 12) | ₦ |
| Monthly revenue | ₦ |
| **Power cost as % of revenue** (healthy: under 8–10%) | % |

**Worked example:** 3.5kVA petrol · ₦1,000/L · 1 L/hr · 8 hrs/day · 26 days = 208 L = **₦208,000** fuel. + ₦10,000 servicing + ₦5,000 repairs + ₦12,000 grid = **₦235,000/month = ₦2.82M/year.**

### Part B — What Each Appliance Costs You (find the hungry ones)

| Appliance | Watts (check label) | Hours/day on generator | kWh/day (W × hrs ÷ 1000) | Share of load (%) | Est. monthly cost (₦) | Needed on generator? (Y/N) |
|---|---|---|---|---|---|---|
| Chest freezer | ~150–250 | | | | | |
| Standing fridge | ~150–300 | | | | | |
| Standing fan (AC) | ~60–80 | | | | | |
| Rechargeable/DC fan | ~15–25 | | | | | |
| LED bulb | ~7–12 each | | | | | |
| Old bulb | ~60 each | | | | | |
| TV | ~60–120 | | | | | |
| Clippers / sewing machine | ~20–100 | | | | | |
| Blender / mixer | ~300–800 | | | | | |
| Air conditioner | ~900–1,500 | | | | | |
| Electric kettle / iron | ~1,000–2,000 | | | | | |
| POS / phone charging | ~5–15 | | | | | |

**Rule:** anything with a heating element (kettle, iron, heater) or an AC uses 10–100× more than lights and phones. Never run them on the generator "for small time."

### Part C — Quick Savings Estimator

| Action | Typical saving | Your estimate (₦/month) |
|---|---|---|
| Run generator in 2-hour blocks for freezers (full freezer + water bottles holds cold 6–10 hrs) | 20–35% of fuel | |
| Swap all bulbs to LED | 5–10% | |
| Replace AC fans with DC/rechargeable fans | 5–10% | |
| Switch off non-essentials while generator runs (TV, extra lights) | 5–15% | |
| Service generator on schedule (dirty plug/filter wastes fuel) | 5–10% | |
| Right-size: smaller generator for small loads (a 1kVA for lights/phones/fans) | 20–40% on light-load hours | |
| Shift energy-heavy tasks (blending, ironing) to grid hours | 10–20% | |
| **Total estimated monthly saving** | | ₦ |

### Part D — Solar / Inverter Payback

| Item | Your figure |
|---|---|
| Quote for solar/inverter system that covers your *essential* load (get 2–3 quotes) | ₦ |
| Monthly generator cost it would replace (from Part A, minus any generator you'd still run) | ₦ |
| Monthly solar maintenance (small) | ₦ |
| **Net monthly saving** | ₦ |
| **Payback period (months)** = System cost ÷ net monthly saving | months |
| Battery replacement expected in (years) and cost | |

**Worked example:** ₦1.8M system replacing ₦180,000/month of fuel → payback **10 months**. After that, ₦2M+ a year stays in your pocket.

**Decision rule:** payback under 24 months = strong yes (if you can fund it without a killer loan). 24–36 months = consider, especially if fuel keeps rising. Over 36 months = wait, or start with a smaller system for lights, fans and phones.

### AI Helper Prompt

> Using these numbers [paste Part A and Part B figures], calculate my true monthly and yearly power cost, identify my three most expensive appliances, estimate savings from [list actions from Part C], and calculate the solar payback if a system costs ₦[quote]. Tell me honestly whether solar makes sense for my business now, and what size system I should ask installers to quote for my essential load. I will verify quotes with real installers.

---

## BONUS 11 📋 — Daily Sales Record Sheet (POS-Friendly)

**What it does:** One page per day. Any staff member can keep it. Cash must balance before closing. Feeds your weekly summary, monthly P&L and 90-day tracker.

### Daily Sheet

```
BUSINESS: ______________________   DATE: ____/____/______   DAY: ________
STAFF ON DUTY: __________________   WEATHER/NOTES (NEPA, rain, event): __________

OPENING CASH IN TILL:  ₦ __________  (counted by: ________)

────────────────────────────── SALES ──────────────────────────────
Time   | Item / Category            | Qty | Amount (₦) | Cash | POS | Transfer | Customer name (if known)
-------|----------------------------|-----|------------|------|-----|----------|------------------------
       |                            |     |            |      |     |          |
       |                            |     |            |      |     |          |
       |                            |     |            |      |     |          |
       (continue overleaf if needed)

TOTAL SALES:        ₦ __________
  of which CASH:    ₦ __________
  of which POS:     ₦ __________   (must match POS machine end-of-day printout)
  of which TRANSFER:₦ __________   (must match bank alerts/app)

───────────────────── EXPENSES PAID FROM TILL ─────────────────────
Time   | Item                       | Amount (₦) | Approved by | Receipt?
-------|----------------------------|------------|-------------|---------
       |                            |            |             |
TOTAL EXPENSES FROM TILL:  ₦ __________

────────────────────────── CREDIT / DEBTS ─────────────────────────
Goods given on credit today (name, amount, due date): _______________________________
Debts collected today (name, amount): ___________________________________________

────────────────────────── RECONCILIATION ─────────────────────────
Expected closing cash = Opening cash + Cash sales − Expenses from till − Cash banked
   = ₦ ________ + ₦ ________ − ₦ ________ − ₦ ________ = ₦ __________
ACTUAL CASH COUNTED:  ₦ __________
DIFFERENCE:           ₦ __________   Reason: __________________________________

Cash banked / handed to owner: ₦ __________   Left in till for tomorrow: ₦ __________

Stock-outs today (items customers asked for that we didn't have): ____________________
Customer complaints / feedback: ______________________________________________
Signed (staff): __________   Photo sent to owner at: ____ : ____   Owner check: ______
```

### Weekly Summary (owner fills every Sunday)

| Day | Total sales (₦) | Cash | POS | Transfer | Expenses from till | Cash difference | Credit given | Debts collected | New customers |
|---|---|---|---|---|---|---|---|---|---|
| Mon | | | | | | | | | |
| Tue | | | | | | | | | |
| Wed | | | | | | | | | |
| Thu | | | | | | | | | |
| Fri | | | | | | | | | |
| Sat | | | | | | | | | |
| Sun | | | | | | | | | |
| **Week total** | | | | | | | | | |
| **vs. last week** | | | | | | | | | |
| **vs. weekly target (Bonus 1)** | | | | | | | | | |

**Rules that make it work:**
1. Sheet must balance before anyone goes home. Any difference over ₦500 gets a written reason.
2. Photo of the completed sheet to the owner's WhatsApp every night (your backup and audit trail).
3. POS total must match the machine's end-of-day printout; staple the printout to the sheet.
4. No expense from the till without approval and a reason — "chop money" is not a reason.
5. Owner does a surprise mid-day cash count at least once a week.

---

## BONUS 12 📋 — Customer Follow-Up Message Bank

**What it does:** 40 ready-to-send messages for every stage after first contact — so no lead goes cold and no customer feels forgotten. All under 60 words. Fill the brackets, personalise the first line, send.

### A. After an Enquiry (no purchase yet)

1. **Day 1 (same day):** Hi [Name], lovely chatting earlier. Here's the [photo/price list] as promised. Any question at all, just ask — I'm here. 😊
2. **Day 2:** Hi [Name], quick one — was there anything about the [item] you were unsure of? Size, colour, delivery? Happy to help you decide.
3. **Day 5 (value):** [Name], just posted a short video showing [item] in use / after 3 washes / being made. Thought you'd like to see it before deciding: [Status/link].
4. **Day 5 (proof):** Hi [Name], a customer in [area] just sent this after receiving her [item] 🙏 (screenshot). Yours can arrive by [day] if you'd like.
5. **Day 10 (gentle close):** Hi [Name], last nudge from me 😊 I have [X] left of the [item]. If it's not for you right now, no wahala at all — I'm here whenever you're ready.
6. **Salary week:** [Name], it's that time of the month 😄 The [item] you liked is still available, and I'll add [free delivery / small gift] if you order before Sunday.
7. **"Too expensive" reply:** I hear you, [Name]. It's ₦[X] because [one reason]. If budget is the issue, I have [smaller option] at ₦[Y], or you can pay ₦[deposit] now and the balance on delivery. Which works?

### B. After Payment (confirmation & reassurance)

8. **Payment received:** Received — thank you, [Name]! 🎉 Order: [item, qty]. It'll be [ready/dispatched] by [time/day]. I'll send you an update.
9. **Preparing:** Hi [Name], your [item] is being [packed/made] now. Here's a quick photo 📸. Dispatching [when].
10. **Dispatched:** On its way! 🚚 Rider: [name, number] / Waybill: [number]. Expect it around [time]. Please keep your phone reachable.
11. **Delayed (be honest):** [Name], a quick heads-up — your delivery is delayed by [reason, briefly] and will now arrive [new time]. I'm sorry for the inconvenience; I'm on it personally.

### C. After Delivery (turn one sale into the next)

12. **Same day:** Hi [Name], did your [item] arrive safely? Please check it and let me know everything is as expected. 🙏
13. **Day 2 (usage tip):** [Name], quick tip to get the best from your [item]: [one tip]. Enjoy it!
14. **Day 5 (review ask):** Hi [Name], hope you're loving the [item]! If you have 30 seconds, a short voice note or text on how you find it would help me a lot 🙏 (And I'd love to share it, with your permission.)
15. **Day 7 (referral):** [Name], thank you again. If anyone in your circle needs [product], send them my way and mention your name — you get [reward] after their first order.
16. **Day 21–30 (repeat trigger, consumables):** Hi [Name], you're probably running low on [item] by now 😊 Want me to send a fresh one this week? Same price, and delivery is on me for returning customers.

### D. Repeat Customers & VIPs

17. **Loyalty milestone:** [Name], this is your [5th] order with us! 🎉 To say thank you, [reward]. You're the reason we're still here.
18. **VIP early access:** [Name], before I post it publicly — new [item] just landed. As one of my best customers, you get first pick. Want photos?
19. **Birthday/occasion (if known):** Happy birthday, [Name]! 🎂 Enjoy [gift/discount] from us this week. Thank you for being family.
20. **Feedback request:** [Name], you've bought from me [X] times and I value your opinion. What's one thing I should improve? Honest answers only 😊

### E. Win-Back (gone quiet 60+ days)

21. Hi [Name], it's [Your name] from [Business]. I noticed it's been a while — I hope you're well. A lot has changed here: [new item/improvement]. Would love to serve you again. 🙏
22. [Name], we miss you! Here's ₦[X] off / free delivery on your next order, valid till [date]. No pressure — just wanted you to know the door is open.
23. Hi [Name], honest question: did we do something that made you stop buying? If so, I'd genuinely like to know and fix it.

### F. Debt & Deposit Follow-Ups (firm but kind)

24. **Deposit reminder:** Hi [Name], to lock in your [item/slot] I'll need the ₦[deposit] by [time]. After that I can't hold it — I have others waiting. Thank you for understanding.
25. **Balance due (day of):** Good morning, [Name]. Your [item] is ready! Balance of ₦[X] is due on delivery/collection today. Transfer details: [details].
26. **Late payment, day 3:** Hi [Name], gentle reminder — ₦[X] for [item] was due on [date]. Please let me know when to expect it today. 🙏
27. **Late payment, day 7:** [Name], I still haven't received the ₦[X]. I understand things can be tight — can you send ₦[part] today and the rest by [date]?
28. **Late payment, day 14 (firm):** [Name], this is my final reminder on the ₦[X] outstanding since [date]. I'd rather resolve it between us; please call me today.

### G. Complaints & Service Recovery

29. **First response (within 1 hour):** [Name], I'm really sorry about this. Thank you for telling me — I take it seriously. Give me [30 minutes] to look into it and I'll come back to you with a solution.
30. **Resolution offer:** [Name], here's what I can do: [option A] or [option B]. Which would you prefer? I want to make this right.
31. **After fixing:** [Name], your [replacement/refund] has been [sent/processed]. Again, my apologies. I've added [small extra] for the trouble. Thank you for your patience.
32. **One week later:** Hi [Name], just checking — is everything okay with the [item] now? Your satisfaction genuinely matters to me.

### H. Seasonal & Broadcast Touches

33. **Festival greeting (no selling):** Happy [Sallah/Christmas/Easter/New Year], [Name]! Wishing you and your family joy and peace. Thank you for your support this year. 🙏
34. **Pre-season:** [Name], [festival] is [X] weeks away. Pre-orders are open — order early, rest easy. Here's what's available: [list/link].
35. **Price change notice:** Hi [Name], a heads-up from me: from [date], [item] moves from ₦[old] to ₦[new] due to [reason]. You can still order at the old price till then.
36. **Restock alert:** [Name], the [item] you asked about is back in stock! 🎉 [X] pieces available. Want me to reserve one?
37. **New product:** [Name], something new: [item] — [one benefit], ₦[price]. Made for customers like you who [need]. Want to see it?
38. **Thank-you broadcast (month-end):** To every customer who bought this month — thank you. You kept a small business alive. Here's to next month. 🙏
39. **Quiet-week nudge:** Slow week here, so I'm offering [small deal] to my saved contacts only. Ends Friday.
40. **Save-my-number:** Hi [Name]! Please save this number as [Business Name] so you don't miss my Status updates and offers. Thank you! 😊

**Golden rules:** personalise the first line · one message, one purpose · never send two follow-ups in one day · always give a graceful exit ("no wahala") · use Labels to send the right message to the right group.

---

## BONUS 13 📋 — Referral Reward Card Template

**What it does:** A pocket-size card (and its digital version) that turns every happy customer into a recruiter — with clear rewards and simple tracking so nobody gets confused.

### Physical Card (business-card size, print 200–500)

**Front:**
```
┌──────────────────────────────────────────────┐
│  [BUSINESS NAME]                    [Logo]   │
│  ────────────────────────────────────────    │
│  A GIFT FROM: ______________________         │
│                                              │
│  You've been referred by a happy customer!   │
│  Show this card and get:                     │
│  ★  [₦1,000 off / free delivery / free gift] │
│     on your first order.                     │
│                                              │
│  📲 [WhatsApp number]   📍 [Area]            │
│  Valid till: ____/____/______                │
└──────────────────────────────────────────────┘
```

**Back:**
```
┌──────────────────────────────────────────────┐
│  HOW IT WORKS                                │
│  1. Your friend gave you this card.          │
│  2. Order and mention their name.            │
│  3. You get [your reward].                   │
│  4. They get [their reward] — and so will    │
│     you, when you refer someone!             │
│                                              │
│  Ask us for your own referral cards. 🙏      │
│  Card no: ______   Referrer code: ______     │
└──────────────────────────────────────────────┘
```

### Digital Version (WhatsApp image or text — send to existing customers)

> 🎁 **[Business Name] Referral Reward**
> Know someone who needs [product]? Send them my number and tell them to mention **your name** when they order.
> **They get:** [new-customer reward]
> **You get:** [₦1,500 airtime / ₦2,000 off / free product] after their first paid order.
> No limit — refer 5, get 5 rewards. Thank you for spreading the word! 🙏

### Reward Options (pick one per side)

| For the new customer | For the referrer | Cost to you |
|---|---|---|
| ₦500–₦1,000 off first order | ₦1,000–₦2,000 airtime (most loved) | Low |
| Free delivery | ₦2,000–₦3,000 off next order | Low–medium |
| Free small gift/sample | Free product after 3 referrals | Medium |
| 10% off | 10% cash reward on referred order | Scales with sale |

**Rule of thumb:** total reward cost ≤ 10–15% of the average first order. If average order is ₦15,000, total rewards of ₦1,500–₦2,000 is right.

### Referral Tracking Sheet

| Date | New customer name & number | Referred by | Order amount (₦) | Paid? | New-customer reward given | Referrer reward given (date) | Notes |
|---|---|---|---|---|---|---|---|

### Launch Plan (7 days)

| Day | Action |
|---|---|
| 1 | Finalise rewards; print cards or design digital version (Canva) |
| 2 | Send the digital version to your 30 best customers personally (not broadcast) |
| 3 | Post on Status: "New: refer a friend, get ₦2,000 airtime" |
| 4–7 | Give 2 physical cards with every order/delivery; mention it at checkout |
| 7 | Review: how many referrals? Reward everyone the same day they qualify |

**Anti-abuse:** reward only after the new customer's first *paid* order · one reward per new customer · referrer's name must be mentioned at time of order (not after) · keep the sheet.

---

## BONUS 14 🤖 — Business Name, Catchphrase & Slogan Creator

**What it does:** Generates and tests names, taglines, slogans, and WhatsApp-friendly catchphrases that Nigerian customers remember and repeat — for a new business, a rebrand, a product line, or a campaign.

### Prompt 1 — Business or Product Name

> I need a name for [a new business / a product line / a bundle / a training programme]. What it is: [describe]. Who it's for: [customers]. Feeling I want: [trustworthy / premium / fun / homely / modern / proudly Nigerian]. Language preference: [English only / English + Pidgin / English + Yoruba/Igbo/Hausa words / a mix]. Things to avoid: [names of competitors, words that are overused like "Divine", "Blessed", "Global", "Ventures"]. Give me 25 name options in five groups: descriptive, invented/modern, Nigerian-language-inspired (with meaning), personal/founder-based, and playful. For each: the name, why it works, and a possible tagline. Then shortlist your top 5 and for each say how it sounds when a customer says "I bought it from ___" and check if it's easy to spell over the phone. Remind me to check CAC availability and Instagram/WhatsApp handle availability before choosing.

### Prompt 2 — Tagline & Slogan

> My business is [name], we [what you do] for [who] in [where]. Our real edge is [1–2 things]. Create: (1) 10 short taglines under 6 words for my logo/profile, (2) 10 slogans under 12 words for flyers and Status, (3) 5 Pidgin or Naija-flavoured catchphrases customers would repeat or joke with, (4) 5 "promise" statements ("Fresh every morning or your money back") I could actually keep, and (5) 3 hashtag-style phrases for social media. Avoid clichés like "passion for excellence", "your satisfaction is our priority", "quality you can trust". Then pick the single best tagline and explain why it will stick in a Nigerian customer's mind.

### Prompt 3 — Campaign or Seasonal Catchphrase

> I'm running a [festival/season/launch] campaign for [product/offer] at [price]. Give me 15 short, catchy campaign lines Nigerians will remember — playful, culturally aware, with light Pidgin where it fits — plus a 3-word version of the best one for a sticker or Status header. Include at least 3 that rhyme and 3 that use a familiar Nigerian phrase or saying, twisted for my product.

### Name Test Checklist (before you commit)

- [ ] Say it out loud 5 times — still easy?
- [ ] Spell it over the phone to a friend — did they get it first time?
- [ ] Search it on Instagram, Facebook and Google — anyone using it nearby?
- [ ] CAC name search done (via the CAC portal or an agent)
- [ ] WhatsApp Business short link and Instagram handle available?
- [ ] Does it still work if you add products/branches later? (Avoid "Ikeja Bread House" if you'll expand.)
- [ ] Does it mean anything embarrassing in Yoruba, Igbo, Hausa or Pidgin? Ask speakers.
- [ ] Ask 5 target customers which of your top 3 they'd trust more — go with the majority.

### Slogan Formulas That Work in Nigeria

| Formula | Example |
|---|---|
| Benefit + honesty | "Fresh bread. Fair price. Every morning." |
| Problem killed | "No more fake fabric." |
| Local pride | "Made in Aba. Worn everywhere." |
| Promise with proof | "Delivered same day — or delivery is free." |
| Pidgin warmth | "Correct thing, no stories." |
| Twist on a saying | "No be by mouth — na by taste." |

---

## BONUS 15 📊 — Risk & Survival Decision Matrix for Naija Businesses

**What it does:** A one-page system to see your biggest risks clearly, decide what to protect first, and know exactly what to do in the first 24 hours when something goes wrong — so a bad day doesn't become a closed business.

### Step 1 — Score Your Risks

Score each: **Likelihood** (1 = rare, 5 = almost certain this year) × **Impact** (1 = annoying, 5 = could close the business) = **Risk Score** (1–25).

| # | Risk | Likelihood (1–5) | Impact (1–5) | Score | Current protection (none / weak / good) |
|---|---|---|---|---|---|
| 1 | Fuel/diesel price spike | | | | |
| 2 | General inflation on stock and materials | | | | |
| 3 | Naira depreciation (imported goods cost more) | | | | |
| 4 | Prolonged power failure spoiling stock | | | | |
| 5 | Staff theft or fraud | | | | |
| 6 | External theft / burglary | | | | |
| 7 | Fire (generator, gas, wiring) | | | | |
| 8 | Flooding / rain damage | | | | |
| 9 | Owner falls sick or is absent for weeks | | | | |
| 10 | Key staff member leaves suddenly | | | | |
| 11 | Main supplier fails or raises prices sharply | | | | |
| 12 | Biggest customer leaves or stops paying | | | | |
| 13 | Customer debts pile up | | | | |
| 14 | Rent increase or eviction | | | | |
| 15 | Government demolition, relocation or new levy | | | | |
| 16 | Fake collectors / harassment ("task force") | | | | |
| 17 | POS/bank failure or frozen account | | | | |
| 18 | Loan default pressure | | | | |
| 19 | Phone lost/stolen (all contacts and records) | | | | |
| 20 | Family/community pressure draining cash | | | | |
| 21 | Bad review or social-media attack | | | | |
| 22 | Product liability (someone harmed by product) | | | | |
| 23 | New competitor undercutting nearby | | | | |
| 24 | Seasonal demand collapse | | | | |
| 25 | *(Your specific risk)* | | | | |

### Step 2 — Prioritise

| Score | Zone | Action |
|---|---|---|
| **15–25** | 🔴 Act this month | Put protection in place now, whatever it costs within reason |
| **8–14** | 🟡 Plan this quarter | Cheap protections now; full plan within 90 days |
| **1–7** | 🟢 Monitor | Review every 6 months |

### Step 3 — Protection Menu (cheap, practical, Nigerian)

| Risk area | Protections |
|---|---|
| **Power & fuel** | Full-freezer habit · 2-hour generator blocks · LED/DC swaps · solar payback check (Bonus 10) · keep 2 weeks' fuel budget in reserve |
| **Inflation & naira** | Monthly price review · "small size" options · buy stock at month-end sales cycle · negotiate supplier terms · avoid long fixed-price contracts |
| **Theft & fraud** | Daily sales sheet that must balance (Bonus 11) · surprise counts · CCTV (even a basic ₦40k camera) · separate cash-handling from stock-handling · guarantor for staff |
| **Fire & flood** | Fire extinguisher by generator/gas (₦15–30k) · generator 3m from building · no fuel stored indoors · raise stock off the floor · micro-insurance for fire/stock (verify terms) |
| **Owner absence** | 5 SOPs on the wall · one trained deputy · shared password sheet with a trusted person · a "shop can run without me" test every quarter |
| **Key staff** | Cross-train 2 people per task · document processes · fair pay + small commission · exit handover rule |
| **Supplier** | Second supplier for 20% of volume · keep relationships warm · 2–4 weeks' buffer of critical stock |
| **Customer concentration** | No single customer > 25% of revenue · keep prospecting even when full |
| **Debts** | Credit policy (Prompt 6.7) · debtors' register · deposits for custom work |
| **Rent & location** | Written tenancy · start saving next rent from month 1 · keep delivery/online channel so a location change isn't fatal |
| **Levies & harassment** | Know your legitimate levies (Prompt 6.9) · join the market/trade association · demand ID and receipt · keep copies of all payments |
| **Bank & POS** | Two accounts at different banks · keep some cash float · payment link as backup |
| **Phone/records** | Back up WhatsApp to Google Drive weekly · save contacts to Google account · photograph records daily · lock screen + Find My Device |
| **Family pressure** | Fixed owner's salary (Prompt 6.5) · "the business pays me a salary" script · separate accounts |
| **Reputation** | Respond to complaints within 1 hour · fix publicly and kindly · Proof folder · never argue online |
| **Cash cushion** | 3 months of fixed costs in an emergency fund (Prompt 6.8) — the protection that covers every risk |

### Step 4 — First-24-Hours Playbook

| If this happens… | First 24 hours |
|---|---|
| **Fire / flood / break-in** | Safety first · photograph everything before touching · report to police (get extract) · inform insurer if any · tell customers honestly via Status · list losses · call supplier for emergency restock terms |
| **Power failure with perishable stock** | Move stock to a neighbour's freezer or cold room · sell fast at a discount via Status ("today only") · cook/process what can be preserved · document losses |
| **Owner sick/absent** | Deputy activates SOPs · owner posts a short Status ("I'm unwell, [Name] is in charge, orders continue") · reduce to core products · pause new commitments |
| **Key staff quits** | Cross-trained person steps in · re-post job description (Prompt 4.7) same day · owner covers customer-facing role temporarily · don't beg them back publicly |
| **Supplier fails** | Call second supplier · tell affected customers *before* they ask, with a new timeline · offer substitutes or refunds · never go silent |
| **Big customer leaves** | Ask why (genuinely) · don't slash prices in panic · activate prospecting (Prompt 5.6) · review whether any other customer is > 25% |
| **Fake collectors / harassment** | Stay calm · ask for ID and official documents · don't pay cash on the spot · call your association chairman · record if safe |
| **Account frozen / POS failure** | Switch to the second account and payment link · post the alternative payment details on Status · call the bank with your reference · keep serving cash customers |
| **Phone lost** | Log in to WhatsApp on another phone/restore backup · change bank and email passwords · tell contacts via a friend's Status · retrieve records from Google Drive backup |
| **Bad review / online attack** | Reply once, calmly, offer to fix privately · move to DM · fix it · ask satisfied customers to share honest experiences · do not engage in back-and-forth |
| **Loan pressure** | Call the lender *before* missing a payment · propose a realistic plan · cut non-essential costs immediately · don't take a second loan to pay the first |

### Step 5 — Quarterly Review

| Quarter | Top 3 risks | Protection added | Emergency fund (₦) | Next action |
|---|---|---|---|---|
| Q1 | | | | |
| Q2 | | | | |
| Q3 | | | | |
| Q4 | | | | |

### AI Helper Prompt

> Here are my scored risks and current protections: [paste table]. My business is a [type] in [area], Nigeria, with monthly revenue ₦[X], fixed costs ₦[Y], and an emergency fund of ₦[Z]. Tell me: my top 5 risks by score and why they matter for my specific business; the cheapest protection for each that I can put in place within 30 days with a cost estimate; anything I've under-scored given Nigerian realities; and a 24-hour playbook for my number-one risk. Be direct.

---

## You Now Have the Complete Toolkit

Fifteen tools. Every one built for the way business actually works in Nigeria — on a phone, with WhatsApp, around NEPA, through haggling, salary weeks, festival rushes and family pressure.

Set up **three of them this week**: the Daily Sales Record Sheet (Bonus 11), the 90-Day Revenue Growth Tracker (Bonus 1), and the WhatsApp Business Profile Optimizer (Bonus 6). Those three create the habit. The rest slot in as you need them.

**Next: Back Matter — Your 90-Day Action Plan, Glossary, and What to Read Next**


<div class='pb'></div>

# BACK MATTER

---

## YOUR 90-DAY ACTION PLAN

You have 120 prompts and 15 tools. Here is the order to use them in, week by week, so that you reach the extra ₦1.5M–₦3M and the 35% cost cut without burning out.

**The rules of the plan:**
- **One hour a day**, ideally the same hour (early morning or after closing).
- **No more than 5 actions per week.** Depth beats breadth.
- **Track every Sunday** in the 90-Day Revenue Growth Tracker (Bonus 1).
- If you miss a week — NEPA, family, illness — **don't restart. Do the next week.**

### PHASE 1 — FOUNDATION (Days 1–30): *Know, Set Up, Start Selling Better*

**Goal by Day 30:** customer clarity, WhatsApp fully set up, daily posting habit, sales script live, daily cash sheet balancing, expense audit done.

| Week | Actions | Prompts / Tools |
|---|---|---|
| **1** | ① Write your 90-Day Promise. ② Build your ideal customer profile. ③ Discover the real problem you solve. ④ Set up the Daily Sales Record Sheet. ⑤ Set up the 90-Day Tracker with your baseline. | 1.1 · 1.5 · Bonus 11 · Bonus 1 |
| **2** | ① Complete your WhatsApp Business profile, greeting, away message, 12 Quick Replies. ② Create 30 days of Status content; start posting daily. ③ Understand why customers choose your competitor. ④ Write your core sales script. ⑤ Set your negotiation floor and "last price" system. | Bonus 6 · 2.2 · 1.3 · 3.1 · 3.3 |
| **3** | ① Do the full expense audit. ② Build your trust "Proof" folder. ③ Write your 12-objection table and rehearse it. ④ Start the 3-message follow-up for everyone who "went quiet." ⑤ Send your first testimonial requests. | 4.1 · 3.6 · 3.9 · 2.9 · 2.7 |
| **4** | ① Calculate true cost and real profit of top 5 products. ② Find your daily break-even; put it on the wall. ③ Open a separate business account; set your owner's salary. ④ Write your first 3 SOPs. ⑤ **Day 30 checkpoint** — fill in Bonus 1; do your first monthly P&L and money review. | 6.1 · 6.3 · 6.5 · 4.3 · 6.6 · 6.19 |

**Day 30 check:** Are enquiries up? Is cash balancing daily? Do you know your break-even? If any is "no," repeat that action in Week 5 before moving on.

### PHASE 2 — GROWTH ENGINES (Days 31–60): *More Leads, More Conversions, Lower Costs*

**Goal by Day 60:** referral system live, bundles selling, upsells on every sale, generator and supplier costs cut, first new revenue stream in test.

| Week | Actions | Prompts / Tools |
|---|---|---|
| **5** | ① Launch your referral programme with cards or digital version. ② Design and display 2–3 named bundles. ③ Add upsell/cross-sell lines to every sale. ④ Cut generator/fuel costs — apply the calculator. ⑤ Post from the Hook Bank daily. | 2.8 · Bonus 13 · 5.2 · 3.7 · 4.2 · Bonus 10 · Bonus 9 |
| **6** | ① Negotiate with your top 2 suppliers. ② Fix the "send account details" drop-off. ③ Write and post your policies (deposits, delivery, returns, credit). ④ Segment customers with WhatsApp Labels. ⑤ Start a waste/spoilage log. | 4.10 · 3.13 · 4.19 · 1.8 · 4.9 |
| **7** | ① Generate your adjacent product/stream ideas; pick one. ② Design its 21-day test with a written "go" threshold. ③ Launch the test to existing customers. ④ Plan your next seasonal/festive campaign. ⑤ Build a weekly schedule that protects your time. | 5.1 · 5.12 · 5.10/5.4/5.7/5.11 · 2.12/5.5 · 4.12 |
| **8** | ① Collect and manage debtors; write your credit policy. ② Build your 8-week cash-flow forecast. ③ Start your emergency fund with an automatic transfer. ④ Turn one-time buyers into repeat customers. ⑤ **Day 60 checkpoint** — Bonus 1; monthly P&L; operations review; sales-funnel review. | 6.7 · 6.4 · 6.8 · 2.17 · 6.6 · 4.20 · 3.20 |

**Day 60 check:** Are you at ⅔ of your revenue target? Have operating costs dropped at least 20%? Did the 21-day test hit its threshold? Decide: scale the new stream or adjust and retest.

### PHASE 3 — SCALE & SECURE (Days 61–90): *Multiply What Works, Protect What You've Built*

**Goal by Day 90:** full target hit, second revenue stream live, B2B or diaspora customer won, systems that run without you, 12-month roadmap ready.

| Week | Actions | Prompts / Tools |
|---|---|---|
| **9** | ① Scale the winning new stream (or launch the second-ranked idea). ② Contact your first B2B or diaspora prospect with a one-page proposal. ③ Add a premium tier to your best seller. ④ Run a monthly marketing review — drop what isn't working. ⑤ Hire or train with the one-page sales guide if needed. | 5.6/5.16 · 3.11 · 5.3 · 2.20 · 3.19/4.8 |
| **10** | ① Build your 12-month product & revenue roadmap. ② Set prices for profit; announce any increases honestly. ③ Create quality-control checklists. ④ Score your risks in the Risk Matrix; add top-3 protections. ⑤ Practise a difficult negotiation with AI role-play. | 5.20 · 6.2 · 4.16 · Bonus 15 · 3.10 |
| **11** | ① Prepare your "Grant Folder" (documents, photos, P&Ls). ② Draft a business proposal if you plan to seek funding. ③ Build your 12-month financial projection. ④ Launch your loyalty programme. ⑤ Test: leave the shop for 2 days — does it run? | 6.11 · Bonus 8 · 6.13 · 5.17 · 6.15 |
| **12** | ① Set your profit-allocation rule and automate it. ② Update your one-page Customer & Market Brief. ③ Improve your best product from feedback. ④ Run your monthly money review. ⑤ Write thank-you messages to your top 20 customers. | 6.14 · 1.20 · 5.15 · 6.19 · Bonus 12 |
| **13** | ① **Day 90 checkpoint** — complete Bonus 1. ② Compare Day 1 vs. Day 90: revenue, costs, profit, hours worked. ③ Write down your 3 biggest wins and 3 biggest lessons. ④ Build the *next* 90-day plan. ⑤ Celebrate — properly. You earned it. | Bonus 1 · Bonus 2 · 6.20 |

### After Day 90

The habits are the prize: daily posting, daily cash sheet, weekly tracker, monthly P&L and reviews, quarterly risk and roadmap check. Keep them, and every 90 days compounds on the last.

---

## QUICK-FIND INDEX: "I NEED HELP WITH…"

| Situation | Go to |
|---|---|
| I don't know who my customer really is | 1.1, 1.14, Bonus 3 |
| Sales are slow and I don't know why | 1.2, 3.20, 2.20 |
| Customers ask price and disappear | 3.5, 2.9, Bonus 12 (A) |
| "E too cost" / "last price?" | 3.2, 3.3, 3.16 |
| "Is it original? Are you real?" | 3.6 |
| People say "I'll come back" | 3.4 |
| I need content for Status | 2.2, Bonus 4, Bonus 9 |
| I want more referrals | 2.8, Bonus 13 |
| I need testimonials | 2.7 |
| Someone owes me money | 3.8, 6.7, Bonus 12 (F) |
| A customer is angry | 3.18, Bonus 12 (G) |
| Generator is eating my profit | 4.2, Bonus 10 |
| Cash doesn't balance | 4.13, Bonus 11 |
| Staff keep making mistakes | 4.3, 4.16, 3.19, 4.8 |
| I need to hire | 4.7 |
| I'm working 14 hours a day | 4.12, 4.5 |
| I want to add a new product or income | 5.1, 5.12, 5.20 |
| I want to raise my average sale | 5.2, 5.3, 3.7 |
| I want dollar customers | 5.16 |
| I don't know my real profit | 6.1, 6.6 |
| I want to raise prices without losing customers | 6.2, 6.18 |
| I'm considering a loan | 6.10 |
| I want a grant | 6.11, 6.12, Bonus 8 |
| Someone wants to invest | 6.16 |
| Should I open a second branch? | 6.15 |
| I need a business name or slogan | Bonus 14 |
| What if disaster strikes? | 6.17, Bonus 15 |
| I need a quotation for a company/school | 3.11, Bonus 7 |
| The AI's answer isn't good | Bonus 5 (Universal Fix-It Prompt) |

---

## GLOSSARY: PLAIN-ENGLISH TERMS USED IN THIS BOOK

| Term | What it means |
|---|---|
| **AI (Artificial Intelligence)** | Software that understands and produces text like a person. In this book: Meta AI, ChatGPT, Gemini, DeepSeek, Copilot. |
| **Prompt** | What you type to the AI — your question or instruction. Better prompt, better answer. |
| **Attach rate** | The share of customers who buy an add-on with their main purchase. |
| **Average sale / average order value** | Total sales ÷ number of transactions. Raising it is often easier than finding new customers. |
| **B2B** | Business-to-business — selling to companies, schools, hotels, churches instead of individuals. |
| **Break-even** | The sales level where you cover all your costs — no profit, no loss. Below it, you're losing money. |
| **Bundle** | Several items sold together at one price, usually with a saving. |
| **Cash flow** | Money actually coming in and going out, and *when*. Different from profit. |
| **Conversion** | Turning an enquiry into a paid sale. "Conversion rate" = paid ÷ enquiries. |
| **Cost of sales / cost of goods** | What you paid for the stock or materials in the products you sold. |
| **Cross-sell** | Suggesting a related item ("a case with that phone"). |
| **Customer avatar / persona** | A detailed description of your ideal customer as if they were one real person. |
| **Debtor** | A customer who owes you money. |
| **Deposit** | Part payment made in advance to secure an order. |
| **Diaspora** | Nigerians living abroad. |
| **Emergency fund** | Money set aside to survive a crisis — target: 3 months of fixed costs. |
| **Fixed costs** | Costs you pay whether you sell or not: rent, salaries, generator baseline, data. |
| **Funnel** | The stages from enquiry → price → agreed → paid. Where people drop off is where money leaks. |
| **Gross profit** | Revenue minus cost of sales. |
| **Gross margin** | Gross profit as a % of revenue. |
| **Lead** | A potential customer who has shown interest. |
| **Lifetime value** | Total profit a customer brings over all the time they buy from you. |
| **Margin** | The profit portion of a price, usually as a percentage. |
| **Net profit** | What's left after *all* costs, including fixed costs — the real profit. |
| **Objection** | A reason a customer gives for not buying ("too expensive", "let me think"). |
| **P&L (Profit & Loss)** | A one-page monthly summary: revenue, costs, profit. |
| **Payback period** | How long an investment takes to pay for itself from savings or profit. |
| **Positioning** | How customers see you compared to competitors (cheapest, best quality, fastest, most trusted). |
| **Pre-order** | Customers pay before the product is ready or arrives. |
| **Quick Replies** | Saved messages in WhatsApp Business you send with a shortcut like /price. |
| **Repurposing** | Using one piece of content in several ways. |
| **Reseller / agent** | Someone who buys from you at a lower price and sells to their own customers. |
| **RRP** | Recommended retail price — the price you tell resellers to sell at. |
| **Segment** | A group of customers with similar needs (bulk buyers, walk-ins, corporate). |
| **SOP (Standard Operating Procedure)** | A written, step-by-step instruction for a task so it's done the same way every time. |
| **Subscription** | Customers pay regularly (weekly/monthly) for regular delivery. |
| **Testimonial** | A customer's words about their experience — your best marketing. |
| **Tier** | A level of offer: standard, premium; silver, gold. |
| **Upsell** | Suggesting a better/bigger version ("the 10-inch instead of the 8-inch"). |
| **Variable costs** | Costs that rise with each sale: materials, packaging, delivery, POS charges. |
| **Wholesale** | Selling in bulk at a lower unit price to resellers. |
| **Working capital** | The cash you need to run day to day — buying stock before you sell it. |

---

## A FINAL WORD FROM THE AUTHOR

This book was written with one conviction: **the Nigerian small-business owner is one of the most resourceful people on earth.** You have built and kept a business alive through fuel hikes, currency swings, power failures, harassment, and a thousand daily frictions that would close most businesses elsewhere in a month.

You never lacked intelligence or work ethic. What was missing was a **tireless, patient, knowledgeable assistant** — one who could write your messages, do your maths, rehearse your negotiations, plan your week and never charge you a kobo. That assistant now lives inside the phone in your hand.

AI will not build your business. **You** will — one prompt, one customer, one honest week of numbers at a time. But you will do it faster, with fewer mistakes, and with more of your profit staying in your pocket.

Use the prompts. Fill in the trackers. Do the Sunday reviews. In 90 days, look back.

Then send me your story — I mean it.

*— Fresh Genesis*

---

## SHARE YOUR RESULTS

Your progress is proof for the next business owner who is where you were on Day 1.

- **WhatsApp:** +234 902 190 6332 — send your Day 1 vs. Day 90 numbers, your biggest win, or a question.
- Tag or forward this book to one business owner who needs it. Small businesses grow small businesses.

---

## WHAT TO READ NEXT — THE *AI MADE SIMPLE* SERIES

Each book in the series follows the same format you've just used: 6 Parts × 20 prompts, real examples, local tips, and ready-to-use tools.

| Book | For | Target outcome |
|---|---|---|
| **AI Made Simple for Job Seekers** | Graduates, NYSC members, career switchers, Nigerians applying abroad | More interviews, confident answers, a better offer |
| **AI Made Simple for Students** | SS1–SS3, JAMB candidates, undergraduates, postgraduates | Higher grades in fewer study hours — honestly |
| **AI Made Simple for Freelancers & Remote Workers** | Writers, designers, VAs, developers selling to local and international clients | Better clients, higher rates, fewer hours |
| **AI Made Simple for Content Creators** | YouTubers, TikTokers, Reels creators, thread writers | Double your output, grow, get paid |
| **AI Made Simple for Teachers & Tutors** | Teachers, lesson tutors, tutorial-centre owners | Two-thirds less prep time, more engaged students, more income |
| **AI Made Simple for Busy Professionals** | Corporate staff, managers, bankers, lawyers, doctors | 8–12 hours a week back, better decisions, faster promotion |

**Also from Fresh Genesis:**
- **Clarity Life Template Pack** — planners and templates to organise your week and goals.
- **Beginner-Friendly AI Prompt Workbook** — 90 general-purpose prompts for everyday life and work.
- **Fresh Start Digital Bundle** — both of the above, together.

Available via WhatsApp (+234 902 190 6332) and the Fresh Genesis store.

---

## ABOUT FRESH GENESIS

Fresh Genesis creates simple, practical digital products that help everyday people use modern tools — especially AI — to earn more, save time, and make better decisions. Everything we publish is built on one test: *could a busy person with a phone use this today?*

---

## COPYRIGHT & DISCLAIMER

© Fresh Genesis. All rights reserved.

This book is for personal use by the purchaser. You may print it for your own business and share individual prompts with your staff. Please do not resell, redistribute, or upload the full book. If it helped you, send someone the link instead — thank you.

**Disclaimer:** This book provides general business education. It is not financial, legal, tax, or investment advice. AI tools can produce errors; results depend on your business, your market, and your execution. Revenue and cost-saving figures are targets and examples, not guarantees. Verify all fees, rates, regulations and programme details with the relevant institutions or a qualified professional before making decisions. Fresh Genesis accepts no liability for actions taken on the basis of this content.

Names, businesses and figures in the examples are illustrative composites drawn from common Nigerian small-business situations.

---

*AI Made Simple for Nigerian Small-Business Owners*
*120 Practical Prompts to Grow Your Business With AI — Even If You've Never Used It Before*

**— END —**
