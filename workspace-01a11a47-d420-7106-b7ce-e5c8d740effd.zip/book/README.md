# AI Made Simple for Nigerian Small-Business Owners — Book 1

**Deliverable:** `PDF/AI-Made-Simple-Nigerian-Small-Business-Owners.pdf` (131 pages, 6×9in, phone-friendly)
**Cover:** `cover/cover.png` (1600×2400) · art in `cover/cover-art.png`
**Listing copy, pricing, launch messages:** `LISTING-AND-LAUNCH-KIT.md`
**Series plan (Books 1–7):** `SERIES-PLAN-AI-Made-Simple-v2.md`

## Manuscript (edit these, then rebuild)
00-front-matter.md · 01…06 Parts 1–6 (120 prompts) · 07/08 Bonuses 1–15 · 09-back-matter.md

## Rebuild
```bash
cd /home/user/book
cat 00-front-matter.md > AI-Made-Simple-Nigerian-Small-Business-Owners-MANUSCRIPT.md
for f in 01 02 03 04 05 06 07 08 09; do printf "\n\n<div class='pb'></div>\n\n" >> AI-Made-Simple-Nigerian-Small-Business-Owners-MANUSCRIPT.md; cat $f-*.md >> AI-Made-Simple-Nigerian-Small-Business-Owners-MANUSCRIPT.md; done
python3 build/build-pdf.py
```
Requires: `pip install playwright pypdf markdown pymupdf` + `python3 -m playwright install chromium` and the extracted Chromium libs in `~/.local/chromium-libs` (see root README).

## Extras (build/build-extras.py)
- `sample/3-AI-Prompts-Every-Naija-Business-Owner-Should-Try-FREE-SAMPLE.pdf` — 8-page lead magnet (Prompts 1.1, 2.2, 3.3 + offer page). Also copied to `simplifyai-site/free/3-AI-Prompts-Sample.pdf` → live at /free/3-AI-Prompts-Sample.pdf after deploy.
- `library/Prompt-Library.html` — companion library for buyers: all 120 prompts with Copy / Send-to-WhatsApp buttons and search. Send this file (or host it on a private link) with every purchase.
- `library/Prompt-Library.txt` — same, plain text.
