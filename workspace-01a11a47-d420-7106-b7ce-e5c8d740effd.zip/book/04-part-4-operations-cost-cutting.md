# PART 4: OPERATIONS, AUTOMATION & COST CUTTING
*(Prompts 4.1 – 4.20)*

---

## The Part Where You Stop Being the Business

There is a stage every Nigerian small business reaches: sales are coming in, but the owner is exhausted. You open the shop, reply the messages, chase the supplier, pay the generator man, argue with the POS network, train the new girl, count the money at night, and start again at 6am. The business is growing — but it is growing around *you*, and you cannot be everywhere.

Meanwhile, money leaks quietly: fuel that costs more every month, stock that expires, data that finishes too fast, staff who waste, rent that eats a third of your profit, small mistakes that cost big.

This Part has one goal: **cut at least 35% off your running costs and save 10+ hours a week** — without lowering quality or firing anyone unfairly. That 35% is not magic. It comes from:

- Writing down how things should be done, once, so you stop repeating yourself (SOPs)
- Letting WhatsApp Business and simple templates do your repetitive typing
- Attacking your five biggest expenses with a plan, not a sigh
- Tracking stock and cash so nothing "disappears"
- Building simple systems that work when you are not there

None of it needs a laptop or a consultant. It needs your phone, this Part, and one honest week of looking at your numbers.

**Start with 4.1, 4.5 and 4.9** — your expense audit, your first SOP, and your WhatsApp automation. Those three alone can recover the 35%.

---

## Prompt 4.1

### Title: Audit Your Expenses and Find the 35% You Can Cut

**Use this when:** You feel money is leaking but you cannot say exactly where. Do this first — everything else in this Part builds on it.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Here are my monthly expenses as best I know them: [list every one with amount — rent, generator fuel, electricity bill, staff salaries, transport/delivery, data/airtime, packaging, stock purchases, POS charges, bank charges, repairs, cleaning, security, levies/association dues, waste/spoilage, personal withdrawals, others]. My monthly revenue is roughly ₦[amount]. Analyse this like an experienced Nigerian business accountant. Tell me: (1) which expenses are unusually high for my type of business, (2) the 5 biggest opportunities to cut costs without hurting sales or quality, with an estimated naira saving for each, (3) which costs I should NOT cut because they drive revenue, (4) hidden costs I probably forgot to list, and (5) a 30-day cost-cutting plan in order of easiest and biggest first.

**Real example (filled in):**

> I run a small restaurant (buka) in Uyo. Monthly expenses: rent ₦45,000; generator fuel ₦95,000; electricity ₦12,000; 3 staff ₦105,000 total; foodstuff purchases ₦380,000; gas ₦38,000; packaging/takeaway packs ₦42,000; water ₦8,000; transport to market ₦24,000; data/airtime ₦9,000; POS charges about ₦6,000; waste (food that spoils or is left over) roughly ₦35,000; repairs ₦10,000; association dues ₦3,000; my own withdrawals ₦80,000. Revenue is roughly ₦950,000. Analyse this like an experienced Nigerian business accountant: what's unusually high, the 5 biggest cost-cutting opportunities with naira savings, what NOT to cut, hidden costs I forgot, and a 30-day plan.

**Naija tip:** Do this with **real numbers, not guesses** — spend one week writing down every kobo that leaves the business, including "small" things like ₦200 bike fares and the ₦500 you gave the LASTMA man. Most owners discover two shocks: their **generator costs more than their rent**, and their **personal withdrawals are not tracked at all**. Both are fixable. Do this audit every quarter; costs in Nigeria creep up while you're busy.

---

## Prompt 4.2

### Title: Cut Your Generator, Fuel and Power Costs

**Use this when:** Fuel and generator costs are eating your profit — which, for most Nigerian businesses today, they are.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. My power situation: NEPA/grid gives about [hours] per day; I run a [generator size] generator for about [hours] daily, costing roughly ₦[amount] per month in fuel plus ₦[amount] in servicing. The things I actually need power for are: [list — fridge/freezer, lights, fans, POS charging, clippers, blender, sewing machine, etc.]. Help me cut this cost by at least 30%. Tell me: (1) which of my power uses actually need the generator and which can run on smaller alternatives, (2) whether a solar/inverter setup makes sense for me and roughly what size and budget — with a payback calculation against my fuel spend, (3) 8 practical habits that reduce fuel use immediately, (4) how to schedule generator use around my busiest hours, and (5) any low-cost equipment swaps (e.g., LED bulbs, DC fans, energy-efficient fridge) worth considering.

**Real example (filled in):**

> I run a frozen foods shop in Abeokuta. NEPA gives about 6–8 hours a day, unpredictable. I run a 3.5kVA generator about 8 hours daily, costing about ₦110,000 monthly in fuel and ₦8,000 in servicing. I need power for: 2 chest freezers, 1 standing fridge, lights, a fan, and POS charging. Help me cut this cost by at least 30%: which uses need the generator versus alternatives, whether solar/inverter makes sense and what size/budget with payback against ₦110,000 monthly fuel, 8 habits that reduce fuel use immediately, how to schedule generator hours, and low-cost equipment swaps.

**Naija tip:** The freezer trick every frozen-foods seller should know: **a full freezer stays cold far longer than a half-empty one** — fill gaps with bottles of water, keep the lid shut, and you can run the generator in 2-hour blocks instead of continuously. Also ask the AI to do the **solar payback maths** with your real fuel figure: at ₦100,000+ per month in fuel, many setups pay for themselves in under 18 months. Treat *Check Before You Trust It* seriously here — get 2–3 real quotes from installers before spending.

---

## Prompt 4.3

### Title: Write a Standard Operating Procedure (SOP) for Any Task

**Use this when:** You keep explaining the same thing to staff, or things go wrong the moment you step out. This prompt lets you write your business down.

**Copy this prompt:**

> Write a simple Standard Operating Procedure (SOP) for [the task — e.g., opening the shop, taking a customer order, packaging a delivery, closing and cashing up, receiving stock from a supplier, handling a return]. My business is a [type] in Nigeria. Details of how I want it done: [describe your way, including any rules, tools, timings, or common mistakes]. Format the SOP as: purpose (1 line), who does it, when it happens, materials needed, numbered steps in very simple English (each step one action), common mistakes and how to avoid them, and what "done properly" looks like. Keep it to one page so it can be printed and pasted on the wall. Add 3 quick check questions I can ask staff to confirm they understand.

**Real example (filled in):**

> Write a simple SOP for closing the shop and cashing up at the end of the day. My business is a small supermarket in Enugu with 2 staff. How I want it done: count cash and compare with the sales record and POS printout, write any difference and the reason, put the cash in the safe, photograph the sales page and send it to me on WhatsApp, switch off the freezers' display lights but not the freezers, check the back door and windows, switch off the generator properly (let it cool first), lock up and send me a "closed" message with the time. Common mistakes: forgetting to record the POS total separately, leaving the fan on, not photographing the record. Format as a one-page SOP with numbered steps and 3 check questions.

**Naija tip:** Write an SOP for the **five tasks that annoy you most** to repeat — that's usually opening, closing, order-taking, delivery packing, and stock receiving. Print them, paste them where the task happens (closing SOP by the door, packing SOP by the packing table). A business with five one-page SOPs can survive the owner being away for a week. That's the beginning of freedom.

---

## Prompt 4.4

### Title: Design a Simple Stock Control System (Stop Things "Disappearing")

**Use this when:** You don't know exactly what you have, stock runs out unexpectedly, items expire, or you suspect stock is walking out the door.

**Copy this prompt:**

> I run a [business type] in Nigeria with about [number] different items in stock. Currently I track stock by [describe — memory, a notebook, nothing]. Problems: [running out of fast-sellers, over-stocking slow items, expiry/spoilage, suspected theft, not knowing profit per item]. Design me a simple stock control system I can run with a notebook or a free phone app (e.g., Google Sheets), including: (1) what to record for each item and how often to count, (2) a reorder rule — when and how much to reorder for fast, medium, and slow items, (3) how to spot theft or unexplained losses quickly, (4) how to handle items with expiry dates (first in, first out), (5) a 15-minute daily routine and a 1-hour weekly routine, and (6) a simple table layout I can copy into a notebook or spreadsheet.

**Real example (filled in):**

> I run a cosmetics and skincare shop in Aba with about 180 different items. Currently I track stock mostly from memory and a rough notebook. Problems: my fast-moving creams run out and customers leave; some expensive serums have expired unsold; I sometimes count and find fewer items than I expect; I don't really know which items make me the most profit. Design a simple stock control system I can run with a notebook or Google Sheets: what to record and how often to count, reorder rules for fast/medium/slow items, how to spot theft or losses quickly, first-in-first-out for expiry items, a 15-minute daily and 1-hour weekly routine, and a simple table layout.

**Naija tip:** Start with your **top 20 items by sales** — not all 180. Those 20 probably bring 70% of your money; control them first. Do a **surprise count** of 10 random items once a week; when staff know the count can come any day, "disappearance" drops dramatically. And put a small sticker with the arrival month on every expiry-sensitive item — the oldest goes to the front, always.

---

## Prompt 4.5

### Title: Automate Your WhatsApp Replies and Save Hours a Day

**Use this when:** You spend 2–4 hours daily typing the same answers — prices, location, delivery, opening hours, "is it available?"

**Copy this prompt:**

> I run a [business type] in Nigeria and I answer the same customer questions on WhatsApp all day. My details: [products/services and prices, location or delivery areas, opening hours, delivery fees and times, payment methods, return/refund policy, how to order]. Set up my WhatsApp Business automation for me: (1) a greeting message for new contacts, (2) an away message for after hours, (3) 12 Quick Replies with a short shortcut name for each (e.g., /price, /delivery, /location, /pay, /hours, /order, /thanks, /followup, /outofstock, /bulk, /return, /proof) and the full text, and (4) a suggested catalogue structure. Each reply should be warm, clear, under 60 words, and end with a next step. Also tell me which questions I should NOT automate and must answer personally.

**Real example (filled in):**

> I run a small bakery and small-chops business in Port Harcourt. Details: bread ₦1,200–₦1,800, meat pie ₦700, small chops tray ₦12,000–₦35,000, custom cakes from ₦18,000; I deliver within GRA, Rumuola, D-Line and Woji for ₦1,500–₦2,500, same day if ordered before 12 noon; open 7am–8pm Mon–Sat; payment by transfer or Paystack link; cakes need 48 hours' notice and 60% deposit; no refunds on custom cakes once baked. Set up my WhatsApp Business automation: greeting, away message, 12 Quick Replies with shortcuts and full text, and a catalogue structure. Tell me which questions I should not automate.

**Naija tip:** Quick Replies are free, live inside WhatsApp Business, and most Nigerian vendors have never opened the menu (Business tools → Quick replies). Type the shortcut, press send: 3 seconds instead of 90. With 100 messages a day, that's **over two hours saved daily**. But never automate the *human* moments — a complaint, a big order, a nervous first-timer. Those get your real voice, fast.

---

## Prompt 4.6

### Title: Create Professional Invoices, Receipts and Price Lists

**Use this when:** You send prices as random voice notes and blurry photos, and customers (especially corporate ones) don't take you seriously.

**Copy this prompt:**

> I run a [business type] in Nigeria. Business name: [name]. Contact: [phone/WhatsApp, address or delivery area]. Products/services and prices: [list]. Payment details: [bank/POS/payment link]. Create for me: (1) a clean price list layout I can type into Google Docs or Canva — grouped by category, with any bulk prices, delivery fees, and terms at the bottom, (2) an invoice template with all the fields a Nigerian customer or company would expect (invoice number, date, customer details, item table, subtotal, delivery, VAT line if applicable, total, payment details, due date, terms), (3) a simple receipt template, and (4) a short note on what makes an invoice look professional versus amateur, and how to number and file them so I can track who has paid.

**Real example (filled in):**

> I run a printing and branding business in Kaduna — flyers, banners, business cards, branded T-shirts and mugs. Business name: [my business name]. Contact: 0902 190 6332, delivery within Kaduna and by waybill nationwide. Prices: A5 flyers (100 pcs) ₦8,000; roll-up banner ₦35,000; business cards (100) ₦6,500; branded T-shirt ₦6,000 each (min 10); branded mug ₦3,500 (min 12). Payment by transfer or Paystack link; 70% deposit on order. Create a price list layout, an invoice template with all the fields a Nigerian company expects, a receipt template, and a note on professional vs. amateur invoices and how to number and file them.

**Naija tip:** A numbered invoice PDF with your business name and account details does three things at once: it makes companies pay faster, it makes tax and record-keeping possible, and it quietly says "this is a real business." Free tools: Google Docs (make a template, duplicate it each time), Canva, or the free invoicing feature in many Nigerian business banking apps (Moniepoint, Kuda Business, etc.). Number invoices by month — 2026-09-001 — so you can find anything in seconds.

---

## Prompt 4.7

### Title: Write Job Descriptions and Hire the Right Staff

**Use this when:** You need to hire a shop assistant, cook, tailor, rider, or apprentice — and your last hires didn't work out.

**Copy this prompt:**

> I need to hire a [role] for my [business type] in [area], Nigeria. Salary budget: ₦[amount] per month. The person will [main duties]. What went wrong with previous hires: [e.g., lateness, dishonesty, rude to customers, left after 2 months, couldn't use a phone/POS]. Help me hire better. Give me: (1) a clear, short job description I can post on WhatsApp Status, community groups, or tell people by word of mouth, (2) the 5 qualities that matter most for this role — and how to test for each in an interview, (3) 8 interview questions including 2 practical tests they must do on the spot, (4) red flags to watch for, (5) a simple 2-week trial arrangement and what to observe, and (6) a one-page agreement covering duties, salary, hours, conduct, and what leads to dismissal.

**Real example (filled in):**

> I need to hire a shop assistant for my boutique in Asaba. Salary budget: ₦45,000 per month. She will attend to customers, take payments by POS and transfer, post on WhatsApp Status, keep the shop tidy, and record sales in a notebook. Previous hires: one was frequently late, one was caught keeping change, one was rude to customers and left after 6 weeks. Help me hire better: a short job description to post, the 5 qualities that matter most and how to test each, 8 interview questions with 2 practical tests (e.g., handle a mock customer, count change correctly), red flags, a 2-week trial plan, and a one-page agreement.

**Naija tip:** **Test, don't ask.** Anybody can say they're honest and hardworking. Instead: give them ₦3,000 in mixed notes and ask them to make change for a ₦1,250 sale; hand them a phone and ask them to write a Status caption for a dress; play an annoying customer and watch their face. Fifteen minutes of practical testing tells you more than a certificate. Always take a guarantor's details and verify them by phone — it is normal in Nigeria and it protects you.

---

## Prompt 4.8

### Title: Train Staff Fast With a One-Week Onboarding Plan

**Use this when:** A new person has started, and you don't have time to stand beside them all day.

**Copy this prompt:**

> I've hired a new [role] for my [business type] in Nigeria. Create a 5-day onboarding plan that gets them working confidently by the end of week one. For each day: what to teach (in order of importance), how to teach it in under 30 minutes, a task they must do alone that day, and how I'll check it. Include: our products/services and prices, how we greet and serve customers, how we handle money and POS, our SOPs for [list your key tasks], what to do when they don't know something, our rules on phone use, punctuality and honesty, and how they'll be evaluated after 2 weeks. Write it so I can hand it to them as a checklist they tick off.

**Real example (filled in):**

> I've hired a new kitchen assistant/server for my small restaurant in Ilorin. Create a 5-day onboarding plan covering: our menu and prices, portion sizes and how we plate, how we greet and serve, hygiene rules (hand washing, hair covering, handling money then food), taking orders and using the POS, our opening and closing SOPs, what to do if a customer complains, phone use during work, punctuality, and how she'll be evaluated after 2 weeks. For each day: what to teach, how to teach it in under 30 minutes, a task she does alone, and how I check it. Write it as a checklist she can tick.

**Naija tip:** The first week decides whether a staff member becomes an asset or a headache. Most Nigerian owners "onboard" by shouting corrections for a month. Instead: **teach one thing, watch them do it, praise what's right, correct what's wrong — then move on**. Pair the new hire with your best staff for the week, and give that senior staff ₦2,000 extra for doing it well. Culture is taught, not hoped for.

---

## Prompt 4.9

### Title: Reduce Waste, Spoilage and Returns

**Use this when:** You throw away food, fabric, materials, or expired stock; or products come back damaged; and it's quietly costing you tens of thousands monthly.

**Copy this prompt:**

> I run a [business type] in Nigeria. Waste I currently experience: [describe — leftover food, spoiled perishables, off-cuts, expired products, damaged goods in delivery, printing errors, customer returns] costing me roughly ₦[amount] per month. How I currently buy and use materials: [describe quantities, frequency, storage]. Help me cut this waste by at least half. Tell me: (1) the root causes, (2) 8 practical changes in how I buy, store, prepare, or package, (3) how to turn some waste into a product or a sale (e.g., end-of-day discounts, smaller portions, off-cut products), (4) how to forecast daily or weekly demand better so I produce or buy closer to what sells, and (5) a simple waste log I can keep for 2 weeks to find the real numbers.

**Real example (filled in):**

> I run a fruit juice and smoothie stand in Lagos (Yaba). Waste: fruits that go bad before use, roughly 15–20% of what I buy; juice made in the morning that isn't sold by evening; cups and packaging spoiled by rain and rough storage. Roughly ₦45,000 per month lost. I buy fruits every 2 days at Mile 12, store them in baskets in the shop, and make juice in big batches each morning. Help me cut waste by at least half: root causes, 8 practical changes in buying, storing, preparing, and packaging, how to turn waste into sales (end-of-day deals, frozen smoothie packs, fruit cups), how to forecast demand day by day, and a 2-week waste log.

**Naija tip:** Every ₦1 of waste you cut is **pure profit** — you already paid for it. The two highest-return moves in food businesses: **make in smaller batches more often** instead of one big morning batch, and run a **"5pm special"** on WhatsApp Status for whatever is left (₦300 off — you still make more than throwing it away). For non-food businesses, most waste comes from **unclear order specifications** — fix the order form and returns drop.

---

## Prompt 4.10

### Title: Negotiate Better Prices With Your Suppliers

**Use this when:** You accept supplier prices as given, or you've never asked for better terms, credit, or delivery — and your margins are suffering.

**Copy this prompt:**

> I run a [business type] in Nigeria. My main suppliers and what I buy: [list suppliers, items, roughly how much I spend with each monthly, how long I've bought from them, how I pay]. Help me negotiate better. Tell me: (1) what I can realistically ask for — price reduction, bulk discount, credit terms, free delivery, better payment timing, returns on unsold stock, priority during scarcity, (2) how to prepare — what numbers to have ready and how to find out what others pay, (3) a respectful negotiation script for a face-to-face or WhatsApp conversation with a supplier I've used for a long time, (4) how to approach a new supplier to create healthy competition without burning the old relationship, and (5) the risks of pushing too hard in the Nigerian market and how to avoid them.

**Real example (filled in):**

> I run a small provisions and drinks shop in Kano. Main suppliers: a drinks distributor (₦280,000 monthly, 2 years, cash on delivery); a rice/grain wholesaler at Dawanau (₦150,000 monthly, 3 years, cash); a toiletries wholesaler in Sabon Gari (₦90,000 monthly, 1 year, cash). Help me negotiate better: what I can realistically ask for from each, how to prepare and find what others pay, a respectful script for the drinks distributor I've used for 2 years, how to approach a second drinks supplier without damaging the relationship, and the risks of pushing too hard.

**Naija tip:** Suppliers give better terms to customers who are **predictable and loyal** — pay on time, buy regularly, and tell them your growth plans. Then ask: "Oga, I've been buying ₦280k every month for two years without fail. What can you do for me on price or credit?" Most Nigerian owners never ask, and suppliers never volunteer. A 5% supplier discount on ₦500,000 monthly purchases is ₦300,000 a year — for one conversation.

---

## Prompt 4.11

### Title: Cut Delivery and Transport Costs

**Use this when:** Delivery fees, dispatch riders, waybills, or your own transport to market are eating your margin — or customers complain your delivery is too expensive.

**Copy this prompt:**

> I run a [business type] in [city], Nigeria. My delivery/transport situation: [how you deliver — own bike/car, dispatch riders, waybill/logistics companies, public transport to market; typical volumes per day/week; what it costs monthly; what you charge customers; common problems like late riders, damaged goods, failed deliveries]. Help me cut these costs and improve reliability. Tell me: (1) whether I'm under-charging customers for delivery and what a fair delivery fee structure looks like by zone, (2) how to batch and schedule deliveries to reduce trips, (3) how to negotiate a better arrangement with dispatch riders or logistics companies, (4) when it makes sense to get my own rider or bike versus outsourcing, with a simple cost comparison, and (5) how to reduce failed deliveries and damaged items.

**Real example (filled in):**

> I run an online fashion store in Lagos, shipping about 8–12 orders a day within Lagos and 10–15 a week to other states. I use different dispatch riders found on Instagram for Lagos (₦2,000–₦4,500 per trip, I charge customers ₦2,500 flat) and GIG/waybill for other states. Problems: riders arrive late or cancel, some customers don't pick calls and the rider returns, I lose money on far deliveries like Ikorodu and Badagry. Monthly delivery cost is roughly ₦380,000. Help me: fair zoned delivery fees for Lagos, how to batch deliveries by area and day, how to negotiate a fixed arrangement with 1–2 reliable riders, own rider vs. outsourcing cost comparison, and reducing failed deliveries.

**Naija tip:** Two changes fix most delivery problems in Lagos and Abuja: **zone-based pricing** (Island / Mainland / Outskirts — never one flat fee) and **"Tuesday & Friday for far zones"** batching. Add a rule that far deliveries are **paid before dispatch**, and failed-delivery losses nearly vanish. If you're sending 8+ packages a day, a fixed retainer with one reliable rider (₦60,000–₦90,000/month) usually beats per-trip pricing — do the maths with the AI.

---

## Prompt 4.12

### Title: Plan Your Week So the Business Doesn't Eat Your Life

**Use this when:** You work 14 hours a day and still feel behind; everything feels urgent; you have no time to think, market, or rest.

**Copy this prompt:**

> I run a [business type] in Nigeria, [alone / with X staff]. Here is what a typical day looks like for me: [describe from waking to sleeping, honestly]. My biggest time-wasters: [e.g., replying messages all day, going to market myself, chasing suppliers, fixing staff mistakes, NEPA/generator issues]. Things I never get time for: [marketing, records, planning, family, rest]. Design a realistic weekly schedule for me that: (1) groups similar tasks into blocks (messages, market runs, records, marketing), (2) identifies which tasks I should delegate or systemise, and to whom, (3) protects 1 hour a day for owner's work (planning, marketing, numbers), (4) includes fixed times for rest and family, and (5) gives me a 10-minute end-of-day routine. Then tell me the ONE change that would give me the most time back.

**Real example (filled in):**

> I run a tailoring and fashion design business in Owerri with 2 apprentices and 1 tailor. Typical day: wake 5:30, market for fabrics/threads 3 times a week, in the shop by 8, cutting and sewing all day while replying WhatsApp constantly, customers dropping by unannounced for measurements or corrections, generator wahala, home by 9pm, then replying messages till midnight. Time-wasters: constant interruptions, market trips, redoing apprentices' mistakes. Never get time for: posting on Status regularly, doing my accounts, resting on Sundays. Design a realistic weekly schedule with task blocks, what to delegate to whom, 1 hour daily for owner's work, fixed rest time, a 10-minute end-of-day routine, and the ONE change that gives me the most time back.

**Naija tip:** For most Nigerian owners, the one change is **fixed hours for WhatsApp** — three blocks a day (e.g., 8am, 1pm, 7pm), with an away message explaining it. Customers adjust within a week and actually respect you more. The second change: **appointment-only measurements/consultations** ("Tuesdays and Thursdays, 10am–2pm"). A business that runs on your rhythm, not everyone else's, is a business you can grow.

---

## Prompt 4.13

### Title: Build a Simple Daily Sales & Cash Record (That Staff Can Keep)

**Use this when:** You don't know your exact daily sales, cash doesn't match at the end of the day, or you can't tell how much profit you made last week.

**Copy this prompt:**

> I run a [business type] in Nigeria and I want a simple daily record that my staff (school-leaver level) can keep accurately. Design a one-page daily record sheet that captures: opening cash, each sale or a sales tally by product/category, payment type (cash / POS / transfer), expenses paid from the till with reason, closing cash, and a reconciliation line showing whether the cash matches. Then: (1) explain how to fill it in simple steps, (2) add a weekly summary sheet that totals sales, expenses, and gross profit, (3) suggest a 5-minute end-of-day check I do by looking at the sheet, and (4) show me how this could live in a free Google Sheet with columns and one or two simple formulas — or in a notebook if I prefer.

**Real example (filled in):**

> I run a small pharmacy in Nsukka with 2 staff. I want a one-page daily record they can keep accurately capturing opening cash, sales tallies by category (drugs, toiletries, baby products, drinks), payment type (cash / POS / transfer), expenses paid from the till with reason, closing cash, and whether the cash matches. Explain how to fill it in simple steps, add a weekly summary that totals sales, expenses, and gross profit, suggest a 5-minute end-of-day check, and show me how to set it up in a free Google Sheet with simple formulas — or in a notebook.

**Naija tip:** Cash that "doesn't balance" is the most common silent loss in Nigerian shops, and it's rarely one big theft — it's ₦500 here, ₦1,200 there, unrecorded "expenses," and change errors. A one-page sheet that **must balance before anyone goes home** ends it. Photograph the sheet daily to WhatsApp — it's your backup and your audit trail. (Bonus 11 in this book gives you a ready-made version.)

---

## Prompt 4.14

### Title: Handle Customer Enquiries and Support Faster With Templates

**Use this when:** Beyond price questions, you get "where is my order?", "how do I use this?", "can I change my order?", "you sent the wrong size" — and each one takes 10 minutes to handle.

**Copy this prompt:**

> I run a [business type] in Nigeria. The support situations I handle repeatedly are: [list — order status, delivery delays, how-to-use questions, order changes, wrong item, damaged item, request for refund, out of stock, payment not confirmed, customer can't find rider]. For each, write a short reply template (under 70 words) that: acknowledges the customer, gives clear information or the next step, and where relevant sets a time expectation. Also give me: (1) a simple internal rule for how fast to reply during and after hours, (2) which situations I should escalate to a phone call rather than text, and (3) a one-line closing I can use to end support chats positively.

**Real example (filled in):**

> I run an online store selling kitchen gadgets and home items across Nigeria. Repeated support situations: "where is my order?" (Lagos and interstate), delivery delayed by logistics company, "how do I use this air fryer/blender?", customer wants to change item after payment, wrong item sent, item arrived damaged, refund request, item out of stock after payment, payment made but not yet confirmed, and customer can't reach the rider. Write a short reply template for each under 70 words. Add a response-time rule, which situations need a phone call, and a positive one-line closing.

**Naija tip:** The single most valuable support habit in Nigeria is the **proactive update**: send the tracking or rider's number *before* the customer asks. "Your order left with GIG today, waybill number XXXX, expect it Thursday." That message prevents five "where is my order?" messages. Save every template as a Quick Reply and reply within 15 minutes in business hours — speed is the cheapest premium service you can offer.

---

## Prompt 4.15

### Title: Reduce Bank, POS and Transaction Charges

**Use this when:** You're losing thousands monthly to POS charges, transfer fees, SMS alerts, and failed-transaction wahala — and you've never added it up.

**Copy this prompt:**

> I run a [business type] in Nigeria. My monthly payment activity: roughly [number] cash sales, [number] POS card payments, [number] transfers received, [number] transfers sent to suppliers; total monthly revenue about ₦[amount]. I currently use [bank names / POS provider / fintech apps]. Charges I've noticed: [POS %, transfer fees, SMS alert fees, maintenance fees, stamp duty, failed transactions]. Help me cut these costs. Tell me: (1) roughly what I'm likely paying in total charges per month and per year, (2) which type of account or provider tends to suit a small business with my pattern (I'll verify current fees myself), (3) practical habits that cut charges — batching supplier payments, using the right channel for the right amount, avoiding failed transactions, (4) how to handle customers who want to pay by POS for tiny amounts, and (5) how to keep a monthly record of charges so I can see them.

**Real example (filled in):**

> I run a small restaurant in Abuja. Monthly: about 900 cash sales, 350 POS card payments, 200 transfers received, 40 transfers sent to suppliers; revenue about ₦1.4M. I use a traditional bank account, a POS from a fintech, and I sometimes receive into my personal account. Charges I've noticed: POS deductions per transaction, ₦10–₦50 per transfer, SMS alert fees, monthly maintenance, stamp duty on some deposits, and occasional failed POS transactions that take days to reverse. Help me estimate my total charges monthly and yearly, what kind of account/provider suits my pattern, practical habits to cut charges, how to handle ₦300 POS payments, and how to keep a monthly charges record.

**Naija tip:** Fees change often in Nigeria — this is a **Check Before You Trust It** prompt. Use the AI for structure and habits, then confirm actual current fees with the providers. Two habits save most owners money immediately: **separate business and personal accounts** (personal-account mixing is where charges and confusion multiply), and **pay suppliers in one batch on one day** instead of dribbling transfers all week.

---

## Prompt 4.16

### Title: Create Checklists for Quality Control (Get It Right Every Time)

**Use this when:** Mistakes reach customers — wrong sizes, missing items, a badly finished product, unclean tables — and each one costs you a customer or a redo.

**Copy this prompt:**

> I run a [business type] in Nigeria. Quality problems that reach customers: [list — wrong item packed, missing part, poor finishing, dirty presentation, late delivery, incorrect measurements, spelling errors on prints, food not hot, etc.]. Create quality-control checklists for the 3 most important points in my process: (1) before starting work/production, (2) before packaging or handing over, and (3) after delivery/service. Each checklist should be 6–10 tick-box items in very simple English, printable on half a page. Then tell me who should own each checklist, how to make staff actually use them (not just tick blindly), and a simple way to track how many mistakes we make per week so I can see improvement.

**Real example (filled in):**

> I run a small printing and branding shop in Ibadan. Quality problems that reach customers: spelling errors on flyers and banners, wrong colours from what was approved, prints cut crookedly, T-shirt prints peeling after a wash, orders delivered late, and packages missing items. Create quality-control checklists for: before starting a job (artwork approval, spelling check, colour confirmation), before packaging/handover, and after delivery. 6–10 tick-box items each, very simple English. Tell me who owns each checklist, how to make staff use them properly, and how to track mistakes per week.

**Naija tip:** The **"customer confirmation screenshot"** rule prevents most disputes in print, tailoring, cake and design businesses: no job starts until the customer has replied "Approved" to the final design, size, or spelling on WhatsApp. Screenshot it. Then when "but I said blue" arrives, you have peace and proof. Reward the staff member with the fewest errors each month — ₦2,000 and public praise — and watch quality rise.

---

## Prompt 4.17

### Title: Use AI as Your Personal Assistant for Daily Admin

**Use this when:** You want to use AI for the small daily tasks that pile up — drafting messages, calculating, summarising, making lists, converting units, planning your day.

**Copy this prompt:**

> Act as my business assistant. I run a [business type] in Nigeria. Today I need help with these small tasks: [list — e.g., calculate my profit on these 5 sales; draft a message to a late supplier; make a shopping list for the market with quantities for 40 plates of jollof; convert this USD price to naira at ₦[rate]; summarise these customer messages into a to-do list; write a polite reminder to a customer; plan my day given these 6 things I must do]. Do each task clearly, one after the other, and keep the answers short and practical. Where you need a number I haven't given, ask me instead of guessing.

**Real example (filled in):**

> Act as my business assistant. I run a small catering business in Lagos. Today I need help with: (1) calculate ingredients and quantities for 80 plates of jollof rice with chicken and 80 plates of fried rice, (2) estimate the cost using these prices: bag of rice ₦95,000 (50kg), chicken ₦4,200/kg, tomato paste ₦1,200 per tin, vegetable oil ₦3,500 per litre, seasoning and spices ₦8,000 total, gas ₦5,000, (3) draft a polite WhatsApp message to my chicken supplier who is 2 days late on delivery, (4) turn these six things into a time-blocked plan for tomorrow: market run, cooking from 6am, delivery by 12 noon, staff payment, posting on Status, calling two prospects, and (5) suggest a price per plate that gives me at least 40% margin. Ask me if you need any number I haven't given.

**Naija tip:** This is the "quiet superpower" prompt. Meta AI in WhatsApp is now your **free personal assistant** — for calculations, quantities, drafts, reminders, and planning — and it never gets tired at 11pm. Start every morning with "Act as my business assistant. Today I need help with…" and list everything on your mind. Ten minutes of this can replace an hour of mental juggling.

---

## Prompt 4.18

### Title: Decide Whether to Buy Equipment, Rent, or Outsource

**Use this when:** You're considering a big purchase — a freezer, industrial sewing machine, delivery bike, oven, printing machine, generator, car — and want to think it through properly.

**Copy this prompt:**

> I run a [business type] in Nigeria and I'm considering [buying / renting / outsourcing] [equipment or capability]. Details: purchase price ₦[amount]; alternative option (renting, hiring, outsourcing) costs ₦[amount] per [use/month]; I'd use it about [frequency]; expected extra revenue or savings it would bring ₦[amount] per month; my available cash is ₦[amount]; maintenance and running costs would be roughly ₦[amount]. Help me decide. Give me: (1) a simple payback calculation — how many months to recover the cost, (2) a comparison of buy vs. rent vs. outsource over 12 and 24 months, (3) the risks I might be ignoring (breakdowns, theft, power needs, fakes, resale value, demand dropping), (4) questions I should ask before buying, and (5) your honest recommendation — with the conditions under which it changes.

**Real example (filled in):**

> I run a small bakery in Jos and I'm considering buying an industrial deck oven for ₦850,000. Currently I use two small gas ovens that limit me to about 150 loaves a day; the big oven would allow 400+ loaves. Renting oven time at a bigger bakery costs ₦25,000 per day. I'd use it 6 days a week. Expected extra revenue is ₦350,000–₦500,000 per month if I can sell the extra loaves. My available cash is ₦1.1M. Running costs: extra gas ₦40,000 monthly, servicing ₦10,000. Help me decide: payback calculation, buy vs. rent vs. outsource over 12 and 24 months, risks I'm ignoring, questions to ask before buying, and your honest recommendation with conditions.

**Naija tip:** The question is never "can I afford it?" — it's "**can I sell what it produces?**" Many Nigerian bakers, tailors and printers buy capacity before they have demand, then the machine sits idle while the loan collects interest. Prove demand first (pre-orders, a reseller who commits, a month of turning customers away), then buy. And always keep at least 2 months of running costs in cash after any big purchase — that's your NEPA-and-wahala buffer.

---

## Prompt 4.19

### Title: Write Clear Policies for Your Business (Returns, Delivery, Deposits, Credit)

**Use this when:** Every dispute becomes a personal argument because nothing is written down — and customers assume whatever suits them.

**Copy this prompt:**

> I run a [business type] in Nigeria. I need clear, fair policies I can post on my WhatsApp, Status, price list, and shop wall for: (1) returns, exchanges and refunds, (2) delivery — areas, fees, timelines, and what happens if the customer is unreachable, (3) deposits and cancellations for custom or pre-ordered items, (4) credit — who qualifies and terms, (5) warranty or guarantee (if relevant), and (6) how complaints are handled and how fast. My current practice and problems: [describe]. Write each policy in 3–5 short, plain sentences — firm but friendly, protecting me while being fair to customers. Then give me a one-paragraph "Our Promise" statement I can post above the policies so they don't feel cold.

**Real example (filled in):**

> I run a custom furniture-making workshop in Nnewi. My current practice: I take 60% deposit, deliver in 3–4 weeks, and offer free minor repairs for 3 months. Problems: customers cancel after I've bought wood and want the full deposit back; customers change designs midway and refuse to pay extra; some collect and pay the balance in "instalments" that stretch for months; customers claim damage weeks after delivery. Write clear, fair policies for returns/exchanges, delivery, deposits and cancellations, credit/balance payment, warranty, and complaints — 3–5 plain sentences each, firm but friendly. Plus a one-paragraph "Our Promise" statement.

**Naija tip:** Post policies **before** the problem, and they protect you. Mention them **after** the problem, and they sound like excuses. Send the relevant policy line with every order confirmation: "Reminder: custom orders need 60% deposit which covers materials and is non-refundable once work starts." Nigerian customers respect clear rules stated kindly — what they resent is surprise.

---

## Prompt 4.20

### Title: Monthly Operations Review — What to Fix, Stop and Improve

**Use this when:** You want a simple monthly habit that keeps costs down and operations tight, without needing an accountant or a consultant.

**Copy this prompt:**

> Here is my operations summary for [month] for my [business type] in Nigeria: revenue ₦[amount]; total expenses ₦[amount] broken down as [list main categories]; last month's expenses were ₦[amount]; stock-outs of fast-sellers: [number/instances]; waste or spoilage: ₦[amount]; customer complaints: [number and types]; late deliveries or missed deadlines: [number]; staff issues: [describe]; hours I personally worked per week: [number]; things that went well: [list]. Review this like an experienced operations manager. Tell me: (1) whether my costs as a percentage of revenue are healthy for my type of business, (2) the three biggest operational problems this month and their likely root causes, (3) what to fix first, what to stop doing, and what to improve, (4) one system or SOP I should create this month, and (5) three targets for next month I can actually measure.

**Real example (filled in):**

> Operations summary for August for my mini-supermarket in Uyo: revenue ₦2.1M; expenses ₦1.72M (stock ₦1.25M, rent ₦60k, staff ₦150k, generator ₦120k, transport ₦35k, POS/bank charges ₦18k, misc ₦87k); last month's expenses were ₦1.6M; stock-outs of fast sellers: 7 times (sachet milk, indomie, pure water); waste: ₦28k in expired items; complaints: 4 (2 about a rude staff, 2 about wrong change); late supplier deliveries: 3; staff issues: one staff late 6 times; I worked about 78 hours a week; went well: new Status posting brought 20+ new customers. Review this as an experienced operations manager: are my cost percentages healthy, the three biggest problems and root causes, what to fix/stop/improve, one SOP to create this month, and three measurable targets for next month.

**Naija tip:** Do this on the **first Sunday of every month**, with a cup of tea and honesty. It takes 30 minutes. The owners who do it every month are the ones whose costs go *down* while revenue goes *up* — the 35% saving in this book's promise is found here, one month at a time. Keep every month's review in a single note; after six months, you will see patterns that no one else in your market can see.

---

## Part 4 Checkpoint

Before moving to Part 5, make sure these five are **done**:

1. You've completed a full expense audit with real numbers and have a 30-day cut plan. *(4.1)*
2. At least three SOPs are written, printed and on the wall. *(4.3)*
3. Your WhatsApp Business greeting, away message and 12 Quick Replies are live. *(4.5)*
4. A daily sales & cash sheet is in use and balances every night. *(4.13)*
5. Your policies (deposits, delivery, returns, credit) are written and posted. *(4.19)*

With costs down and systems running, you've stopped the leaks. Now the business can carry more weight — and it's time to add new products, new offers and new income streams on top of the foundation you've built.

**Next: Part 5 — Product Innovation & New Revenue Streams (Prompts 5.1 – 5.20)**
