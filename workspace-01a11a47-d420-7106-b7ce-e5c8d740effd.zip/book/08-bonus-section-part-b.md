# BONUS SECTION: 15 READY-TO-USE TOOLS
*(Bonus 9 – 15)*

---

## BONUS 9 📋 — WhatsApp Status Sales Hook Bank

**What it does:** 60 ready-made opening lines for Status posts, grouped by purpose. A hook is the first line people see — it decides whether they tap or skip. Copy, fill the brackets, post.

**How to use:** Pick a hook that matches today's theme (Bonus 4). Add one photo or short video and a clear way to order. Rotate categories so your Status never feels like one long advert.

### A. Problem-First Hooks (they feel the pain, you have the fix)

1. Tired of [problem]? This is what I tell all my customers…
2. NEPA don take light again? Here's how my [product] keeps you going.
3. If your [item] keeps [spoiling / tearing / fading] by the second month, read this.
4. You're paying ₦[X] every week on [problem]. This costs ₦[Y] once.
5. Still queuing for [service] on Saturdays? We come to you.
6. The reason your [product] doesn't last: [common mistake]. Fix →
7. Stop buying [cheap alternative] every month. Buy this once.
8. This is for everyone who has ever been disappointed by [bad experience].

### B. Proof & Trust Hooks

9. Another happy customer in [area] 🙏 (swipe for her message)
10. She was scared it was fake. See what she said after using it for 2 weeks →
11. 47 deliveries this month. Zero complaints. Here's how we do it.
12. "I've been buying from you since 2023" — messages like this keep me going.
13. Before ➡️ After. Same client, 3 weeks apart.
14. Delivered to Kano, Enugu, Lagos and Abuja this week. Where next?
15. Unboxing video from a customer in [city] — I didn't even ask her to send this.
16. The batch code on every bottle. Check it yourself. That's how confident we are.

### C. Offer & Urgency Hooks (honest only)

17. Salary week special: [offer] — ends Sunday night.
18. My next stock lands at a higher price. Buy at today's price till [date].
19. Only [X] pieces of this colour came in. [Y] gone already.
20. First 10 orders today get [free delivery / free gift]. Reply "ME".
21. Pre-orders for [season/festival] close on [date]. After that, no promise.
22. Buy 2, get the 3rd at half price — this week only.
23. I have [X] slots left for [service] this weekend.
24. Price goes up Monday. You've been warned with love. ❤️

### D. Curiosity & Story Hooks

25. I almost didn't post this…
26. A customer asked me yesterday: "[interesting question]". My answer:
27. Three years ago I started this business with ₦[amount]. Today…
28. The mistake I made in my first month that cost me ₦[amount].
29. Why I refuse to sell [cheap version] even though it's more profitable.
30. What happens in my kitchen/workshop at 5am (video)
31. Guess how many of these we made today? (answer at the end)
32. My most expensive item — and why people buy it anyway.

### E. Question & Engagement Hooks

33. Quick one: which colour should I restock? 🔴 or 🔵 — reply!
34. What's the one thing you wish [product] did better? I'm listening.
35. Be honest: how often do you [related habit]?
36. Naming my new [product] — vote: A, B or C?
37. Who else is tired of [relatable Nigerian frustration]? 🙋‍♀️
38. What are you cooking/wearing/planning this weekend? Let me help.
39. Tag a friend who needs to see this (screenshot and send!).
40. If you could only buy one thing from me this month, what would it be?

### F. Value & Teach Hooks

41. 3 ways to make your [product] last twice as long:
42. How to spot fake [product] in 10 seconds:
43. What ₦5,000 gets you at my shop vs. the big supermarket:
44. The right way to store [product] during rainy season.
45. Pro tip from [X] years of doing this:
46. Don't buy [product] until you check these 3 things.
47. The difference between ₦3,000 and ₦8,000 [product] — explained.
48. What I wish every customer knew before ordering.

### G. Seasonal & Occasion Hooks

49. Detty December is coming. Is your [product/plan] ready?
50. Back-to-school checklist — tick what you already have ✅
51. Sallah/Christmas/Easter orders now open. Pre-order and rest.
52. Harmattan is here. Your [skin/hair/car/generator] needs this.
53. Valentine's is [X] days away. Don't be that person who forgot.
54. Rainy season = [problem]. Solution below ☔
55. End of the month. Treat yourself — you worked for it.
56. New month, new stock, same honest prices. 🙏

### H. Personal & Human Hooks

57. Not selling anything today. Just grateful for every one of you.
58. Small business, real person. This is me, [name], behind every order.
59. My daughter helped pack orders today (photo). Family business in action.
60. Sunday rest. Back tomorrow with fresh stock. Have a blessed day.

**Rules:** max 3 emojis · one hook per post · always end with how to order ("Reply 'YES'", "Send 'PRICE'", "Tap to chat") · never post a fake urgency hook.

---

## BONUS 10 📊 — NEPA & Generator Expense Calculator

**What it does:** Shows exactly what your power costs per month and per year, what each appliance costs to run, and whether solar/inverter pays off — so you can make the decision with numbers, not fear.

### Part A — What You Spend Now

| Item | Your figure |
|---|---|
| Generator size (kVA) | |
| Fuel type (petrol / diesel) | |
| Fuel price per litre (₦) | |
| Litres used per hour (typical: 1kVA≈0.4L, 2.5kVA≈0.8L, 3.5kVA≈1L, 5kVA≈1.4L, 7kVA≈2L — check yours) | |
| Hours generator runs per day | |
| Days per month | |
| **Monthly fuel cost** = litres/hr × hrs/day × days × price | ₦ |
| Servicing & oil per month | ₦ |
| Repairs per month (average) | ₦ |
| Grid electricity bill per month | ₦ |
| **TOTAL MONTHLY POWER COST** | ₦ |
| **TOTAL YEARLY POWER COST** (× 12) | ₦ |
| Monthly revenue | ₦ |
| **Power cost as % of revenue** (healthy: under 8–10%) | % |

**Worked example:** 3.5kVA petrol · ₦1,000/L · 1 L/hr · 8 hrs/day · 26 days = 208 L = **₦208,000** fuel. + ₦10,000 servicing + ₦5,000 repairs + ₦12,000 grid = **₦235,000/month = ₦2.82M/year.**

### Part B — What Each Appliance Costs You (find the hungry ones)

| Appliance | Watts (check label) | Hours/day on generator | kWh/day (W × hrs ÷ 1000) | Share of load (%) | Est. monthly cost (₦) | Needed on generator? (Y/N) |
|---|---|---|---|---|---|---|
| Chest freezer | ~150–250 | | | | | |
| Standing fridge | ~150–300 | | | | | |
| Standing fan (AC) | ~60–80 | | | | | |
| Rechargeable/DC fan | ~15–25 | | | | | |
| LED bulb | ~7–12 each | | | | | |
| Old bulb | ~60 each | | | | | |
| TV | ~60–120 | | | | | |
| Clippers / sewing machine | ~20–100 | | | | | |
| Blender / mixer | ~300–800 | | | | | |
| Air conditioner | ~900–1,500 | | | | | |
| Electric kettle / iron | ~1,000–2,000 | | | | | |
| POS / phone charging | ~5–15 | | | | | |

**Rule:** anything with a heating element (kettle, iron, heater) or an AC uses 10–100× more than lights and phones. Never run them on the generator "for small time."

### Part C — Quick Savings Estimator

| Action | Typical saving | Your estimate (₦/month) |
|---|---|---|
| Run generator in 2-hour blocks for freezers (full freezer + water bottles holds cold 6–10 hrs) | 20–35% of fuel | |
| Swap all bulbs to LED | 5–10% | |
| Replace AC fans with DC/rechargeable fans | 5–10% | |
| Switch off non-essentials while generator runs (TV, extra lights) | 5–15% | |
| Service generator on schedule (dirty plug/filter wastes fuel) | 5–10% | |
| Right-size: smaller generator for small loads (a 1kVA for lights/phones/fans) | 20–40% on light-load hours | |
| Shift energy-heavy tasks (blending, ironing) to grid hours | 10–20% | |
| **Total estimated monthly saving** | | ₦ |

### Part D — Solar / Inverter Payback

| Item | Your figure |
|---|---|
| Quote for solar/inverter system that covers your *essential* load (get 2–3 quotes) | ₦ |
| Monthly generator cost it would replace (from Part A, minus any generator you'd still run) | ₦ |
| Monthly solar maintenance (small) | ₦ |
| **Net monthly saving** | ₦ |
| **Payback period (months)** = System cost ÷ net monthly saving | months |
| Battery replacement expected in (years) and cost | |

**Worked example:** ₦1.8M system replacing ₦180,000/month of fuel → payback **10 months**. After that, ₦2M+ a year stays in your pocket.

**Decision rule:** payback under 24 months = strong yes (if you can fund it without a killer loan). 24–36 months = consider, especially if fuel keeps rising. Over 36 months = wait, or start with a smaller system for lights, fans and phones.

### AI Helper Prompt

> Using these numbers [paste Part A and Part B figures], calculate my true monthly and yearly power cost, identify my three most expensive appliances, estimate savings from [list actions from Part C], and calculate the solar payback if a system costs ₦[quote]. Tell me honestly whether solar makes sense for my business now, and what size system I should ask installers to quote for my essential load. I will verify quotes with real installers.

---

## BONUS 11 📋 — Daily Sales Record Sheet (POS-Friendly)

**What it does:** One page per day. Any staff member can keep it. Cash must balance before closing. Feeds your weekly summary, monthly P&L and 90-day tracker.

### Daily Sheet

```
BUSINESS: ______________________   DATE: ____/____/______   DAY: ________
STAFF ON DUTY: __________________   WEATHER/NOTES (NEPA, rain, event): __________

OPENING CASH IN TILL:  ₦ __________  (counted by: ________)

────────────────────────────── SALES ──────────────────────────────
Time   | Item / Category            | Qty | Amount (₦) | Cash | POS | Transfer | Customer name (if known)
-------|----------------------------|-----|------------|------|-----|----------|------------------------
       |                            |     |            |      |     |          |
       |                            |     |            |      |     |          |
       |                            |     |            |      |     |          |
       (continue overleaf if needed)

TOTAL SALES:        ₦ __________
  of which CASH:    ₦ __________
  of which POS:     ₦ __________   (must match POS machine end-of-day printout)
  of which TRANSFER:₦ __________   (must match bank alerts/app)

───────────────────── EXPENSES PAID FROM TILL ─────────────────────
Time   | Item                       | Amount (₦) | Approved by | Receipt?
-------|----------------------------|------------|-------------|---------
       |                            |            |             |
TOTAL EXPENSES FROM TILL:  ₦ __________

────────────────────────── CREDIT / DEBTS ─────────────────────────
Goods given on credit today (name, amount, due date): _______________________________
Debts collected today (name, amount): ___________________________________________

────────────────────────── RECONCILIATION ─────────────────────────
Expected closing cash = Opening cash + Cash sales − Expenses from till − Cash banked
   = ₦ ________ + ₦ ________ − ₦ ________ − ₦ ________ = ₦ __________
ACTUAL CASH COUNTED:  ₦ __________
DIFFERENCE:           ₦ __________   Reason: __________________________________

Cash banked / handed to owner: ₦ __________   Left in till for tomorrow: ₦ __________

Stock-outs today (items customers asked for that we didn't have): ____________________
Customer complaints / feedback: ______________________________________________
Signed (staff): __________   Photo sent to owner at: ____ : ____   Owner check: ______
```

### Weekly Summary (owner fills every Sunday)

| Day | Total sales (₦) | Cash | POS | Transfer | Expenses from till | Cash difference | Credit given | Debts collected | New customers |
|---|---|---|---|---|---|---|---|---|---|
| Mon | | | | | | | | | |
| Tue | | | | | | | | | |
| Wed | | | | | | | | | |
| Thu | | | | | | | | | |
| Fri | | | | | | | | | |
| Sat | | | | | | | | | |
| Sun | | | | | | | | | |
| **Week total** | | | | | | | | | |
| **vs. last week** | | | | | | | | | |
| **vs. weekly target (Bonus 1)** | | | | | | | | | |

**Rules that make it work:**
1. Sheet must balance before anyone goes home. Any difference over ₦500 gets a written reason.
2. Photo of the completed sheet to the owner's WhatsApp every night (your backup and audit trail).
3. POS total must match the machine's end-of-day printout; staple the printout to the sheet.
4. No expense from the till without approval and a reason — "chop money" is not a reason.
5. Owner does a surprise mid-day cash count at least once a week.

---

## BONUS 12 📋 — Customer Follow-Up Message Bank

**What it does:** 40 ready-to-send messages for every stage after first contact — so no lead goes cold and no customer feels forgotten. All under 60 words. Fill the brackets, personalise the first line, send.

### A. After an Enquiry (no purchase yet)

1. **Day 1 (same day):** Hi [Name], lovely chatting earlier. Here's the [photo/price list] as promised. Any question at all, just ask — I'm here. 😊
2. **Day 2:** Hi [Name], quick one — was there anything about the [item] you were unsure of? Size, colour, delivery? Happy to help you decide.
3. **Day 5 (value):** [Name], just posted a short video showing [item] in use / after 3 washes / being made. Thought you'd like to see it before deciding: [Status/link].
4. **Day 5 (proof):** Hi [Name], a customer in [area] just sent this after receiving her [item] 🙏 (screenshot). Yours can arrive by [day] if you'd like.
5. **Day 10 (gentle close):** Hi [Name], last nudge from me 😊 I have [X] left of the [item]. If it's not for you right now, no wahala at all — I'm here whenever you're ready.
6. **Salary week:** [Name], it's that time of the month 😄 The [item] you liked is still available, and I'll add [free delivery / small gift] if you order before Sunday.
7. **"Too expensive" reply:** I hear you, [Name]. It's ₦[X] because [one reason]. If budget is the issue, I have [smaller option] at ₦[Y], or you can pay ₦[deposit] now and the balance on delivery. Which works?

### B. After Payment (confirmation & reassurance)

8. **Payment received:** Received — thank you, [Name]! 🎉 Order: [item, qty]. It'll be [ready/dispatched] by [time/day]. I'll send you an update.
9. **Preparing:** Hi [Name], your [item] is being [packed/made] now. Here's a quick photo 📸. Dispatching [when].
10. **Dispatched:** On its way! 🚚 Rider: [name, number] / Waybill: [number]. Expect it around [time]. Please keep your phone reachable.
11. **Delayed (be honest):** [Name], a quick heads-up — your delivery is delayed by [reason, briefly] and will now arrive [new time]. I'm sorry for the inconvenience; I'm on it personally.

### C. After Delivery (turn one sale into the next)

12. **Same day:** Hi [Name], did your [item] arrive safely? Please check it and let me know everything is as expected. 🙏
13. **Day 2 (usage tip):** [Name], quick tip to get the best from your [item]: [one tip]. Enjoy it!
14. **Day 5 (review ask):** Hi [Name], hope you're loving the [item]! If you have 30 seconds, a short voice note or text on how you find it would help me a lot 🙏 (And I'd love to share it, with your permission.)
15. **Day 7 (referral):** [Name], thank you again. If anyone in your circle needs [product], send them my way and mention your name — you get [reward] after their first order.
16. **Day 21–30 (repeat trigger, consumables):** Hi [Name], you're probably running low on [item] by now 😊 Want me to send a fresh one this week? Same price, and delivery is on me for returning customers.

### D. Repeat Customers & VIPs

17. **Loyalty milestone:** [Name], this is your [5th] order with us! 🎉 To say thank you, [reward]. You're the reason we're still here.
18. **VIP early access:** [Name], before I post it publicly — new [item] just landed. As one of my best customers, you get first pick. Want photos?
19. **Birthday/occasion (if known):** Happy birthday, [Name]! 🎂 Enjoy [gift/discount] from us this week. Thank you for being family.
20. **Feedback request:** [Name], you've bought from me [X] times and I value your opinion. What's one thing I should improve? Honest answers only 😊

### E. Win-Back (gone quiet 60+ days)

21. Hi [Name], it's [Your name] from [Business]. I noticed it's been a while — I hope you're well. A lot has changed here: [new item/improvement]. Would love to serve you again. 🙏
22. [Name], we miss you! Here's ₦[X] off / free delivery on your next order, valid till [date]. No pressure — just wanted you to know the door is open.
23. Hi [Name], honest question: did we do something that made you stop buying? If so, I'd genuinely like to know and fix it.

### F. Debt & Deposit Follow-Ups (firm but kind)

24. **Deposit reminder:** Hi [Name], to lock in your [item/slot] I'll need the ₦[deposit] by [time]. After that I can't hold it — I have others waiting. Thank you for understanding.
25. **Balance due (day of):** Good morning, [Name]. Your [item] is ready! Balance of ₦[X] is due on delivery/collection today. Transfer details: [details].
26. **Late payment, day 3:** Hi [Name], gentle reminder — ₦[X] for [item] was due on [date]. Please let me know when to expect it today. 🙏
27. **Late payment, day 7:** [Name], I still haven't received the ₦[X]. I understand things can be tight — can you send ₦[part] today and the rest by [date]?
28. **Late payment, day 14 (firm):** [Name], this is my final reminder on the ₦[X] outstanding since [date]. I'd rather resolve it between us; please call me today.

### G. Complaints & Service Recovery

29. **First response (within 1 hour):** [Name], I'm really sorry about this. Thank you for telling me — I take it seriously. Give me [30 minutes] to look into it and I'll come back to you with a solution.
30. **Resolution offer:** [Name], here's what I can do: [option A] or [option B]. Which would you prefer? I want to make this right.
31. **After fixing:** [Name], your [replacement/refund] has been [sent/processed]. Again, my apologies. I've added [small extra] for the trouble. Thank you for your patience.
32. **One week later:** Hi [Name], just checking — is everything okay with the [item] now? Your satisfaction genuinely matters to me.

### H. Seasonal & Broadcast Touches

33. **Festival greeting (no selling):** Happy [Sallah/Christmas/Easter/New Year], [Name]! Wishing you and your family joy and peace. Thank you for your support this year. 🙏
34. **Pre-season:** [Name], [festival] is [X] weeks away. Pre-orders are open — order early, rest easy. Here's what's available: [list/link].
35. **Price change notice:** Hi [Name], a heads-up from me: from [date], [item] moves from ₦[old] to ₦[new] due to [reason]. You can still order at the old price till then.
36. **Restock alert:** [Name], the [item] you asked about is back in stock! 🎉 [X] pieces available. Want me to reserve one?
37. **New product:** [Name], something new: [item] — [one benefit], ₦[price]. Made for customers like you who [need]. Want to see it?
38. **Thank-you broadcast (month-end):** To every customer who bought this month — thank you. You kept a small business alive. Here's to next month. 🙏
39. **Quiet-week nudge:** Slow week here, so I'm offering [small deal] to my saved contacts only. Ends Friday.
40. **Save-my-number:** Hi [Name]! Please save this number as [Business Name] so you don't miss my Status updates and offers. Thank you! 😊

**Golden rules:** personalise the first line · one message, one purpose · never send two follow-ups in one day · always give a graceful exit ("no wahala") · use Labels to send the right message to the right group.

---

## BONUS 13 📋 — Referral Reward Card Template

**What it does:** A pocket-size card (and its digital version) that turns every happy customer into a recruiter — with clear rewards and simple tracking so nobody gets confused.

### Physical Card (business-card size, print 200–500)

**Front:**
```
┌──────────────────────────────────────────────┐
│  [BUSINESS NAME]                    [Logo]   │
│  ────────────────────────────────────────    │
│  A GIFT FROM: ______________________         │
│                                              │
│  You've been referred by a happy customer!   │
│  Show this card and get:                     │
│  ★  [₦1,000 off / free delivery / free gift] │
│     on your first order.                     │
│                                              │
│  📲 [WhatsApp number]   📍 [Area]            │
│  Valid till: ____/____/______                │
└──────────────────────────────────────────────┘
```

**Back:**
```
┌──────────────────────────────────────────────┐
│  HOW IT WORKS                                │
│  1. Your friend gave you this card.          │
│  2. Order and mention their name.            │
│  3. You get [your reward].                   │
│  4. They get [their reward] — and so will    │
│     you, when you refer someone!             │
│                                              │
│  Ask us for your own referral cards. 🙏      │
│  Card no: ______   Referrer code: ______     │
└──────────────────────────────────────────────┘
```

### Digital Version (WhatsApp image or text — send to existing customers)

> 🎁 **[Business Name] Referral Reward**
> Know someone who needs [product]? Send them my number and tell them to mention **your name** when they order.
> **They get:** [new-customer reward]
> **You get:** [₦1,500 airtime / ₦2,000 off / free product] after their first paid order.
> No limit — refer 5, get 5 rewards. Thank you for spreading the word! 🙏

### Reward Options (pick one per side)

| For the new customer | For the referrer | Cost to you |
|---|---|---|
| ₦500–₦1,000 off first order | ₦1,000–₦2,000 airtime (most loved) | Low |
| Free delivery | ₦2,000–₦3,000 off next order | Low–medium |
| Free small gift/sample | Free product after 3 referrals | Medium |
| 10% off | 10% cash reward on referred order | Scales with sale |

**Rule of thumb:** total reward cost ≤ 10–15% of the average first order. If average order is ₦15,000, total rewards of ₦1,500–₦2,000 is right.

### Referral Tracking Sheet

| Date | New customer name & number | Referred by | Order amount (₦) | Paid? | New-customer reward given | Referrer reward given (date) | Notes |
|---|---|---|---|---|---|---|---|

### Launch Plan (7 days)

| Day | Action |
|---|---|
| 1 | Finalise rewards; print cards or design digital version (Canva) |
| 2 | Send the digital version to your 30 best customers personally (not broadcast) |
| 3 | Post on Status: "New: refer a friend, get ₦2,000 airtime" |
| 4–7 | Give 2 physical cards with every order/delivery; mention it at checkout |
| 7 | Review: how many referrals? Reward everyone the same day they qualify |

**Anti-abuse:** reward only after the new customer's first *paid* order · one reward per new customer · referrer's name must be mentioned at time of order (not after) · keep the sheet.

---

## BONUS 14 🤖 — Business Name, Catchphrase & Slogan Creator

**What it does:** Generates and tests names, taglines, slogans, and WhatsApp-friendly catchphrases that Nigerian customers remember and repeat — for a new business, a rebrand, a product line, or a campaign.

### Prompt 1 — Business or Product Name

> I need a name for [a new business / a product line / a bundle / a training programme]. What it is: [describe]. Who it's for: [customers]. Feeling I want: [trustworthy / premium / fun / homely / modern / proudly Nigerian]. Language preference: [English only / English + Pidgin / English + Yoruba/Igbo/Hausa words / a mix]. Things to avoid: [names of competitors, words that are overused like "Divine", "Blessed", "Global", "Ventures"]. Give me 25 name options in five groups: descriptive, invented/modern, Nigerian-language-inspired (with meaning), personal/founder-based, and playful. For each: the name, why it works, and a possible tagline. Then shortlist your top 5 and for each say how it sounds when a customer says "I bought it from ___" and check if it's easy to spell over the phone. Remind me to check CAC availability and Instagram/WhatsApp handle availability before choosing.

### Prompt 2 — Tagline & Slogan

> My business is [name], we [what you do] for [who] in [where]. Our real edge is [1–2 things]. Create: (1) 10 short taglines under 6 words for my logo/profile, (2) 10 slogans under 12 words for flyers and Status, (3) 5 Pidgin or Naija-flavoured catchphrases customers would repeat or joke with, (4) 5 "promise" statements ("Fresh every morning or your money back") I could actually keep, and (5) 3 hashtag-style phrases for social media. Avoid clichés like "passion for excellence", "your satisfaction is our priority", "quality you can trust". Then pick the single best tagline and explain why it will stick in a Nigerian customer's mind.

### Prompt 3 — Campaign or Seasonal Catchphrase

> I'm running a [festival/season/launch] campaign for [product/offer] at [price]. Give me 15 short, catchy campaign lines Nigerians will remember — playful, culturally aware, with light Pidgin where it fits — plus a 3-word version of the best one for a sticker or Status header. Include at least 3 that rhyme and 3 that use a familiar Nigerian phrase or saying, twisted for my product.

### Name Test Checklist (before you commit)

- [ ] Say it out loud 5 times — still easy?
- [ ] Spell it over the phone to a friend — did they get it first time?
- [ ] Search it on Instagram, Facebook and Google — anyone using it nearby?
- [ ] CAC name search done (via the CAC portal or an agent)
- [ ] WhatsApp Business short link and Instagram handle available?
- [ ] Does it still work if you add products/branches later? (Avoid "Ikeja Bread House" if you'll expand.)
- [ ] Does it mean anything embarrassing in Yoruba, Igbo, Hausa or Pidgin? Ask speakers.
- [ ] Ask 5 target customers which of your top 3 they'd trust more — go with the majority.

### Slogan Formulas That Work in Nigeria

| Formula | Example |
|---|---|
| Benefit + honesty | "Fresh bread. Fair price. Every morning." |
| Problem killed | "No more fake fabric." |
| Local pride | "Made in Aba. Worn everywhere." |
| Promise with proof | "Delivered same day — or delivery is free." |
| Pidgin warmth | "Correct thing, no stories." |
| Twist on a saying | "No be by mouth — na by taste." |

---

## BONUS 15 📊 — Risk & Survival Decision Matrix for Naija Businesses

**What it does:** A one-page system to see your biggest risks clearly, decide what to protect first, and know exactly what to do in the first 24 hours when something goes wrong — so a bad day doesn't become a closed business.

### Step 1 — Score Your Risks

Score each: **Likelihood** (1 = rare, 5 = almost certain this year) × **Impact** (1 = annoying, 5 = could close the business) = **Risk Score** (1–25).

| # | Risk | Likelihood (1–5) | Impact (1–5) | Score | Current protection (none / weak / good) |
|---|---|---|---|---|---|
| 1 | Fuel/diesel price spike | | | | |
| 2 | General inflation on stock and materials | | | | |
| 3 | Naira depreciation (imported goods cost more) | | | | |
| 4 | Prolonged power failure spoiling stock | | | | |
| 5 | Staff theft or fraud | | | | |
| 6 | External theft / burglary | | | | |
| 7 | Fire (generator, gas, wiring) | | | | |
| 8 | Flooding / rain damage | | | | |
| 9 | Owner falls sick or is absent for weeks | | | | |
| 10 | Key staff member leaves suddenly | | | | |
| 11 | Main supplier fails or raises prices sharply | | | | |
| 12 | Biggest customer leaves or stops paying | | | | |
| 13 | Customer debts pile up | | | | |
| 14 | Rent increase or eviction | | | | |
| 15 | Government demolition, relocation or new levy | | | | |
| 16 | Fake collectors / harassment ("task force") | | | | |
| 17 | POS/bank failure or frozen account | | | | |
| 18 | Loan default pressure | | | | |
| 19 | Phone lost/stolen (all contacts and records) | | | | |
| 20 | Family/community pressure draining cash | | | | |
| 21 | Bad review or social-media attack | | | | |
| 22 | Product liability (someone harmed by product) | | | | |
| 23 | New competitor undercutting nearby | | | | |
| 24 | Seasonal demand collapse | | | | |
| 25 | *(Your specific risk)* | | | | |

### Step 2 — Prioritise

| Score | Zone | Action |
|---|---|---|
| **15–25** | 🔴 Act this month | Put protection in place now, whatever it costs within reason |
| **8–14** | 🟡 Plan this quarter | Cheap protections now; full plan within 90 days |
| **1–7** | 🟢 Monitor | Review every 6 months |

### Step 3 — Protection Menu (cheap, practical, Nigerian)

| Risk area | Protections |
|---|---|
| **Power & fuel** | Full-freezer habit · 2-hour generator blocks · LED/DC swaps · solar payback check (Bonus 10) · keep 2 weeks' fuel budget in reserve |
| **Inflation & naira** | Monthly price review · "small size" options · buy stock at month-end sales cycle · negotiate supplier terms · avoid long fixed-price contracts |
| **Theft & fraud** | Daily sales sheet that must balance (Bonus 11) · surprise counts · CCTV (even a basic ₦40k camera) · separate cash-handling from stock-handling · guarantor for staff |
| **Fire & flood** | Fire extinguisher by generator/gas (₦15–30k) · generator 3m from building · no fuel stored indoors · raise stock off the floor · micro-insurance for fire/stock (verify terms) |
| **Owner absence** | 5 SOPs on the wall · one trained deputy · shared password sheet with a trusted person · a "shop can run without me" test every quarter |
| **Key staff** | Cross-train 2 people per task · document processes · fair pay + small commission · exit handover rule |
| **Supplier** | Second supplier for 20% of volume · keep relationships warm · 2–4 weeks' buffer of critical stock |
| **Customer concentration** | No single customer > 25% of revenue · keep prospecting even when full |
| **Debts** | Credit policy (Prompt 6.7) · debtors' register · deposits for custom work |
| **Rent & location** | Written tenancy · start saving next rent from month 1 · keep delivery/online channel so a location change isn't fatal |
| **Levies & harassment** | Know your legitimate levies (Prompt 6.9) · join the market/trade association · demand ID and receipt · keep copies of all payments |
| **Bank & POS** | Two accounts at different banks · keep some cash float · payment link as backup |
| **Phone/records** | Back up WhatsApp to Google Drive weekly · save contacts to Google account · photograph records daily · lock screen + Find My Device |
| **Family pressure** | Fixed owner's salary (Prompt 6.5) · "the business pays me a salary" script · separate accounts |
| **Reputation** | Respond to complaints within 1 hour · fix publicly and kindly · Proof folder · never argue online |
| **Cash cushion** | 3 months of fixed costs in an emergency fund (Prompt 6.8) — the protection that covers every risk |

### Step 4 — First-24-Hours Playbook

| If this happens… | First 24 hours |
|---|---|
| **Fire / flood / break-in** | Safety first · photograph everything before touching · report to police (get extract) · inform insurer if any · tell customers honestly via Status · list losses · call supplier for emergency restock terms |
| **Power failure with perishable stock** | Move stock to a neighbour's freezer or cold room · sell fast at a discount via Status ("today only") · cook/process what can be preserved · document losses |
| **Owner sick/absent** | Deputy activates SOPs · owner posts a short Status ("I'm unwell, [Name] is in charge, orders continue") · reduce to core products · pause new commitments |
| **Key staff quits** | Cross-trained person steps in · re-post job description (Prompt 4.7) same day · owner covers customer-facing role temporarily · don't beg them back publicly |
| **Supplier fails** | Call second supplier · tell affected customers *before* they ask, with a new timeline · offer substitutes or refunds · never go silent |
| **Big customer leaves** | Ask why (genuinely) · don't slash prices in panic · activate prospecting (Prompt 5.6) · review whether any other customer is > 25% |
| **Fake collectors / harassment** | Stay calm · ask for ID and official documents · don't pay cash on the spot · call your association chairman · record if safe |
| **Account frozen / POS failure** | Switch to the second account and payment link · post the alternative payment details on Status · call the bank with your reference · keep serving cash customers |
| **Phone lost** | Log in to WhatsApp on another phone/restore backup · change bank and email passwords · tell contacts via a friend's Status · retrieve records from Google Drive backup |
| **Bad review / online attack** | Reply once, calmly, offer to fix privately · move to DM · fix it · ask satisfied customers to share honest experiences · do not engage in back-and-forth |
| **Loan pressure** | Call the lender *before* missing a payment · propose a realistic plan · cut non-essential costs immediately · don't take a second loan to pay the first |

### Step 5 — Quarterly Review

| Quarter | Top 3 risks | Protection added | Emergency fund (₦) | Next action |
|---|---|---|---|---|
| Q1 | | | | |
| Q2 | | | | |
| Q3 | | | | |
| Q4 | | | | |

### AI Helper Prompt

> Here are my scored risks and current protections: [paste table]. My business is a [type] in [area], Nigeria, with monthly revenue ₦[X], fixed costs ₦[Y], and an emergency fund of ₦[Z]. Tell me: my top 5 risks by score and why they matter for my specific business; the cheapest protection for each that I can put in place within 30 days with a cost estimate; anything I've under-scored given Nigerian realities; and a 24-hour playbook for my number-one risk. Be direct.

---

## You Now Have the Complete Toolkit

Fifteen tools. Every one built for the way business actually works in Nigeria — on a phone, with WhatsApp, around NEPA, through haggling, salary weeks, festival rushes and family pressure.

Set up **three of them this week**: the Daily Sales Record Sheet (Bonus 11), the 90-Day Revenue Growth Tracker (Bonus 1), and the WhatsApp Business Profile Optimizer (Bonus 6). Those three create the habit. The rest slot in as you need them.

**Next: Back Matter — Your 90-Day Action Plan, Glossary, and What to Read Next**
