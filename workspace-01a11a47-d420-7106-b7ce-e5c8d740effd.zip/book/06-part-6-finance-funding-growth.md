# PART 6: FINANCE, FUNDING & SMART GROWTH
*(Prompts 6.1 – 6.20)*

---

## The Part That Decides Whether You Keep the Money

You can do everything in Parts 1–5 perfectly and still end the year with nothing. It happens to Nigerian businesses every day: sales are strong, the shop is busy, and yet there is no money in the account. The owner cannot say what the profit was last month, whether the ₦8,000 dress actually makes money after delivery and returns, or where the ₦300,000 that "should be there" went.

This Part is about **keeping what you earn, knowing your numbers, and growing on solid ground.** Specifically:

- Pricing so every sale is actually profitable — after *all* costs
- Knowing your break-even, your real profit, and your cash position every week
- Separating business money from personal money (the number one silent killer)
- Managing debtors, savings, and the "small small" that leaks away
- Preparing for funding — grants, loans, investors — only when it makes sense, with proposals that get read
- Growing (a second branch, more staff, more stock) with a plan, not a prayer

**A word before you start — read "Check Before You Trust It" again.** This Part deals with money, tax, loans and legal matters. AI is an excellent thinking partner and calculator; it is **not** your accountant, lawyer, tax adviser or bank. Interest rates, tax rules, grant conditions and bank fees change and vary. Use every prompt here to *understand and prepare*, then confirm specifics with a qualified professional or the institution itself before you sign anything or pay anyone.

**Start with 6.1, 6.3 and 6.5** — true costing, break-even, and separating your money. Those three prevent most business deaths in Nigeria.

---

## Prompt 6.1

### Title: Calculate the True Cost and Real Profit of Each Product

**Use this when:** You "know" your profit is the selling price minus what you paid the supplier — and you've never included transport, packaging, delivery, waste, POS charges, your time, or rent.

**Copy this prompt:**

> I sell [product/service] in Nigeria at ₦[selling price]. Here is everything I can think of that goes into it: purchase/production cost ₦[amount]; transport to get it ₦[amount]; packaging ₦[amount]; delivery cost I absorb ₦[amount]; POS/transfer charges roughly [%]; average discount I give ₦[amount]; waste, returns or spoilage roughly [%]; time I or staff spend per unit [minutes] at a labour cost of ₦[amount] per hour; my monthly fixed costs are ₦[amount] and I sell about [number] units of all products per month. Calculate: (1) the true cost per unit including a fair share of fixed costs, (2) my real profit per unit and real profit margin, (3) how that compares to the profit I *thought* I was making, (4) the minimum price I should never sell below, and (5) three ways to raise the real margin without raising the price.

**Real example (filled in):**

> I sell ready-to-wear women's gowns in Lagos at ₦12,000. Costs: fabric and tailoring ₦6,500; transport to the tailor and market ₦300 per gown on average; packaging (nylon, tag, thank-you card) ₦250; I absorb delivery about half the time, average ₦900 per gown; POS/transfer charges about 1.5%; average discount ₦700; returns/exchange costs roughly 5%; my time per gown on posting, chatting and packing about 40 minutes at ₦1,500/hour; monthly fixed costs (rent, data, generator, assistant) ₦145,000 and I sell about 90 gowns a month. Calculate my true cost per gown, real profit and margin, how it compares to the ₦5,500 I thought I was making, my minimum price, and three ways to raise the margin without raising the price.

**Naija tip:** Almost every Nigerian owner who does this for the first time discovers their real profit is **30–50% lower** than they thought — the "small" costs add up to thousands. That's not bad news; it's the beginning of being profitable on purpose. Do this for your **top 5 products** today. Then look at the cheapest one — it's often not worth selling at all, and dropping it can *raise* your profit.

---

## Prompt 6.2

### Title: Set Prices for Profit (Not Just to Compete)

**Use this when:** You set prices by copying the person next to you, or by "what customers will accept," and your margins are thin.

**Copy this prompt:**

> I run a [business type] in Nigeria. Using the true costs from my products [paste or list true cost per unit], my monthly fixed costs of ₦[amount], and a target of [X]% net profit, help me set proper prices. Give me: (1) a price for each product that hits my profit target, (2) a comparison to current market prices [list them] and advice on where I'm too low, too high, or fine, (3) a pricing strategy — cost-plus, value-based, tiered, or psychological pricing (₦4,990 vs ₦5,000) — that suits my customers, (4) which products to use as "attraction" prices and which are my profit-makers, (5) how to raise prices on existing customers without losing them — timing, wording, and a message template, and (6) how often to review prices given inflation and exchange-rate changes.

**Real example (filled in):**

> I run a small bakery in Kaduna. True cost per unit: family loaf ₦780, small loaf ₦420, meat pie ₦380, chin chin (500g) ₦650, birthday cake 8" ₦7,200. Monthly fixed costs ₦210,000. Target net profit 25%. Market prices: family loaf ₦1,200–₦1,500, small loaf ₦600–₦800, meat pie ₦600–₦800, chin chin ₦1,200–₦1,500, cake ₦15,000–₦25,000. Give me a price for each that hits my target, a comparison with the market, the best pricing strategy for my customers, which products attract and which make profit, how to raise prices on existing customers with a message template, and how often to review given flour and sugar price changes.

**Naija tip:** Raise prices **in small steps, with notice, and with a reason people understand**: "From Monday, family loaf becomes ₦1,400 — flour has gone up 30% since March. Thank you for staying with us." Nigerians accept honest increases; they resent silent ones. And use **attraction pricing** deliberately: keep one visible item (the small loaf) competitively priced to bring people in, and make your money on the cakes and chin chin they add.

---

## Prompt 6.3

### Title: Find Your Break-Even Point (How Much You Must Sell to Survive)

**Use this when:** You don't know the exact daily or monthly sales figure below which you're losing money — so you can't tell a good month from a dangerous one.

**Copy this prompt:**

> I run a [business type] in Nigeria. My monthly fixed costs are: [list: rent, salaries, generator/fuel, data, transport, loan repayment, insurance, subscriptions, levies, your own basic salary]. My products/services and their price and variable cost per unit: [list]. My typical sales mix is roughly [percentages or numbers per product]. Calculate: (1) my monthly break-even in naira and in units, (2) my daily break-even (for the days I'm open), (3) the sales level I need to earn ₦[target profit] per month, (4) how much a 10% price increase or a 10% cost reduction would change my break-even, and (5) a simple "danger signal" rule I can check each week to know if I'm on track.

**Real example (filled in):**

> I run a small restaurant in Owerri, open 26 days a month. Fixed costs: rent ₦50,000; 3 staff ₦120,000; generator and fuel ₦85,000; gas ₦30,000; data and airtime ₦8,000; transport ₦20,000; loan repayment ₦40,000; my own salary ₦100,000. Products: rice and chicken plate (price ₦1,800, variable cost ₦1,050), swallow and soup (₦2,200, ₦1,250), drinks (₦500, ₦320), small chops pack (₦1,500, ₦800). Sales mix: 45% rice plates, 30% swallow, 20% drinks, 5% small chops. Calculate my monthly and daily break-even, sales needed for ₦250,000 profit, the effect of a 10% price increase or 10% cost cut, and a weekly danger-signal rule.

**Naija tip:** Your **daily break-even number** is the most important number in your business. Write it on the wall in the back room: "We need ₦68,000 a day to break even." Now every staff member understands why 3pm with ₦30,000 in the till is a problem, not a rest break. Recalculate it whenever rent, fuel, or salaries change — in Nigeria, that's every few months.

---

## Prompt 6.4

### Title: Build a Simple Weekly Cash-Flow Forecast

**Use this when:** You have "profit" on paper but never seem to have cash when rent, salaries or a big stock purchase is due.

**Copy this prompt:**

> I run a [business type] in Nigeria. Help me build a simple 8-week cash-flow forecast I can keep in a notebook or Google Sheet. My starting cash is ₦[amount]. Expected weekly cash in: [sales estimates by week, plus any money owed to me and when it should arrive]. Expected cash out by week: [stock purchases and dates, rent and date, salaries and date, generator/fuel, loan repayment date, supplier payments, big one-off items coming up]. Show me: (1) a week-by-week table of cash in, cash out, and closing balance, (2) any week where I go negative or dangerously low, and by how much, (3) 5 practical moves to fix those weeks — timing of purchases, collecting debts, deposits from customers, negotiating supplier dates, (4) how much buffer I should aim to keep, and (5) how to update this every Monday in 10 minutes.

**Real example (filled in):**

> I run a building materials shop in Abuja (Kubwa). Starting cash ₦420,000. Expected weekly sales: ₦650k, ₦700k, ₦550k, ₦800k, ₦600k, ₦650k, ₦900k, ₦700k; a contractor owes me ₦380,000 due in week 3. Cash out: cement and rods restock ₦900k in week 1 and ₦1.1M in week 5; rent ₦600k due week 4; salaries ₦180k weeks 4 and 8; generator ₦25k weekly; loan repayment ₦120k in weeks 2 and 6; new delivery tricycle ₦850k planned for week 6. Show me the 8-week table, the weeks I go negative, 5 practical fixes, the buffer I should keep, and a 10-minute Monday update routine.

**Naija tip:** **Profit is an opinion; cash is a fact.** A Nigerian business rarely dies of losses — it dies the week it can't pay rent or restock despite being "profitable." The two fastest fixes: **collect deposits before big jobs** and **pay suppliers on the day after your best sales day**, not before. Once you can see 8 weeks ahead, you stop panicking and start planning — and you'll never again buy a tricycle in the same week rent is due.

---

## Prompt 6.5

### Title: Separate Business Money From Personal Money (Pay Yourself a Salary)

**Use this when:** You take money from the till for school fees, contributions, and family needs, and you honestly can't say how much the business made versus how much you spent.

**Copy this prompt:**

> I run a [business type] in Nigeria. Currently business and personal money are mixed: [describe — one account, taking from the till, paying family from sales, using business money for personal emergencies]. My business makes roughly ₦[revenue] per month with about ₦[profit] profit. My personal and family needs are about ₦[amount] per month. Help me separate them properly: (1) a simple account structure (which accounts to open and what each is for — operating, savings/tax, personal), (2) how to decide a fair, fixed owner's salary and when to pay it, (3) what to do when a personal emergency hits and the money is in the business, (4) how to handle family and community requests for money from "the business," and (5) a 30-day transition plan from mixed to separated, including the conversation I may need to have with my spouse or family.

**Real example (filled in):**

> I run a provisions and drinks shop in Enugu. Currently everything is mixed: one personal bank account, I take cash from the till for school fees, church contributions, and my mother's medicine; relatives assume "the shop is doing well" and ask for help. The business does about ₦1.6M monthly with roughly ₦280,000 profit. My family needs about ₦180,000 a month. Help me: a simple account structure, how to set and pay myself a fixed salary, what to do when an emergency hits, how to handle family and community requests, and a 30-day transition plan including the conversation with my husband.

**Naija tip:** This is the single most important financial habit in this book. **Pay yourself a fixed salary on a fixed day — and nothing else leaves the business for personal use.** When family asks, the answer becomes "the business pays me a salary; I've already spent this month's" — which is true and ends the argument. Open a separate business account (most Nigerian banks and fintechs make this quick) and move to it within 30 days. Businesses that do this survive. Businesses that don't, don't.

---

## Prompt 6.6

### Title: Build a Simple Monthly Profit & Loss (Know Exactly What You Made)

**Use this when:** You want a clear, honest one-page picture every month: sales, costs, profit — without an accountant.

**Copy this prompt:**

> Help me create a simple monthly Profit & Loss statement for my [business type] in Nigeria that I can fill in with a notebook or Google Sheet. My income sources: [list]. My cost categories: [cost of goods/materials, staff, rent, power/fuel, transport/delivery, packaging, marketing, bank/POS charges, repairs, levies, owner's salary, others]. Show me: (1) a clean one-page layout with sections for revenue, cost of sales, gross profit, operating expenses, and net profit, (2) how to fill it in from my daily sales sheet and expense records in under an hour a month, (3) the 5 percentages I should calculate each month (e.g., gross margin, staff cost %, power cost %) and what healthy ranges look like for my type of business, (4) how to compare month to month and spot problems early, and (5) three questions to ask myself when I look at each month's numbers.

**Real example (filled in):**

> Help me create a simple monthly Profit & Loss for my beauty salon and product retail business in Port Harcourt. Income: hair services, nail services, product sales, training classes. Costs: hair and product purchases, 4 staff salaries and commissions, rent, generator and electricity, water, consumables (shampoo, gloves, towels laundry), marketing/data, POS and bank charges, repairs and maintenance, association levies, my own salary. Show me the one-page layout, how to fill it from my daily records in under an hour, the 5 percentages to track with healthy ranges for a salon, month-to-month comparison, and three questions to ask each month.

**Naija tip:** A one-page monthly P&L is what separates a **business** from a **hustle**. It also becomes your strongest weapon when you approach a bank, a grant, or an investor — six months of clean P&Ls answers half their questions before they ask. Fill it in on the first Sunday of every month alongside the operations review from Prompt 4.20. Same tea, same honesty, thirty extra minutes.

---

## Prompt 6.7

### Title: Manage Customers Who Owe You (Debtors) Without Killing the Relationship

**Use this when:** "I'll pay you next week" has become a serious hole in your cash — and you need a system, not more patience.

**Copy this prompt:**

> I run a [business type] in Nigeria. Money currently owed to me: [list debtors by type — e.g., 6 regular customers owing ₦180,000 total, 1 contractor owing ₦400,000 for 2 months, small credits to neighbours ₦35,000]. My total monthly sales are ₦[amount], so debts are about [X]% of a month's sales. Help me: (1) assess which debts are likely recoverable and which I should write off, (2) design a firm-but-friendly collection plan for each debtor type over the next 30 days — messages, calls, part-payment offers, and when to escalate, (3) set a credit policy going forward — who qualifies, limits, terms, and how to say no gracefully, (4) create a simple debtors' register to track everything, and (5) calculate what these debts are costing me in lost stock purchases or interest so I stay motivated to fix it.

**Real example (filled in):**

> I run a wholesale foodstuff business in Ibadan (Bodija). Owed to me: 8 retailers owing between ₦40,000 and ₦150,000 each (₦620,000 total, some for 6+ weeks); one caterer owing ₦280,000 for 3 months who keeps promising; small credits to neighbours and a church member totalling ₦60,000. Monthly sales about ₦4.2M. Help me assess which debts are recoverable, design a 30-day collection plan for each type, set a credit policy going forward with limits and how to say no gracefully, create a debtors' register, and calculate what these debts are costing me.

**Naija tip:** In Nigeria, credit is culture — you cannot refuse everyone, but you can **structure it**. The policy that works: credit only for customers with a **track record** (5+ paid purchases), a **limit** (never more than one week of their average purchases), a **date**, and a **written or WhatsApp record** ("Sent ₦85,000 goods on credit, due Friday 14th — please confirm"). That confirmation message is your evidence and your reminder. Collection tip: a **part-payment request** ("Can you do ₦100k today?") recovers far more than "pay everything now."

---

## Prompt 6.8

### Title: Build an Emergency Fund and a Savings Discipline for the Business

**Use this when:** One bad month, one broken generator, one sick week, or one family emergency could sink the business — and you have nothing put aside.

**Copy this prompt:**

> I run a [business type] in Nigeria with monthly revenue of about ₦[amount], profit of about ₦[amount], and fixed monthly costs of ₦[amount]. I currently save [nothing / an irregular amount]. Help me build a savings system: (1) how big my business emergency fund should be (in months of fixed costs) and a realistic target in naira, (2) how much to set aside weekly or monthly to get there in 6–12 months without starving the business, (3) where to keep it so it's safe, earns something, but isn't too easy to touch — with the trade-offs of options available in Nigeria (I'll verify current rates and terms myself), (4) separate "pots" I should consider — emergency, tax/levies, equipment replacement, expansion — and how to split contributions, and (5) rules for when I'm allowed to touch each pot.

**Real example (filled in):**

> I run a tailoring and fashion business in Abuja with monthly revenue of about ₦1.1M, profit about ₦320,000, and fixed costs of ₦240,000. I currently save irregularly — sometimes ₦20,000, often nothing. Help me build a savings system: how big my emergency fund should be and a naira target, how much to set aside weekly to reach it in 6–12 months, where to keep it safely with the trade-offs of Nigerian options (bank savings, fixed deposit, fintech savings apps, cooperative/ajo, treasury bills), separate pots for emergency, tax, machine replacement and expansion, and rules for touching each.

**Naija tip:** Start with **3 months of fixed costs** as your target — in the example, ₦720,000. It sounds far; at ₦15,000 a week it's 48 weeks. The trick is **automation**: a standing order or a savings-app auto-debit on the day money comes in, before you can see it. Many owners also use a **trusted ajo/cooperative** for discipline — it works, but only with people you truly trust and with records. And keep the emergency pot boring: safe beats high-yield when it's the money that keeps your doors open.

---

## Prompt 6.9

### Title: Understand Your Basic Tax and Levy Obligations (And Stop Fearing Them)

**Use this when:** You avoid the topic of tax entirely, pay random "levies" to whoever shows up, or want to formalise but fear it will cost too much.

**Copy this prompt:**

> I run a [business type] in [state], Nigeria, [registered as a business name / limited company / not registered], with annual revenue of roughly ₦[amount]. Explain in plain language: (1) the main types of taxes and levies a business like mine may be subject to in Nigeria — federal, state, and local — and which ones typically apply at my size, (2) which ones are commonly confused with each other or exploited by fake collectors, and how to identify legitimate demands, (3) the potential advantages of being registered and compliant (bank loans, grants, corporate customers, tenders), (4) simple record-keeping habits that make compliance easy and cheap, and (5) the questions I should ask a tax professional or the relevant tax office to confirm my exact obligations. Be clear about what you are not certain of — I will verify with a professional.

**Real example (filled in):**

> I run a printing and branding business in Lagos, registered as a business name with CAC, annual revenue roughly ₦14M. Explain in plain language: the main taxes and levies that may apply to a business like mine at this size (e.g., personal income tax for a business-name owner, VAT thresholds, state and local levies, signage/business premises levies), which ones fake collectors abuse and how to spot legitimate demands, the advantages of being compliant for getting corporate clients and loans, simple record-keeping habits, and the exact questions to ask a tax professional or the Lagos tax office. Be clear about what you're not certain of.

**Naija tip:** This is a **Check Before You Trust It** prompt in capital letters. Tax rules in Nigeria change (recent reforms have adjusted thresholds and exemptions for small businesses), and they differ by state and structure. Use this prompt to *understand the landscape and prepare your questions*, then spend ₦20,000–₦50,000 on one session with a real accountant. That one session typically saves multiples of its cost — in avoided penalties, avoided fake "levies," and access to opportunities that require compliance.

---

## Prompt 6.10

### Title: Decide Whether You Should Take a Loan (And What Kind)

**Use this when:** A loan offer is on the table — bank, microfinance, fintech app, cooperative, or a "friend" — and you want to think clearly before you sign.

**Copy this prompt:**

> I run a [business type] in Nigeria and I'm considering borrowing ₦[amount] for [purpose]. The loan terms offered: [interest rate and whether monthly or annual, tenure, repayment schedule, fees, collateral or guarantor requirements, lender type]. My business numbers: monthly revenue ₦[amount], monthly profit ₦[amount], current cash ₦[amount], existing debts ₦[amount]. Help me decide: (1) the total cost of this loan in naira over its life, and the true annual interest rate if it was quoted monthly, (2) whether the purpose will generate enough extra profit to repay it comfortably — show the calculation, (3) the risks specific to this type of lender in Nigeria and warning signs of a bad deal, (4) alternatives to borrowing — deposits, pre-orders, supplier credit, selling idle assets, slower growth, (5) if I do borrow, the maximum I should take and the questions to ask before signing. Be honest if this is a bad idea.

**Real example (filled in):**

> I run a frozen foods shop in Lagos and I'm considering borrowing ₦1.5M from a fintech lending app to buy a second deep freezer and stock up before December. Terms: 6% per month, 6 months, equal monthly repayments, 2% processing fee, no collateral, guarantor required. My numbers: monthly revenue ₦2.2M, profit ₦310,000, cash ₦280,000, existing debt ₦0. Help me decide: total cost of the loan and true annual rate, whether the freezer and December stock will generate enough extra profit to repay comfortably, risks with fintech lenders in Nigeria and warning signs, alternatives to borrowing, and if I borrow, the maximum amount and the questions to ask. Be honest if this is a bad idea.

**Naija tip:** The most dangerous words in Nigerian small-business lending are **"just 5% monthly"** — that is over 60% a year before fees, and it can destroy a business that makes 15% margins. Rules: **only borrow for things that make money** (stock that sells, equipment that produces), never for rent or salaries; never borrow more than you can repay from *current* profit if the plan fails; and read every line about defaults, late fees, and access to your contacts or bank account. If a lender rushes you, walk away.

---

## Prompt 6.11

### Title: Find Grants, Competitions and Support Programmes You Actually Qualify For

**Use this when:** You hear about grants and business competitions but never apply — or you apply to everything and win nothing.

**Copy this prompt:**

> I run a [business type] in [state], Nigeria. Details: [gender/age of owner, years in business, registered or not, revenue, number of staff, sector, whether it's a youth/women/agri/tech/creative business, any social impact]. Help me approach grants and support programmes strategically: (1) the *types* of programmes that typically exist for a business like mine in Nigeria — government agencies, development banks, bank foundations, corporate CSR, international organisations, business competitions, accelerators — and what each usually looks for, (2) how to check whether a programme is legitimate and current, and red flags of grant scams, (3) what I should prepare in advance so I can apply quickly when one opens — documents, numbers, a short business profile, photos, (4) how to write answers that stand out to reviewers, and (5) a realistic plan: how many to apply to per quarter and how to track them. Note that I will verify specific programme names, deadlines and criteria myself.

**Real example (filled in):**

> I run a cassava processing business (garri and fufu flour) in Ogun State. Owner: female, 34, registered business name, 3 years in business, revenue about ₦9M a year, 5 staff (4 women), agri-processing sector, we buy from 30 smallholder farmers. Help me approach grants strategically: the types of programmes that exist for a women-led agri-processing business in Nigeria and what each looks for, how to verify legitimacy and spot scams, what to prepare in advance, how to write standout answers, and a quarterly application plan. I'll verify specific programme names and deadlines myself.

**Naija tip:** Grants are won by the **prepared**, not the deserving. Keep a "Grant Folder" always ready: CAC certificate, TIN, 6 months of P&Ls, bank statements, a 1-page business profile, 10 good photos, and a 2-minute video pitch on your phone. Then when a legitimate opportunity opens with a 5-day deadline, you apply in 2 hours while everyone else scrambles. And the golden rule: **legitimate grants never ask you to pay a fee to receive money.** Never.

---

## Prompt 6.12

### Title: Write a Business Proposal or Plan That Banks, Grants and Investors Take Seriously

**Use this when:** You need a formal document — for a loan application, a grant, an investor, or a corporate partner — and you want it to read like a serious business, not a school essay.

**Copy this prompt:**

> Write a professional business plan/proposal for my [business type] in [location], Nigeria, for the purpose of [loan application / grant / investor / partnership]. Business facts: [what we do, when started, registration, owner background, team, customers, monthly revenue and profit for the past 6–12 months, key achievements, what makes us different, competitors]. The ask: ₦[amount] for [detailed use of funds], expected results [revenue, jobs, expansion], and repayment/return plan [if applicable]. Structure it with: executive summary, business description, market and customers, products/services, marketing and sales strategy, operations, management team, financial summary (past and 12-month projection table), use of funds, risks and how we'll manage them, and the ask/closing. Keep it clear, factual and confident — about 3–5 pages — with simple tables where helpful.

**Real example (filled in):**

> Write a professional business plan for my poultry farm in Ibadan for a ₦4M loan application to a development bank. Facts: started 2022, registered business name, I have a diploma in animal science and 3 staff; we run 2,000 layers producing about 55 crates daily, plus broilers at festive periods; customers are 12 shops, 3 restaurants and walk-in families; revenue averages ₦2.9M monthly with ₦520,000 profit over the past 8 months; we've never missed a supply day. The ask: ₦4M to add a 2,000-bird pen (₦2.2M), birds (₦1.4M) and feed buffer (₦400k); expected to double egg output within 6 months, adding 2 jobs; repayment over 24 months from increased profit. Structure it fully with a financial summary table and 12-month projection, use of funds, risks, and closing.

**Naija tip:** Reviewers at Nigerian banks and grant bodies read dozens of proposals — what stands out is **specific numbers, real track record, and a clear use of funds**. "₦2.2M for a 2,000-bird pen (quote attached)" beats "funds for expansion." Attach evidence: photos, supplier quotes, bank statements, customer letters. Have the AI's draft reviewed by someone who has actually received funding before you submit — and always tailor the executive summary to the specific programme's stated goals.

---

## Prompt 6.13

### Title: Create a 12-Month Financial Projection (Realistic, Not Fantasy)

**Use this when:** A funder asks for projections, or you want to see where your business could be in a year — based on believable assumptions.

**Copy this prompt:**

> Help me build a realistic 12-month financial projection for my [business type] in Nigeria. Starting point: monthly revenue ₦[amount], cost of sales [%], monthly fixed costs ₦[amount], current profit ₦[amount]. Planned changes and their timing: [e.g., new product in month 3, price increase of 8% in month 4, second staff in month 5, seasonal peaks in months 11–12, a loan repayment of ₦X monthly from month 2]. Assumptions I believe are reasonable: [growth rate, inflation on costs, seasonality]. Produce: (1) a month-by-month table with revenue, cost of sales, gross profit, fixed costs, net profit and cumulative cash, (2) a conservative, expected, and optimistic scenario, (3) the assumptions listed clearly so a funder can see them, (4) the months I should watch for cash pressure, and (5) the 3 assumptions that most affect the outcome — so I know what to track.

**Real example (filled in):**

> Build a realistic 12-month projection for my skincare production business in Lagos. Starting: monthly revenue ₦1.4M, cost of sales 42%, fixed costs ₦380,000, profit about ₦430,000. Planned: reseller programme launching month 2 (expected +₦150k/month growing to +₦500k by month 8), price increase of 8% in month 4, one extra production staff in month 5 (+₦60k), a ₦1.2M packaging-machine loan repaid at ₦120k/month from month 2, Christmas gift-set peak in months 11–12 (+40%). Assumptions: 4% monthly growth in core sales, 2% monthly inflation on materials. Produce the month-by-month table, three scenarios, listed assumptions, cash-pressure months, and the 3 assumptions that matter most.

**Naija tip:** Funders in Nigeria have seen a thousand "hockey stick" projections; **conservative and explained** builds far more trust than optimistic and vague. Always show the three scenarios — it proves you've thought about downside. And build inflation into costs; a projection that assumes flour, fuel and packaging stay flat for 12 months is not credible in Nigeria. Revisit the projection every quarter and note where reality differed — that record makes your *next* projection much stronger.

---

## Prompt 6.14

### Title: Decide Whether to Reinvest, Save or Pay Yourself More

**Use this when:** Profit is finally coming in, and you don't know how to split it between growing the business, protecting it, and enjoying it.

**Copy this prompt:**

> My [business type] in Nigeria now makes about ₦[profit] per month after paying me a salary of ₦[amount]. My emergency fund is at ₦[amount] (target ₦[amount]). Debts: ₦[amount]. Opportunities to reinvest: [list with estimated cost and expected return — more stock, equipment, staff, marketing, a second location]. Personal goals: [list — house rent, children's fees, a car, savings]. Help me create a profit-allocation rule: (1) a sensible percentage split between reinvestment, emergency/savings, debt repayment, tax set-aside, and owner's bonus at my current stage, (2) which reinvestment options give the best return for the risk, ranked, (3) when I should pay myself more versus keep reinvesting, (4) a simple rule I can apply automatically every month so I don't decide emotionally, and (5) how this split should change as the business grows.

**Real example (filled in):**

> My phone accessories and repair business in Onitsha now makes about ₦450,000 profit monthly after paying me ₦150,000 salary. Emergency fund ₦200,000 (target ₦600,000). Debt ₦0. Reinvestment options: more fast-moving stock (₦300k, could add ₦120k/month profit), a second technician (₦60k/month, could add ₦150k/month if demand holds), a small second kiosk near the polytechnic (₦900k setup, uncertain), social media ads (₦40k/month, unknown return). Personal goals: rent due in 5 months (₦700k), a used car. Help me create a profit-allocation rule with percentages, rank the reinvestments, tell me when to pay myself more, give me an automatic monthly rule, and show how it should change as I grow.

**Naija tip:** The **"profit first" habit** for Nigerian small businesses: the moment monthly profit is known, split it *immediately* by fixed percentages — e.g., 40% reinvest, 25% savings/emergency, 15% tax/levies pot, 20% owner's bonus — into separate accounts or envelopes. Deciding once and automating beats deciding every month under pressure from family, opportunities and temptation. Adjust the percentages quarterly, not weekly.

---

## Prompt 6.15

### Title: Evaluate a Second Branch, Bigger Shop or Major Expansion

**Use this when:** You're tempted to open another location, move to a bigger space, or triple your capacity — and you want a clear-headed assessment before committing.

**Copy this prompt:**

> I run a [business type] in [current location], Nigeria, and I'm considering [second branch in X / moving to a bigger shop / doubling production capacity]. Current business: revenue ₦[amount], profit ₦[amount], how long profitable, how dependent it is on me personally, staff quality. The expansion: estimated setup cost ₦[amount], monthly running cost ₦[amount], expected revenue ₦[amount] after [months], how I'd fund it, who would run it. Give me: (1) an honest readiness assessment — is my current business stable and systemised enough to survive my attention being split, (2) the financial case — payback period, break-even for the new unit, and what happens to my cash in the first 6 months, (3) the 5 biggest reasons expansions fail in Nigeria and how each applies to me, (4) a lower-risk way to test the expansion first, and (5) a go/no-go checklist with the conditions I must meet before committing.

**Real example (filled in):**

> I run a successful buka in Yaba, Lagos — revenue ₦2.6M, profit ₦480,000, profitable for 2 years, but very dependent on me (I cook the soups and manage cash), and my staff are okay but not leaders. I'm considering a second buka in Surulere: setup ₦2.8M (rent, kitchen, furniture), monthly running ₦900k, expected revenue ₦2M after 4 months, funded from ₦1.5M savings plus a ₦1.3M loan, run by my most senior staff. Give me an honest readiness assessment, the financial case with payback and break-even and first-6-months cash picture, the 5 biggest reasons expansions fail in Nigeria and how they apply to me, a lower-risk way to test first, and a go/no-go checklist.

**Naija tip:** The second branch is where many good Nigerian businesses die. The reason is almost never the market; it's that **the first branch was really the owner**, and the owner cannot be in two places. Before expanding: leave your current branch for two full weeks and see what happens. If revenue holds and nothing burns, you have a system. If it collapses — fix that first; it's cheaper than a second rent. Test with a **lower-risk version** — a delivery-only kitchen, a weekend stand, a partnership — before a full second shop.

---

## Prompt 6.16

### Title: Prepare for an Investor Conversation (Equity, Partners, Family Money)

**Use this when:** Someone — an investor, a wealthy relative, a friend, a business partner — is offering money for a share of your business, and you want to protect yourself and your business.

**Copy this prompt:**

> I run a [business type] in Nigeria, revenue ₦[amount], profit ₦[amount], [years] in business. Someone is offering ₦[amount] for [X% of the business / a profit share / a loan with conditions]. Details of the person and the offer: [describe]. Help me think clearly: (1) roughly what my business might be worth on simple, common-sense measures, and whether the offer is fair — explaining the reasoning, (2) the difference between equity, profit-share, and a loan, and which suits my situation, (3) the critical questions to ask them and the terms I must get in writing — decision rights, profit distribution, exit, what happens if things go wrong, family dynamics if applicable, (4) red flags in investor or partner deals common in Nigeria, (5) how to structure a smaller first step (a trial period or milestone-based investment), and (6) the point at which I must involve a lawyer. Be honest about what you can't judge without more information.

**Real example (filled in):**

> I run a fashion production business in Aba (ready-to-wear for boutiques), revenue ₦3.1M monthly, profit ₦620,000, 4 years in business. My uncle's friend, a businessman in Lagos, is offering ₦8M for 40% of the business — he says he'll bring "connections" but won't be involved daily. Help me think clearly: a rough common-sense sense of what my business might be worth and whether 40% for ₦8M is fair, equity vs. profit-share vs. loan for my situation, critical questions and terms to get in writing (decision rights, profit distribution, exit, disputes), red flags in such deals in Nigeria, how to structure a smaller trial step, and when I must involve a lawyer.

**Naija tip:** Never take investment money on a handshake — **especially from family or "family friends"**; those are the deals that end businesses and relationships together. Insist on a written agreement, get a lawyer (₦50,000–₦150,000 for a simple agreement is cheap insurance), and start with a **milestone-based or smaller first tranche**. And remember: 40% of your business forever, for money you could raise from profits in 13 months, is usually a bad trade. Money is the *least* valuable thing a good investor brings — ask what else they offer, and get that in writing too.

---

## Prompt 6.17

### Title: Protect Your Business Against Nigerian Risks (Inflation, Naira, Theft, Fire, Illness)

**Use this when:** You want to stop living one disaster away from closure — and build simple protections against the risks every Nigerian business faces.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Help me identify and protect against the risks most likely to hurt my business: inflation and rising costs, naira depreciation (especially if I buy imported goods), theft by staff or outsiders, fire or flood, my own illness or absence, a key staff member leaving, a key supplier failing, a major customer leaving, power failure spoiling stock, government demolition or relocation, and family or community disputes. For each risk: how likely and how damaging it is for my specific business, one or two practical, affordable protections (habits, systems, insurance, contracts, diversification, savings), and what to do in the first 24 hours if it happens. Then rank the top 5 risks I should address this month.

**Real example (filled in):**

> I run a frozen foods and drinks shop in Kano. Help me identify and protect against the risks most likely to hurt me — inflation, naira depreciation (some frozen fish and chicken prices track the dollar), staff theft, fire from the generator, power failure spoiling stock, my own illness, my only experienced staff leaving, my main fish supplier failing during Ramadan demand, a market relocation, and disputes. For each: likelihood and damage for my shop, one or two affordable protections, and what to do in the first 24 hours if it happens. Rank my top 5 risks to address this month.

**Naija tip:** Most Nigerian business protection is **cheap and boring**: a second supplier you buy 20% from (so they know you), a fire extinguisher by the generator, a full-freezer-and-bottles habit, a stock count that surprises, a written SOP so the shop runs when you're sick, and a **3-month emergency fund**. Look into simple **micro-insurance** for fire and stock — several Nigerian insurers offer affordable plans; verify terms carefully (*Check Before You Trust It*). Bonus 15 gives you a full Risk & Survival Decision Matrix.

---

## Prompt 6.18

### Title: Handle Inflation and Rising Costs Without Losing Customers

**Use this when:** Your costs rose 20–40% this year, your customers' incomes didn't, and you're squeezed between raising prices and losing sales.

**Copy this prompt:**

> I run a [business type] in Nigeria. Over the past [months], my main costs have risen: [list items and percentage increases]. My customers are [describe, including their income pressure]. My current margins are [describe]. Help me respond intelligently to inflation: (1) which costs I can offset through substitution, supplier changes, or efficiency, (2) how to adjust prices — full pass-through, partial, or phased — and what each does to my margin and likely sales, (3) "shrink or split" options — smaller sizes, portion options, tiered products — that protect access for poorer customers while keeping margins, (4) how to communicate increases honestly and keep loyalty, and (5) what to watch monthly so I'm not caught off guard again.

**Real example (filled in):**

> I run a small bakery in Enugu. Over the past 8 months: flour up 35%, sugar up 28%, butter and margarine up 40%, diesel up 25%, packaging up 20%. My customers are working families, students and small retailers who are also under pressure. Margin on family loaf has fallen from about 30% to 12%. Help me respond intelligently: costs I can offset through substitution or efficiency, how to adjust prices (full, partial, phased) and the effect on margin and sales, "shrink or split" options like smaller loaf sizes or a student loaf, how to communicate increases honestly, and what to watch monthly.

**Naija tip:** The most successful Nigerian responses to inflation share one idea: **give customers a choice instead of a shock.** Keep a smaller, cheaper option ("student loaf ₦600") beside the standard, so no one is priced out, while your standard product carries a proper margin. Review prices **monthly** now, not yearly — small regular adjustments are accepted; one big jump after months of silence causes anger. And tell the truth: "flour has gone up again" is a sentence every Nigerian understands.

---

## Prompt 6.19

### Title: Create Your Monthly Money Review Routine

**Use this when:** You want one simple monthly ritual that keeps your finances healthy — bringing together your P&L, cash flow, debtors, savings and decisions in under an hour.

**Copy this prompt:**

> Design a monthly money review routine for my [business type] in Nigeria that takes under 60 minutes and uses only my daily sales sheet, expense records, bank/POS statements, debtors' list and savings balances. Give me: (1) a step-by-step agenda with time for each step, (2) the 10 numbers I must produce each month (revenue, gross profit, net profit, key cost percentages, cash position, debtors, savings, break-even coverage, etc.) and a one-page template to record them, (3) the 5 questions to answer every month based on those numbers, (4) the decisions this review should trigger — price changes, cost cuts, collections, savings top-up, reinvestment, (5) how to compare to previous months and my 90-day target, and (6) a short prompt I can paste into AI each month with my numbers to get an instant analysis.

**Real example (filled in):**

> Design a monthly money review for my bakery and small-chops business in Port Harcourt that takes under 60 minutes, using my daily sales sheet, expense notebook, bank and POS statements, my debtors' list (3 event clients), and my savings-app balance. Give me a timed agenda, the 10 numbers to produce each month with a one-page template, the 5 questions to answer, the decisions it should trigger, comparison to previous months and my 90-day target of ₦2M extra revenue, and a short prompt I can paste into AI with my numbers each month for instant analysis.

**Naija tip:** Put it in your calendar: **first Sunday of every month, 4pm, phone on silent.** Do the operations review (4.20) and this money review together — ninety minutes that will change your business more than ninety hours of hustle. Keep every month's one-page template in one folder. In twelve months you will hold something almost no small business in your market has: a **year of clean, honest numbers** — and every bank, grant and investor will notice.

---

## Prompt 6.20

### Title: Build Your 90-Day Growth Plan (Bring It All Together)

**Use this when:** You've worked through this book and want a single, focused 90-day plan to reach the extra ₦1.5M–₦3M and the 35% cost cut — with weekly actions, not just intentions.

**Copy this prompt:**

> I run a [business type] in [area], Nigeria. Current monthly revenue ₦[amount], profit ₦[amount], monthly costs ₦[amount]. My 90-day targets: extra revenue of ₦[amount] total and a cost reduction of [X]%. Here's what I've learned and decided from my research and planning: ideal customer [summary]; best marketing channels [summary]; sales fixes [summary]; cost cuts identified [summary with naira]; new products/streams to launch [summary]; financial habits to install [summary]. Turn all this into a 90-day plan: (1) three 30-day phases, each with a theme and 3–5 measurable goals, (2) a week-by-week action list (13 weeks) with no more than 5 actions per week, (3) the numbers to track weekly and the targets for each week, (4) the likely obstacles in each phase and how to handle them, and (5) a one-paragraph statement of what my business looks like on day 90 if I execute this.

**Real example (filled in):**

> I run a unisex salon in Ikeja, Lagos. Current revenue ₦850,000, profit ₦280,000, costs ₦570,000. 90-day targets: ₦1.8M extra revenue total and a 35% cost cut. What I've decided: ideal customer is a working woman 25–40 who values speed and style longevity; best channels are WhatsApp Status, referrals and Instagram Reels; sales fixes are a proper enquiry script, upsells on every service, and a deposit policy; cost cuts are generator scheduling (₦35k), supplier negotiation (₦20k), waste and product control (₦15k), fixed WhatsApp hours to free my time; new streams are a retail product line, Monday-morning slots, a braiding class and home-service barbing; financial habits are a separate account, owner's salary, daily cash sheet, monthly P&L. Turn this into a 90-day plan with three phases, a 13-week action list, weekly numbers and targets, obstacles per phase, and a day-90 statement.

**Naija tip:** Print the 13-week plan and paste it where you'll see it every morning. Tick the actions. Track the numbers in the 90-Day Revenue Growth Tracker (Bonus 1). Some weeks you'll miss — NEPA, family, a sick child; that's Nigeria, that's life. Don't restart; just do the next week. The owners who reach ₦1.5M–₦3M extra are not the ones who executed perfectly — they are the ones who **kept going for all thirteen weeks.** You've already done the hard part: you now understand your business better than 95% of your competitors. Go and prove it.

---

## Part 6 Checkpoint

Before moving to the Bonus Section, make sure these five are **done**:

1. You know the **true cost and real profit** of your top 5 products. *(6.1)*
2. Your **daily break-even number** is calculated and on the wall. *(6.3)*
3. Business and personal money are **separated**, and you pay yourself a fixed salary. *(6.5)*
4. A **monthly P&L and money review** is scheduled for the first Sunday of every month. *(6.6, 6.19)*
5. Your **90-day growth plan** is printed and week 1 has started. *(6.20)*

---

## You've Completed the 120 Prompts

Six Parts. One hundred and twenty prompts. If you have worked through them honestly, your business is now different from the one you started with:

- You **know your customer** — by name, need, and fear.
- You **market for almost nothing** — consistently, from your phone.
- You **close more sales at better prices** — with scripts, proof, and a floor.
- You **run on systems** — SOPs, automation, controlled costs.
- You **earn from more than one direction** — bundles, tiers, classes, subscriptions, resellers.
- You **keep your money** — true costs, break-even, separate accounts, monthly reviews, a plan.

Everything that follows in the Bonus Section is a ready-to-use tool that makes this faster: trackers, calculators, message banks, templates, and decision frameworks — all built for Nigerian businesses like yours.

**Next: The Bonus Section — 15 Ready-to-Use Tools (Bonus 1 – 15)**
