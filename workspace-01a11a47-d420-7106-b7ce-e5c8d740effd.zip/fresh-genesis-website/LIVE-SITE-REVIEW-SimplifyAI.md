# Live Site Review — freshgenesiscopresents.netlify.app ("SimplifyAI")
*Reviewed: home, /sales, /faq. Scored as a paying customer and as a conversion specialist.*

**Overall: 6/10 as a document, 3/10 as a sales site.** It is clean, honest and well-organised — and it will not sell much in its current state. The problems are not design; they are **broken buttons, exposed developer notes, a product with no clear person in mind, and a price ladder that pushes people to the cheapest option.**

---

## PART A — BLOCKERS (fix before sending one more visitor)

| # | Issue | Where | Why it matters |
|---|---|---|---|
| 1 | **Every "free" button is dead** — "Get Quick Start free", "Send me Quick Start", "Get by email" all link to `#` | Home ×3 | Your lead magnet — the top of your funnel — does nothing. Visitors click, nothing happens, they leave and don't come back. |
| 2 | **Paid buttons have no visible destination** — "Choose Foundations Pack", "Get the complete system", "Buy Foundations" etc. appear as plain text/buttons with no link in the page content | Home ×8, Sales ×2 | If these also go nowhere (or to a modal that isn't wired), you have a store with no checkout. Verify each one on a phone. |
| 3 | **Developer notes are visible to customers:** "Before launch, connect your Selar free-product URL in `assets/config.js`." | Home, free-guide section | Screams "unfinished". Kills trust instantly. |
| 4 | Same again in FAQ: "The Selar URL must be connected before launch." and "Product-specific checkout and delivery automation should be configured before the public launch." | Home FAQ + /faq ×2 | You are telling buyers the delivery system isn't set up. |
| 5 | **"Powered by Netlify — Build your own site" badge** on every page | Footer, all pages | Free-tier advert on a sales page. Remove in Netlify: Site settings → Site details → Netlify badge, or delete the injected snippet. |
| 6 | **No visible payment method or trust signal** — no Paystack/Flutterwave logos, no "secure checkout", no business name/CAC, no face | All pages | Nigerian buyers paying a stranger online need to see *how* they pay and *who* they pay. |
| 7 | **"Delivery-help page" is referenced but not linked**; "Refund Policy" is referenced but not linked | Sales FAQ, /faq | Referencing pages that don't exist reads as another unfinished corner. |

---

## PART B — POSITIONING PROBLEMS (why it won't convert even when the buttons work)

### 1. It is a product for "beginners" — which is nobody in particular
"Use AI confidently. Build useful workflows. Plan a calmer week." Ask: *who* wakes up wanting this? A beginner at what, for what? Your Book 1 works because it speaks to a salon owner in Ikeja who is losing money to "last price". SimplifyAI speaks to an abstract person who "feels overwhelmed by technical language." Abstract people don't buy.

**Fix:** pick the primary buyer and say it in the hero. Options that fit what you already have:
- *"For Nigerian professionals and business owners who want to use AI at work — without the jargon."*
- Or split: SimplifyAI = the **general foundation**; the *AI Made Simple* books = the **job-specific application**. Then the site's story is: *Learn the basics once (SimplifyAI) → apply it to your work (choose your book).*

### 2. The hero says "workflows" seven times and "money" zero times
"Workflows", "human-review checkpoints", "CLEAR method", "reusable workflows", "realistic capacity and buffer" — this is the vocabulary of a corporate training deck. Nigerian buyers respond to **outcomes**: save time, make money, stop wasting data, sound professional, pass the exam, close the sale. Not one outcome in the hero is concrete.

**Fix:** rewrite the H1 around a result: *"Learn to use AI properly in 7 days — then use it to write, plan, sell and decide faster."*

### 3. Page counts are doing the job that benefits should do
"10 pages", "12 pages", "11 pages", "21 pages" — you are quantifying thinness. A 11-page product at ₦4,000 makes the reader do the maths (₦364 a page). Your new book is 131 pages for ₦5,000 — which makes the SimplifyAI single products look expensive by comparison on your own site.

**Fix:** remove page counts from cards (keep them in FAQ if you like). Replace with what each one *does*: "Write a prompt that actually works — first try" / "Plan your week in 15 minutes."

### 4. The price ladder pushes people to the cheapest option
Free (₦0) → Foundations Pack (₦7,500) → Complete (₦15,000), *plus* seven singles from ₦3,000. Ten options. Decision fatigue → the visitor takes the free one or nothing. And the "Best value" tag sits on the option most people scroll past.

**Fix:** three choices, max, above the fold: **Free Quick Start → Complete System ₦15,000 (anchor, "most popular") → single products further down for the curious.** Kill the middle "Foundations Pack" or make it the default with the Complete System as the upsell — not both.

### 5. "₦15,000 / $25" — the dollar price is under-priced and the naira price is over-priced
At today's rates ₦15,000 ≈ $10. Charging Nigerians ₦15,000 and foreigners $25 is defensible (purchasing power) — but showing them side by side invites Nigerians to feel overcharged and foreigners to switch to the naira link. Your Book 1 uses $7 ≈ ₦5,000 (roughly honest).

**Fix:** show **one currency at a time** based on the button the visitor picks (as the workspace site's payment modal does), or align them: ₦15,000 / $15.

### 6. No proof of any kind
No testimonials, no screenshots of the product pages, no sample page, no numbers of buyers, no author. "Human-review checkpoints" is repeated as though it were a feature — it is a caveat.

**Fix:** add 3 real testimonials (get them from your first buyers with a WhatsApp voice-note ask), 4 actual page previews (the "Inside the PDFs" section currently shows covers, not pages), and a short "Who made this" block with your first name and one line of credibility.

### 7. The free lead magnet has no follow-up story
"Delivered through Selar email signup" — then what? There is no mention of what happens after the 7 days, no nudge toward the paid system, no WhatsApp option (Nigerians check WhatsApp; many never check email).

**Fix:** deliver the free guide via **WhatsApp** ("Send 'START' to +234…") as well as Selar email; put a one-line bridge on the free page: "On day 7 you'll unlock a ₦2,000 discount on the Complete System."

### 8. It hides the best thing Fresh Genesis owns
The new book — *AI Made Simple for Nigerian Small-Business Owners* — is your most specific, most sellable, most Nigerian product and it is absent. It also gives the whole site a purpose: **SimplifyAI teaches the skill, the books apply it.**

---

## PART C — COPY, TONE AND SMALL THINGS

| Line on site | Problem | Suggested rewrite |
|---|---|---|
| "Fresh Genesis Co presents SimplifyAI" | "presents" is a film-poster phrase; adds nothing | "SimplifyAI by Fresh Genesis" |
| "Seven connected resources · 104 customer-ready pages · Human-review checkpoints · Digital delivery after confirmation" | "customer-ready" is internal language; "after confirmation" sounds slow | "7 PDFs · 104 pages · 96 prompts · Instant download" |
| "Choose your starting point / Three clear ways to begin" | Two headings saying the same thing | Keep one |
| "Build a system you can reuse—not a folder you forget" | Good line — best on the site | Move it to the hero |
| "Personal-use licence" as a bullet in the price box | A restriction listed as a benefit | Move to FAQ |
| "Does the system guarantee accurate AI answers? No." | Correct, but four "No" answers in a row in the FAQ make the product feel hedged | Lead FAQ with positive answers; keep the honest ones lower |
| "reputable chat-based AI tool" (×3) | Vague and cold | "Meta AI in WhatsApp, ChatGPT, Gemini or DeepSeek — all free" |
| "Complete Starter System — Vol. 1" | "Vol. 1" promises a Vol. 2 that doesn't exist | Drop "Vol. 1" until Vol. 2 is real |
| Email: `Freshgenesisco@gmail.com` | Capital F looks like a typo; Gmail on a brand site is fine for now, but lower-case it | `freshgenesisco@gmail.com` |
| Site title: "Fresh Genesis Co SimplifyAI | Beginner-Friendly AI Workflows and Planning Tools" | No searcher types "AI workflows and planning tools" | "SimplifyAI — Learn to Use AI in Plain English (Nigeria) | Fresh Genesis" |

**Consistency:** the site says "Fresh Genesis Co"; the book and the workspace site say "Fresh Genesis". Pick one everywhere (recommendation: **Fresh Genesis** — shorter, and it's what the Paystack page shows).

---

## PART D — STRUCTURE I'D RECOMMEND (one site, two product lines)

```
HOME
├─ Hero: one buyer, one outcome, two buttons (Start free · See the books)
├─ "Choose your path" — 3 cards:
│    • I want to learn AI properly → SimplifyAI Complete (₦15,000)
│    • I run a small business → AI Made Simple: Small-Business Owners (₦5,000 launch)   ← NEW
│    • I want a free start → Quick Start (WhatsApp or email)
├─ Proof: 3 testimonials + 4 real page previews
├─ How it works (Understand → Apply → Build a rhythm) — keep, tighten
├─ Individual library (collapsed/secondary)
├─ FAQ (positive first)
└─ Footer: payment logos, WhatsApp, email, policies, no Netlify badge

/sales            → SimplifyAI Complete (existing, tightened)
/business-book    → AI Made Simple for Nigerian Small-Business Owners (new; copy in book/LISTING-AND-LAUNCH-KIT.md)
/faq /refunds /delivery-help  → real pages, linked
```

---

## PART E — PRIORITY ORDER

**Today (30 minutes):** remove the three developer notes · remove the Netlify badge · wire every free button to WhatsApp (`wa.me/2349021906332?text=START`) until Selar is connected · verify every paid button opens a real payment link on a phone.

**This week:** add the new book as a product · rewrite hero + card copy around outcomes · cut page counts · reduce to 3 choices above the fold · add payment logos and a "who made this" block · create /refunds and /delivery-help · unify brand name.

**Within 30 days:** collect 5 testimonials and add them · add 4 real page previews · set up Selar auto-delivery for all products · decide the naira/dollar display rule.

---

*When you upload the source files, I can apply all of Part A and most of Part B/C directly and hand back a deploy-ready folder.*
