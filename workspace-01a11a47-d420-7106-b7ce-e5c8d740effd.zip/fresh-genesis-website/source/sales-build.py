#!/usr/bin/env python3
"""Build script: embeds the SVG covers from ../covers/ into
sales-template.html (this folder) and writes the final self-contained
page to ../sales.html.
Run after editing sales-template.html:  python3 source/sales-build.py
"""
import base64
from pathlib import Path

root = Path(__file__).parent.parent          # project root
tpl = (root / 'source' / 'sales-template.html').read_text()

for token, name in [('__COVER_1__', 'clarity.svg'),
                    ('__COVER_2__', 'ai.svg'),
                    ('__COVER_3__', 'bundle.svg')]:
    p = root / 'covers' / name
    data = base64.b64encode(p.read_bytes()).decode()
    tpl = tpl.replace(token, 'data:image/svg+xml;base64,' + data)

if '__COVER_' in tpl:
    raise SystemExit("Unresolved cover tokens remain in sales-template.html")

(root / 'sales.html').write_text(tpl)
print(f"OK — sales.html built ({ (root/'sales.html').stat().st_size:,} bytes)")
