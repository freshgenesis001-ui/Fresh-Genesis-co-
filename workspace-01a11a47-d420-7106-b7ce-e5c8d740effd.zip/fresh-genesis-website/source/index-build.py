#!/usr/bin/env python3
"""Build script: embeds the SVG covers from ../covers/ into
index-template.html (this folder) and writes the final self-contained
page to ../index.html.
Run after editing index-template.html:  python3 source/index-build.py
"""
import base64
from pathlib import Path

root = Path(__file__).parent.parent          # project root
tpl = (root / 'source' / 'index-template.html').read_text()

for token, name in [('__COVER_1__', 'clarity.svg'),
                    ('__COVER_2__', 'ai.svg'),
                    ('__COVER_3__', 'bundle.svg'),
                    ('__COVER_4__', 'ai-made-simple.jpg')]:
    p = root / 'covers' / name
    data = base64.b64encode(p.read_bytes()).decode()
    mime = 'image/jpeg' if name.endswith('.jpg') else 'image/svg+xml'
    tpl = tpl.replace(token, f'data:{mime};base64,' + data)

if '__COVER_' in tpl:
    raise SystemExit("Unresolved cover tokens remain in index-template.html")

(root / 'index.html').write_text(tpl)
print(f"OK — index.html built ({ (root/'index.html').stat().st_size:,} bytes)")
