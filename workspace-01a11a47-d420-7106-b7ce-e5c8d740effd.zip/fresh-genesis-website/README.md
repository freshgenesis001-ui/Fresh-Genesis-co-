# Fresh Genesis — Digital Products Website

Beginner-friendly digital products (templates, ebooks, tutorials).
Home page + detailed sales page, fully self-contained (no external
images or fonts) and publishable anywhere.

## Files

| File | What it is |
|---|---|
| `index.html` | ✅ Home page — publish this |
| `sales.html` | ✅ Detailed sales page (Fresh Start Bundle) — publish this too |
| `PDFs/` | Shareable PDF versions of both pages (for WhatsApp/email) |
| `covers/` | The 3 product cover images (SVG) |
| `source/` | Editable templates + build scripts (see below) |

## Payment setup (already wired in ✅)

Every Buy button opens a payment choice:
- **Paystack (₦)** → `https://paystack.shop/pay/7eipl558t6`
- **Flutterwave (USD)** → `https://flutterwave.com/pay/nahf6maetqjs`
- **WhatsApp order** → +234 902 190 6332 (pre-filled message)
- **Bizflex** → `https://www.bizflex.com.ng/store/blessing-ukwuoma`

To change them, edit the `PAY = { ... }` block at the bottom of the
`<script>` in `source/index-template.html` and
`source/sales-template.html`.

## Editing & rebuilding

1. Edit `source/index-template.html` and/or `source/sales-template.html`
2. Rebuild: `python3 source/index-build.py` and `python3 source/sales-build.py`
3. The final `index.html` / `sales.html` are regenerated

## Publishing (free)

- **Netlify Drop** — drag the folder (or just the two HTML files) onto
  [app.netlify.com/drop](https://app.netlify.com/drop) → instant URL
- **Cloudflare Pages** — Direct Upload of the same files
- **GitHub Pages** — push to a repo, enable Pages

## Prices

| Product | Price | Compare-at |
|---|---|---|
| Clarity Life Template Pack | $19 (≈ ₦28,500) | $29 |
| AI Prompt Workbook | $24 (≈ ₦36,000) | $34 |
| Fresh Start Bundle | $39 (≈ ₦58,500) | $53 |

Naira equivalents shown in the payment modal; the prices themselves live
in each buy button's `data-price` / `data-ngn` attributes.
